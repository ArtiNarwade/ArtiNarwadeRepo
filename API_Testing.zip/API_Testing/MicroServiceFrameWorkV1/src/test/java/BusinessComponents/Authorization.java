package BusinessComponents;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.ArrayList;
import java.util.Base64;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.security.Keys;
import java.util.Date;
import java.util.Hashtable;
import java.util.List;
import java.time.Instant;
import java.time.temporal.ChronoUnit;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

import org.joda.time.DateTime;

import com.EndPoints.EndPoints;
import com.relevantcodes.extentreports.LogStatus;

import baseTestPackage.BaseTest_TestNG;
import baseTestPackage.SuiteConstant;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import reusableLibrary.JsonUtils;
import reusableLibrary.ResuableComponents;

public class Authorization extends BaseTest_TestNG {
	List<String> list = new ArrayList<String>();
	
	SuiteConstant suiteMap = new SuiteConstant();
	ResuableComponents resuableComponents = new ResuableComponents();
	static String accessTokenCLC=null;
	static String accessTokenCMS=null;
	public String GetAccessToken(String controller) throws Exception
	{  if(controller.equals("clc"))
		{
		if(accessTokenCLC==null)
		
		{
			Response resp = resuableComponents.getAuthToken(globalProp.getProperty("clcClientId"),globalProp.getProperty("clcClientSecret"),globalProp,test);
			accessTokenCLC= JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.access_token");
		}
		
		
		return accessTokenCLC;
	}
	else
	{
		if(accessTokenCMS==null)
			
		{
			Response resp = resuableComponents.getAuthToken(globalProp.getProperty("cmsClientID"),globalProp.getProperty("cmsClientSecret"),globalProp,test);
			accessTokenCMS= JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.access_token");
		}
		
		
		return accessTokenCMS;
	}
	}		 
	
	public String GenerateAVIAccesstoken(String videRefId) throws Exception
	{  
			String secret= globalProp.getProperty("aviAuthorizationKey");
			byte[] hash = secret.getBytes(StandardCharsets.UTF_8);
			Mac sha256Hmac = Mac.getInstance("HmacSHA256");
			SecretKeySpec secretKey = new SecretKeySpec(hash, "HmacSHA256");
	        sha256Hmac.init(secretKey);
	        byte[] signedBytes = sha256Hmac.doFinal(videRefId.getBytes(StandardCharsets.UTF_8));
	        return new String(signedBytes, StandardCharsets.UTF_8);
	}
	
	    public String generateToken(String videoRefId) {
	    	Key hmacKey = new SecretKeySpec(Base64.getDecoder().decode(globalProp.getProperty("aviAuthorizationKey")), 
                    SignatureAlgorithm.HS256.getJcaName());
	    	
	        String token = Jwts.builder().setHeaderParam("type","JWT")
	                .claim("videoRefId", videoRefId)
	                .setIssuedAt(new Date())
	                .signWith(SignatureAlgorithm.HS256,globalProp.getProperty("aviAuthorizationKey"))
	                .compact();
	        return token;
	    }
	}		 

