package BusinessComponents;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

import com.EndPoints.EndPoints;
import com.relevantcodes.extentreports.LogStatus;

import baseTestPackage.BaseTest_TestNG;
import baseTestPackage.SuiteConstant;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import reusableLibrary.JsonUtils;
import reusableLibrary.ResuableComponents;

public class CLCCMSADInitiation extends BaseTest_TestNG {
	List<String> list = new ArrayList<String>();
	
	SuiteConstant suiteMap = new SuiteConstant();
	ResuableComponents resuableComponents = new ResuableComponents();

	public Response POSTVideotoAVIResponse( String reqBody, Hashtable<String, String> headers) throws Exception {
		Response resp = resuableComponents.executePostAPI(globalProp.getProperty("cmsapi")+"/"+EndPoints.endPointList.get("InitiateAdPublishtoAVI"), reqBody, globalProp, test,headers);;
		test.log(LogStatus.INFO, "<b>DataStore: </b>" + SuiteConstant.dataStore);
		return resp;
	}
	
	public Response PostFileUpload(String filePath,String fileType,Hashtable<String, String> headers,Hashtable<String, String> formParams)
	{
		Response resp = resuableComponents.executePOSTMultiform(globalProp.getProperty("cmsapi")+"/"+EndPoints.endPointList.get("UploadFile"),filePath,fileType, globalProp, headers,formParams, test);
		return resp;
	}
	
	public Response PostUploadS3( String reqBody, Hashtable<String, String> headers) throws Exception {
		Response resp = resuableComponents.executePostAPI(globalProp.getProperty("cmsapi")+"/"+EndPoints.endPointList.get("UploadS3"), reqBody, globalProp, test, headers);;
		test.log(LogStatus.INFO, "<b>DataStore: </b>" + SuiteConstant.dataStore);
		return resp;
	}
	
	public Response GetStatus(Hashtable<String, String> headers, String assetId) throws Exception {
		String endPoint=  EndPoints.endPointList.get("GetStatus").replace("{assetid}", assetId);
		Response resp = resuableComponents.executeGetAPI(globalProp.getProperty("cmsapi")+"/"+endPoint, globalProp, test,headers);
		test.log(LogStatus.INFO, "<b>DataStore: </b>" + SuiteConstant.dataStore);
		return resp;
	}
	
	public Response PostUploadGcp( String reqBody, Hashtable<String, String> headers) throws Exception {
		Response resp = resuableComponents.executePostAPI(globalProp.getProperty("cmsapi")+"/"+EndPoints.endPointList.get("UploadGcp"), reqBody, globalProp, test, headers);;
		test.log(LogStatus.INFO, "<b>DataStore: </b>" + SuiteConstant.dataStore);
		return resp;
	}
	
		 
}
