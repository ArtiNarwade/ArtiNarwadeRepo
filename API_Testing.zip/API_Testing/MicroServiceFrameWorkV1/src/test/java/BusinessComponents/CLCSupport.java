package BusinessComponents;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

import com.EndPoints.EndPoints;
import com.relevantcodes.extentreports.LogStatus;

import baseTestPackage.BaseTest_TestNG;
import baseTestPackage.SuiteConstant;
import io.restassured.response.Response;
import reusableLibrary.ResuableComponents;

public class CLCSupport extends BaseTest_TestNG {
	List<String> list = new ArrayList<String>();
	
	SuiteConstant suiteMap = new SuiteConstant();
	ResuableComponents resuableComponents = new ResuableComponents();


	public Response ResetWorkflowStatus( String reqBody, Hashtable<String, String> headers) throws Exception {
		String endPoint=  EndPoints.endPointList.get("ResetWorkflowStatus");
		Response resp = resuableComponents.executePostAPI(globalProp.getProperty("clcapi")+"/"+endPoint, reqBody, globalProp, test, headers);;
		test.log(LogStatus.INFO, "<b>DataStore: </b>" + SuiteConstant.dataStore);
		return resp;
	}
		 
}
