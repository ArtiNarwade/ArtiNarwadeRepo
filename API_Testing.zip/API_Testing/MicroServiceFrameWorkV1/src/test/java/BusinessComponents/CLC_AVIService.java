package BusinessComponents;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

import com.EndPoints.EndPoints;
import com.relevantcodes.extentreports.LogStatus;

import baseTestPackage.BaseTest_TestNG;
import baseTestPackage.SuiteConstant;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import reusableLibrary.JsonUtils;
import reusableLibrary.ResuableComponents;

public class CLC_AVIService extends BaseTest_TestNG {
	List<String> list = new ArrayList<String>();
	
	SuiteConstant suiteMap = new SuiteConstant();
	ResuableComponents resuableComponents = new ResuableComponents();

	public Response AVICallback( String videoRefId,String messageId,String state,String token, Hashtable<String, String> headers) throws Exception 
	{
		String resourcePath = EndPoints.endPointList.get("AVICallBack");
		resourcePath = resourcePath.replace("$(videoRefId)",videoRefId);
		resourcePath= resourcePath.replace("$(id)",messageId);
		resourcePath= resourcePath.replace("$(state)",state);
		resourcePath = resourcePath.replace("$(callBackToken)", token);
		Response resp = resuableComponents.executePostAPI(globalProp.getProperty("aviURL")+"/"+resourcePath,"",globalProp, test,headers);;
		test.log(LogStatus.INFO, "<b>DataStore: </b>" + SuiteConstant.dataStore);
		return resp;
	} 
}