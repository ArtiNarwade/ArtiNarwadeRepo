package BusinessComponents;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

import com.EndPoints.EndPoints;
import com.relevantcodes.extentreports.LogStatus;

import baseTestPackage.BaseTest_TestNG;
import baseTestPackage.SuiteConstant;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import reusableLibrary.JsonUtils;
import reusableLibrary.ResuableComponents;

public class Search_AzureCognitive extends BaseTest_TestNG {
	List<String> list = new ArrayList<String>();
	
	SuiteConstant suiteMap = new SuiteConstant();
	ResuableComponents resuableComponents = new ResuableComponents();

	public Response GetSearchResponse( String reqBody,Hashtable<String, String> headers) throws Exception {
		Response resp = resuableComponents.executePostAPI(globalProp.getProperty("searchURI")+"/"+EndPoints.endPointList.get("SearchTerm"), reqBody, globalProp, test,headers);;
		test.log(LogStatus.INFO, "<b>DataStore: </b>" + SuiteConstant.dataStore);
		return resp;
	}
		 
}
