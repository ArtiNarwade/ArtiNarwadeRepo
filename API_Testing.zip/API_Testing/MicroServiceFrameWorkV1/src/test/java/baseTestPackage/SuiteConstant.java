package baseTestPackage;

import java.util.HashMap;

public class SuiteConstant {
	public static HashMap<String, String> dataStore = new HashMap<String, String>();
	public static HashMap<String, String> dataStoreIterative = new HashMap<String, String>();
}
