package com.EndPoints;

import java.util.HashMap;
import java.util.Map;

public class EndPoints {

	public static Map<String, String> endPointList = new HashMap<String, String>() {{
	    put("ALLUSER", "/api/users?page=2");
	    put("CREATEUSER", "/api/users");
	    put("GETSINGLEUSER", "/api/users/$(id)");
	    put("REGISTERUSER", "/api/register");
	    put("LISTUSER", "/api/unknown");
	    put("UPDATEUSER", "/api/users/$(id)");
	    put("SearchTerm","indexes/title-index/docs/search?api-version=2016-09-01");
	    put("GetAdsStack","getadstack?assetId={assetId}");
	    put("GetAds","getads?adTypesFilter=ProductAds&mkt=en-in");
	    put("InitiateAdPublishtoAVI","cms/initiateadpubprocess");
	    put("GetAdsStackFromCLC","clc/adstack?assetId={assetId}");
	    put("GetAdsFromCLC","clc/getads?adTypesFilter=ProductAds&mkt=en-in");
	    put("UploadFile","cms/upload");
	    put("UploadS3","cms/upload-S3");
	    put("UploadGcp","cms/upload-gcp");
	    put("GetStatus","cms/getStatus/{assetid}");
	    put("AVICallBack","avi/updateStatus?videoRefId=$(videoRefId)&id=$(id)&state=$(state)&callBackToken=$(callBackToken)");
	    put("ResetWorkflowStatus","clc-support/resetworkflowstatus");
	    
	}};
}
