package com.OTTPlatform.ModuleName;

import java.util.Hashtable;

import org.testng.Assert;
import org.testng.annotations.Test;

import BusinessComponents.AdsDummyAPIs;
import BusinessComponents.Authorization;
import BusinessComponents.CLCGetAds;
import baseTestPackage.BaseTest_TestNG;
import io.restassured.response.Response;
import reusableLibrary.DBUtils;
import reusableLibrary.JsonUtils;
import reusableLibrary.ResuableComponents;

public class CLCAds_APITests extends BaseTest_TestNG{
	
	CLCGetAds ads = new CLCGetAds();
	Authorization cAuth= new Authorization();
	ResuableComponents resuableComponents= new ResuableComponents();

	@Test
	public void getAdStackCorrectAssetId() throws Exception {
		
		String accessToken= cAuth.GetAccessToken("clc");
		test = report.startTest(new Object(){}.getClass().getEnclosingMethod().getName());
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("Authorization", "Bearer " +accessToken);
		String assetId = globalProp.getProperty("getAdStackAssetId");
		Response resp = ads.GetAdStack(assetId,headers);
		resuableComponents.assertEqualValue("HTTP Status Code",Integer.toString(resp.getStatusCode()), Integer.toString(200),test);
		String status= JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.status");
		String code= JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.code");
		String message= JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.message");
		resuableComponents.assertEqualValue("Status",status,"Success",test);
		resuableComponents.assertEqualValue("Code",code,"5003",test);
		resuableComponents.assertEqualValue("Message",message,"Ad stack retrieved successfully for the video " + assetId,test);
		String timeStamps= JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.clcVideo.timestamps");
		String cosmosentry= DBUtils.getvaluefromDBusingProperty("avitimestamps","videoInfo.assetId",assetId);
		String timestampsFromDB = JsonUtils.getValueFromJSONusingJSONPath(cosmosentry, "$.cursor.firstBatch[0].timestamps");
		String formattedTimeStamp= formatTimeStampsFromDB(timestampsFromDB);
		resuableComponents.assertEqualValue("Timestamp",formattedTimeStamp, timeStamps,test);
	}
	
	@Test
	public void getAdStackCorrectIncorrectAssetId() throws Exception 
	{
		String accessToken= cAuth.GetAccessToken("clc");
		test = report.startTest(new Object(){}.getClass().getEnclosingMethod().getName());
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("Authorization", "Bearer " +accessToken);
		String assetId = "9-9-999999";
		Response resp = ads.GetAdStack(assetId,headers);
		resuableComponents.assertEqualValue("HTTP Status Code",Integer.toString(resp.getStatusCode()), Integer.toString(404),test);
		String status= JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.status");
		String code= JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.code");
		String message= JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.message");
		resuableComponents.assertEqualValue("Status",status,"Failed",test);
		resuableComponents.assertEqualValue("Code",code,"5004",test);
		resuableComponents.assertEqualValue("Message",message,"Ad stack not found for the video " + assetId,test);
	}
	
	
	@Test
	public void getAdStackError() throws Exception {
		String accessToken= cAuth.GetAccessToken("clc");
		test = report.startTest(new Object(){}.getClass().getEnclosingMethod().getName());
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("Authorization", "Bearer " +accessToken);
		String assetId = "0-0-000";
		Response resp = ads.GetAdStack(assetId,headers);
		System.out.println(Integer.toString(resp.getStatusCode()));
		resuableComponents.assertEqualValue("HTTP Status Code",Integer.toString(resp.getStatusCode()), Integer.toString(404),test);
		String status= JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.status");
		String code= JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.code");
		String message= JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.message");
		resuableComponents.assertEqualValue("Status",status,"Failed",test);
		resuableComponents.assertEqualValue("Code",code,"5004",test);
		resuableComponents.assertEqualValue("Message",message,"Ad stack not found for the video " + assetId,test);
	}
	
	@Test
	public void getAdStackWithoutAuthorization() throws Exception {
		
		test = report.startTest(new Object(){}.getClass().getEnclosingMethod().getName());
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = ads.GetAdStack("0-0-102514",headers);
		resuableComponents.assertEqualValue("HTTP Status Code",Integer.toString(resp.getStatusCode()), Integer.toString(401),test);
		String status= JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.status");
		String code= JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.code");
		String message= JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.message");
		resuableComponents.assertEqualValue("Status",status,"Failed",test);
		resuableComponents.assertEqualValue("Code",code,"1001",test);
		resuableComponents.assertEqualValue("Message",message,"Authentication Failed.",test);
	}
	
	@Test
	public void getAdsCorrectAssetID() throws Exception {
		String accessToken= cAuth.GetAccessToken("clc");
		test = report.startTest(new Object(){}.getClass().getEnclosingMethod().getName());
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("Authorization", "Bearer " +accessToken);
		headers.put("videoRefId", "138639948819370403156945965314003784895");
		headers.put("timestamp", "114");
		Response resp = ads.GetAds(headers);
		resuableComponents.assertEqualValue("HTTP Status Code",Integer.toString(resp.getStatusCode()), Integer.toString(200),test);
		String status = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.status");
		String code = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.code");
		String message = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.message");
		resuableComponents.assertEqualValue("Status","Success",status,test);
		resuableComponents.assertEqualValue("Code","5000",code,test);
		resuableComponents.assertEqualValue("Message","Ads generated successfully for the video 138639948819370403156945965314003784895 and timestamp 114",message,test);
		
	}
	
	
	@Test
	public void getAdsWithoutAssetID() throws Exception {
		String accessToken= cAuth.GetAccessToken("clc");
		test = report.startTest(new Object(){}.getClass().getEnclosingMethod().getName());
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("Authorization", "Bearer " +accessToken);
		headers.put("timestamp", "114");
		Response resp = ads.GetAds(headers);
		resuableComponents.assertEqualValue("HTTP Status Code",Integer.toString(resp.getStatusCode()), Integer.toString(400),test);
		String status = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.status");
		String code = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.code");
		String message = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.message");
		resuableComponents.assertEqualValue("Status","Failed",status,test);
		resuableComponents.assertEqualValue("Code","5002",code,test);
		resuableComponents.assertEqualValue("Message","Input validation failed for VideoRefId id / Timestamp",message,test);
		
	}
	@Test
	public void getAdsWithoutTimeStamp() throws Exception {
		String accessToken= cAuth.GetAccessToken("clc");
		test = report.startTest(new Object(){}.getClass().getEnclosingMethod().getName());
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("Authorization", "Bearer " +accessToken);
		headers.put("videoRefId", "138639948819370403156945965314003784895");
		Response resp = ads.GetAds(headers);
		resuableComponents.assertEqualValue("HTTP Status Code",Integer.toString(resp.getStatusCode()), Integer.toString(400),test);
		String status = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.status");
		String code = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.code");
		String message = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.message");
		resuableComponents.assertEqualValue("Status","Failed",status,test);
		resuableComponents.assertEqualValue("Code","5002",code,test);
		resuableComponents.assertEqualValue("Message","Input validation failed for VideoRefId id / Timestamp",message,test);
		
	}
	
	@Test
	public void getAdsWithoutTimeStampAndAssetID() throws Exception {
		String accessToken= cAuth.GetAccessToken("clc");
		test = report.startTest(new Object(){}.getClass().getEnclosingMethod().getName());
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("Authorization", "Bearer " +accessToken);
		Response resp = ads.GetAds(headers);
		resuableComponents.assertEqualValue("HTTP Status Code",Integer.toString(resp.getStatusCode()), Integer.toString(400),test);
		String status = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.status");
		String code = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.code");
		String message = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.message");
		resuableComponents.assertEqualValue("Status","Failed",status,test);
		resuableComponents.assertEqualValue("Code","5002",code,test);
		resuableComponents.assertEqualValue("Message","Input validation failed for VideoRefId id / Timestamp",message,test);
		
	}
	@Test
	public void getAdsWithoutAuthorization() throws Exception {
		test = report.startTest(new Object(){}.getClass().getEnclosingMethod().getName());
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("videoRefId", "138639948819370403156945965314003784895");
		headers.put("timestamp", "114");
		Response resp = ads.GetAds(headers);
		resuableComponents.assertEqualValue("HTTP Status Code",Integer.toString(resp.getStatusCode()), Integer.toString(401),test);
		String status = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.status");
		String code = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.code");
		String message = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.message");
		resuableComponents.assertEqualValue("Status",status,"Failed",test);
		resuableComponents.assertEqualValue("Code",code,"1001",test);
		resuableComponents.assertEqualValue("Message",message,"Authentication Failed.",test);
		
	}
	
	
	
	public String formatTimeStampsFromDB(String dbTimeStamps) 
	{   String formattedString="[";
		String[] arrOfStr = dbTimeStamps.split(",");
		for (String s : arrOfStr)
		{
			formattedString= formattedString+ s.split("=")[1]+",";
		}
		formattedString = formattedString.substring(0,formattedString.length()-2);
		formattedString = formattedString+"]";
		return formattedString;
		
	}
	
}
