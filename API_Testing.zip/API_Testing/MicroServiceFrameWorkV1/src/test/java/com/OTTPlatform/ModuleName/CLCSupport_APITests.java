
package com.OTTPlatform.ModuleName;

import java.util.Hashtable;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import BusinessComponents.AdsDummyAPIs;
import BusinessComponents.Authorization;
import BusinessComponents.CLCCMSADInitiation;
import BusinessComponents.CLCSupport;
import BusinessComponents.CLC_AVIService;
import baseTestPackage.BaseTest_TestNG;
import io.restassured.response.Response;
import reusableLibrary.DBUtils;
import reusableLibrary.JsonUtils;
import reusableLibrary.ResuableComponents;
import reusableLibrary.StringUtils;

public class CLCSupport_APITests extends BaseTest_TestNG {

	AdsDummyAPIs ads = new AdsDummyAPIs();
	ResuableComponents reusableComponents = new ResuableComponents();
	StringUtils stringUtils = new StringUtils();
	Authorization auth = new Authorization();
	CLCCMSADInitiation adInitiation = new CLCCMSADInitiation();
	CLC_AVIService clcAVIService = new CLC_AVIService();
	CLCSupport clcSupport = new CLCSupport();

	@Test(dataProvider = "uploads3", groups = { "Regression" })
	public void ResetStatusAviFailedToYetToStart(String fileName) throws Exception {
		test = report.startTest(new Object() {
		}.getClass().getEnclosingMethod().getName());
		String assetid = stringUtils.generateAssetid();
		String accessToken = auth.GetAccessToken("cms");
		String reqBody = JsonUtils.jsonFileReader(fileName);
		reqBody = reqBody.replace("{ASSETID}", assetid);
		reqBody = reqBody.replace("{S3URL}", globalProp.getProperty("s3Url"));
		reqBody = reqBody.replace("{VIDEONAME}", "Automation Test Video");
		reqBody = reqBody.replace("{VIDEOTYPE}", "Video");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("Authorization", "Bearer " + accessToken);
		Response resp = adInitiation.PostUploadS3(reqBody, headers);
		reusableComponents.assertEqualValue("HTTP Status Code", Integer.toString(resp.getStatusCode()),
				Integer.toString(201), test);
		String code = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.code");
		String status = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.status");
		String message = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.message");
		String additionalInfoMessage = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(),
				"$.result.additionalInfo[0].message");
		String additionalInfoTitle = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(),
				"$.result.additionalInfo[0].title");
		String videoID = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(),
				"$.cmsUploadResponse.clcVideo.videoRefId");
		String cosmosentry = DBUtils.getvaluefromDB("clcvideos", videoID);
		String wfStatus = JsonUtils.getValueFromJSONusingJSONPath(cosmosentry,
				"$.cursor.firstBatch[0].status.wfStatus");
		String subStatus = JsonUtils.getValueFromJSONusingJSONPath(cosmosentry,
				"$.cursor.firstBatch[0].status.subStatus");
		String isActive = JsonUtils.getValueFromJSONusingJSONPath(cosmosentry, "$.cursor.firstBatch[0].isActive");
		reusableComponents.assertEqualValue("ResultCode", code, "2006", test);
		reusableComponents.assertEqualValue("ResultStatus", status, "Success", test);
		reusableComponents.assertEqualValue("ResultMessage", message, "Video " + assetid + "is uploaded successfully.",
				test);
		reusableComponents.assertEqualValue("additionalInfoMessage", additionalInfoMessage,
				"Ad publishing submitted successfully for the video " + assetid + ".", test);
		reusableComponents.assertEqualValue("additionalInfoTitle", additionalInfoTitle, "/cms/initiateadpubprocess",
				test);
		reusableComponents.assertEqualValue("WFStatus", wfStatus, "Submitted", test);
		reusableComponents.assertEqualValue("SubStatus", subStatus, "YetToStart", test);
		reusableComponents.assertEqualValue("IsActiveFlag", isActive, "true", test);
		Thread.sleep(10000);
		String cosmosentrynew = DBUtils.getvaluefromDB("clcvideos", videoID);
		String wfStatusnew = JsonUtils.getValueFromJSONusingJSONPath(cosmosentrynew,
				"$.cursor.firstBatch[0].status.wfStatus");
		String subStatusnew = JsonUtils.getValueFromJSONusingJSONPath(cosmosentrynew,
				"$.cursor.firstBatch[0].status.subStatus");
		reusableComponents.assertEqualValue("Sub Status after AVI Initiated", wfStatusnew, "InProgress", test);
		reusableComponents.assertEqualValue("sub status", subStatusnew, "AVIInitiated", test);
		String token = auth.generateToken(videoID);
		Hashtable<String, String> headers1 = new Hashtable<String, String>();
		headers1.put("Content-Type", globalProp.getProperty("contentTypeAVI"));
		Response respAVICallback = clcAVIService.AVICallback(videoID, "SampleMessage", "Failed", token, headers1);
		Thread.sleep(7000);
		reusableComponents.assertEqualValue("HTTP Status Code", Integer.toString(respAVICallback.getStatusCode()),
				Integer.toString(201), test);
		String cosmosentryupdated = DBUtils.getvaluefromDB("clcvideos", videoID);
		String wfStatusupdated = JsonUtils.getValueFromJSONusingJSONPath(cosmosentryupdated,
				"$.cursor.firstBatch[0].status.wfStatus");
		String subStatusupdated = JsonUtils.getValueFromJSONusingJSONPath(cosmosentryupdated,
				"$.cursor.firstBatch[0].status.subStatus");
		reusableComponents.assertEqualValue("Sub Status after AVI Initiated", wfStatusupdated, "Failed", test);
		reusableComponents.assertEqualValue("sub status", subStatusupdated, "AVIFailed", test);
		String reqBodyResetWorkflow = "{\n" + "  \"videoRefId\": \"" + videoID + "\",\n"
				+ "  \"targetSubStatus\": \"YetToStart\" \n}";
		Hashtable<String, String> headersResetWorkflowStatus = new Hashtable<String, String>();
		headersResetWorkflowStatus.put("Content-Type", globalProp.getProperty("contentType"));
		String accessToken1 = auth.GetAccessToken("clc");
		headersResetWorkflowStatus.put("Authorization", "Bearer " + accessToken1);

		Response restWorkflowResponse = clcSupport.ResetWorkflowStatus(reqBodyResetWorkflow,
				headersResetWorkflowStatus);
		System.out.println(restWorkflowResponse.asString());
		reusableComponents.assertEqualValue("HTTP Status Code", Integer.toString(restWorkflowResponse.getStatusCode()),
				Integer.toString(200), test);
		String statusResp = JsonUtils.getValueFromJSONusingJSONPath(restWorkflowResponse.asString(), "$.result.status");
		String codeResp = JsonUtils.getValueFromJSONusingJSONPath(restWorkflowResponse.asString(), "$.result.code");
		String messageResp = JsonUtils.getValueFromJSONusingJSONPath(restWorkflowResponse.asString(),
				"$.result.message");
		reusableComponents.assertEqualValue("Status in reset workflow response", statusResp, "Success", test);
		reusableComponents.assertEqualValue("Code in reset workflow response", codeResp, "11001", test);
		reusableComponents.assertEqualValue("Message in reset workflow response", messageResp,
				"Workflow restarted successfully for videoRefId " + videoID + " with targetSubStatus YetToStart", test);

	}

	@Test(dataProvider = "uploads3", groups = { "Regression" })
	public void ResetStatusBase64FailedToYetToStart(String fileName) throws Exception {
		test = report.startTest(new Object() {
		}.getClass().getEnclosingMethod().getName());
		String assetid = stringUtils.generateAssetid();
		String accessToken = auth.GetAccessToken("cms");
		String reqBody = JsonUtils.jsonFileReader(fileName);
		reqBody = reqBody.replace("{ASSETID}", assetid);
		reqBody = reqBody.replace("{S3URL}", globalProp.getProperty("s3Url"));
		reqBody = reqBody.replace("{VIDEONAME}", "Automation Test Video");
		reqBody = reqBody.replace("{VIDEOTYPE}", "Video");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("Authorization", "Bearer " + accessToken);
		Response resp = adInitiation.PostUploadS3(reqBody, headers);
		reusableComponents.assertEqualValue("HTTP Status Code", Integer.toString(resp.getStatusCode()),
				Integer.toString(201), test);
		String code = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.code");
		String status = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.status");
		String message = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.message");
		String additionalInfoMessage = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(),
				"$.result.additionalInfo[0].message");
		String additionalInfoTitle = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(),
				"$.result.additionalInfo[0].title");
		String videoID = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(),
				"$.cmsUploadResponse.clcVideo.videoRefId");
		String cosmosentry = DBUtils.getvaluefromDB("clcvideos", videoID);
		String wfStatus = JsonUtils.getValueFromJSONusingJSONPath(cosmosentry,
				"$.cursor.firstBatch[0].status.wfStatus");
		String subStatus = JsonUtils.getValueFromJSONusingJSONPath(cosmosentry,
				"$.cursor.firstBatch[0].status.subStatus");
		String isActive = JsonUtils.getValueFromJSONusingJSONPath(cosmosentry, "$.cursor.firstBatch[0].isActive");
		reusableComponents.assertEqualValue("ResultCode", code, "2006", test);
		reusableComponents.assertEqualValue("ResultStatus", status, "Success", test);
		reusableComponents.assertEqualValue("ResultMessage", message, "Video " + assetid + "is uploaded successfully.",
				test);
		reusableComponents.assertEqualValue("additionalInfoMessage", additionalInfoMessage,
				"Ad publishing submitted successfully for the video " + assetid + ".", test);
		reusableComponents.assertEqualValue("additionalInfoTitle", additionalInfoTitle, "/cms/initiateadpubprocess",
				test);
		reusableComponents.assertEqualValue("WFStatus", wfStatus, "Submitted", test);
		reusableComponents.assertEqualValue("SubStatus", subStatus, "YetToStart", test);
		reusableComponents.assertEqualValue("IsActiveFlag", isActive, "true", test);
		Thread.sleep(10000);
		String cosmosentrynew = DBUtils.getvaluefromDB("clcvideos", videoID);
		String wfStatusnew = JsonUtils.getValueFromJSONusingJSONPath(cosmosentrynew,
				"$.cursor.firstBatch[0].status.wfStatus");
		String subStatusnew = JsonUtils.getValueFromJSONusingJSONPath(cosmosentrynew,
				"$.cursor.firstBatch[0].status.subStatus");
		reusableComponents.assertEqualValue("Sub Status after AVI Initiated", wfStatusnew, "InProgress", test);
		reusableComponents.assertEqualValue("sub status", subStatusnew, "AVIInitiated", test);
		String token = auth.generateToken(videoID);
		Hashtable<String, String> headers1 = new Hashtable<String, String>();
		headers1.put("Content-Type", globalProp.getProperty("contentTypeAVI"));
		Response respAVICallback = clcAVIService.AVICallback(videoID, "SampleMessage", "Processed", token, headers1);
		Thread.sleep(15000);
		reusableComponents.assertEqualValue("HTTP Status Code", Integer.toString(respAVICallback.getStatusCode()),
				Integer.toString(201), test);
		String cosmosentryupdated = DBUtils.getvaluefromDB("clcvideos", videoID);
		String wfStatusupdated = JsonUtils.getValueFromJSONusingJSONPath(cosmosentryupdated,
				"$.cursor.firstBatch[0].status.wfStatus");
		String subStatusupdated = JsonUtils.getValueFromJSONusingJSONPath(cosmosentryupdated,
				"$.cursor.firstBatch[0].status.subStatus");
		reusableComponents.assertEqualValue("Sub Status after AVI Initiated", wfStatusupdated, "Failed", test);
		reusableComponents.assertEqualValue("sub status", subStatusupdated, "Base64Failed", test);
		String reqBodyResetWorkflow = "{\n" + "  \"videoRefId\": \"" + videoID + "\",\n"
				+ "  \"targetSubStatus\": \"YetToStart\" \n}";
		Hashtable<String, String> headersResetWorkflowStatus = new Hashtable<String, String>();
		headersResetWorkflowStatus.put("Content-Type", globalProp.getProperty("contentType"));
		String accessToken1 = auth.GetAccessToken("clc");
		headersResetWorkflowStatus.put("Authorization", "Bearer " + accessToken1);

		Response restWorkflowResponse = clcSupport.ResetWorkflowStatus(reqBodyResetWorkflow,
				headersResetWorkflowStatus);
		System.out.println(restWorkflowResponse.asString());
		reusableComponents.assertEqualValue("HTTP Status Code", Integer.toString(restWorkflowResponse.getStatusCode()),
				Integer.toString(200), test);
		String statusResp = JsonUtils.getValueFromJSONusingJSONPath(restWorkflowResponse.asString(), "$.result.status");
		String codeResp = JsonUtils.getValueFromJSONusingJSONPath(restWorkflowResponse.asString(), "$.result.code");
		String messageResp = JsonUtils.getValueFromJSONusingJSONPath(restWorkflowResponse.asString(),
				"$.result.message");
		reusableComponents.assertEqualValue("Status in reset workflow response", statusResp, "Success", test);
		reusableComponents.assertEqualValue("Code in reset workflow response", codeResp, "11001", test);
		reusableComponents.assertEqualValue("Message in reset workflow response", messageResp,
				"Workflow restarted successfully for videoRefId " + videoID + " with targetSubStatus YetToStart", test);
	}

	@Test(dataProvider = "uploads3", groups = { "Regression" })
	public void ResetStatusBase64FailedToAVICompleted(String fileName) throws Exception {
		test = report.startTest(new Object() {
		}.getClass().getEnclosingMethod().getName());
		String assetid = stringUtils.generateAssetid();
		String accessToken = auth.GetAccessToken("cms");
		String reqBody = JsonUtils.jsonFileReader(fileName);
		reqBody = reqBody.replace("{ASSETID}", assetid);
		reqBody = reqBody.replace("{S3URL}", globalProp.getProperty("s3Url"));
		reqBody = reqBody.replace("{VIDEONAME}", "Automation Test Video");
		reqBody = reqBody.replace("{VIDEOTYPE}", "Video");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("Authorization", "Bearer " + accessToken);
		Response resp = adInitiation.PostUploadS3(reqBody, headers);
		reusableComponents.assertEqualValue("HTTP Status Code", Integer.toString(resp.getStatusCode()),
				Integer.toString(201), test);
		String code = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.code");
		String status = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.status");
		String message = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.message");
		String additionalInfoMessage = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(),
				"$.result.additionalInfo[0].message");
		String additionalInfoTitle = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(),
				"$.result.additionalInfo[0].title");
		String videoID = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(),
				"$.cmsUploadResponse.clcVideo.videoRefId");
		String cosmosentry = DBUtils.getvaluefromDB("clcvideos", videoID);
		String wfStatus = JsonUtils.getValueFromJSONusingJSONPath(cosmosentry,
				"$.cursor.firstBatch[0].status.wfStatus");
		String subStatus = JsonUtils.getValueFromJSONusingJSONPath(cosmosentry,
				"$.cursor.firstBatch[0].status.subStatus");
		String isActive = JsonUtils.getValueFromJSONusingJSONPath(cosmosentry, "$.cursor.firstBatch[0].isActive");
		reusableComponents.assertEqualValue("ResultCode", code, "2006", test);
		reusableComponents.assertEqualValue("ResultStatus", status, "Success", test);
		reusableComponents.assertEqualValue("ResultMessage", message, "Video " + assetid + "is uploaded successfully.",
				test);
		reusableComponents.assertEqualValue("additionalInfoMessage", additionalInfoMessage,
				"Ad publishing submitted successfully for the video " + assetid + ".", test);
		reusableComponents.assertEqualValue("additionalInfoTitle", additionalInfoTitle, "/cms/initiateadpubprocess",
				test);
		reusableComponents.assertEqualValue("WFStatus", wfStatus, "Submitted", test);
		reusableComponents.assertEqualValue("SubStatus", subStatus, "YetToStart", test);
		reusableComponents.assertEqualValue("IsActiveFlag", isActive, "true", test);
		Thread.sleep(10000);
		String cosmosentrynew = DBUtils.getvaluefromDB("clcvideos", videoID);
		String wfStatusnew = JsonUtils.getValueFromJSONusingJSONPath(cosmosentrynew,
				"$.cursor.firstBatch[0].status.wfStatus");
		String subStatusnew = JsonUtils.getValueFromJSONusingJSONPath(cosmosentrynew,
				"$.cursor.firstBatch[0].status.subStatus");
		reusableComponents.assertEqualValue("Sub Status after AVI Initiated", wfStatusnew, "InProgress", test);
		reusableComponents.assertEqualValue("sub status", subStatusnew, "AVIInitiated", test);
		String token = auth.generateToken(videoID);
		Hashtable<String, String> headers1 = new Hashtable<String, String>();
		headers1.put("Content-Type", globalProp.getProperty("contentTypeAVI"));
		Response respAVICallback = clcAVIService.AVICallback(videoID, "SampleMessage", "Processed", token, headers1);
		Thread.sleep(15000);
		reusableComponents.assertEqualValue("HTTP Status Code", Integer.toString(respAVICallback.getStatusCode()),
				Integer.toString(201), test);
		String cosmosentryupdated = DBUtils.getvaluefromDB("clcvideos", videoID);
		String wfStatusupdated = JsonUtils.getValueFromJSONusingJSONPath(cosmosentryupdated,
				"$.cursor.firstBatch[0].status.wfStatus");
		String subStatusupdated = JsonUtils.getValueFromJSONusingJSONPath(cosmosentryupdated,
				"$.cursor.firstBatch[0].status.subStatus");
		reusableComponents.assertEqualValue("Sub Status after AVI Initiated", wfStatusupdated, "Failed", test);
		reusableComponents.assertEqualValue("sub status", subStatusupdated, "Base64Failed", test);
		String reqBodyResetWorkflow = "{\n" + "  \"videoRefId\": \"" + videoID + "\",\n"
				+ "  \"targetSubStatus\": \"AviCompleted\" \n}";
		Hashtable<String, String> headersResetWorkflowStatus = new Hashtable<String, String>();
		headersResetWorkflowStatus.put("Content-Type", globalProp.getProperty("contentType"));
		String accessToken1 = auth.GetAccessToken("clc");
		headersResetWorkflowStatus.put("Authorization", "Bearer " + accessToken1);

		Response restWorkflowResponse = clcSupport.ResetWorkflowStatus(reqBodyResetWorkflow,
				headersResetWorkflowStatus);
		System.out.println(restWorkflowResponse.asString());
		reusableComponents.assertEqualValue("HTTP Status Code", Integer.toString(restWorkflowResponse.getStatusCode()),
				Integer.toString(200), test);
		String statusResp = JsonUtils.getValueFromJSONusingJSONPath(restWorkflowResponse.asString(), "$.result.status");
		String codeResp = JsonUtils.getValueFromJSONusingJSONPath(restWorkflowResponse.asString(), "$.result.code");
		String messageResp = JsonUtils.getValueFromJSONusingJSONPath(restWorkflowResponse.asString(),
				"$.result.message");
		reusableComponents.assertEqualValue("Status in reset workflow response", statusResp, "Success", test);
		reusableComponents.assertEqualValue("Code in reset workflow response", codeResp, "11001", test);
		reusableComponents.assertEqualValue("Message in reset workflow response", messageResp,
				"Workflow restarted successfully for videoRefId " + videoID + " with targetSubStatus AviCompleted",
				test);
	}

	@Test
	public void ResetStatusVideoRefIdMissingKey() throws Exception {
		test = report.startTest(new Object() {
		}.getClass().getEnclosingMethod().getName());

		// videoRefId key missing in body
		String reqBodyResetWorkflow = "{\n \"targetSubStatus\": \"AviCompleted\" \n}";
		Hashtable<String, String> headersResetWorkflowStatus = new Hashtable<String, String>();
		headersResetWorkflowStatus.put("Content-Type", globalProp.getProperty("contentType"));
		String accessToken1 = auth.GetAccessToken("clc");
		headersResetWorkflowStatus.put("Authorization", "Bearer " + accessToken1);
		Response restWorkflowResponse = clcSupport.ResetWorkflowStatus(reqBodyResetWorkflow,
				headersResetWorkflowStatus);
		System.out.println(restWorkflowResponse.asString());
		reusableComponents.assertEqualValue("HTTP Status Code", Integer.toString(restWorkflowResponse.getStatusCode()),
				Integer.toString(400), test);
		String statusResp = JsonUtils.getValueFromJSONusingJSONPath(restWorkflowResponse.asString(), "$.result.status");
		String codeResp = JsonUtils.getValueFromJSONusingJSONPath(restWorkflowResponse.asString(), "$.result.code");
		String messageResp = JsonUtils.getValueFromJSONusingJSONPath(restWorkflowResponse.asString(),
				"$.result.message");
		reusableComponents.assertEqualValue("Status in reset workflow response", statusResp, "Failed", test);
		reusableComponents.assertEqualValue("Code in reset workflow response", codeResp, "11005", test);
		reusableComponents.assertEqualValue("Message in reset workflow response", messageResp,
				"videoRefId should not be empty videoRefId must be a string", test);
	}

	@Test
	public void ResetStatusTargetSubStatusMissingKey() throws Exception {
		test = report.startTest(new Object() {
		}.getClass().getEnclosingMethod().getName());

		// targetSubStatus key missing in body
		String reqBodyResetWorkflow = "{\n \"videoRefId\": \"6540d599e1f8e9bd30b2e0kk\" \n}";
		Hashtable<String, String> headersResetWorkflowStatus = new Hashtable<String, String>();
		headersResetWorkflowStatus.put("Content-Type", globalProp.getProperty("contentType"));
		String accessToken1 = auth.GetAccessToken("clc");
		headersResetWorkflowStatus.put("Authorization", "Bearer " + accessToken1);
		Response restWorkflowResponse = clcSupport.ResetWorkflowStatus(reqBodyResetWorkflow,
				headersResetWorkflowStatus);
		System.out.println(restWorkflowResponse.asString());
		reusableComponents.assertEqualValue("HTTP Status Code", Integer.toString(restWorkflowResponse.getStatusCode()),
				Integer.toString(400), test);
		String statusResp = JsonUtils.getValueFromJSONusingJSONPath(restWorkflowResponse.asString(), "$.result.status");
		String codeResp = JsonUtils.getValueFromJSONusingJSONPath(restWorkflowResponse.asString(), "$.result.code");
		String messageResp = JsonUtils.getValueFromJSONusingJSONPath(restWorkflowResponse.asString(),
				"$.result.message");
		reusableComponents.assertEqualValue("Status in reset workflow response", statusResp, "Failed", test);
		reusableComponents.assertEqualValue("Code in reset workflow response", codeResp, "11005", test);
		reusableComponents.assertEqualValue("Message in reset workflow response", messageResp,
				"targetSubStatus should not be empty targetSubStatus must be a string", test);
	}

	@Test
	public void ResetStatusTargetSubStatusNull() throws Exception {
		test = report.startTest(new Object() {
		}.getClass().getEnclosingMethod().getName());

		// targetSubStatus and videoRefId set to null in request body
		String reqBodyResetWorkflow = "{\n" + "  \"videoRefId\": null ,\n" + "  \"targetSubStatus\": null \n}";
		Hashtable<String, String> headersResetWorkflowStatus = new Hashtable<String, String>();
		headersResetWorkflowStatus.put("Content-Type", globalProp.getProperty("contentType"));
		String accessToken1 = auth.GetAccessToken("clc");
		headersResetWorkflowStatus.put("Authorization", "Bearer " + accessToken1);
		Response restWorkflowResponse = clcSupport.ResetWorkflowStatus(reqBodyResetWorkflow,
				headersResetWorkflowStatus);
		System.out.println(restWorkflowResponse.asString());
		reusableComponents.assertEqualValue("HTTP Status Code", Integer.toString(restWorkflowResponse.getStatusCode()),
				Integer.toString(400), test);
		String statusResp = JsonUtils.getValueFromJSONusingJSONPath(restWorkflowResponse.asString(), "$.result.status");
		String codeResp = JsonUtils.getValueFromJSONusingJSONPath(restWorkflowResponse.asString(), "$.result.code");
		String messageResp = JsonUtils.getValueFromJSONusingJSONPath(restWorkflowResponse.asString(),
				"$.result.message");
		reusableComponents.assertEqualValue("Status in reset workflow response", statusResp, "Failed", test);
		reusableComponents.assertEqualValue("Code in reset workflow response", codeResp, "11005", test);
		reusableComponents.assertEqualValue("Message in reset workflow response", messageResp,
				"videoRefId should not be empty videoRefId must be a string,targetSubStatus should not be empty targetSubStatus must be a string",
				test);
	}

	@DataProvider(name = "uploads3")
	public Object[][] getSingle1DataJSONSource() {
		return new Object[][] { { "PayLoad/uploads3.json" } };
	}

}
