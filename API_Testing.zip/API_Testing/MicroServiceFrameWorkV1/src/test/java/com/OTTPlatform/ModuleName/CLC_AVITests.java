package com.OTTPlatform.ModuleName;

import java.util.Hashtable;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import BusinessComponents.AdsDummyAPIs;
import BusinessComponents.Authorization;
import BusinessComponents.CLCCMSADInitiation;
import BusinessComponents.CLC_AVIService;
import baseTestPackage.BaseTest_TestNG;
import io.restassured.response.Response;
import reusableLibrary.AzureUtils;
import reusableLibrary.DBUtils;
import reusableLibrary.JsonUtils;
import reusableLibrary.ResuableComponents;
import reusableLibrary.StringUtils;

public class CLC_AVITests extends BaseTest_TestNG{
	
	AdsDummyAPIs ads = new AdsDummyAPIs();
	ResuableComponents reusableComponents= new ResuableComponents();
	StringUtils stringUtils = new StringUtils();
	Authorization auth= new Authorization();
	CLCCMSADInitiation adInitiation = new CLCCMSADInitiation();
	CLC_AVIService clcAVIService = new CLC_AVIService();

	
	//@Test(dataProvider = "uploadgcp", groups = {"Regression" })
	@Test(dataProvider = "uploadgcp", groups = {"Regression" })
	public void AVICallBack_SuccessProcessed(String fileName) throws Exception {
		test = report.startTest(new Object(){}.getClass().getEnclosingMethod().getName());
		String assetid= stringUtils.generateAssetid();
		String accessToken = auth.GetAccessToken("cms");
		String reqBody = JsonUtils.jsonFileReader(fileName);
		reqBody= reqBody.replace("{ASSETID}", assetid);
		//reqBody=reqBody.replace("{GCPURL}", globalProp.getProperty("gcpUrl"));
		reqBody=reqBody.replace("{GCPURL}", globalProp.getProperty("gcpUrl"));
		reqBody=reqBody.replace("{VIDEONAME}", "Automation Test Video");
		reqBody=reqBody.replace("{VIDEOTYPE}", "Video");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("Authorization", "Bearer " + accessToken);
		//Response resp = adInitiation.PostUploadGcp(reqBody,headers);
		Response resp = adInitiation.PostUploadGcp(reqBody,headers);
		reusableComponents.assertEqualValue("HTTP Status Code",Integer.toString(resp.getStatusCode()), Integer.toString(201),test);
		String code= JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.code");
		String status = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.status");
		String message = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.message");
		String additionalInfoMessage = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.additionalInfo[0].message");
		String additionalInfoTitle = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.additionalInfo[0].title");
		String videoID = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.cmsUploadResponse.clcVideo.videoRefId");
		String cosmosentry= DBUtils.getvaluefromDB("clcvideos",videoID);
		String wfStatus = JsonUtils.getValueFromJSONusingJSONPath(cosmosentry, "$.cursor.firstBatch[0].status.wfStatus");
		String subStatus= JsonUtils.getValueFromJSONusingJSONPath(cosmosentry, "$.cursor.firstBatch[0].status.subStatus");
		String isActive = JsonUtils.getValueFromJSONusingJSONPath(cosmosentry, "$.cursor.firstBatch[0].isActive");
		reusableComponents.assertEqualValue("ResultCode",code,"2006",test);
		reusableComponents.assertEqualValue("ResultStatus",status,"Success",test);
		reusableComponents.assertEqualValue("ResultMessage",message,"Video " + assetid + "is uploaded successfully.",test);
		reusableComponents.assertEqualValue("additionalInfoMessage",additionalInfoMessage,"Ad publishing submitted successfully for the video "+ assetid+".",test);
		reusableComponents.assertEqualValue("additionalInfoTitle",additionalInfoTitle,"/cms/initiateadpubprocess",test);
		reusableComponents.assertEqualValue("WFStatus",wfStatus,"Submitted",test);
		reusableComponents.assertEqualValue("SubStatus",subStatus,"YetToStart",test);
		reusableComponents.assertEqualValue("IsActiveFlag",isActive,"true",test);
		Thread.sleep(13000);
		String cosmosentrynew= DBUtils.getvaluefromDB("clcvideos",videoID);
		String wfStatusnew = JsonUtils.getValueFromJSONusingJSONPath(cosmosentrynew, "$.cursor.firstBatch[0].status.wfStatus");
		String subStatusnew= JsonUtils.getValueFromJSONusingJSONPath(cosmosentrynew, "$.cursor.firstBatch[0].status.subStatus");
		reusableComponents.assertEqualValue("Sub Status after AVI Initiated",wfStatusnew,"InProgress",test);
		reusableComponents.assertEqualValue("sub status",subStatusnew,"AVIInitiated",test);
		String token = auth.generateToken(videoID);
		Hashtable<String, String> headers1 = new Hashtable<String, String>();
		headers1.put("Content-Type", globalProp.getProperty("contentTypeAVI"));
		Response respAVICallback= clcAVIService.AVICallback(videoID, "SampleMessage","Processed", token,headers1);
		//Thread.sleep(1000);
		reusableComponents.assertEqualValue("HTTP Status Code",Integer.toString(respAVICallback.getStatusCode()), Integer.toString(201),test);
		String cosmosentryupdated= DBUtils.getvaluefromDB("clcvideos",videoID);
		String wfStatusupdated = JsonUtils.getValueFromJSONusingJSONPath(cosmosentryupdated, "$.cursor.firstBatch[0].status.wfStatus");
		String subStatusupdated= JsonUtils.getValueFromJSONusingJSONPath(cosmosentryupdated, "$.cursor.firstBatch[0].status.subStatus");
		reusableComponents.assertEqualValue("Sub Status after AVI Initiated",wfStatusupdated,"InProgress",test);
		reusableComponents.assertEqualValue("sub status",subStatusupdated,"AVICompleted",test);
		reusableComponents.assertEqualValue("ErrorCode",JsonUtils.getValueFromJSONusingJSONPath(respAVICallback.asString(), "$.result.code"),"3006",test);
		reusableComponents.assertEqualValue("Error Message",JsonUtils.getValueFromJSONusingJSONPath(respAVICallback.asString(), "$.result.message"),"Successfully updated AVI workflow status values for the video "+ videoID,test);
		reusableComponents.assertEqualValue("Status",JsonUtils.getValueFromJSONusingJSONPath(respAVICallback.asString(), "$.result.status"),"Success",test);
		
	}
	
	//@Test(dataProvider = "uploadgcp", groups = {"Regression" })
	@Test(dataProvider = "uploadgcp", groups = {"Regression" })
	public void AVICallBack_IncorrectAuthorization(String fileName) throws Exception {
		test = report.startTest(new Object(){}.getClass().getEnclosingMethod().getName());
		String assetid= stringUtils.generateAssetid();
		String accessToken = auth.GetAccessToken("cms");
		String reqBody = JsonUtils.jsonFileReader(fileName);
		reqBody= reqBody.replace("{ASSETID}", assetid);
		//reqBody=reqBody.replace("{GCPURL}", globalProp.getProperty("gcpUrl"));
		reqBody=reqBody.replace("{GCPURL}", globalProp.getProperty("gcpUrl"));
		reqBody=reqBody.replace("{VIDEONAME}", "Automation Test Video");
		reqBody=reqBody.replace("{VIDEOTYPE}", "Video");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("Authorization", "Bearer " + accessToken);
		//Response resp = adInitiation.PostUploadGcp(reqBody,headers);
		Response resp = adInitiation.PostUploadGcp(reqBody,headers);
		reusableComponents.assertEqualValue("HTTP Status Code",Integer.toString(resp.getStatusCode()), Integer.toString(201),test);
		String code= JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.code");
		String status = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.status");
		String message = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.message");
		String additionalInfoMessage = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.additionalInfo[0].message");
		String additionalInfoTitle = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.additionalInfo[0].title");
		String videoID = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.cmsUploadResponse.clcVideo.videoRefId");
		String cosmosentry= DBUtils.getvaluefromDB("clcvideos",videoID);
		String wfStatus = JsonUtils.getValueFromJSONusingJSONPath(cosmosentry, "$.cursor.firstBatch[0].status.wfStatus");
		String subStatus= JsonUtils.getValueFromJSONusingJSONPath(cosmosentry, "$.cursor.firstBatch[0].status.subStatus");
		String isActive = JsonUtils.getValueFromJSONusingJSONPath(cosmosentry, "$.cursor.firstBatch[0].isActive");
		reusableComponents.assertEqualValue("ResultCode",code,"2006",test);
		reusableComponents.assertEqualValue("ResultStatus",status,"Success",test);
		reusableComponents.assertEqualValue("ResultMessage",message,"Video " + assetid + "is uploaded successfully.",test);
		reusableComponents.assertEqualValue("additionalInfoMessage",additionalInfoMessage,"Ad publishing submitted successfully for the video "+ assetid+".",test);
		reusableComponents.assertEqualValue("additionalInfoTitle",additionalInfoTitle,"/cms/initiateadpubprocess",test);
		reusableComponents.assertEqualValue("WFStatus",wfStatus,"Submitted",test);
		reusableComponents.assertEqualValue("SubStatus",subStatus,"YetToStart",test);
		reusableComponents.assertEqualValue("IsActiveFlag",isActive,"true",test);
		Thread.sleep(10000);
		String cosmosentrynew= DBUtils.getvaluefromDB("clcvideos",videoID);
		String wfStatusnew = JsonUtils.getValueFromJSONusingJSONPath(cosmosentrynew, "$.cursor.firstBatch[0].status.wfStatus");
		String subStatusnew= JsonUtils.getValueFromJSONusingJSONPath(cosmosentrynew, "$.cursor.firstBatch[0].status.subStatus");
		reusableComponents.assertEqualValue("Sub Status after AVI Initiated",wfStatusnew,"InProgress",test);
		reusableComponents.assertEqualValue("sub status",subStatusnew,"AVIInitiated",test);
		String token = "TestToken";
		Hashtable<String, String> headers1 = new Hashtable<String, String>();
		headers1.put("Content-Type", globalProp.getProperty("contentTypeAVI"));
		Response respAVICallback= clcAVIService.AVICallback(videoID, "SampleMessage","Processed", token,headers1);
		reusableComponents.assertEqualValue("HTTP Status Code",Integer.toString(respAVICallback.getStatusCode()), Integer.toString(401),test);
		reusableComponents.assertEqualValue("ErrorCode",JsonUtils.getValueFromJSONusingJSONPath(respAVICallback.asString(), "$.result.code"),"1001",test);
		reusableComponents.assertEqualValue("Error Message",JsonUtils.getValueFromJSONusingJSONPath(respAVICallback.asString(), "$.result.message"),"Authentication Failed.",test);
		reusableComponents.assertEqualValue("Status",JsonUtils.getValueFromJSONusingJSONPath(respAVICallback.asString(), "$.result.status"),"Failed",test);
	}
	
	//@Test(dataProvider = "uploadgcp", groups = {"Regression" })
	@Test(dataProvider = "uploadgcp", groups = {"Regression" })
	public void AVICallBack_IncorrectStatus(String fileName) throws Exception {
		test = report.startTest(new Object(){}.getClass().getEnclosingMethod().getName());
		String assetid= stringUtils.generateAssetid();
		String accessToken = auth.GetAccessToken("cms");
		String reqBody = JsonUtils.jsonFileReader(fileName);
		reqBody= reqBody.replace("{ASSETID}", assetid);
		reqBody=reqBody.replace("{GCPURL}", globalProp.getProperty("gcpUrl"));
		reqBody=reqBody.replace("{GCPURL}", globalProp.getProperty("gcpUrl"));
		reqBody=reqBody.replace("{VIDEONAME}", "Automation Test Video");
		reqBody=reqBody.replace("{VIDEOTYPE}", "Video");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("Authorization", "Bearer " + accessToken);
		//Response resp = adInitiation.PostUploadGcp(reqBody,headers);
		Response resp = adInitiation.PostUploadGcp(reqBody,headers);
		reusableComponents.assertEqualValue("HTTP Status Code",Integer.toString(resp.getStatusCode()), Integer.toString(201),test);
		String code= JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.code");
		String status = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.status");
		String message = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.message");
		String additionalInfoMessage = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.additionalInfo[0].message");
		String additionalInfoTitle = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.additionalInfo[0].title");
		String videoID = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.cmsUploadResponse.clcVideo.videoRefId");
		String cosmosentry= DBUtils.getvaluefromDB("clcvideos",videoID);
		String wfStatus = JsonUtils.getValueFromJSONusingJSONPath(cosmosentry, "$.cursor.firstBatch[0].status.wfStatus");
		String subStatus= JsonUtils.getValueFromJSONusingJSONPath(cosmosentry, "$.cursor.firstBatch[0].status.subStatus");
		String isActive = JsonUtils.getValueFromJSONusingJSONPath(cosmosentry, "$.cursor.firstBatch[0].isActive");
		reusableComponents.assertEqualValue("ResultCode",code,"2006",test);
		reusableComponents.assertEqualValue("ResultStatus",status,"Success",test);
		reusableComponents.assertEqualValue("ResultMessage",message,"Video " + assetid + "is uploaded successfully.",test);
		reusableComponents.assertEqualValue("additionalInfoMessage",additionalInfoMessage,"Ad publishing submitted successfully for the video "+ assetid+".",test);
		reusableComponents.assertEqualValue("additionalInfoTitle",additionalInfoTitle,"/cms/initiateadpubprocess",test);
		reusableComponents.assertEqualValue("WFStatus",wfStatus,"Submitted",test);
		reusableComponents.assertEqualValue("SubStatus",subStatus,"YetToStart",test);
		reusableComponents.assertEqualValue("IsActiveFlag",isActive,"true",test);
		Thread.sleep(10000);
		String cosmosentrynew= DBUtils.getvaluefromDB("clcvideos",videoID);
		String wfStatusnew = JsonUtils.getValueFromJSONusingJSONPath(cosmosentrynew, "$.cursor.firstBatch[0].status.wfStatus");
		String subStatusnew= JsonUtils.getValueFromJSONusingJSONPath(cosmosentrynew, "$.cursor.firstBatch[0].status.subStatus");
		reusableComponents.assertEqualValue("Sub Status after AVI Initiated",wfStatusnew,"InProgress",test);
		reusableComponents.assertEqualValue("sub status",subStatusnew,"AVIInitiated",test);
		String token = auth.generateToken(videoID);
		Hashtable<String, String> headers1 = new Hashtable<String, String>();
		headers1.put("Content-Type", globalProp.getProperty("contentTypeAVI"));
		Response respAVICallback= clcAVIService.AVICallback(videoID, "SampleMessage","Test", token,headers1);
		reusableComponents.assertEqualValue("HTTP Status Code",Integer.toString(respAVICallback.getStatusCode()), Integer.toString(400),test);
		reusableComponents.assertEqualValue("ErrorCode",JsonUtils.getValueFromJSONusingJSONPath(respAVICallback.asString(), "$.result.code"),"3001",test);
		reusableComponents.assertEqualValue("Error Message",JsonUtils.getValueFromJSONusingJSONPath(respAVICallback.asString(), "$.result.message"),"AVI notification message payload validation failed for the message",test);
		reusableComponents.assertEqualValue("Status",JsonUtils.getValueFromJSONusingJSONPath(respAVICallback.asString(), "$.result.status"),"Failed",test);
		reusableComponents.assertEqualValue("Additional Info",JsonUtils.getValueFromJSONusingJSONPath(respAVICallback.asString(), "$.result.additionalInfo[0]"),"state must be one of the following values: Processed, Failed, Timeout, Cancelled, CancelledExternally",test);
	}
	
	//@Test(dataProvider = "uploadgcp", groups = {"Regression" })
	@Test(dataProvider = "uploadgcp", groups = {"Regression" })
	public void AVICallBack_SuccessFailed(String fileName) throws Exception {
		test = report.startTest(new Object(){}.getClass().getEnclosingMethod().getName());
		String assetid= stringUtils.generateAssetid();
		String accessToken = auth.GetAccessToken("cms");
		String reqBody = JsonUtils.jsonFileReader(fileName);
		reqBody= reqBody.replace("{ASSETID}", assetid);
		//reqBody=reqBody.replace("{GCPURL}", globalProp.getProperty("gcpUrl"));
		reqBody=reqBody.replace("{GCPURL}", globalProp.getProperty("gcpUrl"));
		reqBody=reqBody.replace("{VIDEONAME}", "Automation Test Video");
		reqBody=reqBody.replace("{VIDEOTYPE}", "Video");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("Authorization", "Bearer " + accessToken);
		//Response resp = adInitiation.PostUploadGcp(reqBody,headers);
		Response resp = adInitiation.PostUploadGcp(reqBody,headers);
		reusableComponents.assertEqualValue("HTTP Status Code",Integer.toString(resp.getStatusCode()), Integer.toString(201),test);
		String code= JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.code");
		String status = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.status");
		String message = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.message");
		String additionalInfoMessage = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.additionalInfo[0].message");
		String additionalInfoTitle = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.additionalInfo[0].title");
		String videoID = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.cmsUploadResponse.clcVideo.videoRefId");
		String cosmosentry= DBUtils.getvaluefromDB("clcvideos",videoID);
		String wfStatus = JsonUtils.getValueFromJSONusingJSONPath(cosmosentry, "$.cursor.firstBatch[0].status.wfStatus");
		String subStatus= JsonUtils.getValueFromJSONusingJSONPath(cosmosentry, "$.cursor.firstBatch[0].status.subStatus");
		String isActive = JsonUtils.getValueFromJSONusingJSONPath(cosmosentry, "$.cursor.firstBatch[0].isActive");
		reusableComponents.assertEqualValue("ResultCode",code,"2006",test);
		reusableComponents.assertEqualValue("ResultStatus",status,"Success",test);
		reusableComponents.assertEqualValue("ResultMessage",message,"Video " + assetid + "is uploaded successfully.",test);
		reusableComponents.assertEqualValue("additionalInfoMessage",additionalInfoMessage,"Ad publishing submitted successfully for the video "+ assetid+".",test);
		reusableComponents.assertEqualValue("additionalInfoTitle",additionalInfoTitle,"/cms/initiateadpubprocess",test);
		reusableComponents.assertEqualValue("WFStatus",wfStatus,"Submitted",test);
		reusableComponents.assertEqualValue("SubStatus",subStatus,"YetToStart",test);
		reusableComponents.assertEqualValue("IsActiveFlag",isActive,"true",test);
		Thread.sleep(10000);
		String cosmosentrynew= DBUtils.getvaluefromDB("clcvideos",videoID);
		String wfStatusnew = JsonUtils.getValueFromJSONusingJSONPath(cosmosentrynew, "$.cursor.firstBatch[0].status.wfStatus");
		String subStatusnew= JsonUtils.getValueFromJSONusingJSONPath(cosmosentrynew, "$.cursor.firstBatch[0].status.subStatus");
		reusableComponents.assertEqualValue("Sub Status after AVI Initiated",wfStatusnew,"InProgress",test);
		reusableComponents.assertEqualValue("sub status",subStatusnew,"AVIInitiated",test);
		String token = auth.generateToken(videoID);
		Hashtable<String, String> headers1 = new Hashtable<String, String>();
		headers1.put("Content-Type", globalProp.getProperty("contentTypeAVI"));
		Response respAVICallback= clcAVIService.AVICallback(videoID, "SampleMessage","Failed", token,headers1);
		Thread.sleep(7000);
		reusableComponents.assertEqualValue("HTTP Status Code",Integer.toString(respAVICallback.getStatusCode()), Integer.toString(201),test);
		String cosmosentryupdated= DBUtils.getvaluefromDB("clcvideos",videoID);
		String wfStatusupdated = JsonUtils.getValueFromJSONusingJSONPath(cosmosentryupdated, "$.cursor.firstBatch[0].status.wfStatus");
		String subStatusupdated= JsonUtils.getValueFromJSONusingJSONPath(cosmosentryupdated, "$.cursor.firstBatch[0].status.subStatus");
		reusableComponents.assertEqualValue("Sub Status after AVI Initiated",wfStatusupdated,"Failed",test);
		reusableComponents.assertEqualValue("sub status",subStatusupdated,"AVIFailed",test);
		reusableComponents.assertEqualValue("ErrorCode",JsonUtils.getValueFromJSONusingJSONPath(respAVICallback.asString(), "$.result.code"),"3006",test);
		reusableComponents.assertEqualValue("Error Message",JsonUtils.getValueFromJSONusingJSONPath(respAVICallback.asString(), "$.result.message"),"Successfully updated AVI workflow status values for the video "+ videoID,test);
		reusableComponents.assertEqualValue("Status",JsonUtils.getValueFromJSONusingJSONPath(respAVICallback.asString(), "$.result.status"),"Success",test);
		
	}
	
	
	@Test(dataProvider = "uploadgcp", groups = {"Regression" })
	public void AVICallBack_SuccessCancelled(String fileName) throws Exception {
		test = report.startTest(new Object(){}.getClass().getEnclosingMethod().getName());
		String assetid= stringUtils.generateAssetid();
		String accessToken = auth.GetAccessToken("cms");
		String reqBody = JsonUtils.jsonFileReader(fileName);
		reqBody= reqBody.replace("{ASSETID}", assetid);
		reqBody=reqBody.replace("{GCPURL}", globalProp.getProperty("gcpUrl"));
		reqBody=reqBody.replace("{VIDEONAME}", "Automation Test Video");
		reqBody=reqBody.replace("{VIDEOTYPE}", "Video");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("Authorization", "Bearer " + accessToken);
		Response resp = adInitiation.PostUploadGcp(reqBody,headers);
		reusableComponents.assertEqualValue("HTTP Status Code",Integer.toString(resp.getStatusCode()), Integer.toString(201),test);
		String code= JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.code");
		String status = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.status");
		String message = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.message");
		String additionalInfoMessage = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.additionalInfo[0].message");
		String additionalInfoTitle = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.additionalInfo[0].title");
		String videoID = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.cmsUploadResponse.clcVideo.videoRefId");
		String cosmosentry= DBUtils.getvaluefromDB("clcvideos",videoID);
		String wfStatus = JsonUtils.getValueFromJSONusingJSONPath(cosmosentry, "$.cursor.firstBatch[0].status.wfStatus");
		String subStatus= JsonUtils.getValueFromJSONusingJSONPath(cosmosentry, "$.cursor.firstBatch[0].status.subStatus");
		String isActive = JsonUtils.getValueFromJSONusingJSONPath(cosmosentry, "$.cursor.firstBatch[0].isActive");
		reusableComponents.assertEqualValue("ResultCode",code,"2006",test);
		reusableComponents.assertEqualValue("ResultStatus",status,"Success",test);
		reusableComponents.assertEqualValue("ResultMessage",message,"Video " + assetid + "is uploaded successfully.",test);
		reusableComponents.assertEqualValue("additionalInfoMessage",additionalInfoMessage,"Ad publishing submitted successfully for the video "+ assetid+".",test);
		reusableComponents.assertEqualValue("additionalInfoTitle",additionalInfoTitle,"/cms/initiateadpubprocess",test);
		reusableComponents.assertEqualValue("WFStatus",wfStatus,"Submitted",test);
		reusableComponents.assertEqualValue("SubStatus",subStatus,"YetToStart",test);
		reusableComponents.assertEqualValue("IsActiveFlag",isActive,"true",test);
		Thread.sleep(10000);
		String cosmosentrynew= DBUtils.getvaluefromDB("clcvideos",videoID);
		String wfStatusnew = JsonUtils.getValueFromJSONusingJSONPath(cosmosentrynew, "$.cursor.firstBatch[0].status.wfStatus");
		String subStatusnew= JsonUtils.getValueFromJSONusingJSONPath(cosmosentrynew, "$.cursor.firstBatch[0].status.subStatus");
		reusableComponents.assertEqualValue("Sub Status after AVI Initiated",wfStatusnew,"InProgress",test);
		reusableComponents.assertEqualValue("sub status",subStatusnew,"AVIInitiated",test);
		resp = adInitiation.PostUploadGcp(reqBody,headers);
		String token = auth.generateToken(videoID);
		Hashtable<String, String> headers1 = new Hashtable<String, String>();
		headers1.put("Content-Type", globalProp.getProperty("contentTypeAVI"));
		Response respAVICallback= clcAVIService.AVICallback(videoID, "SampleMessage","Processed", token,headers1);
		reusableComponents.assertEqualValue("HTTP Status Code",Integer.toString(respAVICallback.getStatusCode()), Integer.toString(201),test);
		String cosmosentryupdated= DBUtils.getvaluefromDB("clcvideos",videoID);
		String wfStatusupdated = JsonUtils.getValueFromJSONusingJSONPath(cosmosentryupdated, "$.cursor.firstBatch[0].status.wfStatus");
		String subStatusupdated= JsonUtils.getValueFromJSONusingJSONPath(cosmosentryupdated, "$.cursor.firstBatch[0].status.subStatus");
		reusableComponents.assertEqualValue("Sub Status after AVI Initiated",wfStatusupdated,"Cancelled",test);
		reusableComponents.assertEqualValue("sub status",subStatusupdated,"AVICancelled",test);
		reusableComponents.assertEqualValue("ErrorCode",JsonUtils.getValueFromJSONusingJSONPath(respAVICallback.asString(), "$.result.code"),"3006",test);
		reusableComponents.assertEqualValue("Error Message",JsonUtils.getValueFromJSONusingJSONPath(respAVICallback.asString(), "$.result.message"),"Successfully updated AVI workflow status values for the video "+ videoID,test);
		reusableComponents.assertEqualValue("Status",JsonUtils.getValueFromJSONusingJSONPath(respAVICallback.asString(), "$.result.status"),"Success",test);
	}
	
	@Test(dataProvider = "uploadgcp", groups = {"Regression" })
	public void AVICallBack_WithAlreadyUpdatedVideoRefId(String fileName) throws Exception {
		test = report.startTest(new Object(){}.getClass().getEnclosingMethod().getName());
		String assetid= stringUtils.generateAssetid();
		String accessToken = auth.GetAccessToken("cms");
		String reqBody = JsonUtils.jsonFileReader(fileName);
		reqBody= reqBody.replace("{ASSETID}", assetid);
		reqBody=reqBody.replace("{GCPURL}", globalProp.getProperty("gcpUrl"));
		reqBody=reqBody.replace("{VIDEONAME}", "Automation Test Video");
		reqBody=reqBody.replace("{VIDEOTYPE}", "Video");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("Authorization", "Bearer " + accessToken);
		Response resp = adInitiation.PostUploadGcp(reqBody,headers);
		reusableComponents.assertEqualValue("HTTP Status Code",Integer.toString(resp.getStatusCode()), Integer.toString(201),test);
		String code= JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.code");
		String status = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.status");
		String message = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.message");
		String additionalInfoMessage = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.additionalInfo[0].message");
		String additionalInfoTitle = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.additionalInfo[0].title");
		String videoID = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.cmsUploadResponse.clcVideo.videoRefId");
		String cosmosentry= DBUtils.getvaluefromDB("clcvideos",videoID);
		String wfStatus = JsonUtils.getValueFromJSONusingJSONPath(cosmosentry, "$.cursor.firstBatch[0].status.wfStatus");
		String subStatus= JsonUtils.getValueFromJSONusingJSONPath(cosmosentry, "$.cursor.firstBatch[0].status.subStatus");
		String isActive = JsonUtils.getValueFromJSONusingJSONPath(cosmosentry, "$.cursor.firstBatch[0].isActive");
		reusableComponents.assertEqualValue("ResultCode",code,"2006",test);
		reusableComponents.assertEqualValue("ResultStatus",status,"Success",test);
		reusableComponents.assertEqualValue("ResultMessage",message,"Video " + assetid + "is uploaded successfully.",test);
		reusableComponents.assertEqualValue("additionalInfoMessage",additionalInfoMessage,"Ad publishing submitted successfully for the video "+ assetid+".",test);
		reusableComponents.assertEqualValue("additionalInfoTitle",additionalInfoTitle,"/cms/initiateadpubprocess",test);
		reusableComponents.assertEqualValue("WFStatus",wfStatus,"Submitted",test);
		reusableComponents.assertEqualValue("SubStatus",subStatus,"YetToStart",test);
		reusableComponents.assertEqualValue("IsActiveFlag",isActive,"true",test);
		Thread.sleep(13000);
		String cosmosentrynew= DBUtils.getvaluefromDB("clcvideos",videoID);
		String wfStatusnew = JsonUtils.getValueFromJSONusingJSONPath(cosmosentrynew, "$.cursor.firstBatch[0].status.wfStatus");
		String subStatusnew= JsonUtils.getValueFromJSONusingJSONPath(cosmosentrynew, "$.cursor.firstBatch[0].status.subStatus");
		reusableComponents.assertEqualValue("Sub Status after AVI Initiated",wfStatusnew,"InProgress",test);
		reusableComponents.assertEqualValue("sub status",subStatusnew,"AVIInitiated",test);
		String token = auth.generateToken(videoID);
		Hashtable<String, String> headers1 = new Hashtable<String, String>();
		headers1.put("Content-Type", globalProp.getProperty("contentTypeAVI"));
		Response respAVICallback= clcAVIService.AVICallback(videoID, "SampleMessage","Processed", token,headers1);
		Thread.sleep(5000);
		reusableComponents.assertEqualValue("HTTP Status Code",Integer.toString(respAVICallback.getStatusCode()), Integer.toString(201),test);
		String cosmosentryupdated= DBUtils.getvaluefromDB("clcvideos",videoID);
		String wfStatusupdated = JsonUtils.getValueFromJSONusingJSONPath(cosmosentryupdated, "$.cursor.firstBatch[0].status.wfStatus");
		String subStatusupdated= JsonUtils.getValueFromJSONusingJSONPath(cosmosentryupdated, "$.cursor.firstBatch[0].status.subStatus");
		reusableComponents.assertEqualValue("Sub Status after AVI Initiated",wfStatusupdated,"InProgress",test);
		reusableComponents.assertEqualValue("sub status",subStatusupdated,"Base64Initiated",test);
		reusableComponents.assertEqualValue("ErrorCode",JsonUtils.getValueFromJSONusingJSONPath(respAVICallback.asString(), "$.result.code"),"3006",test);
		reusableComponents.assertEqualValue("Error Message",JsonUtils.getValueFromJSONusingJSONPath(respAVICallback.asString(), "$.result.message"),"Successfully updated AVI workflow status values for the video "+ videoID,test);
		reusableComponents.assertEqualValue("Status",JsonUtils.getValueFromJSONusingJSONPath(respAVICallback.asString(), "$.result.status"),"Success",test);
		respAVICallback= clcAVIService.AVICallback(videoID, "SampleMessage","Processed", token,headers1);
		reusableComponents.assertEqualValue("HTTP Status Code",Integer.toString(respAVICallback.getStatusCode()), Integer.toString(400),test);
		reusableComponents.assertEqualValue("ErrorCode",JsonUtils.getValueFromJSONusingJSONPath(respAVICallback.asString(), "$.result.code"),"3021",test);
		reusableComponents.assertEqualValue("Error Message",JsonUtils.getValueFromJSONusingJSONPath(respAVICallback.asString(), "$.result.message"),"Failed to retrieve video data from AVI for the video "+ videoID,test);
		reusableComponents.assertEqualValue("Status",JsonUtils.getValueFromJSONusingJSONPath(respAVICallback.asString(), "$.result.status"),"Failed",test);
		}
	
	@Test(dataProvider = "uploadgcp", groups = {"Regression" })
	public void AVICallBack_WithIncorrectVideoRefId(String fileName) throws Exception {
		test = report.startTest(new Object(){}.getClass().getEnclosingMethod().getName());
		String assetid= stringUtils.generateAssetid();
		String accessToken = auth.GetAccessToken("cms");
		String reqBody = JsonUtils.jsonFileReader(fileName);
		reqBody= reqBody.replace("{ASSETID}", assetid);
		reqBody=reqBody.replace("{GCPURL}", globalProp.getProperty("gcpUrl"));
		reqBody=reqBody.replace("{VIDEONAME}", "Automation Test Video");
		reqBody=reqBody.replace("{VIDEOTYPE}", "Video");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("Authorization", "Bearer " + accessToken);
		Response resp = adInitiation.PostUploadGcp(reqBody,headers);
		reusableComponents.assertEqualValue("HTTP Status Code",Integer.toString(resp.getStatusCode()), Integer.toString(201),test);
		String code= JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.code");
		String status = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.status");
		String message = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.message");
		String additionalInfoMessage = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.additionalInfo[0].message");
		String additionalInfoTitle = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.additionalInfo[0].title");
		String videoID = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.cmsUploadResponse.clcVideo.videoRefId");
		String cosmosentry= DBUtils.getvaluefromDB("clcvideos",videoID);
		String wfStatus = JsonUtils.getValueFromJSONusingJSONPath(cosmosentry, "$.cursor.firstBatch[0].status.wfStatus");
		String subStatus= JsonUtils.getValueFromJSONusingJSONPath(cosmosentry, "$.cursor.firstBatch[0].status.subStatus");
		String isActive = JsonUtils.getValueFromJSONusingJSONPath(cosmosentry, "$.cursor.firstBatch[0].isActive");
		reusableComponents.assertEqualValue("ResultCode",code,"2006",test);
		reusableComponents.assertEqualValue("ResultStatus",status,"Success",test);
		reusableComponents.assertEqualValue("ResultMessage",message,"Video " + assetid + "is uploaded successfully.",test);
		reusableComponents.assertEqualValue("additionalInfoMessage",additionalInfoMessage,"Ad publishing submitted successfully for the video "+ assetid+".",test);
		reusableComponents.assertEqualValue("additionalInfoTitle",additionalInfoTitle,"/cms/initiateadpubprocess",test);
		reusableComponents.assertEqualValue("WFStatus",wfStatus,"Submitted",test);
		reusableComponents.assertEqualValue("SubStatus",subStatus,"YetToStart",test);
		reusableComponents.assertEqualValue("IsActiveFlag",isActive,"true",test);
		Thread.sleep(10000);
		String cosmosentrynew= DBUtils.getvaluefromDB("clcvideos",videoID);
		String wfStatusnew = JsonUtils.getValueFromJSONusingJSONPath(cosmosentrynew, "$.cursor.firstBatch[0].status.wfStatus");
		String subStatusnew= JsonUtils.getValueFromJSONusingJSONPath(cosmosentrynew, "$.cursor.firstBatch[0].status.subStatus");
		reusableComponents.assertEqualValue("Sub Status after AVI Initiated",wfStatusnew,"InProgress",test);
		reusableComponents.assertEqualValue("sub status",subStatusnew,"AVIInitiated",test);
		String videoIDNew = videoID.substring(0,8);
		String token = auth.generateToken(videoIDNew);
		Hashtable<String, String> headers1 = new Hashtable<String, String>();
		headers1.put("Content-Type", globalProp.getProperty("contentTypeAVI"));
		Response respAVICallback= clcAVIService.AVICallback(videoIDNew, "SampleMessage","Processed", token,headers1);
		reusableComponents.assertEqualValue("HTTP Status Code",Integer.toString(respAVICallback.getStatusCode()), Integer.toString(400),test);
		reusableComponents.assertEqualValue("ErrorCode",JsonUtils.getValueFromJSONusingJSONPath(respAVICallback.asString(), "$.result.code"),"3021",test);
		reusableComponents.assertEqualValue("Error Message",JsonUtils.getValueFromJSONusingJSONPath(respAVICallback.asString(), "$.result.message"),"Failed to retrieve video data from AVI for the video "+ videoIDNew,test);
		reusableComponents.assertEqualValue("Status",JsonUtils.getValueFromJSONusingJSONPath(respAVICallback.asString(), "$.result.status"),"Failed",test);
		}
	
	@Test(dataProvider = "avinotificationeventhub", groups = {"Regression" })
	public void AviEventInvalidMsgType(String fileName) throws Exception {
		test = report.startTest(new Object(){}.getClass().getEnclosingMethod().getName());
		String reqBody = JsonUtils.jsonFileReader(fileName);
		String msgId = "automationtestmsg" + stringUtils.getRandomString();
		reqBody= reqBody.replace("{msgId}", msgId);
		reqBody=reqBody.replace("{msgType}", "Notification");
		reqBody=reqBody.replace("{retryCount}", "0");
		reqBody=reqBody.replace("{assetId}", "1-1-770777");
		reqBody=reqBody.replace("{videoName}", "Elephant Dreams");
		reqBody=reqBody.replace("{clcVideoId}", "001");
		reqBody=reqBody.replace("{cmsUrl}", "https://dummyvideos.com/2023/09/13/f63fb394-247b-4119-9db9-0c67a4fe467b.mp4");

		AzureUtils.KafkaToEventHubSender(globalProp.getProperty("aviEventHubName"),reqBody );
		Thread.sleep(3000);
		String cosmosentryupdated= DBUtils.getvaluefromDBusingProperty("asyncmessagelogs","msgId",msgId);
		String fetchedMsgId = JsonUtils.getValueFromJSONusingJSONPath(cosmosentryupdated, "$.cursor.firstBatch[0].msgId");
		String fetchedMsgType = JsonUtils.getValueFromJSONusingJSONPath(cosmosentryupdated, "$.cursor.firstBatch[0].msgType");
		String msgProcessStatus = JsonUtils.getValueFromJSONusingJSONPath(cosmosentryupdated, "$.cursor.firstBatch[0].msgProcessStatus");
		String rejectedReason = JsonUtils.getValueFromJSONusingJSONPath(cosmosentryupdated, "$.cursor.firstBatch[0].rejectedReason");
		reusableComponents.assertEqualValue("Msg Id",fetchedMsgId,msgId,test);
		reusableComponents.assertEqualValue("Msg Type",fetchedMsgType,"AviNotification",test);
		reusableComponents.assertEqualValue("Msg Process Status",msgProcessStatus,"Rejected",test);
		reusableComponents.assertEqualValue("Rejected Reason",rejectedReason,"Payload msgType is null or empty or not equal to AVINotification.",test);

	}
	
	@Test(dataProvider = "avinotificationeventhub", groups = {"Regression" })
	public void AviEventInvalidAssetId(String fileName) throws Exception {
		test = report.startTest(new Object(){}.getClass().getEnclosingMethod().getName());
		String reqBody = JsonUtils.jsonFileReader(fileName);
		String msgId = "automationtestmsg" + stringUtils.getRandomString();
		reqBody= reqBody.replace("{msgId}", msgId);
		reqBody=reqBody.replace("{msgType}", "AviNotification");
		reqBody=reqBody.replace("{retryCount}", "0");
		reqBody=reqBody.replace("{assetId}", "1-1-771");
		reqBody=reqBody.replace("{videoName}", "Elephant Dreams");
		reqBody=reqBody.replace("{clcVideoId}", "001");
		reqBody=reqBody.replace("{cmsUrl}", globalProp.getProperty("cmsUrl"));

		AzureUtils.KafkaToEventHubSender(globalProp.getProperty("aviEventHubName"),reqBody );
		Thread.sleep(3000);
		String cosmosentryupdated= DBUtils.getvaluefromDBusingProperty("asyncmessagelogs","msgId",msgId);
		String fetchedMsgType = JsonUtils.getValueFromJSONusingJSONPath(cosmosentryupdated, "$.cursor.firstBatch[0].msgType");
		String msgProcessStatus = JsonUtils.getValueFromJSONusingJSONPath(cosmosentryupdated, "$.cursor.firstBatch[0].msgProcessStatus");
		String rejectedReason = JsonUtils.getValueFromJSONusingJSONPath(cosmosentryupdated, "$.cursor.firstBatch[0].rejectedReason");
		reusableComponents.assertEqualValue("Msg Type",fetchedMsgType,"AviNotification",test);
		reusableComponents.assertEqualValue("Msg Process Status",msgProcessStatus,"Rejected",test);
		reusableComponents.assertEqualValue("Rejected Reason",rejectedReason,"Error while fetching clcVideo for clcVideoId: 001 and assetId: 1-1-771.",test);

	}
	
	@Test(dataProvider = "avinotificationeventhub", groups = {"Regression" })
	public void AviEventInvalidClcVideoId(String fileName) throws Exception {
		test = report.startTest(new Object(){}.getClass().getEnclosingMethod().getName());
		String reqBody = JsonUtils.jsonFileReader(fileName);
		String msgId = "automationtestmsg" + stringUtils.getRandomString();
		reqBody= reqBody.replace("{msgId}", msgId);
		reqBody=reqBody.replace("{msgType}", "AviNotification");
		reqBody=reqBody.replace("{retryCount}", "0");
		reqBody=reqBody.replace("{assetId}", "1-1-777777");
		reqBody=reqBody.replace("{videoName}", "Elephant Dreams1");
		reqBody=reqBody.replace("clcVideoId", "001");
		reqBody=reqBody.replace("{cmsUrl}", globalProp.getProperty("cmsUrl"));

		AzureUtils.KafkaToEventHubSender(globalProp.getProperty("aviEventHubName"),reqBody );
		Thread.sleep(2000);
		String cosmosentryupdated= DBUtils.getvaluefromDBusingProperty("asyncmessagelogs","rejectedPayload.videoInfo.videoName","Elephant Dreams1");
		String fetchedMsgType = JsonUtils.getValueFromJSONusingJSONPath(cosmosentryupdated, "$.cursor.firstBatch[0].msgType");
		String msgProcessStatus = JsonUtils.getValueFromJSONusingJSONPath(cosmosentryupdated, "$.cursor.firstBatch[0].msgProcessStatus");
		String rejectedReason = JsonUtils.getValueFromJSONusingJSONPath(cosmosentryupdated, "$.cursor.firstBatch[0].rejectedReason");
		reusableComponents.assertEqualValue("Msg Type",fetchedMsgType,"AviNotification",test);
		reusableComponents.assertEqualValue("Msg Process Status",msgProcessStatus,"Rejected",test);
		reusableComponents.assertEqualValue("Rejected Reason",rejectedReason,"Payload clcVideoId is null or empty.",test);

	}
	
	@Test(dataProvider = "uploadgcp", groups = {"Regression" })
	public void AVICallBackFailedAsynMessageLog(String fileName) throws Exception {
		test = report.startTest(new Object(){}.getClass().getEnclosingMethod().getName());
		String assetid= stringUtils.generateAssetid();
		String accessToken = auth.GetAccessToken("cms");
		String reqBody = JsonUtils.jsonFileReader(fileName);
		reqBody= reqBody.replace("{ASSETID}", assetid);
		reqBody=reqBody.replace("{GCPURL}", globalProp.getProperty("gcpUrl"));
		reqBody=reqBody.replace("{VIDEONAME}", "Automation Test Video");
		reqBody=reqBody.replace("{VIDEOTYPE}", "Video");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("Authorization", "Bearer " + accessToken);
		Response resp = adInitiation.PostUploadGcp(reqBody,headers);
		reusableComponents.assertEqualValue("HTTP Status Code",Integer.toString(resp.getStatusCode()), Integer.toString(201),test);

		String videoID = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.cmsUploadResponse.clcVideo.videoRefId");
		Thread.sleep(5000);

		String token = auth.generateToken(videoID);
		Hashtable<String, String> headers1 = new Hashtable<String, String>();
		headers1.put("Content-Type", globalProp.getProperty("contentTypeAVI"));
		String msgId = "automationtestmsg" + stringUtils.getRandomString();
		clcAVIService.AVICallback(videoID, "111111","Failed", token,headers1);
		Thread.sleep(2000);
		String cosmosentryupdated= DBUtils.getvaluefromDBusingProperty("asyncmessagelogs","msgId","111111");
		String fetchedMsgId = JsonUtils.getValueFromJSONusingJSONPath(cosmosentryupdated, "$.cursor.firstBatch[0].msgId");
		String fetchedMsgType = JsonUtils.getValueFromJSONusingJSONPath(cosmosentryupdated, "$.cursor.firstBatch[0].msgType");
		String msgProcessStatus = JsonUtils.getValueFromJSONusingJSONPath(cosmosentryupdated, "$.cursor.firstBatch[0].msgProcessStatus");
		String subStatus = JsonUtils.getValueFromJSONusingJSONPath(cosmosentryupdated, "$.cursor.firstBatch[0].cmsNotification.status.subStatus");
		reusableComponents.assertEqualValue("Msg Id",fetchedMsgId,"111111",test);
		reusableComponents.assertEqualValue("Msg Type",fetchedMsgType,"CmsNotification",test);
		reusableComponents.assertEqualValue("Msg Process Status",msgProcessStatus,"Read",test);
		reusableComponents.assertEqualValue("Rejected Reason",subStatus,"AVIFailed",test);
		
	}
	
	@DataProvider (name = "uploads3")
	public Object[][] getSingle1DataJSONSource() {
		return new Object[][] {
			{ "PayLoad/uploads3.json"}
		};
	}
	
	@DataProvider (name = "uploadgcp")
	public Object[][] getSingle3DataJSONSource() {
		return new Object[][] {
			{ "PayLoad/uploadgcp.json"}
		};
	}
	
	@DataProvider (name = "avinotificationeventhub")
	public Object[][] getSingle2DataJSONSource() {
		return new Object[][] {
			{ "PayLoad/avinotificationeventhub.json"}
		};
	}
}
