package com.OTTPlatform.ModuleName;

import java.util.Hashtable;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import BusinessComponents.AdsDummyAPIs;
import BusinessComponents.Authorization;
import BusinessComponents.CLCCMSADInitiation;
import BusinessComponents.CLC_AVIService;
import baseTestPackage.BaseTest_TestNG;
import io.restassured.response.Response;
import reusableLibrary.AzureUtils;
import reusableLibrary.DBUtils;
import reusableLibrary.JsonUtils;
import reusableLibrary.ResuableComponents;
import reusableLibrary.StringUtils;

public class CLC_BingTests extends BaseTest_TestNG{
	
	AdsDummyAPIs ads = new AdsDummyAPIs();
	ResuableComponents reusableComponents= new ResuableComponents();
	StringUtils stringUtils = new StringUtils();
	Authorization auth= new Authorization();
	CLCCMSADInitiation adInitiation = new CLCCMSADInitiation();
	CLC_AVIService clcAVIService = new CLC_AVIService();
    DBUtils dbUtils = new DBUtils();
	
	@Test(dataProvider = "uploadgcp", groups = {"Regression" })
	public void AVI_KeyFramesSuccess(String fileName) throws Exception {
		test = report.startTest(new Object(){}.getClass().getEnclosingMethod().getName());
		String assetid= stringUtils.generateAssetid();
		String accessToken = auth.GetAccessToken("cms");
		String reqBody = JsonUtils.jsonFileReader(fileName);
		reqBody= reqBody.replace("{ASSETID}", assetid);
		reqBody=reqBody.replace("{GCPURL}", globalProp.getProperty("secondGcpUrl"));
		reqBody=reqBody.replace("{VIDEONAME}", "Automation Test Video");
		reqBody=reqBody.replace("{VIDEOTYPE}", "Video");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("Authorization", "Bearer " + accessToken);
		Response resp = adInitiation.PostUploadGcp(reqBody,headers);
		reusableComponents.assertEqualValue("HTTP Status Code",Integer.toString(resp.getStatusCode()), Integer.toString(201),test);
		String code= JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.code");
		String status = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.status");
		String message = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.message");
		String videoID = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.cmsUploadResponse.clcVideo.videoRefId");
		reusableComponents.assertEqualValue("ResultCode",code,"2006",test);
		reusableComponents.assertEqualValue("ResultStatus",status,"Success",test);
		reusableComponents.assertEqualValue("ResultMessage",message,"Video " + assetid + "is uploaded successfully.",test);
		resp = adInitiation.GetStatus(headers,assetid);
		reusableComponents.assertEqualValue("HTTP Status Code",Integer.toString(resp.getStatusCode()), Integer.toString(200),test);
		String videoSubStatus = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.data.videoSubStatus");
		while(!videoSubStatus.equals("BingAdInitiated"))
		{
			resp = adInitiation.GetStatus(headers,assetid);
			reusableComponents.assertEqualValue("HTTP Status Code",Integer.toString(resp.getStatusCode()), Integer.toString(200),test);
			videoSubStatus = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.data.videoSubStatus");
		}
		dbUtils.checkBlobExists("aviMediaServiceStorage","keyframes",videoID+"/"+assetid+".zip",test);
	}
	
	@Test(dataProvider = "bingnotificationeventhub", groups = {"Regression" })
	public void BingEventInvalidMsgType(String fileName) throws Exception {
		test = report.startTest(new Object(){}.getClass().getEnclosingMethod().getName());
		String reqBody = JsonUtils.jsonFileReader(fileName);
		String msgId = "automationtestmsg" + stringUtils.getRandomString();
		reqBody= reqBody.replace("{msgId}", msgId);
		reqBody=reqBody.replace("{msgType}", "Notification");
		reqBody=reqBody.replace("{retryCount}", "0");
		reqBody=reqBody.replace("{assetId}", "1-1-770777");
		reqBody=reqBody.replace("{videoName}", "Elephant Dreams");
		reqBody=reqBody.replace("{clcVideoId}", "001");
		reqBody=reqBody.replace("{cmsUrl}", "https://dummyvideos.com/2023/09/13/f63fb394-247b-4119-9db9-0c67a4fe467b.mp4");

		AzureUtils.KafkaToEventHubSender(globalProp.getProperty("bingEventHubName"),reqBody.toString());
		Thread.sleep(2000);
		String cosmosentryupdated= DBUtils.getvaluefromDBusingProperty("asyncmessagelogs","msgId",msgId);
		String fetchedMsgId = JsonUtils.getValueFromJSONusingJSONPath(cosmosentryupdated, "$.cursor.firstBatch[0].msgId");
		String fetchedMsgType = JsonUtils.getValueFromJSONusingJSONPath(cosmosentryupdated, "$.cursor.firstBatch[0].msgType");
		String msgProcessStatus = JsonUtils.getValueFromJSONusingJSONPath(cosmosentryupdated, "$.cursor.firstBatch[0].msgProcessStatus");
		String rejectedReason = JsonUtils.getValueFromJSONusingJSONPath(cosmosentryupdated, "$.cursor.firstBatch[0].rejectedReason");
		reusableComponents.assertEqualValue("Msg Id",fetchedMsgId,msgId,test);
		reusableComponents.assertEqualValue("Msg Type",fetchedMsgType,"BingNotification",test);
		reusableComponents.assertEqualValue("Msg Process Status",msgProcessStatus,"Rejected",test);
		reusableComponents.assertEqualValue("Rejected Reason",rejectedReason,"Payload msgType is null or empty or not equal to BingNotification.",test);

	}
	
	@Test(dataProvider = "bingnotificationeventhub", groups = {"Regression" })
	public void BingEventInvalidAssetId(String fileName) throws Exception {
		test = report.startTest(new Object(){}.getClass().getEnclosingMethod().getName());
		String reqBody = JsonUtils.jsonFileReader(fileName);
		String msgId = "automationtestmsg" + stringUtils.getRandomString();
		reqBody= reqBody.replace("{msgId}", msgId);
		reqBody=reqBody.replace("{msgType}", "BingNotification");
		reqBody=reqBody.replace("{retryCount}", "0");
		reqBody=reqBody.replace("{assetId}", "1-1-77");
		reqBody=reqBody.replace("{videoName}", "Elephant Dreams");
		reqBody=reqBody.replace("{clcVideoId}", "001");
		reqBody=reqBody.replace("{cmsUrl}", globalProp.getProperty("cmsUrl"));

		AzureUtils.KafkaToEventHubSender(globalProp.getProperty("bingEventHubName"),reqBody.toString());
		Thread.sleep(2000);
		String cosmosentryupdated= DBUtils.getvaluefromDBusingProperty("asyncmessagelogs","msgId",msgId);
		String fetchedMsgId = JsonUtils.getValueFromJSONusingJSONPath(cosmosentryupdated, "$.cursor.firstBatch[0].msgId");
		String fetchedMsgType = JsonUtils.getValueFromJSONusingJSONPath(cosmosentryupdated, "$.cursor.firstBatch[0].msgType");
		String msgProcessStatus = JsonUtils.getValueFromJSONusingJSONPath(cosmosentryupdated, "$.cursor.firstBatch[0].msgProcessStatus");
		String rejectedReason = JsonUtils.getValueFromJSONusingJSONPath(cosmosentryupdated, "$.cursor.firstBatch[0].rejectedReason");
		reusableComponents.assertEqualValue("Msg Id",fetchedMsgId,msgId,test);
		reusableComponents.assertEqualValue("Msg Type",fetchedMsgType,"BingNotification",test);
		reusableComponents.assertEqualValue("Msg Process Status",msgProcessStatus,"Rejected",test);
		reusableComponents.assertEqualValue("Rejected Reason",rejectedReason,"Payload clcVideoId is null or empty.",test);

	}
	
	@Test(dataProvider = "bingnotificationeventhub", groups = {"Regression" })
	public void BingEventInvalidClcVideoId(String fileName) throws Exception {
		test = report.startTest(new Object(){}.getClass().getEnclosingMethod().getName());
		String reqBody = JsonUtils.jsonFileReader(fileName);
		String msgId = "automationtestmsg" + stringUtils.getRandomString();
		reqBody= reqBody.replace("{msgId}", msgId);
		reqBody=reqBody.replace("{msgType}", "BingNotification");
		reqBody=reqBody.replace("{retryCount}", "0");
		reqBody=reqBody.replace("{assetId}", "1-1-777777");
		reqBody=reqBody.replace("{videoName}", "Elephant Dreams");
		reqBody=reqBody.replace("clcVideoId", "001");
		reqBody=reqBody.replace("{cmsUrl}", globalProp.getProperty("cmsUrl"));

		AzureUtils.KafkaToEventHubSender(globalProp.getProperty("bingEventHubName"),reqBody.toString());
		Thread.sleep(2000);
		String cosmosentryupdated= DBUtils.getvaluefromDBusingProperty("asyncmessagelogs","msgId",msgId);
		String fetchedMsgId = JsonUtils.getValueFromJSONusingJSONPath(cosmosentryupdated, "$.cursor.firstBatch[0].msgId");
		String fetchedMsgType = JsonUtils.getValueFromJSONusingJSONPath(cosmosentryupdated, "$.cursor.firstBatch[0].msgType");
		String msgProcessStatus = JsonUtils.getValueFromJSONusingJSONPath(cosmosentryupdated, "$.cursor.firstBatch[0].msgProcessStatus");
		String rejectedReason = JsonUtils.getValueFromJSONusingJSONPath(cosmosentryupdated, "$.cursor.firstBatch[0].rejectedReason");
		reusableComponents.assertEqualValue("Msg Id",fetchedMsgId,msgId,test);
		reusableComponents.assertEqualValue("Msg Type",fetchedMsgType,"BingNotification",test);
		reusableComponents.assertEqualValue("Msg Process Status",msgProcessStatus,"Rejected",test);
		reusableComponents.assertEqualValue("Rejected Reason",rejectedReason,"Payload clcVideoId is null or empty.",test);

	}
	
	@DataProvider (name = "uploads3")
	public Object[][] getSingle1DataJSONSource() {
		return new Object[][] {
			{ "PayLoad/uploads3.json"}
		};
	}
	@DataProvider (name = "uploadgcp")
	public Object[][] getSingle3DataJSONSource() {
		return new Object[][] {
			{ "PayLoad/uploadgcp.json"}
		};
	}
	
	@DataProvider (name = "bingnotificationeventhub")
	public Object[][] getSingle2DataJSONSource() {
		return new Object[][] {
			{ "PayLoad/bingnotificationeventhub.json"}
		};
	}
}
