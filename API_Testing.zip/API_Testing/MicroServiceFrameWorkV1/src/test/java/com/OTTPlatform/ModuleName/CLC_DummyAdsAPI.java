package com.OTTPlatform.ModuleName;

import java.util.Hashtable;

import org.testng.Assert;
import org.testng.annotations.Test;

import BusinessComponents.AdsDummyAPIs;
import baseTestPackage.BaseTest_TestNG;
import io.restassured.response.Response;
import reusableLibrary.JsonUtils;
import reusableLibrary.ResuableComponents;

public class CLC_DummyAdsAPI extends BaseTest_TestNG{
	
	AdsDummyAPIs ads = new AdsDummyAPIs();
	ResuableComponents resuableComponents= new ResuableComponents();

	@Test
	public void getAdStack() throws Exception {
		test = report.startTest(new Object(){}.getClass().getEnclosingMethod().getName());
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("Authorization", "Bearer " +globalProp.getProperty("adsAuthorisation"));
		Response resp = ads.GetAdStack("c68f17bb-2587-4abc-a356-c3f2fcb42c77",headers);
		resuableComponents.assertEqualValue("HTTP Status Code",Integer.toString(resp.getStatusCode()), Integer.toString(200),test);
		String timeStamps= JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.clcVideo.timestamps");
		resuableComponents.assertEqualValue("TimeStamps","[300,600]", timeStamps,test);
	}
	
	@Test
	public void getAdStackwithoutAuthorisation() throws Exception {
		test = report.startTest(new Object(){}.getClass().getEnclosingMethod().getName());
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("Authorization", "");
		Response resp = ads.GetAdStack("c68f17bb-2587-4abc-a356-c3f2fcb42c77",headers);
		resuableComponents.assertEqualValue("HTTP Status Code",Integer.toString(resp.getStatusCode()), Integer.toString(401),test);
		String errorMessage= JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.message");
		resuableComponents.assertEqualValue("Error Message","Authentication failed", errorMessage,test);
	}

	@Test
	public void getAdStackwithincorrectAssetId() throws Exception {
		test = report.startTest(new Object(){}.getClass().getEnclosingMethod().getName());
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("Authorization", "Bearer " +globalProp.getProperty("adsAuthorisation"));
		Response resp = ads.GetAdStack("c",headers);
		resuableComponents.assertEqualValue("HTTP Status Code",Integer.toString(resp.getStatusCode()), Integer.toString(400),test);
		String errorMessage= JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.message");
		resuableComponents.assertEqualValue("Error Message","Input validation failed for assetId", errorMessage,test);
	}
	@Test()
	
	public void getAdShirt() throws Exception {
		test = report.startTest(new Object(){}.getClass().getEnclosingMethod().getName());
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("Authorization", "Bearer " +globalProp.getProperty("adsAuthorisation"));
		headers.put("assetId", "c68f17bb-2587-4abc-a356-c3f2fcb42c77");
		headers.put("timestamp", "600");
		Response resp = ads.GetAds(headers);
		resuableComponents.assertEqualValue("Status Code",Integer.toString(resp.getStatusCode()), Integer.toString(200),test);
		String category= JsonUtils.getJsonValueByKey(resp.asString(), "originalQuery");
		String name= JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.ad.value[0].offer.seller.name");
		resuableComponents.assertEqualValue("category",category,"tshirt",test);
		resuableComponents.assertEqualValue("Name",name, "H&M",test);
	}
	
	@Test
	
	public void getAdShoes() throws Exception {
		test = report.startTest(new Object(){}.getClass().getEnclosingMethod().getName());
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("Authorization", "Bearer " +globalProp.getProperty("adsAuthorisation"));
		headers.put("assetId", "c68f17bb-2587-4abc-a356-c3f2fcb42c77");
		headers.put("timestamp", "300");
		Response resp = ads.GetAds(headers);
		resuableComponents.assertEqualValue("HTTP Status Code",Integer.toString(resp.getStatusCode()), Integer.toString(200),test);
		String category= JsonUtils.getJsonValueByKey(resp.asString(), "originalQuery");
		String name= JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.ad.value[0].offer.seller.name");
		Assert.assertEquals(category,"shoes");
		Assert.assertEquals(name, "H&M");
	}
	
	@Test
	
	public void getAdsWithoutAssetID() throws Exception {
		test = report.startTest(new Object(){}.getClass().getEnclosingMethod().getName());
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("Authorization", "Bearer " +globalProp.getProperty("adsAuthorisation"));
		headers.put("timestamp", "300");
		Response resp = ads.GetAds(headers);
		resuableComponents.assertEqualValue("HTTP Status Code",Integer.toString(resp.getStatusCode()), Integer.toString(400),test);
		String errorMessage= JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.message");
		String errorCode= JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.code");
		resuableComponents.assertEqualValue("Error Message",errorMessage,"Input validation failed",test);
		resuableComponents.assertEqualValue("Error Code",errorCode, "5007",test);
	}
	
	@Test
	
	public void getAdsWithoutTimeStamp() throws Exception {
		test = report.startTest(new Object(){}.getClass().getEnclosingMethod().getName());
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("Authorization", "Bearer " +globalProp.getProperty("adsAuthorisation"));
		headers.put("assetId", "c68f17bb-2587-4abc-a356-c3f2fcb42c77");
		Response resp = ads.GetAds(headers);
		resuableComponents.assertEqualValue("HTTP Status Code",Integer.toString(resp.getStatusCode()), Integer.toString(400),test);
		String errorMessage= JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.message");
		String errorCode= JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.code");
		resuableComponents.assertEqualValue("Error Message",errorMessage,"Input validation failed",test);
		resuableComponents.assertEqualValue("Error Code",errorCode, "5007",test);
		
	}
	
	@Test
	
	public void getAdsWithoutAuthorisation() throws Exception {
		test = report.startTest(new Object(){}.getClass().getEnclosingMethod().getName());
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("timestamp", "300");
		headers.put("assetId", "c68f17bb-2587-4abc-a356-c3f2fcb42c77");
		Response resp = ads.GetAds(headers);
		resuableComponents.assertEqualValue("HTTP Status Code",Integer.toString(resp.getStatusCode()), Integer.toString(401),test);
		String errorMessage= JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.message");
		String errorCode= JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.code");
		resuableComponents.assertEqualValue("Error Message",errorMessage,"App authentication failed",test);
		resuableComponents.assertEqualValue("Error Message",errorCode, "5008",test);
	}
}
