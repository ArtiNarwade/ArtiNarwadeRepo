package com.OTTPlatform.ModuleName;

import java.util.Hashtable;
import java.util.Map;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import BusinessComponents.Authorization;
import BusinessComponents.CLCCMSADInitiation;
import baseTestPackage.BaseTest_TestNG;
import io.restassured.response.Response;
import reusableLibrary.AzureUtils;
import reusableLibrary.DBUtils;
import reusableLibrary.JsonUtils;
import reusableLibrary.ResuableComponents;
import reusableLibrary.StringUtils;

public class CMS_APITests extends BaseTest_TestNG{
	
	CLCCMSADInitiation adInitiation = new CLCCMSADInitiation();
	ResuableComponents reusableComponents= new ResuableComponents();
    StringUtils stringUtils = new StringUtils();
    Authorization auth = new Authorization();
    DBUtils dbUtils = new DBUtils();
	
	@Test(dataProvider = "CmsNotification", groups = {"Regression" })
	public void postvideotoAVIsuccess(String fileName) throws Exception 
	{   
		test = report.startTest(new Object(){}.getClass().getEnclosingMethod().getName());
		String accessToken = auth.GetAccessToken("cms");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("Authorization", "Bearer " + accessToken);
		String reqBody = JsonUtils.jsonFileReader(fileName);
		String assetId= stringUtils.generateAssetid();
		reqBody= reqBody.replace("{AssetID}", assetId);
		reqBody=reqBody.replace("{CMSURL}", globalProp.getProperty("cmsUrl"));
		reqBody=reqBody.replace("{VideoName}", "Automation Test Video");
		reqBody=reqBody.replace("{VideoType}", "Video");
		Response resp = adInitiation.POSTVideotoAVIResponse(reqBody,headers);
		reusableComponents.assertEqualValue("HTTP Status Code",Integer.toString(resp.getStatusCode()), Integer.toString(201),test);
		String code= JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.code");
		String status = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.status");
		String message = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.message");
		String videoID = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.clcVideo.videoRefId");
		String cosmosentry= DBUtils.getvaluefromDB("clcvideos",videoID);
		String wfStatus = JsonUtils.getValueFromJSONusingJSONPath(cosmosentry, "$.cursor.firstBatch[0].status.wfStatus");
		String subStatus= JsonUtils.getValueFromJSONusingJSONPath(cosmosentry, "$.cursor.firstBatch[0].status.subStatus");
		String isActive = JsonUtils.getValueFromJSONusingJSONPath(cosmosentry, "$.cursor.firstBatch[0].isActive");
		reusableComponents.assertEqualValue("ResultCode",code,"2000",test);
		reusableComponents.assertEqualValue("ResultStatus",status,"Success",test);
		reusableComponents.assertEqualValue("ResultMessage",message,"Ad publishing submitted successfully for the video "+ assetId+".",test);
		reusableComponents.assertEqualValue("WFStatus",wfStatus,"Submitted",test);
		reusableComponents.assertEqualValue("SubStatus",subStatus,"YetToStart",test);
		reusableComponents.assertEqualValue("IsActiveFlag",isActive,"true",test);
	}
	
	@Test(dataProvider = "CmsNotification", groups = {"Regression" })
	public void postvideotoAVIIncorrectCMSURL(String fileName) throws Exception 
	{
		test = report.startTest(new Object(){}.getClass().getEnclosingMethod().getName());
		String accessToken = auth.GetAccessToken("cms");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("Authorization", "Bearer " + accessToken);
		String reqBody = JsonUtils.jsonFileReader(fileName);
		String assetId= stringUtils.generateAssetid();
		reqBody= reqBody.replace("{AssetID}", assetId);
		reqBody=reqBody.replace("{CMSURL}", "https://www.google.com");
		reqBody=reqBody.replace("{VideoName}", "Automation Test Video");
		reqBody=reqBody.replace("{VideoType}", "Video");
		Response resp = adInitiation.POSTVideotoAVIResponse(reqBody,headers);
		reusableComponents.assertEqualValue("HTTP Status Code",Integer.toString(resp.getStatusCode()), Integer.toString(400),test);
		String code= JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.code");
		String status = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.status");
		String message = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.message");
		String errormessage = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.additionalInfo[0]");
		reusableComponents.assertEqualValue("ResultCode",code,"2002",test);
		reusableComponents.assertEqualValue("ResultStatus",status,"Failed",test);
		reusableComponents.assertEqualValue("ResultMessage",message,"Input validation failed for the Ad publish process.",test);
		reusableComponents.assertEqualValue("ResultErrorMessage",errormessage,"CmsUrl should be a whitelisted URL.",test);
        
	}
	
	
	@Test(dataProvider = "CmsNotificationError", groups = {"Regression" })
	public void postvideotoAVIIncorrectAssetId(String fileName) throws Exception 
	{
		test = report.startTest(new Object(){}.getClass().getEnclosingMethod().getName());
		String accessToken = auth.GetAccessToken("cms");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("Authorization", "Bearer " + accessToken);
		String reqBody = JsonUtils.jsonFileReader(fileName);
		reqBody=reqBody.replace("{CMSURL}", "https://google.co.in");
		Response resp = adInitiation.POSTVideotoAVIResponse(reqBody,headers);
		reusableComponents.assertEqualValue("HTTP Status Code",Integer.toString(resp.getStatusCode()), Integer.toString(400),test);
		String code= JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.code");
		String status = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.status");
		String message = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.message");
		String errormessage = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.additionalInfo[0]");
		reusableComponents.assertEqualValue("Result Code",code,"2002",test);
		reusableComponents.assertEqualValue("Result Status",status,"Failed",test);
		reusableComponents.assertEqualValue("Result Message",message,"Input validation failed for the Ad publish process.",test);
		reusableComponents.assertEqualValue("Result Error Message",errormessage,"AssetId should be in the format of '{1 digit int}-{1 digit int}-{1 to 25 non-white space charaters}', e.g. '0-0-101197'. AssetId should be a string.",test);
        
	}
	
	@Test(dataProvider = "CmsNotificationError", groups = {"Regression" })
	public void postvideotoAVIIncorrectAssetIdandIncorrectCMSURL(String fileName) throws Exception 
	{
		test = report.startTest(new Object(){}.getClass().getEnclosingMethod().getName());
		String accessToken = auth.GetAccessToken("cms");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("Authorization", "Bearer " + accessToken);
		String reqBody = JsonUtils.jsonFileReader(fileName);
		reqBody=reqBody.replace("{CMSURL}", "http://www.ms.com/");
		Response resp = adInitiation.POSTVideotoAVIResponse(reqBody,headers);
		reusableComponents.assertEqualValue("HTTP Status Code",Integer.toString(resp.getStatusCode()), Integer.toString(400),test);
		String code= JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.code");
		String status = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.status");
		String message = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.message");
		String errormessage1 = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.additionalInfo[0]");
		String errormessage2 = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.additionalInfo[1]");
		reusableComponents.assertEqualValue("Result Code",code,"2002",test);
		reusableComponents.assertEqualValue("Result Status",status,"Failed",test);
		reusableComponents.assertEqualValue("Result Message",message,"Input validation failed for the Ad publish process.",test);
		reusableComponents.assertEqualValue("Result Error Message 1",errormessage1,"AssetId should be in the format of '{1 digit int}-{1 digit int}-{1 to 25 non-white space charaters}', e.g. '0-0-101197'. AssetId should be a string.",test);
		reusableComponents.assertEqualValue("Result Error Message 2",errormessage2,"CmsUrl should be a valid URL.",test);
        
	}
	
	@Test(dataProvider = "CmsNotification", groups = {"Regression" })
	public void postvideotoAVImultipletimes(String fileName) throws Exception 
	{   
		test = report.startTest(new Object(){}.getClass().getEnclosingMethod().getName());
		String accessToken = auth.GetAccessToken("cms");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("Authorization", "Bearer " + accessToken);
		String reqBody = JsonUtils.jsonFileReader(fileName);
		String assetId= stringUtils.generateAssetid();
		reqBody= reqBody.replace("{AssetID}", assetId);
		reqBody=reqBody.replace("{CMSURL}", globalProp.getProperty("cmsUrl"));
		reqBody=reqBody.replace("{VideoName}", "Automation Test Video");
		reqBody=reqBody.replace("{VideoType}", "Video");
		Response resp = adInitiation.POSTVideotoAVIResponse(reqBody,headers);
		reusableComponents.assertEqualValue("HTTP Status Code",Integer.toString(resp.getStatusCode()), Integer.toString(201),test);
		String code= JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.code");
		String status = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.status");
		String message = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.message");
		String videoID = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.clcVideo.videoRefId");
		String cosmosentry= DBUtils.getvaluefromDB("clcvideos",videoID);
		String wfStatus = JsonUtils.getValueFromJSONusingJSONPath(cosmosentry, "$.cursor.firstBatch[0].status.wfStatus");
		String subStatus= JsonUtils.getValueFromJSONusingJSONPath(cosmosentry, "$.cursor.firstBatch[0].status.subStatus");
		String isActive = JsonUtils.getValueFromJSONusingJSONPath(cosmosentry, "$.cursor.firstBatch[0].isActive");
		reusableComponents.assertEqualValue("Result Code",code,"2000",test);
		reusableComponents.assertEqualValue("Result Status",status,"Success",test);
		reusableComponents.assertEqualValue("Result Message",message,"Ad publishing submitted successfully for the video "+ assetId+".",test);
		reusableComponents.assertEqualValue("WF Status",wfStatus,"Submitted",test);
		reusableComponents.assertEqualValue("Sub Status",subStatus,"YetToStart",test);
		reusableComponents.assertEqualValue("IsActive Flag",isActive,"true",test);
        resp = adInitiation.POSTVideotoAVIResponse(reqBody,headers);
        reusableComponents.assertEqualValue("HTTP Status Code",Integer.toString(resp.getStatusCode()), Integer.toString(201),test);
		String newvideoID = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.clcVideo.videoRefId");
		String oldcosmosentry= DBUtils.getvaluefromDB("clcvideos",videoID);
		String isActiveOld = JsonUtils.getValueFromJSONusingJSONPath(oldcosmosentry, "$.cursor.firstBatch[0].isActive");
		String newcosmosentry= DBUtils.getvaluefromDB("clcvideos",newvideoID);
		String isActivenew = JsonUtils.getValueFromJSONusingJSONPath(newcosmosentry, "$.cursor.firstBatch[0].isActive");
		reusableComponents.assertEqualValue("IsActive Flag for Old record",isActiveOld,"false",test);
		reusableComponents.assertEqualValue("IsActive Flag for new record",isActivenew,"true",test);
	}
	
	@Test(dataProvider = "CmsNotification", groups = {"Regression" })
	public void postvideotoAVIWithoutAuthorization(String fileName) throws Exception 
	{   
		test = report.startTest(new Object(){}.getClass().getEnclosingMethod().getName());
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		String reqBody = JsonUtils.jsonFileReader(fileName);
		String assetId= stringUtils.generateAssetid();
		reqBody= reqBody.replace("{AssetID}", assetId);
		reqBody=reqBody.replace("{CMSURL}", "https://google.co.in");
		reqBody=reqBody.replace("{VideoName}", "Automation Test Video");
		reqBody=reqBody.replace("{VideoType}", "Video");
		Response resp = adInitiation.POSTVideotoAVIResponse(reqBody,headers);
		reusableComponents.assertEqualValue("HTTP Status Code",Integer.toString(resp.getStatusCode()), Integer.toString(401),test);
		String code= JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.code");
		String status = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.status");
		String message = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.message");
		reusableComponents.assertEqualValue("ResultCode",code,"1001",test);
		reusableComponents.assertEqualValue("ResultStatus",status,"Failed",test);
		reusableComponents.assertEqualValue("ResultMessage",message,"Authentication Failed.",test);
	}
	@Test (enabled = false)
	public void uploadVideoSuccess() throws Exception 
	{   
		test = report.startTest(new Object(){}.getClass().getEnclosingMethod().getName());
		String accessToken = auth.GetAccessToken("cms");
		String assetId= stringUtils.generateAssetid();
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Authorization", "Bearer " + accessToken);
		Hashtable<String, String> formParams = new Hashtable<String, String>();
		formParams.put("assetId", assetId);
		formParams.put("videoName", "Test Video Name");
		formParams.put("subType","Episode");
		String filePath = System.getProperty("user.dir")+"\\Files\\Videos\\Video1.mp4";
		Response resp = adInitiation.PostFileUpload(filePath,"video/mp4",headers,formParams);
		reusableComponents.assertEqualValue("HTTP Status Code",Integer.toString(resp.getStatusCode()), Integer.toString(201),test);
        String url = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.cmsUploadResponse.url");
		String videoRefId = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.cmsUploadResponse.clcVideo.videoRefId");
		String cmsStatus = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.additionalInfo[0].status");
		String cmsCode = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.additionalInfo[0].code");
		String cmsMessage = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.additionalInfo[0].message");
		String resultstatus = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.status");
		String resultcode = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.code");
		String resultmessage = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.message");
		reusableComponents.assertEqualValue("CMSStatus", "Success", cmsStatus, test);
		reusableComponents.assertEqualValue("CMSCode", "2000", cmsCode, test);
		reusableComponents.assertEqualValue("CMSMessage","Ad publishing submitted successfully for the video "+assetId+".",cmsMessage, test);
		reusableComponents.assertEqualValue("ResultStatus", "Success", resultstatus, test);
		reusableComponents.assertEqualValue("ResultCode", "2006", resultcode, test);
		Thread.sleep(10000);
		reusableComponents.assertEqualValue("ResultMessage","Video  is uploaded successfully.",resultmessage, test);
		String cosmosentry= DBUtils.getvaluefromDBusingProperty("clcvideos","videoInfo.assetId",assetId);
		String wfStatus = JsonUtils.getValueFromJSONusingJSONPath(cosmosentry, "$.cursor.firstBatch[0].status.wfStatus");
		String subStatus= JsonUtils.getValueFromJSONusingJSONPath(cosmosentry, "$.cursor.firstBatch[0].status.subStatus");
		String isActive = JsonUtils.getValueFromJSONusingJSONPath(cosmosentry, "$.cursor.firstBatch[0].isActive");
		String cmsURL= JsonUtils.getValueFromJSONusingJSONPath(cosmosentry, "$.cursor.firstBatch[0].videoInfo.cmsUrl");
		reusableComponents.assertEqualValue("CMS URL", url, cmsURL, test);
		reusableComponents.assertEqualValue("WFStatus",wfStatus,"InProgress",test);
		reusableComponents.assertEqualValue("SubStatus",subStatus,"AVIInitiated",test);
		reusableComponents.assertEqualValue("IsActive",isActive,"true",test);
	}
	@Test (enabled = false)
	public void uploadVideowithoutAuthorization() throws Exception 
	{   
		test = report.startTest(new Object(){}.getClass().getEnclosingMethod().getName());
		String filePath = System.getProperty("user.dir")+"\\Files\\Videos\\Video1.mp4";
		String assetId= stringUtils.generateAssetid();
		Hashtable<String, String> headers = new Hashtable<String, String>();
		Hashtable<String, String> formParams = new Hashtable<String, String>();
		formParams.put("assetId", assetId);
		formParams.put("videoName", "Test Video Name");
		formParams.put("subType","Episode");
		Response resp = adInitiation.PostFileUpload(filePath,"video/mp4",headers,formParams);
		reusableComponents.assertEqualValue("HTTP Status Code",Integer.toString(resp.getStatusCode()), Integer.toString(401),test);
		String resultstatus = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.status");
		String resultcode = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.code");
		String resultmessage = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.message");
		reusableComponents.assertEqualValue("ResultStatus", "Failed", resultstatus, test);
		reusableComponents.assertEqualValue("ResultCode", "1001", resultcode, test);
		reusableComponents.assertEqualValue("ResultMessage","Authentication Failed.",resultmessage, test);
		
	}
	
	@Test (enabled = false)
	public void uploadVideoWithIncorrectFileType() throws Exception 
	{   
		test = report.startTest(new Object(){}.getClass().getEnclosingMethod().getName());
		String filePath = System.getProperty("user.dir")+"\\Files\\TextFile.txt";
		String assetId= stringUtils.generateAssetid();
		String accessToken = auth.GetAccessToken("cms");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Authorization", "Bearer " + accessToken);
		Hashtable<String, String> formParams = new Hashtable<String, String>();
		formParams.put("assetId", assetId);
		formParams.put("videoName", "Test Video Name");
		formParams.put("subType","Test");
		Response resp = adInitiation.PostFileUpload(filePath,"text/txt",headers,formParams);
		reusableComponents.assertEqualValue("HTTP Status Code",Integer.toString(resp.getStatusCode()), Integer.toString(400),test);
		String resultstatus = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.status");
		String resultcode = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.code");
		String resultAdditionalInfo = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.additionalInfo");
		String resultmessage = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.message");
		reusableComponents.assertEqualValue("ResultStatus", "Failed", resultstatus, test);
		reusableComponents.assertEqualValue("ResultCode", "2008", resultcode, test);
		reusableComponents.assertEqualValue("ResultMessage","Invalid video format. Video must be of video/mp4 format.",resultmessage, test);
		reusableComponents.assertEqualValue("Result Additional Info","Invalid File",resultAdditionalInfo, test);
	 }
	
	@Test (enabled = false)
	public void uploadVideoWithEmptySubType() throws Exception 
	{   
		test = report.startTest(new Object(){}.getClass().getEnclosingMethod().getName());
		String filePath = System.getProperty("user.dir")+"\\Files\\Videos\\Video1.mp4";
		String assetId= stringUtils.generateAssetid();
		String accessToken = auth.GetAccessToken("cms");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Authorization", "Bearer " + accessToken);
		Hashtable<String, String> formParams = new Hashtable<String, String>();
		formParams.put("assetId", assetId);
		formParams.put("videoName", "Test Video Name");
		formParams.put("subType","");
		Response resp = adInitiation.PostFileUpload(filePath,"video/mp4",headers,formParams);
		reusableComponents.assertEqualValue("HTTP Status Code",Integer.toString(resp.getStatusCode()), Integer.toString(400),test);
		String resultstatus = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.status");
		String resultcode = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.code");
		String resultAdditionalInfo = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.additionalInfo[0]");
		String resultmessage = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.message");
		reusableComponents.assertEqualValue("ResultStatus", "Failed", resultstatus, test);
		reusableComponents.assertEqualValue("ResultCode", "2009", resultcode, test);
		reusableComponents.assertEqualValue("ResultMessage","Field Validation Has Failed.Please check Additional Details for more information.",resultmessage, test);
		reusableComponents.assertEqualValue("Result Additional Info","subType should not be empty",resultAdditionalInfo, test);
	 }
	
	@Test (enabled = false)
	public void uploadVideoWithEmptyVideoName() throws Exception 
	{   
		test = report.startTest(new Object(){}.getClass().getEnclosingMethod().getName());
		String filePath = System.getProperty("user.dir")+"\\Files\\Videos\\Video1.mp4";
		String assetId= stringUtils.generateAssetid();
		String accessToken = auth.GetAccessToken("cms");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Authorization", "Bearer " + accessToken);
		Hashtable<String, String> formParams = new Hashtable<String, String>();
		formParams.put("assetId", assetId);
		formParams.put("videoName", "");
		formParams.put("subType","Test");
		Response resp = adInitiation.PostFileUpload(filePath,"video/mp4",headers,formParams);
		reusableComponents.assertEqualValue("HTTP Status Code",Integer.toString(resp.getStatusCode()), Integer.toString(400),test);
		String resultstatus = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.status");
		String resultcode = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.code");
		String resultAdditionalInfo = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.additionalInfo[0]");
		String resultmessage = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.message");
		reusableComponents.assertEqualValue("ResultStatus", "Failed", resultstatus, test);
		reusableComponents.assertEqualValue("ResultCode", "2009", resultcode, test);
		reusableComponents.assertEqualValue("ResultMessage","Field Validation Has Failed.Please check Additional Details for more information.",resultmessage, test);
		reusableComponents.assertEqualValue("Result Additional Info","videoName should not be empty",resultAdditionalInfo, test);
	 }
	
	@Test (enabled = false)
	public void aviJobSuccess() throws Exception 
	{   
		test = report.startTest(new Object(){}.getClass().getEnclosingMethod().getName());
		String accessToken = auth.GetAccessToken("cms");
		String assetId= stringUtils.generateAssetid();
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Authorization", "Bearer " + accessToken);
		Hashtable<String, String> formParams = new Hashtable<String, String>();
		formParams.put("assetId", assetId);
		formParams.put("videoName", "Test Video Name");
		formParams.put("subType","Episode");
		String filePath = System.getProperty("user.dir")+"\\Files\\Videos\\Video1.mp4";
		Response resp = adInitiation.PostFileUpload(filePath,"video/mp4",headers,formParams);
		reusableComponents.assertEqualValue("HTTP Status Code",Integer.toString(resp.getStatusCode()), Integer.toString(201),test);
        String url = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.cmsUploadResponse.url");
		String videoRefId = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.cmsUploadResponse.clcVideo.videoRefId");
		String cmsStatus = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.additionalInfo[0].status");
		String cmsCode = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.additionalInfo[0].code");
		String cmsMessage = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.additionalInfo[0].message");
		String resultstatus = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.status");
		String resultcode = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.code");
		String resultmessage = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.message");
		reusableComponents.assertEqualValue("CMSStatus", "Success", cmsStatus, test);
		reusableComponents.assertEqualValue("CMSCode", "2000", cmsCode, test);
		reusableComponents.assertEqualValue("CMSMessage","Ad publishing submitted successfully for the video "+assetId+".",cmsMessage, test);
		reusableComponents.assertEqualValue("ResultStatus", "Success", resultstatus, test);
		reusableComponents.assertEqualValue("ResultCode", "2006", resultcode, test);
		Thread.sleep(10000);
		reusableComponents.assertEqualValue("ResultMessage","Video  is uploaded successfully.",resultmessage, test);
		String cosmosentry= DBUtils.getvaluefromDBusingProperty("clcvideos","videoInfo.assetId",assetId);
		String wfStatus = JsonUtils.getValueFromJSONusingJSONPath(cosmosentry, "$.cursor.firstBatch[0].status.wfStatus");
		String subStatus= JsonUtils.getValueFromJSONusingJSONPath(cosmosentry, "$.cursor.firstBatch[0].status.subStatus");
		String isActive = JsonUtils.getValueFromJSONusingJSONPath(cosmosentry, "$.cursor.firstBatch[0].isActive");
		String cmsURL= JsonUtils.getValueFromJSONusingJSONPath(cosmosentry, "$.cursor.firstBatch[0].videoInfo.cmsUrl");
		reusableComponents.assertEqualValue("CMS URL", url, cmsURL, test);
		reusableComponents.assertEqualValue("WFStatus",wfStatus,"InProgress",test);
		reusableComponents.assertEqualValue("SubStatus",subStatus,"AVIInitiated",test);
		reusableComponents.assertEqualValue("IsActive",isActive,"true",test);
	}
	
	@Test(dataProvider = "CmsNotification", groups = {"Regression" })
	public void aviJobIncorrectURL(String fileName) throws Exception 
	{   
		test = report.startTest(new Object(){}.getClass().getEnclosingMethod().getName());
		String accessToken = auth.GetAccessToken("cms");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("Authorization", "Bearer " + accessToken);
		String reqBody = JsonUtils.jsonFileReader(fileName);
		String assetId= stringUtils.generateAssetid();
		String invalidCmsUrl = globalProp.getProperty("cmsUrl").substring(0, globalProp.getProperty("cmsUrl").length()-4);
		reqBody= reqBody.replace("{AssetID}", assetId);
		reqBody=reqBody.replace("{CMSURL}", invalidCmsUrl);
		reqBody=reqBody.replace("{VideoName}", "Automation Test Video");
		reqBody=reqBody.replace("{VideoType}", "Video");
		Response resp = adInitiation.POSTVideotoAVIResponse(reqBody,headers);
		System.out.println(resp.asString() + resp.getStatusCode());
		reusableComponents.assertEqualValue("HTTP Status Code",Integer.toString(resp.getStatusCode()), Integer.toString(201),test);
		String code= JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.code");
		String status = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.status");
		String message = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.message");
		String videoID = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.clcVideo.videoRefId");
		String cosmosentry= DBUtils.getvaluefromDB("clcvideos",videoID);
		String wfStatus = JsonUtils.getValueFromJSONusingJSONPath(cosmosentry, "$.cursor.firstBatch[0].status.wfStatus");
		String subStatus= JsonUtils.getValueFromJSONusingJSONPath(cosmosentry, "$.cursor.firstBatch[0].status.subStatus");
		String isActive = JsonUtils.getValueFromJSONusingJSONPath(cosmosentry, "$.cursor.firstBatch[0].isActive");
		reusableComponents.assertEqualValue("ResultCode",code,"2000",test);
		reusableComponents.assertEqualValue("ResultStatus",status,"Success",test);
		reusableComponents.assertEqualValue("ResultMessage",message,"Ad publishing submitted successfully for the video "+ assetId+".",test);
		reusableComponents.assertEqualValue("WFStatus",wfStatus,"Submitted",test);
		reusableComponents.assertEqualValue("SubStatus",subStatus,"YetToStart",test);
		reusableComponents.assertEqualValue("IsActiveFlag",isActive,"true",test);
		Thread.sleep(7000);
		String cosmosentrynew= DBUtils.getvaluefromDB("clcvideos",videoID);
		String wfStatusnew = JsonUtils.getValueFromJSONusingJSONPath(cosmosentrynew, "$.cursor.firstBatch[0].status.wfStatus");
		String subStatusnew= JsonUtils.getValueFromJSONusingJSONPath(cosmosentrynew, "$.cursor.firstBatch[0].status.subStatus");
		reusableComponents.assertEqualValue("Sub Status after failure",wfStatusnew,"Failed",test);
		reusableComponents.assertEqualValue("IsActive Flag after failure",subStatusnew,"AVIFailed",test);
		
	}
	
	@Test(dataProvider = "uploads3", groups = {"Regression" })
	public void uploadS3Success(String fileName) throws Exception
	{   
		test = report.startTest(new Object(){}.getClass().getEnclosingMethod().getName());
		String accessToken = auth.GetAccessToken("cms");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("Authorization", "Bearer " + accessToken);
		String reqBody = JsonUtils.jsonFileReader(fileName);
		String assetId= stringUtils.generateAssetid();
		reqBody= reqBody.replace("{ASSETID}", assetId);
		reqBody=reqBody.replace("{S3URL}", globalProp.getProperty("s3Url"));
		reqBody=reqBody.replace("{VIDEONAME}", "Automation Test Video");
		reqBody=reqBody.replace("{VIDEOTYPE}", "Video");
		Response resp = adInitiation.PostUploadS3(reqBody,headers);
		reusableComponents.assertEqualValue("HTTP Status Code",Integer.toString(resp.getStatusCode()), Integer.toString(201),test);
		String url = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.cmsUploadResponse.url");
		String blobName= url.split("zeevideos")[1];
		blobName = blobName.substring(1);
		Map<String, String> metaData= DBUtils.getBlobProperties("clcmsVideosStorage", "zeevideos", blobName, test);
		String s3URLFromMetaData= metaData.get("s3Url");
		String assetIdFromMetaData= metaData.get("assetId");
		String videoNameFromMetaData= metaData.get("videoName");
		String subTypeFromMetaData= metaData.get("subType");
		reusableComponents.assertEqualValue("S3URL in Metadata",globalProp.getProperty("s3Url"),s3URLFromMetaData,test);
		reusableComponents.assertEqualValue("AssetId in Metadata",assetId,assetIdFromMetaData,test);
		reusableComponents.assertEqualValue("VideoName in Metadata","Automation Test Video",videoNameFromMetaData,test);
		reusableComponents.assertEqualValue("SubType in Metadata","Video",subTypeFromMetaData,test);
		String code= JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.code");
		String status = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.status");
		String message = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.message");
		String additionalInfoMessage = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.additionalInfo[0].message");
		String additionalInfoTitle = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.additionalInfo[0].title");
		String videoID = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.cmsUploadResponse.clcVideo.videoRefId");
		String cosmosentry= DBUtils.getvaluefromDB("clcvideos",videoID);
		String wfStatus = JsonUtils.getValueFromJSONusingJSONPath(cosmosentry, "$.cursor.firstBatch[0].status.wfStatus");
		String subStatus= JsonUtils.getValueFromJSONusingJSONPath(cosmosentry, "$.cursor.firstBatch[0].status.subStatus");
		String isActive = JsonUtils.getValueFromJSONusingJSONPath(cosmosentry, "$.cursor.firstBatch[0].isActive");
		String s3URL= JsonUtils.getValueFromJSONusingJSONPath(cosmosentry, "$.cursor.firstBatch[0].videoInfo.s3Url");
		reusableComponents.assertEqualValue("ResultCode",code,"2006",test);
		reusableComponents.assertEqualValue("ResultStatus",status,"Success",test);
		reusableComponents.assertEqualValue("ResultMessage",message,"Video " + assetId + "is uploaded successfully.",test);
		reusableComponents.assertEqualValue("additionalInfoMessage",additionalInfoMessage,"Ad publishing submitted successfully for the video "+ assetId+".",test);
		reusableComponents.assertEqualValue("additionalInfoTitle",additionalInfoTitle,"/cms/initiateadpubprocess",test);
		reusableComponents.assertEqualValue("WFStatus",wfStatus,"Submitted",test);
		reusableComponents.assertEqualValue("SubStatus",subStatus,"YetToStart",test);
		reusableComponents.assertEqualValue("IsActiveFlag",isActive,"true",test);
		reusableComponents.assertEqualValue("S3URL",s3URL,globalProp.getProperty("s3Url"),test);
		String cosmosentryCMS= DBUtils.getvaluefromDBusingProperty("cmsstorages","videoInfo.assetId",assetId);
		String s3URLCMS= JsonUtils.getValueFromJSONusingJSONPath(cosmosentryCMS, "$.cursor.firstBatch[0].videoInfo.s3Url");
		reusableComponents.assertEqualValue("S3URL in CMSStorage",s3URLCMS,globalProp.getProperty("s3Url"),test);
		Thread.sleep(18000);
		String cosmosentrynew= DBUtils.getvaluefromDB("clcvideos",videoID);
		String wfStatusnew = JsonUtils.getValueFromJSONusingJSONPath(cosmosentrynew, "$.cursor.firstBatch[0].status.wfStatus");
		String subStatusnew= JsonUtils.getValueFromJSONusingJSONPath(cosmosentrynew, "$.cursor.firstBatch[0].status.subStatus");
		reusableComponents.assertEqualValue("Sub Status after AVI Initiated",wfStatusnew,"InProgress",test);
		reusableComponents.assertEqualValue("sub status",subStatusnew,"AVIInitiated",test);
			
	}
	
	@Test(dataProvider = "uploads3", groups = {"Regression" })
	public void uploadS3ApiInvalids3Url(String fileName) throws Exception
	{   
		test = report.startTest(new Object(){}.getClass().getEnclosingMethod().getName());
		String accessToken = auth.GetAccessToken("cms");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("Authorization", "Bearer " + accessToken);
		String s3TamperedUrl = "https://clccmsvideos.blob.core.windows.net/zeevideos/2023/09/25/9-9-239251-1695616380706.mp4";
		String reqBody = JsonUtils.jsonFileReader(fileName);
		String assetId= stringUtils.generateAssetid();
		reqBody= reqBody.replace("{ASSETID}", assetId);
		reqBody=reqBody.replace("{S3URL}", s3TamperedUrl);
		reqBody=reqBody.replace("{VIDEONAME}", "Automation Test Video");
		reqBody=reqBody.replace("{VIDEOTYPE}", "Video");
		Response resp = adInitiation.PostUploadS3(reqBody,headers);
		reusableComponents.assertEqualValue("HTTP Status Code",Integer.toString(resp.getStatusCode()), Integer.toString(400),test);
		String code= JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.code");
		String status = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.status");
		String message = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.message");
		reusableComponents.assertEqualValue("ResultCode",code,"2007",test);
		reusableComponents.assertEqualValue("ResultStatus",status,"Bad Request",test);
		reusableComponents.assertContainsValue("ResultMessage",message,"Invalid AWS s3Url: https:",test);
		reqBody = JsonUtils.jsonFileReader(fileName);
		reqBody= reqBody.replace("{ASSETID}", assetId);
		reqBody=reqBody.replace("{S3URL}", "");
		reqBody=reqBody.replace("{VIDEONAME}", "Automation Test Video");
		reqBody=reqBody.replace("{VIDEOTYPE}", "Video");
		resp = adInitiation.PostUploadS3(reqBody,headers);
		reusableComponents.assertEqualValue("HTTP Status Code",Integer.toString(resp.getStatusCode()), Integer.toString(400),test);
		code= JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.code");
		status = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.status");
		message = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.message");
		reusableComponents.assertEqualValue("ResultCode",code,"2009",test);
		reusableComponents.assertEqualValue("ResultStatus",status,"Failed",test);
		reusableComponents.assertEqualValue("ResultMessage",message,"Field Validation Has Failed.Please check Additional Details for more information.",test);
	}
	
	@Test(dataProvider = "uploads3", groups = {"Regression" })
	public void uploadS3Override(String fileName) throws Exception
	{   
		test = report.startTest(new Object(){}.getClass().getEnclosingMethod().getName());
		String accessToken = auth.GetAccessToken("cms");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("Authorization", "Bearer " + accessToken);
		String reqBody = JsonUtils.jsonFileReader(fileName);
		String assetId= stringUtils.generateAssetid();
		reqBody= reqBody.replace("{ASSETID}", assetId);
		reqBody=reqBody.replace("{S3URL}", globalProp.getProperty("s3Url"));
		reqBody=reqBody.replace("{VIDEONAME}", "Automation Test Video");
		reqBody=reqBody.replace("{VIDEOTYPE}", "Video");
		Response resp = adInitiation.PostUploadS3(reqBody,headers);
		reusableComponents.assertEqualValue("HTTP Status Code",Integer.toString(resp.getStatusCode()), Integer.toString(201),test);
		String code= JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.code");
		String status = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.status");
		String videoID = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.cmsUploadResponse.clcVideo.videoRefId");
		String cosmosentry= DBUtils.getvaluefromDB("clcvideos",videoID);
		String wfStatus = JsonUtils.getValueFromJSONusingJSONPath(cosmosentry, "$.cursor.firstBatch[0].status.wfStatus");
		String subStatus= JsonUtils.getValueFromJSONusingJSONPath(cosmosentry, "$.cursor.firstBatch[0].status.subStatus");
		String isActive = JsonUtils.getValueFromJSONusingJSONPath(cosmosentry, "$.cursor.firstBatch[0].isActive");
		reusableComponents.assertEqualValue("ResultCode",code,"2006",test);
		reusableComponents.assertEqualValue("ResultStatus",status,"Success",test);
		reusableComponents.assertEqualValue("WFStatus",wfStatus,"Submitted",test);
		reusableComponents.assertEqualValue("SubStatus",subStatus,"YetToStart",test);
		reusableComponents.assertEqualValue("IsActiveFlag",isActive,"true",test);
		
		resp = adInitiation.PostUploadS3(reqBody,headers);
		reusableComponents.assertEqualValue("HTTP Status Code",Integer.toString(resp.getStatusCode()), Integer.toString(201),test);
		String newVideoID = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.cmsUploadResponse.clcVideo.videoRefId");
		String newcosmosentry= DBUtils.getvaluefromDB("clcvideos",newVideoID);
		wfStatus = JsonUtils.getValueFromJSONusingJSONPath(newcosmosentry, "$.cursor.firstBatch[0].status.wfStatus");
		subStatus= JsonUtils.getValueFromJSONusingJSONPath(newcosmosentry, "$.cursor.firstBatch[0].status.subStatus");
		isActive = JsonUtils.getValueFromJSONusingJSONPath(newcosmosentry, "$.cursor.firstBatch[0].isActive");
		reusableComponents.assertEqualValue("WFStatus",wfStatus,"Submitted",test);
		reusableComponents.assertEqualValue("SubStatus",subStatus,"YetToStart",test);
		reusableComponents.assertEqualValue("IsActiveFlag",isActive,"true",test);
		
		cosmosentry= DBUtils.getvaluefromDB("clcvideos",videoID);
		isActive = JsonUtils.getValueFromJSONusingJSONPath(cosmosentry, "$.cursor.firstBatch[0].isActive");
		reusableComponents.assertEqualValue("IsActiveFlag",isActive,"false",test);		
			
	}
	
	@Test(dataProvider = "uploads3", groups = {"Regression" })
	public void uploadS3ApiInvalidToken(String fileName) throws Exception
	{   
		test = report.startTest(new Object(){}.getClass().getEnclosingMethod().getName());
		String accessToken = stringUtils.getRandomString();
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("Authorization", "Bearer " + accessToken);
		String reqBody = JsonUtils.jsonFileReader(fileName);
		String assetId= stringUtils.generateAssetid();
		reqBody= reqBody.replace("{ASSETID}", assetId);
		reqBody=reqBody.replace("{S3URL}", globalProp.getProperty("s3Url"));
		reqBody=reqBody.replace("{VIDEONAME}", "Automation Test Video");
		reqBody=reqBody.replace("{VIDEOTYPE}", "Video");
		Response resp = adInitiation.PostUploadS3(reqBody,headers);
		reusableComponents.assertEqualValue("HTTP Status Code",Integer.toString(resp.getStatusCode()), Integer.toString(401),test);
		String code= JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.code");
		String status = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.status");
		String message = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.message");
		reusableComponents.assertEqualValue("ResultCode",code,"1001",test);
		reusableComponents.assertEqualValue("ResultStatus",status,"Failed",test);
		reusableComponents.assertEqualValue("ResultMessage",message,"Authentication Failed.",test);
			
	}
	
	@Test(dataProvider = "uploadgcp", groups = {"Regression" })
	public void getStatusSuccess(String fileName) throws Exception 
	{   
		test = report.startTest(new Object(){}.getClass().getEnclosingMethod().getName());
		String accessToken = auth.GetAccessToken("cms");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("Authorization", "Bearer " + accessToken);
		String reqBody = JsonUtils.jsonFileReader(fileName);
		String assetId= stringUtils.generateAssetid();
		reqBody= reqBody.replace("{ASSETID}", assetId);
		//reqBody=reqBody.replace("{S3URL}", globalProp.getProperty("s3Url"));
		reqBody=reqBody.replace("{GCPURL}", globalProp.getProperty("gcpUrl"));
		reqBody=reqBody.replace("{VIDEONAME}", "Automation Test Video");
		reqBody=reqBody.replace("{VIDEOTYPE}", "Video");
		//Response resp = adInitiation.PostUploadS3(reqBody,headers);
		Response resp = adInitiation.PostUploadGcp(reqBody,headers);
		resp = adInitiation.GetStatus(headers,assetId);
		reusableComponents.assertEqualValue("HTTP Status Code",Integer.toString(resp.getStatusCode()), Integer.toString(200),test);
		String fetchedassetId = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.data.assetId");
		String vidRefId = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.data.videoRefId");
		String videoStatus = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.data.videoStatus");
		String videoSubStatus = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.data.videoSubStatus");
		String resultcode = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.code");
		String resultmessage = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.message");
		reusableComponents.assertEqualValue("CMSStatus", assetId, fetchedassetId, test);
		reusableComponents.assertEqualValue("Video Status","Submitted",videoStatus, test);
		reusableComponents.assertEqualValue("Video Sub Status", "YetToStart", videoSubStatus, test);
		reusableComponents.assertEqualValue("ResultCode", "2013", resultcode, test);
		reusableComponents.assertEqualValue("Result Message", "Clc Video Status API: Status retrieved successfully for video with assetId: " + fetchedassetId, resultmessage, test);
		
		String cosmosentry= DBUtils.getvaluefromDBusingProperty("clcvideos","videoInfo.assetId",assetId);
		String wfStatus = JsonUtils.getValueFromJSONusingJSONPath(cosmosentry, "$.cursor.firstBatch[0].status.wfStatus");
		String subStatus= JsonUtils.getValueFromJSONusingJSONPath(cosmosentry, "$.cursor.firstBatch[0].status.subStatus");
		String isActive = JsonUtils.getValueFromJSONusingJSONPath(cosmosentry, "$.cursor.firstBatch[0].isActive");
		reusableComponents.assertEqualValue("WFStatus",wfStatus,"Submitted",test);
		reusableComponents.assertEqualValue("SubStatus",subStatus,"YetToStart",test);
		reusableComponents.assertEqualValue("IsActive",isActive,"true",test);
	}
	
	@Test
	public void getStatusInvalidAssetid() throws Exception 
	{   
		test = report.startTest(new Object(){}.getClass().getEnclosingMethod().getName());
		String accessToken = auth.GetAccessToken("cms");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("Authorization", "Bearer " + accessToken);		
		Response resp = adInitiation.GetStatus(headers,"invalid");
		reusableComponents.assertEqualValue("HTTP Status Code",Integer.toString(resp.getStatusCode()), Integer.toString(404),test);
		String resultcode = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.code");
		String resultmessage = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.message");
		String resultStatus = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.status");
		reusableComponents.assertEqualValue("ResultStatus", "Failed", resultStatus, test);
		reusableComponents.assertEqualValue("ResultCode", "1005", resultcode, test);
		reusableComponents.assertEqualValue("Result Message", "Not Found.", resultmessage, test);
		}
	
	@Test(dataProvider = "uploadgcp", groups = {"Regression" })
	public void getStatusOverriddenVideo(String fileName) throws Exception 
	{   
		test = report.startTest(new Object(){}.getClass().getEnclosingMethod().getName());
		String accessToken = auth.GetAccessToken("cms");
		
		//upload first video
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("Authorization", "Bearer " + accessToken);
		String reqBody = JsonUtils.jsonFileReader(fileName);
		String assetId= stringUtils.generateAssetid();
		reqBody= reqBody.replace("{ASSETID}", assetId);
		//reqBody=reqBody.replace("{S3URL}", globalProp.getProperty("s3Url"));
		reqBody=reqBody.replace("{GCPURL}", globalProp.getProperty("gcpUrl"));
		reqBody=reqBody.replace("{VIDEONAME}", "Automation Test Video");
		reqBody=reqBody.replace("{VIDEOTYPE}", "Video");
		Response resp = adInitiation.PostUploadGcp(reqBody,headers);
		
		//upload second video with same asset id but different s3url and video name
		//reqBody = reqBody.replace(globalProp.getProperty("s3Url"), globalProp.getProperty("secondS3Url"));
		reqBody = reqBody.replace(globalProp.getProperty("gcpUrl"), globalProp.getProperty("secondGcpUrl"));
		reqBody=reqBody.replace("Automation Test Video", "New Automation Test Video");
		//resp = adInitiation.PostUploadS3(reqBody,headers);
		resp = adInitiation.PostUploadGcp(reqBody,headers);

		//get status api with above asset id
		resp = adInitiation.GetStatus(headers,assetId);
		reusableComponents.assertEqualValue("HTTP Status Code",Integer.toString(resp.getStatusCode()), Integer.toString(200),test);
		String fetchedassetId = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.data.assetId");
		String vidRefId = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.data.videoRefId");
		String videoStatus = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.data.videoStatus");
		String videoSubStatus = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.data.videoSubStatus");
		String resultcode = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.code");
		String resultmessage = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.message");
		reusableComponents.assertEqualValue("CMSStatus", assetId, fetchedassetId, test);
		reusableComponents.assertEqualValue("Video Status","Submitted",videoStatus, test);
		reusableComponents.assertEqualValue("Video Sub Status", "YetToStart", videoSubStatus, test);
		reusableComponents.assertEqualValue("ResultCode", "2013", resultcode, test);
		reusableComponents.assertEqualValue("Result Message", "Clc Video Status API: Status retrieved successfully for video with assetId: " + fetchedassetId, resultmessage, test);
		
		//validate that new video name is added to same asset id
		String cosmosentry= DBUtils.getvaluefromDB("clcvideos",vidRefId);
		String videoNameFromDb= JsonUtils.getValueFromJSONusingJSONPath(cosmosentry, "$.cursor.firstBatch[0].videoInfo.videoName");
		String wfStatus = JsonUtils.getValueFromJSONusingJSONPath(cosmosentry, "$.cursor.firstBatch[0].status.wfStatus");
		String subStatus= JsonUtils.getValueFromJSONusingJSONPath(cosmosentry, "$.cursor.firstBatch[0].status.subStatus");
		String isActive = JsonUtils.getValueFromJSONusingJSONPath(cosmosentry, "$.cursor.firstBatch[0].isActive");
		reusableComponents.assertEqualValue("New Video Name",videoNameFromDb,"New Automation Test Video",test);
		reusableComponents.assertEqualValue("WFStatus",wfStatus,"Submitted",test);
		reusableComponents.assertEqualValue("SubStatus",subStatus,"YetToStart",test);
		reusableComponents.assertEqualValue("IsActive",isActive,"true",test);
	}
	
	@Test
	public void getStatusInvalidBearerToken() throws Exception 
	{   
		test = report.startTest(new Object(){}.getClass().getEnclosingMethod().getName());
		String invalidToken = "kkhkhkhkh";
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("Authorization", "Bearer " + invalidToken);	
		String assetId= stringUtils.generateAssetid();
		Response resp = adInitiation.GetStatus(headers,assetId);
		reusableComponents.assertEqualValue("HTTP Status Code",Integer.toString(resp.getStatusCode()), Integer.toString(401),test);
		String resultcode = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.code");
		String resultmessage = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.message");
		String resultStatus = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.status");
		reusableComponents.assertEqualValue("ResultStatus", "Failed", resultStatus, test);
		reusableComponents.assertEqualValue("ResultCode", "1001", resultcode, test);
		reusableComponents.assertEqualValue("Result Message", "Authentication Failed.", resultmessage, test);
		}
	
	
	@Test(dataProvider = "uploads3", groups = {"Regression" })
	public void uploadS3ApiFileDoesNotExists3Url(String fileName) throws Exception
	{   
		test = report.startTest(new Object(){}.getClass().getEnclosingMethod().getName());
		String accessToken = auth.GetAccessToken("cms");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("Authorization", "Bearer " + accessToken);
		String s3TamperedUrl = "https://zee5transcoding-source-staging.s3.ap-south-1.amazonaws.com/Retranscoding/Movies/Drama/Tum_Ho_BablooB_Arijit_music_hi1234.mp4";
		String reqBody = JsonUtils.jsonFileReader(fileName);
		String assetId= stringUtils.generateAssetid();
		reqBody= reqBody.replace("{ASSETID}", assetId);
		reqBody=reqBody.replace("{S3URL}", s3TamperedUrl);
		reqBody=reqBody.replace("{VIDEONAME}", "Automation Test Video");
		reqBody=reqBody.replace("{VIDEOTYPE}", "Video");
		Response resp = adInitiation.PostUploadS3(reqBody,headers);
		reusableComponents.assertEqualValue("HTTP Status Code",Integer.toString(resp.getStatusCode()), Integer.toString(404),test);
		String code= JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.code");
		String status = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.status");
		String message = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.message");
		reusableComponents.assertEqualValue("ResultCode",code,"2007",test);
		reusableComponents.assertEqualValue("ResultStatus",status,"Not found",test);
		reusableComponents.assertContainsValue("ResultMessage",message,"File does not exist in AWS S3 for s3Url: ",test);
	}
	
	@Test(dataProvider = "uploads3", groups = {"Regression" })
	public void uploadS3ApiFileNoPermission3Url(String fileName) throws Exception
	{   
		test = report.startTest(new Object(){}.getClass().getEnclosingMethod().getName());
		String accessToken = auth.GetAccessToken("cms");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("Authorization", "Bearer " + accessToken);
		String s3TamperedUrl = "https://zee5transcoding-source-staging.s3.ap-south-1.amazonaws.com/Retranscoding/TV_Shows/ZEE_TV/Tum_Ho_BablooB_Arijit_music_MSS_test2.mp4";
		String reqBody = JsonUtils.jsonFileReader(fileName);
		String assetId= stringUtils.generateAssetid();
		reqBody= reqBody.replace("{ASSETID}", assetId);
		reqBody=reqBody.replace("{S3URL}", s3TamperedUrl);
		reqBody=reqBody.replace("{VIDEONAME}", "Automation Test Video");
		reqBody=reqBody.replace("{VIDEOTYPE}", "Video");
		Response resp = adInitiation.PostUploadS3(reqBody,headers);
		reusableComponents.assertEqualValue("HTTP Status Code",Integer.toString(resp.getStatusCode()), Integer.toString(403),test);
		String code= JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.code");
		String status = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.status");
		String message = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.message");
		reusableComponents.assertEqualValue("ResultCode",code,"2007",test);
		reusableComponents.assertEqualValue("ResultStatus",status,"Forbidden",test);
		reusableComponents.assertContainsValue("ResultMessage",message,"File is Forbidden to access in AWS S3 for s3Url:",test);
	}
	
	@Test(dataProvider = "cmsnotificationeventhub", groups = {"Regression" })
	public void CmsEventInvalidMsgType(String fileName) throws Exception {
		test = report.startTest(new Object(){}.getClass().getEnclosingMethod().getName());
		String reqBody = JsonUtils.jsonFileReader(fileName);
		String msgId = "automationtestmsg" + stringUtils.getRandomString();
		reqBody= reqBody.replace("{msgId}", msgId);
		reqBody=reqBody.replace("{msgType}", "Notification");
		reqBody=reqBody.replace("{retryCount}", "0");
		reqBody=reqBody.replace("{assetId}", "1-1-770888");
		reqBody=reqBody.replace("{videoName}", "Elephant Dreams");
		reqBody=reqBody.replace("{clcVideoId}", "001");
		reqBody=reqBody.replace("{cmsUrl}", "https://dummyvideos.com/2023/09/13/f63fb394-247b-4119-9db9-0c67a4fe467b.mp4");

		AzureUtils.KafkaToEventHubSender(globalProp.getProperty("cmsEventHubName"),reqBody );
		Thread.sleep(3000);
		String cosmosentryupdated= DBUtils.getvaluefromDBusingProperty("asyncmessagelogs","msgId",msgId);
		String fetchedMsgId = JsonUtils.getValueFromJSONusingJSONPath(cosmosentryupdated, "$.cursor.firstBatch[0].msgId");
		String fetchedMsgType = JsonUtils.getValueFromJSONusingJSONPath(cosmosentryupdated, "$.cursor.firstBatch[0].msgType");
		String msgProcessStatus = JsonUtils.getValueFromJSONusingJSONPath(cosmosentryupdated, "$.cursor.firstBatch[0].msgProcessStatus");
		String rejectedReason = JsonUtils.getValueFromJSONusingJSONPath(cosmosentryupdated, "$.cursor.firstBatch[0].rejectedReason");
		reusableComponents.assertEqualValue("Msg Id",fetchedMsgId,msgId,test);
		reusableComponents.assertEqualValue("Msg Type",fetchedMsgType,"CmsNotification",test);
		reusableComponents.assertEqualValue("Msg Process Status",msgProcessStatus,"Rejected",test);
		reusableComponents.assertEqualValue("Rejected Reason",rejectedReason,"Payload msgType is null or empty or not equal to CmsNotification.",test);

	}
	
	@Test(dataProvider = "cmsnotificationeventhub", groups = {"Regression" })
	public void CmsEventInvalidAssetId(String fileName) throws Exception {
		test = report.startTest(new Object(){}.getClass().getEnclosingMethod().getName());
		String reqBody = JsonUtils.jsonFileReader(fileName);
		String msgId = "automationtestmsg" + stringUtils.getRandomString();
		reqBody= reqBody.replace("{msgId}", msgId);
		reqBody=reqBody.replace("{msgType}", "CmsNotification");
		reqBody=reqBody.replace("{retryCount}", "0");
		reqBody=reqBody.replace("{assetId}", "1-1-770");
		reqBody=reqBody.replace("{videoName}", "Elephant Dreams");
		reqBody=reqBody.replace("{clcVideoId}", "001");
		reqBody=reqBody.replace("{cmsUrl}", "https://dummyvideos.com/2023/09/13/f63fb394-247b-4119-9db9-0c67a4fe467b.mp4");

		AzureUtils.KafkaToEventHubSender(globalProp.getProperty("cmsEventHubName"),reqBody.toString());
		Thread.sleep(3000);
		String cosmosentryupdated= DBUtils.getvaluefromDBusingProperty("asyncmessagelogs","msgId",msgId);
		String fetchedMsgId = JsonUtils.getValueFromJSONusingJSONPath(cosmosentryupdated, "$.cursor.firstBatch[0].msgId");
		String fetchedMsgType = JsonUtils.getValueFromJSONusingJSONPath(cosmosentryupdated, "$.cursor.firstBatch[0].msgType");
		String msgProcessStatus = JsonUtils.getValueFromJSONusingJSONPath(cosmosentryupdated, "$.cursor.firstBatch[0].msgProcessStatus");
		String rejectedReason = JsonUtils.getValueFromJSONusingJSONPath(cosmosentryupdated, "$.cursor.firstBatch[0].rejectedReason");
		reusableComponents.assertEqualValue("Msg Id",fetchedMsgId,msgId,test);
		reusableComponents.assertEqualValue("Msg Type",fetchedMsgType,"CmsNotification",test);
		reusableComponents.assertEqualValue("Msg Process Status",msgProcessStatus,"Rejected",test);
		reusableComponents.assertEqualValue("Rejected Reason",rejectedReason,"Error while fetching clcVideo for clcVideoId: 001 and assetId: 1-1-770.",test);

	}
	
	@Test(enabled=false, dataProvider = "cmsnotificationeventhub", groups = {"Regression" })
	public void CmsEventInvalidClcVideoId(String fileName) throws Exception {
		test = report.startTest(new Object(){}.getClass().getEnclosingMethod().getName());
		String reqBody = JsonUtils.jsonFileReader(fileName);
		String msgId = "automationtestmsg" + stringUtils.getRandomString();
		reqBody= reqBody.replace("{msgId}", msgId);
		reqBody=reqBody.replace("{msgType}", "CmsNotification");
		reqBody=reqBody.replace("{retryCount}", "0");
		String assetId= stringUtils.generateAssetid();
		reqBody=reqBody.replace("{assetId}", assetId);
		reqBody=reqBody.replace("{videoName}", "Elephant Dreams");
		reqBody=reqBody.replace("{clcVideoId}", "444kkkk");
		reqBody=reqBody.replace("{cmsUrl}", "https://dummyvideos.com/2023/09/13/f63fb394-247b-4119-9db9-0c67a4fe467b.mp4");

		AzureUtils.KafkaToEventHubSender(globalProp.getProperty("cmsEventHubName"),reqBody.toString());
		Thread.sleep(3000);
		String cosmosentryupdated= DBUtils.getvaluefromDBusingProperty("asyncmessagelogs","cmsNotification.videoInfo.assetId",assetId);
		String fetchedMsgId = JsonUtils.getValueFromJSONusingJSONPath(cosmosentryupdated, "$.cursor.firstBatch[0].msgId");
		String fetchedMsgType = JsonUtils.getValueFromJSONusingJSONPath(cosmosentryupdated, "$.cursor.firstBatch[0].msgType");
		String msgProcessStatus = JsonUtils.getValueFromJSONusingJSONPath(cosmosentryupdated, "$.cursor.firstBatch[0].msgProcessStatus");
		String rejectedReason = JsonUtils.getValueFromJSONusingJSONPath(cosmosentryupdated, "$.cursor.firstBatch[0].rejectedReason");
		reusableComponents.assertEqualValue("Msg Id",fetchedMsgId,msgId,test);
		reusableComponents.assertEqualValue("Msg Type",fetchedMsgType,"CmsNotification",test);
		reusableComponents.assertEqualValue("Msg Process Status",msgProcessStatus,"Rejected",test);
		reusableComponents.assertEqualValue("Rejected Reason",rejectedReason,"Payload clcVideoId is null or empty.",test);

	}
	
	@Test(dataProvider = "uploadgcp", groups = {"Regression" })
	public void uploadGcpSuccess(String fileName) throws Exception
	{   
		test = report.startTest(new Object(){}.getClass().getEnclosingMethod().getName());
		String accessToken = auth.GetAccessToken("cms");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("Authorization", "Bearer " + accessToken);
		String reqBody = JsonUtils.jsonFileReader(fileName);
		String assetId= stringUtils.generateAssetid();
		reqBody= reqBody.replace("{ASSETID}", assetId);
		reqBody=reqBody.replace("{GCPURL}", globalProp.getProperty("gcpUrl"));
		reqBody=reqBody.replace("{VIDEONAME}", "Automation Test Video");
		reqBody=reqBody.replace("{VIDEOTYPE}", "Video");
		Response resp = adInitiation.PostUploadGcp(reqBody,headers);
		reusableComponents.assertEqualValue("HTTP Status Code",Integer.toString(resp.getStatusCode()), Integer.toString(201),test);
		String url = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.cmsUploadResponse.url");
		String blobName= url.split("zeevideos")[1];
		blobName = blobName.substring(1);
		Map<String, String> metaData= DBUtils.getBlobProperties("clcmsVideosStorage", "zeevideos", blobName, test);
		String gcpURLFromMetaData= metaData.get("gcpUrl");
		String assetIdFromMetaData= metaData.get("assetId");
		String videoNameFromMetaData= metaData.get("videoName");
		String subTypeFromMetaData= metaData.get("subType");
		reusableComponents.assertEqualValue("GCPURL in Metadata",globalProp.getProperty("gcpUrl"),gcpURLFromMetaData,test);
		reusableComponents.assertEqualValue("AssetId in Metadata",assetId,assetIdFromMetaData,test);
		reusableComponents.assertEqualValue("VideoName in Metadata","Automation Test Video",videoNameFromMetaData,test);
		reusableComponents.assertEqualValue("SubType in Metadata","Video",subTypeFromMetaData,test);
		String code= JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.code");
		String status = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.status");
		String message = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.message");
		String additionalInfoMessage = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.additionalInfo[0].message");
		String additionalInfoTitle = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.additionalInfo[0].title");
		String videoID = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.cmsUploadResponse.clcVideo.videoRefId");
		String cosmosentry= DBUtils.getvaluefromDB("clcvideos",videoID);
		String wfStatus = JsonUtils.getValueFromJSONusingJSONPath(cosmosentry, "$.cursor.firstBatch[0].status.wfStatus");
		String subStatus= JsonUtils.getValueFromJSONusingJSONPath(cosmosentry, "$.cursor.firstBatch[0].status.subStatus");
		String isActive = JsonUtils.getValueFromJSONusingJSONPath(cosmosentry, "$.cursor.firstBatch[0].isActive");
		String gcpURL= JsonUtils.getValueFromJSONusingJSONPath(cosmosentry, "$.cursor.firstBatch[0].videoInfo.gcpUrl");
		reusableComponents.assertEqualValue("ResultCode",code,"2006",test);
		reusableComponents.assertEqualValue("ResultStatus",status,"Success",test);
		reusableComponents.assertEqualValue("ResultMessage",message,"Video " + assetId + "is uploaded successfully.",test);
		reusableComponents.assertEqualValue("additionalInfoMessage",additionalInfoMessage,"Ad publishing submitted successfully for the video "+ assetId+".",test);
		reusableComponents.assertEqualValue("additionalInfoTitle",additionalInfoTitle,"/cms/initiateadpubprocess",test);
		reusableComponents.assertEqualValue("WFStatus",wfStatus,"Submitted",test);
		reusableComponents.assertEqualValue("SubStatus",subStatus,"YetToStart",test);
		reusableComponents.assertEqualValue("IsActiveFlag",isActive,"true",test);
		reusableComponents.assertEqualValue("GCPURL",gcpURL,globalProp.getProperty("gcpUrl"),test);
		String cosmosentryCMS= DBUtils.getvaluefromDBusingProperty("cmsstorages","videoInfo.assetId",assetId);
		String gcpURLCMS= JsonUtils.getValueFromJSONusingJSONPath(cosmosentryCMS, "$.cursor.firstBatch[0].videoInfo.gcpUrl");
		reusableComponents.assertEqualValue("GCPURL in CMSStorage",gcpURLCMS,globalProp.getProperty("gcpUrl"),test);
		Thread.sleep(18000);
		String cosmosentrynew= DBUtils.getvaluefromDB("clcvideos",videoID);
		String wfStatusnew = JsonUtils.getValueFromJSONusingJSONPath(cosmosentrynew, "$.cursor.firstBatch[0].status.wfStatus");
		String subStatusnew= JsonUtils.getValueFromJSONusingJSONPath(cosmosentrynew, "$.cursor.firstBatch[0].status.subStatus");
		reusableComponents.assertEqualValue("Sub Status after AVI Initiated",wfStatusnew,"InProgress",test);
		reusableComponents.assertEqualValue("sub status",subStatusnew,"AVIInitiated",test);
			
	}
	
	@Test(dataProvider = "uploadgcp", groups = {"Regression" })
	public void uploadGcpApiInvalidgcpUrl(String fileName) throws Exception
	{   
		test = report.startTest(new Object(){}.getClass().getEnclosingMethod().getName());
		String accessToken = auth.GetAccessToken("cms");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("Authorization", "Bearer " + accessToken);
		String gcpTamperedUrl = "https://clccmsvideos.blob.core.windows.net/zeevideos/2023/09/25/9-9-239251-1695616380706.mp4";
		String reqBody = JsonUtils.jsonFileReader(fileName);
		String assetId= stringUtils.generateAssetid();
		reqBody= reqBody.replace("{ASSETID}", assetId);
		reqBody=reqBody.replace("{GCPURL}", gcpTamperedUrl);
		reqBody=reqBody.replace("{VIDEONAME}", "Automation Test Video");
		reqBody=reqBody.replace("{VIDEOTYPE}", "Video");
		Response resp = adInitiation.PostUploadGcp(reqBody,headers);
		reusableComponents.assertEqualValue("HTTP Status Code",Integer.toString(resp.getStatusCode()), Integer.toString(400),test);
		String code= JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.code");
		String status = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.status");
		String message = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.message");
		reusableComponents.assertEqualValue("ResultCode",code,"2007",test);
		reusableComponents.assertEqualValue("ResultStatus",status,"Bad Request",test);
		reusableComponents.assertContainsValue("ResultMessage",message,"Invalid GCP URL: https:",test);
		reqBody = JsonUtils.jsonFileReader(fileName);
		reqBody= reqBody.replace("{ASSETID}", assetId);
		reqBody=reqBody.replace("{GCPURL}", "");
		reqBody=reqBody.replace("{VIDEONAME}", "Automation Test Video");
		reqBody=reqBody.replace("{VIDEOTYPE}", "Video");
		resp = adInitiation.PostUploadGcp(reqBody,headers);
		reusableComponents.assertEqualValue("HTTP Status Code",Integer.toString(resp.getStatusCode()), Integer.toString(400),test);
		code= JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.code");
		status = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.status");
		message = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.message");
		reusableComponents.assertEqualValue("ResultCode",code,"2009",test);
		reusableComponents.assertEqualValue("ResultStatus",status,"Failed",test);
		reusableComponents.assertEqualValue("ResultMessage",message,"Field Validation Has Failed.Please check Additional Details for more information.",test);
	}
	
	@Test(dataProvider = "uploadgcp", groups = {"Regression" })
	public void uploadGcpOverride(String fileName) throws Exception
	{   
		test = report.startTest(new Object(){}.getClass().getEnclosingMethod().getName());
		String accessToken = auth.GetAccessToken("cms");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("Authorization", "Bearer " + accessToken);
		String reqBody = JsonUtils.jsonFileReader(fileName);
		String assetId= stringUtils.generateAssetid();
		reqBody= reqBody.replace("{ASSETID}", assetId);
		reqBody=reqBody.replace("{GCPURL}", globalProp.getProperty("gcpUrl"));
		reqBody=reqBody.replace("{VIDEONAME}", "Automation Test Video");
		reqBody=reqBody.replace("{VIDEOTYPE}", "Video");
		Response resp = adInitiation.PostUploadGcp(reqBody,headers);
		reusableComponents.assertEqualValue("HTTP Status Code",Integer.toString(resp.getStatusCode()), Integer.toString(201),test);
		String code= JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.code");
		String status = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.status");
		String videoID = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.cmsUploadResponse.clcVideo.videoRefId");
		String cosmosentry= DBUtils.getvaluefromDB("clcvideos",videoID);
		String wfStatus = JsonUtils.getValueFromJSONusingJSONPath(cosmosentry, "$.cursor.firstBatch[0].status.wfStatus");
		String subStatus= JsonUtils.getValueFromJSONusingJSONPath(cosmosentry, "$.cursor.firstBatch[0].status.subStatus");
		String isActive = JsonUtils.getValueFromJSONusingJSONPath(cosmosentry, "$.cursor.firstBatch[0].isActive");
		reusableComponents.assertEqualValue("ResultCode",code,"2006",test);
		reusableComponents.assertEqualValue("ResultStatus",status,"Success",test);
		reusableComponents.assertEqualValue("WFStatus",wfStatus,"Submitted",test);
		reusableComponents.assertEqualValue("SubStatus",subStatus,"YetToStart",test);
		reusableComponents.assertEqualValue("IsActiveFlag",isActive,"true",test);
		
		resp = adInitiation.PostUploadGcp(reqBody,headers);
		reusableComponents.assertEqualValue("HTTP Status Code",Integer.toString(resp.getStatusCode()), Integer.toString(201),test);
		String newVideoID = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.cmsUploadResponse.clcVideo.videoRefId");
		String newcosmosentry= DBUtils.getvaluefromDB("clcvideos",newVideoID);
		wfStatus = JsonUtils.getValueFromJSONusingJSONPath(newcosmosentry, "$.cursor.firstBatch[0].status.wfStatus");
		subStatus= JsonUtils.getValueFromJSONusingJSONPath(newcosmosentry, "$.cursor.firstBatch[0].status.subStatus");
		isActive = JsonUtils.getValueFromJSONusingJSONPath(newcosmosentry, "$.cursor.firstBatch[0].isActive");
		reusableComponents.assertEqualValue("WFStatus",wfStatus,"Submitted",test);
		reusableComponents.assertEqualValue("SubStatus",subStatus,"YetToStart",test);
		reusableComponents.assertEqualValue("IsActiveFlag",isActive,"true",test);
		
		cosmosentry= DBUtils.getvaluefromDB("clcvideos",videoID);
		isActive = JsonUtils.getValueFromJSONusingJSONPath(cosmosentry, "$.cursor.firstBatch[0].isActive");
		reusableComponents.assertEqualValue("IsActiveFlag",isActive,"false",test);		
			
	}
	
	@Test(dataProvider = "uploadgcp", groups = {"Regression" })
	public void uploadGcpApiInvalidToken(String fileName) throws Exception
	{   
		test = report.startTest(new Object(){}.getClass().getEnclosingMethod().getName());
		String accessToken = stringUtils.getRandomString();
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("Authorization", "Bearer " + accessToken);
		String reqBody = JsonUtils.jsonFileReader(fileName);
		String assetId= stringUtils.generateAssetid();
		reqBody= reqBody.replace("{ASSETID}", assetId);
		reqBody=reqBody.replace("{GCPURL}", globalProp.getProperty("gcpUrl"));
		reqBody=reqBody.replace("{VIDEONAME}", "Automation Test Video");
		reqBody=reqBody.replace("{VIDEOTYPE}", "Video");
		Response resp = adInitiation.PostUploadGcp(reqBody,headers);
		reusableComponents.assertEqualValue("HTTP Status Code",Integer.toString(resp.getStatusCode()), Integer.toString(401),test);
		String code= JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.code");
		String status = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.status");
		String message = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.message");
		reusableComponents.assertEqualValue("ResultCode",code,"1001",test);
		reusableComponents.assertEqualValue("ResultStatus",status,"Failed",test);
		reusableComponents.assertEqualValue("ResultMessage",message,"Authentication Failed.",test);
			
	}
	
	@Test(dataProvider = "uploadgcp", groups = {"Regression" })
	public void uploadGcpApiFileDoesNotExistgcpUrl(String fileName) throws Exception
	{   
		test = report.startTest(new Object(){}.getClass().getEnclosingMethod().getName());
		String accessToken = auth.GetAccessToken("cms");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("Authorization", "Bearer " + accessToken);
		String gcpTamperedUrl = "https://storage.cloud.google.com/gcs-zee5-dev-azure-clc/Aston_Stitching/TV_SHOWS/ZEE_PUNJABI/October2021/11102021/Preview/AVOD_Kamli___29102020_pa.mp4";
		String reqBody = JsonUtils.jsonFileReader(fileName);
		String assetId= stringUtils.generateAssetid();
		reqBody= reqBody.replace("{ASSETID}", assetId);
		reqBody=reqBody.replace("{GCPURL}", gcpTamperedUrl);
		reqBody=reqBody.replace("{VIDEONAME}", "Automation Test Video");
		reqBody=reqBody.replace("{VIDEOTYPE}", "Video");
		Response resp = adInitiation.PostUploadGcp(reqBody,headers);
		reusableComponents.assertEqualValue("HTTP Status Code",Integer.toString(resp.getStatusCode()), Integer.toString(404),test);
		String code= JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.code");
		String status = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.status");
		String message = JsonUtils.getValueFromJSONusingJSONPath(resp.asString(), "$.result.message");
		reusableComponents.assertEqualValue("ResultCode",code,"2007",test);
		reusableComponents.assertEqualValue("ResultStatus",status,"Not found",test);
		reusableComponents.assertContainsValue("ResultMessage",message,"File not exist in GCP Bucket gcpUrl: ",test);
	}
	
	@DataProvider (name = "CmsNotification")
	public Object[][] getSingleDataJSONSource() {
		return new Object[][] {
			{ "PayLoad/cmsnotification.json"}
		};
	}
	
	@DataProvider (name = "uploads3")
	public Object[][] getSingle1DataJSONSource() {
		return new Object[][] {
			{ "PayLoad/uploads3.json"}
		};
	}
	
	@DataProvider (name = "uploadgcp")
	public Object[][] getSingle1DataJSONSource2() {
		return new Object[][] {
			{ "PayLoad/uploadgcp.json"}
		};
	}
	
	@DataProvider (name = "CmsNotificationError")
	public Object[][] getDataJSONSource() {
		return new Object[][] {
			{ "PayLoad/cmsnotificationerror.json"}
		};
	}
	
	@DataProvider (name = "cmsnotificationeventhub")
	public Object[][] getSecondDataJSONSource() {
		return new Object[][] {
			{ "PayLoad/cmsnotificationeventhub.json"}
		};
	}
	
	
}
