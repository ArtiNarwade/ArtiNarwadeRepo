package com.OTTPlatform.ModuleName;

import java.util.Hashtable;

import org.apache.commons.lang3.StringUtils;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;


import BusinessComponents.Search_AzureCognitive;
import baseTestPackage.BaseTest_TestNG;
import io.restassured.response.Response;
import reusableLibrary.JsonUtils;
import reusableLibrary.ResuableComponents;

public class CognitiveSearch_Tests extends BaseTest_TestNG{
	
	Search_AzureCognitive sc = new Search_AzureCognitive();
	ResuableComponents resuableComponents= new ResuableComponents();

	@Test(dataProvider = "Search", groups = {"Regression" })
	public void cognitiveSearchByMovieName(String fileName) throws Exception {
		test = report.startTest("Execute Search API with Actor Name");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("Api-Key",globalProp.getProperty("searchapikey"));
		String reqBody = JsonUtils.jsonFileReader(fileName);
		reqBody= reqBody.replace("{FilterParameter}", "(genres/any(t: t eq 'Adventure'))");
		reqBody=reqBody.replace("{SearchTerm}", "Ranbir");
		Response resp = sc.GetSearchResponse(reqBody,headers);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
		
	}
	
	@DataProvider (name = "Search")
	public Object[][] getSingleDataJSONSource() {
		return new Object[][] {
			{ "PayLoad/search.json"}
		};
	}
	
}
