package reusableLibrary;

import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.avro.generic.GenericRecord;
import org.apache.kafka.clients.producer.Callback;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.apache.kafka.common.serialization.StringSerializer;

import com.azure.messaging.eventhubs.EventData;
import com.azure.messaging.eventhubs.EventDataBatch;
import com.azure.messaging.eventhubs.EventHubClientBuilder;
import com.azure.messaging.eventhubs.EventHubProducerClient;

import baseTestPackage.BaseTest_TestNG;
import io.confluent.kafka.serializers.KafkaAvroSerializer;

public class AzureUtils  extends BaseTest_TestNG{

	    private static final String connectionString = globalProp.getProperty("eventHubConnectionString");

	    public static void SendEventToAzureEventHub(String eventHub, String myEventData) {
	        EventHubProducerClient producerClient = new EventHubClientBuilder()
	                .connectionString(connectionString, eventHub)
	                .buildProducerClient();

	        try {
	            
	                EventDataBatch batch = producerClient.createBatch();
	                String eventData = myEventData;
	                batch.tryAdd(new EventData(eventData));
	                producerClient.send(batch);
	                System.out.println("Sent: " + eventData);
	                TimeUnit.SECONDS.sleep(1); 
	        } catch (Exception e) {
	            System.err.println("Error: " + e.getMessage());
	        } finally {
	            producerClient.close();
	        }
	    }
	    

	        public static void KafkaToEventHubSender(String eventHub, String message) {
	            // Azure Event Hub connection string
	            String eventHubNamespace = globalProp.getProperty("eventHubNamespace");
	            String connectionString = null;
	            String notificationType = null;
	            if(eventHub.equalsIgnoreCase(globalProp.getProperty("cmsEventHubName"))) {
	            	connectionString = globalProp.getProperty("cmsEBConnectionString");
	            	notificationType = "CmsNotification";
	            }
	            else if(eventHub.equalsIgnoreCase(globalProp.getProperty("aviEventHubName"))) {
	            	connectionString = globalProp.getProperty("aviEBConnectionString");
	            	notificationType = "AviNotification";
	            	}
	            else if(eventHub.equalsIgnoreCase(globalProp.getProperty("bingEventHubName"))) {
	            	connectionString = globalProp.getProperty("bingEBConnectionString");
	            	notificationType = "BingNotification";
	            }
	            // Set up Kafka producer properties
	            Properties props = new Properties();
	            
	            props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, eventHubNamespace); // Replace with your Event Hub FQDN and port
	            props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
	            props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
	            props.put("security.protocol", "SASL_SSL");
	            props.put("sasl.mechanism", "PLAIN");
	            props.put("sasl.jaas.config", "org.apache.kafka.common.security.plain.PlainLoginModule required username=\"$ConnectionString\" password=\"" + connectionString + "\";");
	            props.put("ssl.endpoint.identification.algorithm", "https");
	            
	            
	            // Create a Kafka producer
	            KafkaProducer<String, String> producer = new KafkaProducer<>(props);
	            ProducerRecord<String, String> kafkaRecord = new ProducerRecord<>(eventHub, notificationType, message);

	            producer.send(kafkaRecord, new Callback() {
	            	public void onCompletion(RecordMetadata recordMetadata, Exception e) {
	            		if(e == null) {
	            			System.out.println("Successfully received the details as \n" +
	            		"Topic" + recordMetadata.topic() + "\n" +
	            		"Partition" + recordMetadata.partition());
	            		}
	            		else {
	            			System.out.println("Error " + e.getMessage());
	            		}
	            	}
	            });
	            
	            // Close the producer when done
	            producer.close();
	        }
	    
 
	}