package reusableLibrary;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.net.URISyntaxException;
import java.nio.charset.StandardCharsets;
import java.security.InvalidKeyException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Scanner;

import org.apache.commons.io.FileUtils;
import org.bson.Document;
import org.bson.types.ObjectId;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.testng.Assert;

import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.azure.storage.blob.*;
import com.azure.storage.blob.models.*;

public class DBUtils {
	
	
	public static Properties globalProp; 
	
	 
	public static String  getvaluefromDB(String collectionName,String partitionId) throws Exception
	{
		if(globalProp==null)
		{
	    File f = new File(".");
		globalProp = loadPropertyFile(f.getCanonicalPath() + "//GlobalProperties.properties");
		}
		MongoClientURI uri = new MongoClientURI(globalProp.getProperty("clccosmosconnectionstring"));
		
        MongoClient mongoClient=null;
        try {
            mongoClient = new MongoClient(uri);        
            
            // Get database
            MongoDatabase database = mongoClient.getDatabase("clc");

            // Get collection
            MongoCollection<Document> collection = database.getCollection(collectionName);
            
            
            System.out.println(collection.count());
            Document document = new Document("_id", new ObjectId(partitionId));
            List claim = new ArrayList();
            List<Document> claims = collection.find(document).into(claim);
            return claims.get(claims.size()-1).toJson().toString();            
            } finally {
        	if (mongoClient != null) {
        		mongoClient.close();
        	}
        }
		
	}
	
	public static String  getvaluefromDBusingProperty(String collectionName,String propertyname,String propertyvalue) throws Exception
	{
		if(globalProp==null)
		{
	    File f = new File(".");
		globalProp = loadPropertyFile(f.getCanonicalPath() + "//GlobalProperties.properties");
		}
		MongoClientURI uri = new MongoClientURI(globalProp.getProperty("clccosmosconnectionstring"));
		
        MongoClient mongoClient=null;
        try {
            mongoClient = new MongoClient(uri);        
            
            // Get database
            MongoDatabase database = mongoClient.getDatabase("clc");

            // Get collection
            MongoCollection<Document> collection = database.getCollection(collectionName);
            
            
            System.out.println(collection.count());
            List claim = new ArrayList();
            List<Document> claims = collection.find(Filters.all(propertyname, propertyvalue)).into(claim);
            return claims.get(claims.size()-1).toJson().toString();            
            } finally {
        	if (mongoClient != null) {
        		mongoClient.close();
        	}
        }
		
	}
	
	public static void checkBlobExists(String storageAccountName,String ContainerName,String blobname,ExtentTest test) throws Exception
	{
		if(globalProp==null)
		{
	    File f = new File(".");
		globalProp = loadPropertyFile(f.getCanonicalPath() + "//GlobalProperties.properties");
		}
		String connectionString = globalProp.getProperty(storageAccountName); 
        BlobServiceClient blobServiceClient = new BlobServiceClientBuilder()
        	    .connectionString(connectionString)
        	    .buildClient();
        BlobContainerClient blobContainerClient = blobServiceClient.getBlobContainerClient(ContainerName);
        BlobClient blobClient= blobContainerClient.getBlobClient(blobname);
        if (blobClient.exists())
		{
		test.log(LogStatus.PASS, "<b>Blob with Name " + blobname +"is created");
		 Assert.assertTrue(true);
		}
	else
	{
		test.log(LogStatus.FAIL, "<b>Blob with Name " + blobname +"is not created");
		 Assert.assertTrue(true);
	}

     }
	public static Map<String, String> getBlobProperties(String storageAccountName,String ContainerName,String blobname,ExtentTest test) throws Exception
	{
		if(globalProp==null)
		{
	    File f = new File(".");
		globalProp = loadPropertyFile(f.getCanonicalPath() + "//GlobalProperties.properties");
		}
		String connectionString = globalProp.getProperty(storageAccountName); 
        BlobServiceClient blobServiceClient = new BlobServiceClientBuilder()
        	    .connectionString(connectionString)
        	    .buildClient();
        BlobContainerClient blobContainerClient = blobServiceClient.getBlobContainerClient(ContainerName);
        BlobClient blobClient= blobContainerClient.getBlobClient(blobname);
        BlobProperties bp = blobClient.getProperties();
        Map<String, String> metaData = bp.getMetadata();
        return metaData;
	}
	
	public static Properties loadPropertyFile(String strFilePath) throws Exception {
		FileReader reader = new FileReader(strFilePath);
		Properties prop = new Properties();
		prop.load(reader);
		return prop;
	}

}
