package BusinessComponents;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

import com.EndPoints.EndPoints;
import com.OTTPlatform.Adtech.AdTech_Config_Test;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import baseTestPackage.BaseTest_TestNG;
import baseTestPackage.SuiteConstant;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import reusableLibrary.ResuableComponents;

public class AdTechConfig extends BaseTest_TestNG {

	List<String> list = new ArrayList<String>();
	SuiteConstant suiteMap = new SuiteConstant();
	ResuableComponents resuableComponents = new ResuableComponents();
	Response resp;
	
	public Response Authenticate(ExtentTest test, String reqBody) throws Exception {
		RestAssured.baseURI = executionParams.get("AdtechConfigAuthenticate");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("AUTHENTICATEADTECH"), reqBody,
				globalProp, test, headers);
		return resp;
		
	}
	
	public Response getPassword(ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("AdtechConfigAuthenticate");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("GENERATEPASSWORDADTECH"), globalProp, test,
				headers);
		return resp;
	}
	
	
	public Response createNonProdCompanionadsLIVE(ExtentTest test, String reqBody ) throws Exception {
		RestAssured.baseURI = executionParams.get("AdtechConfigAuthenticate");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("Cookie", AdTech_Config_Test.Cookie);
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("ADTECHCONFIGENDPOINT"),
				reqBody, globalProp, test, headers);
		return resp;
	}
	
	public Response default_MISC(ExtentTest test, String reqBody ) throws Exception {
		RestAssured.baseURI = executionParams.get("AdtechConfigAuthenticate");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("Cookie", AdTech_Config_Test.Cookie);
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("DEFAULT_MISC"),
				reqBody, globalProp, test, headers);
		return resp;
	}
	
	
	public Response GetConfig(ExtentTest test,String reqBody) throws Exception {
		RestAssured.baseURI = executionParams.get("AdtechConfigAuthenticate");
		Response resp1=Authenticate(test, reqBody);
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Cookie", resp1.getHeader("Set-Cookie"));
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("GETALLCONFIG"), globalProp, test,
				headers);
		return resp;
	}
	
	public Response GetConfigDetail(ExtentTest test,String reqBody) throws Exception {
		RestAssured.baseURI = executionParams.get("AdtechConfigAuthenticate");
		Response resp1=Authenticate(test, reqBody);
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Cookie", resp1.getHeader("Set-Cookie"));
		Response resp = resuableComponents.executeGetAPIEncodingURL(EndPoints.endPointList.get("GETDETAILS"), globalProp, test,
				headers);
		return resp;
	}
	
	public Response ReloadComponent(ExtentTest test,String reqBody) throws Exception {
		RestAssured.baseURI = executionParams.get("AdtechConfigAuthenticate");
		Response resp1=Authenticate(test, reqBody);
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Cookie", resp1.getHeader("Set-Cookie"));
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("RELOADCONFIG"), "",
				globalProp, test, headers);
		return resp;
	}
	
	public Response ReloadContext(ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("AdtechConfigAuthenticate");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		try {
		headers.put("Cookie", AdTech_Config_Test.Cookie);
		}catch(Exception ex)
		{
			System.out.println("Getting Cookie" +ex);
			test.log(LogStatus.FAIL, ex);
		}
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("RELOADCONTEXT"), "",
				globalProp, test, headers);
		return resp;
	}
	
	public Response DisableConfig(ExtentTest test,String reqBody) throws Exception {
		RestAssured.baseURI = executionParams.get("AdtechConfigAuthenticate");
		Response resp1=Authenticate(test, reqBody);
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("Cookie", resp1.getHeader("Set-Cookie"));
		Response resp = resuableComponents.executeDeleteAPIEncoding(EndPoints.endPointList.get("DISABLECONFIG"), globalProp,
				test, headers);
		return resp;
	}
	
	public Response FlushConfig(ExtentTest test,String reqBody) throws Exception {
		RestAssured.baseURI = executionParams.get("AdtechConfigAuthenticate");
		Response resp1=Authenticate(test, reqBody);
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("Cookie", resp1.getHeader("Set-Cookie"));
		Response resp = resuableComponents.executeDeleteAPI(EndPoints.endPointList.get("FLUSHCONFIG"), globalProp, test,
				headers);
		return resp;
	}
	
	public Response FlushConfigCache(ExtentTest test,String reqBody) throws Exception {
		RestAssured.baseURI = executionParams.get("AdtechConfigAuthenticate");
		Response resp1=Authenticate(test, reqBody);
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("Cookie", resp1.getHeader("Set-Cookie"));
		Response resp = resuableComponents.executeDeleteAPI(EndPoints.endPointList.get("FLUSHCONFIGCACHE"), globalProp,
				test, headers);
		return resp;
	}
	
	public Response ForceDrop(ExtentTest test,String reqBody) throws Exception {
		RestAssured.baseURI = executionParams.get("AdtechConfigAuthenticate");
		Response resp1=Authenticate(test, reqBody);
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Cookie", resp1.getHeader("Set-Cookie"));
		Response resp = resuableComponents.executeDeleteAPIEncoding(EndPoints.endPointList.get("FORCEDROP"), globalProp, test,
				headers);
		return resp;
	}
	
	public Response getDiscoveryComponentType(ExtentTest test,String reqBody) throws Exception {
		RestAssured.baseURI = executionParams.get("AdtechConfigAuthenticate");
		Response resp1=Authenticate(test, reqBody);
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Cookie", resp1.getHeader("Set-Cookie"));
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("GETDISCOVERYCOMPONENTTYPE"),
				globalProp, test, headers);
		return resp;
	}
	
	public Response getDiscoveryAdServerType(ExtentTest test,String reqBody) throws Exception {
		RestAssured.baseURI = executionParams.get("AdtechConfigAuthenticate");
		Response resp1=Authenticate(test, reqBody);
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Cookie", resp1.getHeader("Set-Cookie"));
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("GETDISCOVERYAdSERVERTYPE"),
				globalProp, test, headers);
		return resp;
	}
	
	public Response getDiscoveryConfigType(ExtentTest test,String reqBody) throws Exception {
		RestAssured.baseURI = executionParams.get("AdtechConfigAuthenticate");
		Response resp1=Authenticate(test, reqBody);
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Cookie", resp1.getHeader("Set-Cookie"));
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("GETDISCOVERYCONFIGTYPE"),
				globalProp, test, headers);
		return resp;
	}
	
	public Response getDiscoveryConfigKeyFormulation(ExtentTest test,String reqBody) throws Exception {
		RestAssured.baseURI = executionParams.get("AdtechConfigAuthenticate");
		Response resp1=Authenticate(test, reqBody);
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Cookie", resp1.getHeader("Set-Cookie"));
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("GETDISCOVERYCONFIGKEYFORMULATION"),
				globalProp, test, headers);
		return resp;
	}
	
	public Response getDiscoveryOperatorDesc(ExtentTest test,String reqBody) throws Exception {
		RestAssured.baseURI = executionParams.get("AdtechConfigAuthenticate");
		Response resp1=Authenticate(test, reqBody);
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Cookie", resp1.getHeader("Set-Cookie"));
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("GETDISCOVERYOPERATORS"),
				globalProp, test, headers);
		return resp;
	}
	
	public Response getDisoveryAvailableConfiKeys(ExtentTest test,String reqBody) throws Exception {
		RestAssured.baseURI = executionParams.get("AdtechConfigAuthenticate");
		Response resp1=Authenticate(test, reqBody);
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Cookie", resp1.getHeader("Set-Cookie"));
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("GETDISCOVERYAVAILABLECONFIGKEYS"),
				globalProp, test, headers);
		return resp;
	}
	
	public Response getDisoveryAllAvailbleRegion(ExtentTest test,String reqBody) throws Exception {
		RestAssured.baseURI = executionParams.get("AdtechConfigAuthenticate");
		Response resp1=Authenticate(test, reqBody);
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Cookie", resp1.getHeader("Set-Cookie"));
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("GETDISCOVERYALLAVAILABLEREGION"),
				globalProp, test, headers);
		return resp;
	}
	
	public Response getDisoveryComponentSupportedRegion(ExtentTest test,String reqBody) throws Exception {
		RestAssured.baseURI = executionParams.get("AdtechConfigAuthenticate");
		Response resp1=Authenticate(test, reqBody);
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Cookie", resp1.getHeader("Set-Cookie"));
		Response resp = resuableComponents.executeGetAPI(
				EndPoints.endPointList.get("GETDISCOVERYCOMPONENTSUPPORTEDREGION"), globalProp, test, headers);
		return resp;
	}
	
	public Response getHealthCheck(ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("AdtechConfigAuthenticate");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("GETDISCOVERYHEALTHCHECK"),
				globalProp, test, headers);
		return resp;
	}
	
	public Response getRediness(ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("AdtechConfigAuthenticate");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
				Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("GETDISCOVERYREADINESS"),
				globalProp, test, headers);
		return resp;
	}
	
}
