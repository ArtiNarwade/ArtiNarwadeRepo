package BusinessComponents;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;



import com.EndPoints.EndPoints;
import com.relevantcodes.extentreports.ExtentTest;

import baseTestPackage.BaseTest_TestNG;
import baseTestPackage.SuiteConstant;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import reusableLibrary.ResuableComponents;

public class AdTechDiff  extends BaseTest_TestNG {
	
		
		List<String> list = new ArrayList<String>();
		SuiteConstant suiteMap = new SuiteConstant();
		ResuableComponents resuableComponents = new ResuableComponents();
		
		
		public Response createauthenticateDif(ExtentTest test,String requestBody) throws  Exception {
			RestAssured.baseURI = executionParams.get("AdtechDiffAuth");
			Hashtable<String, String> headers = new Hashtable<String, String>();
			headers.put("Content-Type", globalProp.getProperty("contentType"));
			Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("AUTHENTICATEDIF"), requestBody,globalProp, test, headers);		
			return resp;			
		}
		public Response postreloadCronJob(ExtentTest test,String requestBody ) throws Exception {
			RestAssured.baseURI = executionParams.get("AdtechDiffAuth");
			Response resp1=createauthenticateDif(test,requestBody);
			Hashtable<String, String> headers = new Hashtable<String, String>();
			headers.put("Content-Type", globalProp.getProperty("contentType"));
			resp1.getHeader("Set-Cookie");
			headers.put("Cookie", resp1.getHeader("Set-Cookie"));
			Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("RELOADCRON"),"",globalProp, test, headers);						
			return resp;			
		}
		public Response getenableOrdisableCron(ExtentTest test, String requestbody) throws Exception {
			RestAssured.baseURI = executionParams.get("AdtechDiffAuth");
			Response resp1=createauthenticateDif(test,requestbody);
			Hashtable<String, String> headers = new Hashtable<String, String>();
			headers.put("Content-Type", globalProp.getProperty("contentType"));
			resp1.getHeader("Set-Cookie");
			headers.put("Cookie", resp1.getHeader("Set-Cookie"));
			Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("ENEBLEDISABLECRON"),"",globalProp, test, headers);						
			return resp;			
		}
		
		public Response setAllSkippedChannels(ExtentTest test, String requestbody) throws Exception {
			RestAssured.baseURI = executionParams.get("AdtechDiffAuth");
			Response resp1=createauthenticateDif(test,requestbody);
			Hashtable<String, String> headers = new Hashtable<String, String>();
			headers.put("Content-Type", globalProp.getProperty("contentType"));
			headers.put("Cookie", resp1.getHeader("Set-Cookie"));
			Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("SETSKIPPEDCHANNELS"),"",globalProp, test, headers);						
			return resp;
			
			
		}
		public Response getAllSkippedChannels(ExtentTest test, String requestbody) throws Exception {
			RestAssured.baseURI = executionParams.get("AdtechDiffAuth");
			Response resp1=createauthenticateDif(test,requestbody);
			Hashtable<String, String> headers = new Hashtable<String, String>();
			headers.put("Content-Type", globalProp.getProperty("contentType"));
			resp1.getHeader("Set-Cookie");
			headers.put("Cookie", resp1.getHeader("Set-Cookie"));
			Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("GETALLSKIPPEDCHANNELS"), globalProp,test, headers);						
			return resp;
			
		}
		public Response getevictChannelidfromCache(ExtentTest test, String requestbody) throws Exception {
			RestAssured.baseURI = executionParams.get("AdtechDiffAuth");
			Response resp1=createauthenticateDif(test,requestbody);
			Hashtable<String, String> headers = new Hashtable<String, String>();
			headers.put("Content-Type", globalProp.getProperty("contentType"));
			resp1.getHeader("Set-Cookie");
			headers.put("Cookie", resp1.getHeader("Set-Cookie"));
			Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("EVICTCHANNELID"),"",globalProp, test, headers);
			return resp;
			
		}
		public Response getAssetInfo(ExtentTest test, String requestbody) throws Exception {
			RestAssured.baseURI = executionParams.get("AdtechDiffAuth");
			Response resp1=createauthenticateDif(test,requestbody);
			Hashtable<String, String> headers = new Hashtable<String, String>();
			headers.put("Content-Type", globalProp.getProperty("contentType"));
			resp1.getHeader("Set-Cookie");
			headers.put("Cookie", resp1.getHeader("Set-Cookie"));
			Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("GETASSETINFO"), globalProp,test, headers);			
			return resp;
		}
		
		public Response setCustomeid(ExtentTest test, String requestbody) throws Exception {
			RestAssured.baseURI = executionParams.get("AdtechDiffAuth");
			Response resp1=createauthenticateDif(test,requestbody);
			Hashtable<String, String> headers = new Hashtable<String, String>();
			headers.put("Content-Type", globalProp.getProperty("contentType"));
			resp1.getHeader("Set-Cookie");
			headers.put("Cookie", resp1.getHeader("Set-Cookie"));
			Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("SETCUSTOMID"), "",globalProp, test, headers);
			return resp;
			
		}
		public Response getAllCustomid(ExtentTest test, String requestbody) throws Exception {
			RestAssured.baseURI = executionParams.get("AdtechDiffAuth");
			Response resp1=createauthenticateDif(test,requestbody);
			Hashtable<String, String> headers = new Hashtable<String, String>();
			headers.put("Content-Type", globalProp.getProperty("contentType"));
			resp1.getHeader("Set-Cookie");
			headers.put("Cookie", resp1.getHeader("Set-Cookie"));
			Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("GETCUSTOMID"), globalProp,test, headers);						
			return resp;	
		}
		public Response getHealthCheck(ExtentTest test) throws Exception {
			RestAssured.baseURI = executionParams.get("AdtechDiffAuth");
			Hashtable<String, String> headers = new Hashtable<String, String>();
			headers.put("Content-Type", globalProp.getProperty("contentType"));
			headers.put("Authorization", globalProp.getProperty("AuthorizationToken"));
			Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("HEALTHCHECK"), globalProp,test, headers);
			return resp;	
		}
		public Response getReadiness(ExtentTest test) throws Exception {
			RestAssured.baseURI = executionParams.get("AdtechDiffAuth");
			Hashtable<String, String> headers = new Hashtable<String, String>();
			headers.put("Content-Type", globalProp.getProperty("contentType"));
			headers.put("Authorization", globalProp.getProperty("AuthorizationToken"));
			Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("REDINESS"), globalProp,test, headers);
			return resp;	
		}
		
		
		
		
}