package BusinessComponents;

import com.EndPoints.EndPoints;
import com.relevantcodes.extentreports.ExtentTest;
import java.util.Hashtable;
import baseTestPackage.BaseTest_TestNG;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import reusableLibrary.ResuableComponents;

public class AdTech_mrssfeed_API extends BaseTest_TestNG {
	
ResuableComponents resuableComponents = new ResuableComponents();
	
	//MRSS Feed
	public Response get_mrssFeed(ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("mrss_feed");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("MRSS_FEED"), globalProp, test,headers);
		return resp;
	}


}
