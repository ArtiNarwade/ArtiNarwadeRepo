package BusinessComponents;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

import com.EndPoints.EndPoints;
import com.OTTPlatform.Adtech.AdTech_InHouse_Test;
import com.relevantcodes.extentreports.ExtentTest;

import baseTestPackage.BaseTest_TestNG;
import baseTestPackage.SuiteConstant;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import reusableLibrary.ResuableComponents;

public class Adtech_Inhouse extends BaseTest_TestNG {
	
	
	List<String> list = new ArrayList<String>();
	SuiteConstant suiteMap = new SuiteConstant();
	ResuableComponents resuableComponents = new ResuableComponents();
	
	public Response inhouseGet(ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("Adtech_InhouseServer");
		Hashtable<String, String> headers =new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("Cookie", globalProp.getProperty("cookie"));
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("ADTECHINHOUSE"), globalProp, test, headers);
	 	return resp;
	}
	public Response pixetrackerGet(ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("Adtech_Pixel");
		Hashtable<String, String> headers =new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("Cookie", globalProp.getProperty("cookie"));
		Response resp = resuableComponents.executeGetAPI(AdTech_InHouse_Test.str, globalProp, test, headers);
	 	return resp;
	}
	public Response pixelImpressionGet(ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("Adtech_Pixel");
		Hashtable<String, String> headers =new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("Cookie", globalProp.getProperty("cookie"));
		Response resp = resuableComponents.executeGetAPI(AdTech_InHouse_Test.imp, globalProp, test, headers);
	 	return resp;
	}
	
	
}
