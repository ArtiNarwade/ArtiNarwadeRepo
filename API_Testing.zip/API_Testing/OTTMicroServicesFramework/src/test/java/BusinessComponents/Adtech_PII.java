package BusinessComponents;

import com.EndPoints.EndPoints;
import com.relevantcodes.extentreports.ExtentTest;
import baseTestPackage.BaseTest_TestNG;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import reusableLibrary.ResuableComponents;
import java.util.Hashtable;

public class Adtech_PII extends BaseTest_TestNG {

	ResuableComponents resuableComponents = new ResuableComponents();

	public Response create_PII(ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("AdtechPII");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("ADTECH_PII"),"",globalProp, test);
		return resp;
	}

}
