package BusinessComponents;

import java.util.Hashtable;

import com.EndPoints.EndPoints;
import com.relevantcodes.extentreports.ExtentTest;

import baseTestPackage.BaseTest_TestNG;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import reusableLibrary.ResuableComponents;

public class Adtech_ViewCount extends BaseTest_TestNG {
	
	ResuableComponents resuableComponents = new ResuableComponents();
	
	public Response Create_Viewcount(ExtentTest test, String reqBody) throws Exception {
		RestAssured.baseURI = executionParams.get("AdtechViewcount");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("ADTECH_VIEWCOUNT"), reqBody, globalProp,test, headers);
		return resp;
	}
	

}
