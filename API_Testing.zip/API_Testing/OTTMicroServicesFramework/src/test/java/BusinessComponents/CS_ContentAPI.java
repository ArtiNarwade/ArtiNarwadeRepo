package BusinessComponents;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

import com.EndPoints.EndPoints;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import baseTestPackage.BaseTest_TestNG;
import baseTestPackage.SuiteConstant;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import reusableLibrary.JsonUtils;
import reusableLibrary.ResuableComponents;

public class CS_ContentAPI extends BaseTest_TestNG{

	List<String> list = new ArrayList<String>();
	SuiteConstant suiteMap = new SuiteConstant();
	ResuableComponents resuableComponents = new ResuableComponents();

 public Response getTvShowGenreListUsingGetCall(ExtentTest test)
 {
	 	RestAssured.baseURI = executionParams.get("baseURICSContentAPI");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("ContentAPIcontentType"));
		headers.put("x-access-token", CSU.decrypt(globalProp.getProperty("ContentAPIXAccessToken")));
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("CONTENTAPITVSHOWGENRELIST"),globalProp, test, headers);
		return resp;
 }
 public Response getMovieGenreUsingGetCall(ExtentTest test)
 {
	 	RestAssured.baseURI = executionParams.get("baseURICSContentAPI");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("ContentAPIcontentType"));
		headers.put("x-access-token", CSU.decrypt(globalProp.getProperty("ContentAPIXAccessToken")));
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("CONTENTAPIMOVIEGENRE"),globalProp, test, headers);
		return resp;
 }
 public Response getPartnerFeedContentListingUsingGetCall(ExtentTest test)
 {
	 	RestAssured.baseURI = executionParams.get("baseURICSContentAPI");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("ContentAPIcontentType"));
		headers.put("x-access-token", CSU.decrypt(globalProp.getProperty("ContentAPIXAccessToken")));
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("CONTENTAPIPARTNERFEEDCONTENTLISTING"),globalProp, test, headers);
		return resp;
 }
 public Response getNewsRelatedUsingGetCall(ExtentTest test)
 {
	 	RestAssured.baseURI = executionParams.get("baseURICSContentAPI");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("ContentAPIcontentType"));
		headers.put("x-access-token", CSU.decrypt(globalProp.getProperty("ContentAPIXAccessToken")));
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("CONTENTAPINEWSRELATED"),globalProp, test, headers);
		return resp;
 }
 public Response getExtractPlatformUrlUsingGetCall(ExtentTest test)
 {
	 	RestAssured.baseURI = executionParams.get("baseURICSContentAPI");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("ContentAPIcontentType"));
		headers.put("x-access-token", CSU.decrypt(globalProp.getProperty("ContentAPIXAccessToken")));
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("CONTENTAPIEXTRACTPLATFORMURL"),globalProp, test, headers);
		return resp;
 }
 public Response getTvShowHomeUsingGetCall(ExtentTest test)
 {
	 	RestAssured.baseURI = executionParams.get("baseURICSContentAPI");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("ContentAPIcontentType"));
		headers.put("x-access-token", CSU.decrypt(globalProp.getProperty("ContentAPIXAccessToken")));
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("CONTENTAPITVSHOWHOME"),globalProp, test, headers);
		return resp;
 }
 public Response getMovieLanguagesUsingGetCall(ExtentTest test)
 {
	 	RestAssured.baseURI = executionParams.get("baseURICSContentAPI");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("ContentAPIcontentType"));
		headers.put("x-access-token", CSU.decrypt(globalProp.getProperty("ContentAPIXAccessToken")));
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("CONTENTAPIMOVIELANGUAGES"),globalProp, test, headers);
		return resp;
 }
 public Response getTvShowGenreUsingGetCall(ExtentTest test)
 {
	 	RestAssured.baseURI = executionParams.get("baseURICSContentAPI");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("ContentAPIcontentType"));
		headers.put("x-access-token", CSU.decrypt(globalProp.getProperty("ContentAPIXAccessToken")));
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("CONTENTAPITVSHOWGENRE"),globalProp, test, headers);
		return resp;
 }
 public Response getSEOGenreOrLanguagesUsingGetCall(ExtentTest test)
 {
	 	RestAssured.baseURI = executionParams.get("baseURICSContentAPI");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("ContentAPIcontentType"));
		headers.put("x-access-token", CSU.decrypt(globalProp.getProperty("ContentAPIXAccessToken")));
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("CONTENTAPISEOGENREORLANGUAGES"),globalProp, test, headers);
		return resp;
 }
 
	
	
}
