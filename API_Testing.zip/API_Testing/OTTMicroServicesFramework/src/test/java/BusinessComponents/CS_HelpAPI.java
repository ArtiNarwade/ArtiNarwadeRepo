package BusinessComponents;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

import com.EndPoints.EndPoints;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import baseTestPackage.BaseTest_TestNG;
import baseTestPackage.SuiteConstant;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import reusableLibrary.JsonUtils;
import reusableLibrary.ResuableComponents;

public class CS_HelpAPI extends BaseTest_TestNG{

	List<String> list = new ArrayList<String>();
	SuiteConstant suiteMap = new SuiteConstant();
	ResuableComponents resuableComponents = new ResuableComponents();

 public Response GetTopicId(ExtentTest test)
 {
	 	RestAssured.baseURI = executionParams.get("baseURICSHelp");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("TOPICID"),globalProp, test, headers);
		return resp;
 }

 public Response GetParentTopicId(ExtentTest test)
 {
	 	RestAssured.baseURI = executionParams.get("baseURICSHelp");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("PARENTTOPICID"),globalProp, test, headers);
		return resp;
 }
 
 public Response GetTopicHomeID(ExtentTest test)
 {
	 	RestAssured.baseURI = executionParams.get("baseURICSHelp");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("HOMETOPICID"),globalProp, test, headers);
		return resp;
 }
 
 public Response GetFAQ(ExtentTest test)
 {
	 	RestAssured.baseURI = executionParams.get("baseURICSHelp");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("FAQ"),globalProp, test, headers);
		return resp;
 }
 
 public Response GETStaticHelp(ExtentTest test)
 {
	 	RestAssured.baseURI = executionParams.get("baseURICSHelp");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("STATICPAGE"),globalProp, test, headers);
		return resp;
 }
	
	
	
}
