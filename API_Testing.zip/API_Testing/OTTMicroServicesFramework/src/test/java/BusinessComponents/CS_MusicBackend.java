package BusinessComponents;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import com.EndPoints.EndPoints;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import baseTestPackage.BaseTest_TestNG;
import baseTestPackage.SuiteConstant;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import reusableLibrary.ResuableComponents;

public class CS_MusicBackend extends BaseTest_TestNG{
		
		List<String> list = new ArrayList<String>();
		ResuableComponents resuableComponents = new ResuableComponents();
		
			public Response getUserPlaylistUsingGetCall(ExtentTest test, Hashtable<String, String> headers1) throws Exception{ 
			RestAssured.baseURI = executionParams.get("MusicBackendUrl");
			Hashtable<String, String> headers = new Hashtable<String, String>();
			headers1.put("X-ACCESS-TOKEN", CSU.decrypt(executionParams.get("X-AccessToken")));
			headers.putAll(headers1);
			
			Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("MUSICBACKENDUSERPLAYLIST"),globalProp, test, headers);
			return resp;			
		}
			public Response getArtistDetailsUsingGetCall(ExtentTest test, Hashtable<String, String> headers1) throws Exception{ 
				RestAssured.baseURI = executionParams.get("MusicBackendUrl");
				Hashtable<String, String> headers = new Hashtable<String, String>();
				headers.put("X-ACCESS-TOKEN", CSU.decrypt(executionParams.get("X-AccessToken")));
				headers.putAll(headers1);
				Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("MUSICBACKENDARTISTDETAILS"),globalProp, test, headers);
				return resp;			
			}
			public Response getSongDetailsUsingGetCall(ExtentTest test, Hashtable<String, String> headers1) throws Exception{ 
				RestAssured.baseURI = executionParams.get("MusicBackendUrl");
				Hashtable<String, String> headers = new Hashtable<String, String>();
				headers.put("X-ACCESS-TOKEN", CSU.decrypt(executionParams.get("X-AccessToken")));
				headers.putAll(headers1);
				Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("MUSICBACKENDSONGDETAILS"),globalProp, test, headers);
				return resp;			
			}
		
		public Response getAlbumDetailsGetCall(ExtentTest test, Hashtable<String, String> headers1) throws Exception
		{
			RestAssured.baseURI = executionParams.get("MusicBackendUrl");
			Hashtable<String, String> headers = new Hashtable<String, String>();
			headers.put("X-ACCESS-TOKEN", CSU.decrypt(executionParams.get("X-AccessToken")));
			headers.putAll(headers1);
			Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("MUSICBACKENDALBUMDETAILS"),globalProp, test, headers);
			return resp;
			
		}
		
		public Response getDiscoveryGetCall(ExtentTest test, Hashtable<String, String> headers1) throws Exception
		{
			RestAssured.baseURI = executionParams.get("MusicBackendUrl");
			Hashtable<String, String> headers = new Hashtable<String, String>();
			headers.put("X-ACCESS-TOKEN", CSU.decrypt(executionParams.get("X-AccessToken")));
			headers.putAll(headers1);
			Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("MUSICBACKENDDISCOVERY"),globalProp, test, headers);
			return resp;
			
		}
		public Response UpdateUserPlaylistPUTCall(ExtentTest test, String requestBody, Hashtable<String, String> headers1) throws Exception
		{
			RestAssured.baseURI = executionParams.get("MusicBackendUrl");
			Hashtable<String, String> headers = new Hashtable<String, String>();
			headers.put("Content-Type", globalProp.getProperty("contentType"));
			headers.put("X-ACCESS-TOKEN", CSU.decrypt(executionParams.get("X-AccessToken")));
			headers.putAll(headers1);
			test.log(LogStatus.INFO, "<b>X-accessToken: </b>" + headers.get("X-ACCESS-TOKEN"));
			test.log(LogStatus.INFO, "<b> Authorization: </b>" + headers1.get("Authorization"));
			Response resp = resuableComponents.executePutAPI(EndPoints.endPointList.get("MUSICBACKENDUPDATEUSERPLAYLIST"), requestBody, globalProp, test, headers);
			return resp;
			
		}
		public Response getSongPlaybackGetCall(ExtentTest test, Hashtable<String, String> headers1) throws Exception
		{
			RestAssured.baseURI = executionParams.get("MusicBackendUrl");
			Hashtable<String, String> headers = new Hashtable<String, String>();
			headers.put("X-ACCESS-TOKEN", CSU.decrypt(executionParams.get("X-AccessToken")));
			headers.putAll(headers1);
			Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("MUSICBACKENDSONGPLAYBACK"),globalProp, test, headers);
			return resp;
			
		}
		
		public Response getLanguageListGetCall(ExtentTest test, Hashtable<String, String> headers1) throws Exception
		{
			RestAssured.baseURI = executionParams.get("MusicBackendUrl");
			Hashtable<String, String> headers = new Hashtable<String, String>();
			headers.put("X-ACCESS-TOKEN", CSU.decrypt(executionParams.get("X-AccessToken")));
			headers.putAll(headers1);
			Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("MUSICBACKENDLANGUAGELIST"),globalProp, test, headers);
			return resp;
			
		}
		
		public Response SetUserLanguagePostCall(ExtentTest test, String requestBody, Hashtable<String, String> headers1) throws Exception {
			RestAssured.baseURI = executionParams.get("MusicBackendUrl");
			Hashtable<String, String> headers = new Hashtable<String, String>();
			headers.put("Content-Type", globalProp.getProperty("contentType"));
			headers.put("X-ACCESS-TOKEN", CSU.decrypt(executionParams.get("X-AccessToken")));
			headers.putAll(headers1);
			Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("MUSICBACKENDSETUSERLANGUAGE"), requestBody,globalProp, test, headers);
			return resp;
		}
		
		public Response getUserLanguageGetCall(ExtentTest test, Hashtable<String, String> headers1) throws Exception
		{
			RestAssured.baseURI = executionParams.get("MusicBackendUrl");
			Hashtable<String, String> headers = new Hashtable<String, String>();
			headers.put("X-ACCESS-TOKEN", CSU.decrypt(executionParams.get("X-AccessToken")));
			headers.putAll(headers1);
			Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("MUSICBACKENDUPDATEUSERLANGUAGE"),globalProp, test, headers);
			return resp;
			
		}
		
		public Response getUserPlayListGetCall(ExtentTest test, Hashtable<String, String> headers1) throws Exception
		{
			RestAssured.baseURI = executionParams.get("MusicBackendUrl");
			Hashtable<String, String> headers = new Hashtable<String, String>();
			headers.put("X-ACCESS-TOKEN", CSU.decrypt(executionParams.get("X-AccessToken")));
			headers.putAll(headers1);
			Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("MUSICBACKENDUSERGETPLAYLIST"),globalProp, test, headers);
			return resp;
			
		}
		
		
		public Response UpdateTrackRecordPlaylistPUTCall(ExtentTest test, String requestBody, Hashtable<String, String> headers1) throws Exception
		{
			RestAssured.baseURI = executionParams.get("MusicBackendUrl");
			Hashtable<String, String> headers = new Hashtable<String, String>();
			headers.put("Content-Type", globalProp.getProperty("contentType"));
			headers.put("X-ACCESS-TOKEN", CSU.decrypt(executionParams.get("X-AccessToken")));
			headers.putAll(headers1);
			Response resp = resuableComponents.executePutAPI(EndPoints.endPointList.get("MUSICBACKENDUPDATETRACKRECORDPLAYLIST"), requestBody, globalProp, test, headers);
			return resp;
			
		}
		
		public Response getUserPlayListDetailsGetCall(ExtentTest test, Hashtable<String, String> headers1) throws Exception
		{
			RestAssured.baseURI = executionParams.get("MusicBackendUrl");
			Hashtable<String, String> headers = new Hashtable<String, String>();
			headers.put("X-ACCESS-TOKEN", CSU.decrypt(executionParams.get("X-AccessToken")));
			headers.putAll(headers1);
			Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("MUSICBACKENDPLAYLISTDETAILS"),globalProp, test, headers);
			return resp;
			
		}
		public Response AddFavouritesPOSTCall(ExtentTest test, String requestBody, Hashtable<String, String> headers1) throws Exception
		{
		RestAssured.baseURI = executionParams.get("MusicBackendUrl");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("X-ACCESS-TOKEN", CSU.decrypt(executionParams.get("X-AccessToken")));
		headers.putAll(headers1);
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("MUSICBACKENDADDFAVOURITE"), requestBody,globalProp, test, headers);
		return resp;
		
		}
		public Response getContentFavoriteGetCall(ExtentTest test, Hashtable<String, String> headers1) throws Exception
		{
			RestAssured.baseURI = executionParams.get("MusicBackendUrl");
			Hashtable<String, String> headers = new Hashtable<String, String>();
			headers.put("X-ACCESS-TOKEN", CSU.decrypt(executionParams.get("X-AccessToken")));
			headers.putAll(headers1);
			Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("MUSICBACKENDCONTENTFAVORITE"),globalProp, test, headers);
			return resp;
			
		}
		public Response getFavoriteTypeCountGetCall(ExtentTest test, Hashtable<String, String> headers1) throws Exception
		{
			RestAssured.baseURI = executionParams.get("MusicBackendUrl");
			Hashtable<String, String> headers = new Hashtable<String, String>();
			headers.put("X-ACCESS-TOKEN", CSU.decrypt(executionParams.get("X-AccessToken")));
			headers.putAll(headers1);
			Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("MUSICBACKENDFAVORITETYPECOUNT"),globalProp, test, headers);
			return resp;
			
		}
		
		public Response SearchGetCall(ExtentTest test, Hashtable<String, String> headers1) throws Exception
		{
			RestAssured.baseURI = executionParams.get("MusicBackendUrl");
			Hashtable<String, String> headers = new Hashtable<String, String>();
			headers.put("X-ACCESS-TOKEN", CSU.decrypt(executionParams.get("X-AccessToken")));
			headers.putAll(headers1);
			Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("MUSICBACKENDSEARCH"),globalProp, test, headers);
			return resp;
			
		}
		
		public Response FollowandUnFollowGetCall(ExtentTest test, Hashtable<String, String> headers1) throws Exception
		{
			RestAssured.baseURI = executionParams.get("MusicBackendUrl");
			Hashtable<String, String> headers = new Hashtable<String, String>();
			headers.put("X-ACCESS-TOKEN", CSU.decrypt(executionParams.get("X-AccessToken")));
			headers.putAll(headers1);
			Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("MUSICBACKENDFOLLOWANDUNFoLLOW"),globalProp, test, headers);
			return resp;
			
		}
		
		public Response RecentlyPlayedPOSTCall(ExtentTest test, String requestBody, Hashtable<String, String> headers1) throws Exception
		{
		RestAssured.baseURI = executionParams.get("MusicBackendUrl");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("X-ACCESS-TOKEN", CSU.decrypt(executionParams.get("X-AccessToken")));
		headers.putAll(headers1);
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("MUSICBACKENDRECENTLYPLAYED"), requestBody,globalProp, test, headers);
		return resp;
		
		}
		
		public Response RecentlyPlayedGETCall(ExtentTest test, Hashtable<String, String> headers1) throws Exception
		{
			RestAssured.baseURI = executionParams.get("MusicBackendUrl");
			Hashtable<String, String> headers = new Hashtable<String, String>();
			headers.put("X-ACCESS-TOKEN", CSU.decrypt(executionParams.get("X-AccessToken")));
			headers.putAll(headers1);
			Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("MUSICBACKENDRECENTLYPLAYEDGET"),globalProp, test, headers);
			return resp;
			
		}
		
		public Response SetUserPlaylistPOSTCall(ExtentTest test, String requestBody, Hashtable<String, String> headers1) throws Exception
		{
		RestAssured.baseURI = executionParams.get("MusicBackendUrl");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("X-ACCESS-TOKEN", CSU.decrypt(executionParams.get("X-AccessToken")));
		headers.putAll(headers1);
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("MUSICBACKENDSETUSERPLAYLISTPOST"), requestBody,globalProp, test, headers);
		return resp;
		}
		
		
		public Response CelebRadioGETCall(ExtentTest test, Hashtable<String, String> headers1) throws Exception
		{
			RestAssured.baseURI = executionParams.get("MusicBackendUrl");
			Hashtable<String, String> headers = new Hashtable<String, String>();
			headers.put("X-ACCESS-TOKEN", CSU.decrypt(executionParams.get("X-AccessToken")));
			headers.putAll(headers1);
			Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("MUSICBACKENDCELEBRADIO"),globalProp, test, headers);
			return resp;
			
		}
		public Response OnDemandRadioGETCall(ExtentTest test, Hashtable<String, String> headers1) throws Exception
		{
			RestAssured.baseURI = executionParams.get("MusicBackendUrl");
			Hashtable<String, String> headers = new Hashtable<String, String>();
			headers.put("X-ACCESS-TOKEN", CSU.decrypt(executionParams.get("X-AccessToken")));
			headers.putAll(headers1);
			Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("MUSICBACKENDONDEMANDRADIO"),globalProp, test, headers);
			return resp;
			
		}
		public Response TrendingArtistDetailsGETCall(ExtentTest test, Hashtable<String, String> headers1) throws Exception
		{
			RestAssured.baseURI = executionParams.get("MusicBackendUrl");
			Hashtable<String, String> headers = new Hashtable<String, String>();
			headers.put("X-ACCESS-TOKEN", CSU.decrypt(executionParams.get("X-AccessToken")));
			headers.putAll(headers1);
			Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("MUSICBACKENDTRENDINGARTISTDETAILS"),globalProp, test, headers);
			return resp;
			
		}
		public Response FollowedArtistDetailsGETCall(ExtentTest test, Hashtable<String, String> headers1) throws Exception
		{
			RestAssured.baseURI = executionParams.get("MusicBackendUrl");
			Hashtable<String, String> headers = new Hashtable<String, String>();
			headers.put("X-ACCESS-TOKEN", CSU.decrypt(executionParams.get("X-AccessToken")));
			headers.putAll(headers1);
			Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("MUSICBACKENDFOLLOWEDARTISTLIST"),globalProp, test, headers);
			return resp;
			
		}
		public Response SongsRecomndatoinGETCall(ExtentTest test, Hashtable<String, String> headers1) throws Exception
		{
			RestAssured.baseURI = executionParams.get("MusicBackendUrl");
			Hashtable<String, String> headers = new Hashtable<String, String>();
			headers.put("X-ACCESS-TOKEN", CSU.decrypt(executionParams.get("X-AccessToken")));
			headers.putAll(headers1);
			Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("MUSICBACKENDSONGSRECOMNIDATION"),globalProp, test, headers);
			return resp;
			
		}
		public Response AllTypesRecomndatoinGETCall(ExtentTest test, Hashtable<String, String> headers1) throws Exception
		{
			RestAssured.baseURI = executionParams.get("MusicBackendUrl");
			Hashtable<String, String> headers = new Hashtable<String, String>();
			headers.put("X-ACCESS-TOKEN", CSU.decrypt(executionParams.get("X-AccessToken")));
			headers.putAll(headers1);
			Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("MUSICBACKENDALLTYPERECOMNDIATION"),globalProp, test, headers);
			return resp;
			
		}
		public Response ArtistRecomndatoinGETCall(ExtentTest test, Hashtable<String, String> headers1) throws Exception
		{
			RestAssured.baseURI = executionParams.get("MusicBackendUrl");
			Hashtable<String, String> headers = new Hashtable<String, String>();
			headers.put("X-ACCESS-TOKEN", CSU.decrypt(executionParams.get("X-AccessToken")));
			headers.putAll(headers1);
			Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("MUSICBACKENDARTISTRECOMNIDATION"),globalProp, test, headers);
			return resp;
			
		}
		public Response PlayListGenereGETCall(ExtentTest test, Hashtable<String, String> headers1) throws Exception
		{
			RestAssured.baseURI = executionParams.get("MusicBackendUrl");
			Hashtable<String, String> headers = new Hashtable<String, String>();
			headers.put("X-ACCESS-TOKEN", CSU.decrypt(executionParams.get("X-AccessToken")));
			headers.putAll(headers1);
			Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("MUSICBACKENDPLAYLISTGENERE"),globalProp, test, headers);
			return resp;
			
		}
		public Response PlayListTagGETCall(ExtentTest test, Hashtable<String, String> headers1) throws Exception
		{
			RestAssured.baseURI = executionParams.get("MusicBackendUrl");
			Hashtable<String, String> headers = new Hashtable<String, String>();
			headers.put("X-ACCESS-TOKEN", CSU.decrypt(executionParams.get("X-AccessToken")));
			headers.putAll(headers1);
			Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("MUSICBACKENDPLAYLISTTAG"),globalProp, test, headers);
			return resp;
		}
		
		public Response ViewBucketGETCall(ExtentTest test, Hashtable<String, String> headers1) throws Exception
		{
			RestAssured.baseURI = executionParams.get("MusicBackendUrl");
			Hashtable<String, String> headers = new Hashtable<String, String>();
			headers.put("X-ACCESS-TOKEN", CSU.decrypt(executionParams.get("X-AccessToken")));
			headers.putAll(headers1);
			Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("MUSICBACKENDVIEWBUCKET"),globalProp, test, headers);
			return resp;
			
		}
		public Response HungamaUseridGETCall(ExtentTest test, Hashtable<String, String> headers1) throws Exception
		{
			RestAssured.baseURI = executionParams.get("MusicBackendUrl");
			Hashtable<String, String> headers = new Hashtable<String, String>();
			headers.put("X-ACCESS-TOKEN", CSU.decrypt(executionParams.get("X-AccessToken")));
			headers.putAll(headers1);
			Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("MUSICBACKENDHUNGAMAUSERID"),globalProp, test, headers);
			return resp;
			
		}
		public Response EntryPointRailsGETCall(ExtentTest test, Hashtable<String, String> headers1) throws Exception
		{
			RestAssured.baseURI = executionParams.get("MusicBackendUrl");
			Hashtable<String, String> headers = new Hashtable<String, String>();
			headers.put("X-ACCESS-TOKEN", CSU.decrypt(executionParams.get("X-AccessToken")));
			headers.putAll(headers1);
			Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("MUSICBACKENDENTRYPOINTRAILS"),globalProp, test, headers);
			return resp;
			
		}
		
		public Response DeleteRemoveFavoriteCall(ExtentTest test, String requestBody,Hashtable<String, String> headers1) throws Exception {
			RestAssured.baseURI = executionParams.get("MusicBackendUrl");
			Hashtable<String, String> headers = new Hashtable<String, String>();
			headers.put("Content-Type", globalProp.getProperty("contentType"));
			headers.put("X-ACCESS-TOKEN", CSU.decrypt(executionParams.get("X-AccessToken")));
			headers.putAll(headers1);
			Response resp = resuableComponents.executeDeleteAPI(EndPoints.endPointList.get("MUSICBACKENDDELETEREMOVEFAVORITE"),requestBody,globalProp, test, headers);
			return resp;
		}
		
		public Response DeleteUserPlaylistDeleteCall(ExtentTest test, Hashtable<String, String> headers1,String PlaylistId) throws Exception {
			RestAssured.baseURI = executionParams.get("MusicBackendUrl");
			Hashtable<String, String> headers = new Hashtable<String, String>();
			headers.put("X-ACCESS-TOKEN", CSU.decrypt(executionParams.get("X-AccessToken")));
			headers.putAll(headers1);
			String modifiedenpoint=EndPoints.endPointList.get("MUSICBACKENDDELETEUSERPLAYLIST").replace("ID", PlaylistId);
			Response resp = resuableComponents.executeDeleteAPI(modifiedenpoint,globalProp, test, headers);
			return resp;
		}
		
		public Response DeleteRecentlyPlayedDeleteCall(ExtentTest test, String requestBody,Hashtable<String, String> headers1) throws Exception {
			RestAssured.baseURI = executionParams.get("MusicBackendUrl");
			Hashtable<String, String> headers = new Hashtable<String, String>();
			headers.put("Content-Type", globalProp.getProperty("contentType"));
			headers.put("X-ACCESS-TOKEN", CSU.decrypt(executionParams.get("X-AccessToken")));
			headers.putAll(headers1);
			Response resp = resuableComponents.executeDeleteAPI(EndPoints.endPointList.get("MUSICBACKENDDELETERECENTLYPLAYED"),requestBody,globalProp, test, headers);
			return resp;
		}
		
		public Response DownloadsGETCall(ExtentTest test, Hashtable<String, String> headers1) throws Exception
		{
			RestAssured.baseURI = executionParams.get("MusicBackendUrl");
			Hashtable<String, String> headers = new Hashtable<String, String>();
			headers.put("X-ACCESS-TOKEN", CSU.decrypt(executionParams.get("X-AccessToken")));
			headers.putAll(headers1);
			Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("MUSICBACKENDDOWNLOADS"),globalProp, test, headers);
			return resp;
			
		}
		
		public Response AddDownloadsTrackPOSTCall(ExtentTest test, String requestBody, Hashtable<String, String> headers1) throws Exception
		{
		RestAssured.baseURI = executionParams.get("MusicBackendUrl");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("X-ACCESS-TOKEN", CSU.decrypt(executionParams.get("X-AccessToken")));
		headers.putAll(headers1);
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("MUSICBACKENDADDDOWNLOADSTRACK"), requestBody,globalProp, test, headers);
		return resp;
		}
		
		public Response RemoveSongDownloadsListGETCall(ExtentTest test, Hashtable<String, String> headers1) throws Exception
		{
			RestAssured.baseURI = executionParams.get("MusicBackendUrl");
			Hashtable<String, String> headers = new Hashtable<String, String>();
			headers.put("X-ACCESS-TOKEN", CSU.decrypt(executionParams.get("X-AccessToken")));
			headers.putAll(headers1);
			Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("MUSICBACKENDREMOVESONGSDOWNLOADLIST"),globalProp, test, headers);
			return resp;
			
		}
		public Response DeleteDownloadSongDeleteCall(ExtentTest test, Hashtable<String, String> headers1) throws Exception {
			RestAssured.baseURI = executionParams.get("MusicBackendUrl");
			Hashtable<String, String> headers = new Hashtable<String, String>();
			headers.put("X-ACCESS-TOKEN", CSU.decrypt(executionParams.get("X-AccessToken")));
			headers.putAll(headers1);
			Response resp = resuableComponents.executeDeleteAPI(EndPoints.endPointList.get("MUSICBACKENDDELETEDOWNLOADSONG"),globalProp, test, headers);
			return resp;
		}
		public Response PodCastDetailsGETCall(ExtentTest test, Hashtable<String, String> headers1) throws Exception
		{
			RestAssured.baseURI = executionParams.get("MusicBackendUrl");
			Hashtable<String, String> headers = new Hashtable<String, String>();
			headers.put("X-ACCESS-TOKEN", CSU.decrypt(executionParams.get("X-AccessToken")));
			headers.putAll(headers1);
			Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("MUSICBACKENDPODCASTDETAILS"),globalProp, test, headers);
			return resp;
			
		}
		public Response SimilarPodCaseGETCall(ExtentTest test, Hashtable<String, String> headers1) throws Exception
		{
			RestAssured.baseURI = executionParams.get("MusicBackendUrl");
			Hashtable<String, String> headers = new Hashtable<String, String>();
			headers.put("X-ACCESS-TOKEN", CSU.decrypt(executionParams.get("X-AccessToken")));
			headers.putAll(headers1);
			Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("MUSICBACKENDSIMILARPODCAST"),globalProp, test, headers);
			return resp;
			
		}
		public Response PodCastTagwiseGETCall(ExtentTest test, Hashtable<String, String> headers1) throws Exception
		{
			RestAssured.baseURI = executionParams.get("MusicBackendUrl");
			Hashtable<String, String> headers = new Hashtable<String, String>();
			headers.put("X-ACCESS-TOKEN", CSU.decrypt(executionParams.get("X-AccessToken")));
			headers.putAll(headers1);
			Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("MUSICBACKENDPODCASTTAGWISE"),globalProp, test, headers);
			return resp;
			
		}
		public Response AuthenticatedHungamaUserGETCall(ExtentTest test, Hashtable<String, String> headers1) throws Exception
		{
			RestAssured.baseURI = executionParams.get("MusicBackendUrl");
			Hashtable<String, String> headers = new Hashtable<String, String>();
			headers.put("X-ACCESS-TOKEN", CSU.decrypt(executionParams.get("X-AccessToken")));
			headers.putAll(headers1);
			Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("MUSICBACKENDAUTHENTICATEDHUNGAMAUSER"),globalProp, test, headers);
			return resp;
			
		}
		
		
}
		