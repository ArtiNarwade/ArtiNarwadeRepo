package BusinessComponents;

import java.util.Hashtable;

import com.EndPoints.EndPoints;
import com.relevantcodes.extentreports.ExtentTest;

import baseTestPackage.BaseTest_TestNG;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import reusableLibrary.ResuableComponents;

public class CommunicationEmailAPI extends BaseTest_TestNG{

	ResuableComponents resuableComponents = new ResuableComponents();
	
	public Response PostCommunicationEmail(String requestBody,ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("CommunicationEmailAPI");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("X-Api-Key", CSU.decrypt(globalProp.getProperty("comwp_x-api-key")));
		headers.put("X-Lob-Id", globalProp.getProperty("comwp_X-Lob-Id"));
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("COMMUNICATIONEMAIL_commemailservice"),requestBody,
				globalProp,test,headers);
		return resp;
	}
}
