package BusinessComponents;

import java.util.Hashtable;

import com.EndPoints.EndPoints;
import com.relevantcodes.extentreports.ExtentTest;

import baseTestPackage.BaseTest_TestNG;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import reusableLibrary.ResuableComponents;

public class CommunicationEngineAPI extends BaseTest_TestNG{

	ResuableComponents resuableComponents = new ResuableComponents();
	
	public Response CreateComm(ExtentTest test,String reqBody) throws Exception {
		RestAssured.baseURI = executionParams.get("communicationURI");
		Hashtable<String, String> headers=new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("X-Api-Key", CSU.decrypt(globalProp.getProperty("X-Api-Key")));
		headers.put("X-Lob-Id", globalProp.getProperty("X-Lob-Id"));
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("COMM_communicationeng"), reqBody,
				globalProp, test, headers);
		return resp;
	}
	
	public Response getCommNotification(ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("communicationURI");
		Hashtable<String, String> headers=new Hashtable<String, String>();
		headers.put("X-Api-Key", CSU.decrypt(globalProp.getProperty("X-Api-Key")));
		headers.put("X-Lob-Id", globalProp.getProperty("X-Lob-Id"));
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("COMMNOTIFICATION_communicationeng"), globalProp,
				test, headers);
		return resp;
	}


}
