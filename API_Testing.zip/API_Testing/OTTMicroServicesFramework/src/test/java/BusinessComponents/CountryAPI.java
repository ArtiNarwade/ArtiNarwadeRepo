package BusinessComponents;

import com.EndPoints.EndPoints;
import com.relevantcodes.extentreports.ExtentTest;

import baseTestPackage.BaseTest_TestNG;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import reusableLibrary.ResuableComponents;

public class CountryAPI extends BaseTest_TestNG{
 
	ResuableComponents resuableComponents = new ResuableComponents();
	
	public Response SingleIpOld(ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("countryAPI");
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("SINGLEIPOLD_country"), globalProp,
				test);
		return resp;
	}
	
	public Response MultipleIpOld(ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("countryAPI");
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("MULTIPLEIPOLD_country"), globalProp,
				test);
		return resp;
	}
	
	public Response SingleIpNew(ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("countryAPI");
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("SINGLEIPNEW_country"), globalProp,
				test);
		return resp;
	}
	
	public Response MultipleIpNew(ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("countryAPI");
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("MULTIPLEIPNEW_country"), globalProp,
				test);
		return resp;
	}
	
	public Response NoIp(ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("countryAPI");
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("NOIP_country"), globalProp,
				test);
		return resp;
	}
}
