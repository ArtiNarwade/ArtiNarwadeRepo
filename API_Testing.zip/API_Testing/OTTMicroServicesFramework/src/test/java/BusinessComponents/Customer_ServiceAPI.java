package BusinessComponents;

import baseTestPackage.BaseTest_TestNG;
import com.EndPoints.EndPoints;
import com.relevantcodes.extentreports.ExtentTest;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import reusableLibrary.ResuableComponents;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

public class Customer_ServiceAPI extends BaseTest_TestNG {

    List<String> list = new ArrayList<String>();
    ResuableComponents resuableComponents = new ResuableComponents();
    public Response CrmCustomerservicePOSTCall(ExtentTest test, String fileName) throws Exception {
        RestAssured.baseURI = executionParams.get("CRMBaseUrl");
        Hashtable<String, String> headers = new Hashtable<String, String>();
        headers.put("Content-Type", globalProp.getProperty("contentType"));
        Response resp = resuableComponents.executePostAPI(  EndPoints.endPointList.get("CRMCustomer"),fileName, globalProp, test, headers);
        return resp;
    }
}