package BusinessComponents;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

import com.EndPoints.EndPoints;
import com.relevantcodes.extentreports.ExtentTest;

import baseTestPackage.BaseTest_TestNG;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import reusableLibrary.DBUtils;
import reusableLibrary.MD5HashGenerator;
import reusableLibrary.ResuableComponents;
import reusableLibrary.StringUtils;

public class GCP_OTP_UAT_API extends BaseTest_TestNG {
	
	List<String> list = new ArrayList<String>();
	ResuableComponents resuableComponents = new ResuableComponents();
	
	
		public Response verifyemail(ExtentTest test, String requestBody) throws Exception {
			RestAssured.baseURI = executionParams.get("baseuriusernode");
			Hashtable<String, String> headers = new Hashtable<String, String>();
			headers.put("Content-Type", globalProp.getProperty("contentType"));
			headers.put("device_id", globalProp.getProperty("UserToken_deviceID"));
			headers.put("esk",globalProp.getProperty("UserToken_eskID"));
			Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("GCP_OTPVERIFY"), requestBody,globalProp, test, headers);
			return resp;
			
		
	}
		public Response SendEmailORMOBILEOTPPOSTCall(ExtentTest test, String requestBody) throws Exception {
			RestAssured.baseURI = executionParams.get("baseuriusernode");
			Hashtable<String, String> headers = new Hashtable<String, String>();
			headers.put("Content-Type", globalProp.getProperty("contentType"));
			headers.put("device_id", globalProp.getProperty("UserToken_deviceID"));
			headers.put("esk",globalProp.getProperty("UserToken_eskID"));
			Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("GCP_SENDMOBILEOTPV2"), requestBody,globalProp, test, headers);
			return resp;
		}
		public Response verifyemailv2(ExtentTest test, String requestBody) throws Exception {
			RestAssured.baseURI = executionParams.get("baseuriusernode");
			Hashtable<String, String> headers = new Hashtable<String, String>();
			headers.put("Content-Type", globalProp.getProperty("contentType"));
			headers.put("device_id", globalProp.getProperty("UserToken_deviceID"));
			headers.put("esk",globalProp.getProperty("UserToken_eskID"));
			Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("GCP_OTPVERIFYV2"), requestBody,globalProp, test, headers);
			return resp;
			
		
	}
		public Response VerifyOTPregisterv2(ExtentTest test, String requestBody) throws Exception 
		{
			RestAssured.baseURI = executionParams.get("baseuriusernode");
			Hashtable<String, String> headers = new Hashtable<String, String>();
			headers.put("Content-Type", globalProp.getProperty("contentType"));
			headers.put("device_id", globalProp.getProperty("UserToken_deviceID"));
			headers.put("esk",globalProp.getProperty("UserToken_eskID"));
			Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("GCP_OTPREGISTEREMAIL"), requestBody,globalProp, test, headers);
			return resp;
		}
		
	
		public Response Userrenewv1_POST(ExtentTest test,String endpoint)
		{
			RestAssured.baseURI = executionParams.get("baseuriusernode");
			Hashtable<String, String> headers = new Hashtable<String, String>();
			headers.put("Content-Type", globalProp.getProperty("contentType"));
			headers.put("device_id", globalProp.getProperty("UserToken_deviceID"));
			headers.put("esk",globalProp.getProperty("UserToken_eskID"));
			Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("GCP_USERRENEW_V1").replace("$RefreshToken$", endpoint), "",globalProp, test, headers);
			return resp;
			
		}
		
		public Response Userrenewv2_POST(ExtentTest test,String endpoint)
		{
			RestAssured.baseURI = executionParams.get("baseuriusernode");
			Hashtable<String, String> headers = new Hashtable<String, String>();
			headers.put("Content-Type", globalProp.getProperty("contentType"));
			headers.put("device_id", globalProp.getProperty("UserToken_deviceID"));
			headers.put("esk",globalProp.getProperty("UserToken_eskID"));
			Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("GCP_USERRENEW_V2").replace("$RefreshToken$", endpoint), "",globalProp, test, headers);
			return resp;
			
		}
		
		public Response HealthCheckV1(ExtentTest test)
		{
			RestAssured.baseURI = executionParams.get("baseuriusernode");
			Hashtable<String, String> headers = new Hashtable<String, String>();
			headers.put("Content-Type", globalProp.getProperty("contentType"));
			headers.put("device_id", globalProp.getProperty("UserToken_deviceID"));
			headers.put("esk",globalProp.getProperty("UserToken_eskID"));
			Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("GCP_AS1"),globalProp, test, headers);
			return resp;
			
		}
		public Response HealthCheckV2(ExtentTest test)
		{
			RestAssured.baseURI = executionParams.get("baseuriusernode");
			Hashtable<String, String> headers = new Hashtable<String, String>();
			headers.put("Content-Type", globalProp.getProperty("contentType"));
			headers.put("device_id", globalProp.getProperty("UserToken_deviceID"));
			headers.put("esk",globalProp.getProperty("UserToken_eskID"));
			Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("GCP_AS2"),globalProp, test, headers);
			return resp;
			
		}
		
		public Response GetUser(ExtentTest test,String Token)
		{
			RestAssured.baseURI = executionParams.get("baseuriusernode");
			Hashtable<String, String> headers = new Hashtable<String, String>();
			headers.put("Content-Type", globalProp.getProperty("contentType"));
			headers.put("device_id", globalProp.getProperty("UserToken_deviceID"));
			headers.put("esk",globalProp.getProperty("UserToken_eskID"));
			headers.put("Authorization", "bearer "+Token);
			Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("GCP_GETUSERV1"),globalProp, test, headers);
			return resp;
			
		}

}
