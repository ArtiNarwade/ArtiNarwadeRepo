package BusinessComponents;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

import com.EndPoints.EndPoints;
import com.relevantcodes.extentreports.ExtentTest;

import baseTestPackage.BaseTest_TestNG;
import baseTestPackage.SuiteConstant;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import reusableLibrary.ResuableComponents;

public class GCP_PlayBack extends BaseTest_TestNG {
	
	
	List<String> list = new ArrayList<String>();
	SuiteConstant suiteMap = new SuiteConstant();
	ResuableComponents resuableComponents = new ResuableComponents();
	
	public Response get_GcpGeneric(ExtentTest test, String global, String endpoint) throws Exception {
		RestAssured.baseURI = executionParams.get(global);
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("x-access-token", CSU.decrypt(globalProp.getProperty("gcptoken")));
			Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get(endpoint),globalProp, test, headers);
		return resp;
	}	
	
}
