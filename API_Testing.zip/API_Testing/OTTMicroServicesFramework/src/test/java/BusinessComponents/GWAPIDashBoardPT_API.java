package BusinessComponents;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

import com.EndPoints.EndPoints;
import com.relevantcodes.extentreports.ExtentTest;

import baseTestPackage.BaseTest_TestNG;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import reusableLibrary.ResuableComponents;

public class GWAPIDashBoardPT_API extends BaseTest_TestNG {
	
	List<String> list = new ArrayList<String>();
	ResuableComponents resuableComponents = new ResuableComponents();
	
	public Response LoginPostCall(ExtentTest test, String requestBody, Hashtable<String, String> headers1) throws Exception {
		RestAssured.baseURI = executionParams.get("baseGWAPIDashboard");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.putAll(headers1);
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("LOGIN"), requestBody,globalProp, test, headers);
		return resp;
	}
	
	public Response TTLUpdatePostCall(ExtentTest test, String requestBody, Hashtable<String, String> headers1) throws Exception {
		RestAssured.baseURI = executionParams.get("baseGWAPIDashboard");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.putAll(headers1);
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("UPDATETTL"), requestBody,globalProp, test, headers);
		return resp;
	}
	
	public Response CachingContentGenreDeleteCall(ExtentTest test, String requestBody,Hashtable<String, String> headers1) throws Exception {
		RestAssured.baseURI = executionParams.get("baseGWAPIDashboard");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		
		headers.putAll(headers1);
		Response resp = resuableComponents.executeDeleteAPI(EndPoints.endPointList.get("CACHINGCONTENTGENRE"),requestBody,globalProp, test, headers);
		return resp;
	}

	public Response DetailsDeleteCall(ExtentTest test, String requestBody,Hashtable<String, String> headers1) throws Exception {
		RestAssured.baseURI = executionParams.get("baseGWAPIDashboard");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		
		headers.putAll(headers1);
		Response resp = resuableComponents.executeDeleteAPI(EndPoints.endPointList.get("DETAILS"),requestBody,globalProp, test, headers);
		return resp;
	}
	
	public Response TVShowAPIDeleteCall(ExtentTest test, String requestBody,Hashtable<String, String> headers1) throws Exception {
		RestAssured.baseURI = executionParams.get("baseGWAPIDashboard");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.putAll(headers1);
		Response resp = resuableComponents.executeDeleteAPI(EndPoints.endPointList.get("TVSHOWAPIS"),requestBody,globalProp, test, headers);
		return resp;
	}
	
	public Response ContentGenreDeleteCall(ExtentTest test, String requestBody,Hashtable<String, String> headers1) throws Exception {
		RestAssured.baseURI = executionParams.get("baseGWAPIDashboard");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.putAll(headers1);
		Response resp = resuableComponents.executeDeleteAPI(EndPoints.endPointList.get("CONTENTGENERE"),requestBody,globalProp, test, headers);
		return resp;
	}
	
	public Response nextpreviousDeleteCall(ExtentTest test, String requestBody,Hashtable<String, String> headers1) throws Exception {
		RestAssured.baseURI = executionParams.get("baseGWAPIDashboard");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.putAll(headers1);
		Response resp = resuableComponents.executeDeleteAPI(EndPoints.endPointList.get("NEXTPREVIOUS"),requestBody,globalProp, test, headers);
		return resp;
	}
	
	public Response APIRulesDeleteCall(ExtentTest test, Hashtable<String, String> headers1) throws Exception {
		RestAssured.baseURI = executionParams.get("baseGWAPIDashboard");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.putAll(headers1);
		Response resp = resuableComponents.executeDeleteAPI(EndPoints.endPointList.get("APIRULES"),globalProp, test, headers);
		return resp;
	}
	
	public Response APIRulesTVShowsDeleteCall(ExtentTest test, Hashtable<String, String> headers1) throws Exception {
		RestAssured.baseURI = executionParams.get("baseGWAPIDashboard");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.putAll(headers1);
		Response resp = resuableComponents.executeDeleteAPI(EndPoints.endPointList.get("APIRULESTVSHOWS"),globalProp, test, headers);
		return resp;
	}
	public Response APIRulesNextPreviousDeleteCall(ExtentTest test, Hashtable<String, String> headers1) throws Exception {
		RestAssured.baseURI = executionParams.get("baseGWAPIDashboard");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.putAll(headers1);
		Response resp = resuableComponents.executeDeleteAPI(EndPoints.endPointList.get("APIRULESNEXTPREVIOUS"),globalProp, test, headers);
		return resp;
	}
	public Response APIRulesDetailsDeleteCall(ExtentTest test, Hashtable<String, String> headers1) throws Exception {
		RestAssured.baseURI = executionParams.get("baseGWAPIDashboard");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.putAll(headers1);
		Response resp = resuableComponents.executeDeleteAPI(EndPoints.endPointList.get("APIRULESDETAILS"),globalProp, test, headers);
		return resp;
	}
}
