package BusinessComponents;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

import com.EndPoints.EndPoints;
import com.relevantcodes.extentreports.ExtentTest;

import baseTestPackage.BaseTest_TestNG;
import baseTestPackage.SuiteConstant;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import reusableLibrary.ResuableComponents;
import io.restassured.path.json.JsonPath;

public class GamesAPI extends BaseTest_TestNG {

	List<String> list = new ArrayList<String>();
	SuiteConstant suiteMap = new SuiteConstant();
	ResuableComponents resuableComponents = new ResuableComponents();

	// method to generate x-access token
	public String getXaccessToken(ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("x-acess");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Cookie", CSU.decrypt(globalProp.getProperty("x-access-cookies")));
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("x-acesstoken"), globalProp, test,
				headers);
		JsonPath jsonPath = resp.jsonPath();
		String token = jsonPath.getString("token");
		return token;
	}

	public Response getCallForAllGames(ExtentTest test) throws Exception {
		String access_token = getXaccessToken(test);
		RestAssured.baseURI = executionParams.get("baseURIGames");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("device-identifier", globalProp.getProperty("games_device_identifier"));
		headers.put("x-access-token", access_token);
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("GAMESFILTERALL"), globalProp, test,
				headers);
		return resp;
	}

	public Response getCallForAllowedTagGames(ExtentTest test) throws Exception {
		String access_token = getXaccessToken(test);
		RestAssured.baseURI = executionParams.get("baseURIGames");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("device-identifier", globalProp.getProperty("games_device_identifier"));
		headers.put("x-access-token", access_token);
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("GAMESALLOWEDTAGS"), globalProp,
				test, headers);
		return resp;
	}

	public Response getRecentlyPlayedGamesWithStreak(ExtentTest test) throws Exception {
		String access_token = getXaccessToken(test);
		RestAssured.baseURI = executionParams.get("baseURIGames");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("device-identifier", globalProp.getProperty("games_device_identifier"));
		headers.put("x-access-token", access_token);
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("GAMESWITHSTREAK"), globalProp,
				test, headers);
		return resp;
	}

	public Response getRecentlyPlayedGamesWithoutStreak(ExtentTest test) throws Exception {
		String access_token = getXaccessToken(test);
		RestAssured.baseURI = executionParams.get("baseURIGames");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("device-identifier", globalProp.getProperty("games_device_identifier"));
		headers.put("x-access-token", access_token);
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("GAMESWITHOUTSTREAK"), globalProp,
				test, headers);
		return resp;
	}

	public Response deleteRecentlyPlayedWithStreak(ExtentTest test) throws Exception {
		String access_token = getXaccessToken(test);
		RestAssured.baseURI = executionParams.get("baseURIGames");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("device-identifier", globalProp.getProperty("games_device_identifier"));
		headers.put("x-access-token", access_token);
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.executeDeleteAPI(EndPoints.endPointList.get("DELETEGAMESWITHSTREAK"),
				globalProp, test, headers);
		return resp;
	}

	public Response deleteRecentlyPlayedWithoutStreak(ExtentTest test) throws Exception {
		String access_token = getXaccessToken(test);
		RestAssured.baseURI = executionParams.get("baseURIGames");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("device-identifier", globalProp.getProperty("games_device_identifier"));
		headers.put("x-access-token", access_token);
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.executeDeleteAPI(EndPoints.endPointList.get("DELETEGAMESWITHOUTSTREAK"),
				globalProp, test, headers);
		return resp;
	}

	public Response getUserDataQuestion(ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("baseURIGames");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("device-identifier", globalProp.getProperty("games_device_identifier"));
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("USERDATAQUESTION"), globalProp,
				test, headers);
		return resp;
	}

	public Response createDataEntry(String requestBody, ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("baseURIGames");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("device-identifier", globalProp.getProperty("games_device_identifier"));
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("CREATEDATAENTRYGAMES"),
				requestBody, globalProp, test, headers);
		return resp;
	}

	public Response feedbackSubmit(String requestBody, ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("baseURIGames");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("device-identifier", globalProp.getProperty("games_device_identifier"));
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("CREATEFEEDBACKSUBMIT"),
				requestBody, globalProp, test, headers);
		return resp;
	}

	public Response feedbackGetQuestion(String requestBody, ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("baseURIGames");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("device-identifier", globalProp.getProperty("games_device_identifier"));
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("CREATEFEEDBACKGETQUESTION"),
				requestBody, globalProp, test, headers);
		return resp;
	}

	public Response getDiscountHyperlink(ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("baseURIGames");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("device-identifier", globalProp.getProperty("games_discount_device_identifier"));
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("DISCOUNTHYPERLINK"), "",
				globalProp, test, headers);
		return resp;
	}

	public Response userDataSubmit(String requestBody, String token, ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("baseURIGames");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("device-identifier", globalProp.getProperty("games_usersubmit_device_identifier"));
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("Authorization", "bearer " + token);
		headers.put("esk", globalProp.getProperty("games_usersubmit_esk"));
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("USERDATASUBMIT"), requestBody,
				globalProp, test, headers);
		return resp;
	}

}