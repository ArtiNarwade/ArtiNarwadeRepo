package BusinessComponents;

import java.util.Hashtable;

import com.EndPoints.EndPoints;
import com.relevantcodes.extentreports.ExtentTest;

import baseTestPackage.BaseTest_TestNG;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import reusableLibrary.ResuableComponents;

public class GuestUserCuj_API extends BaseTest_TestNG{

	ResuableComponents resuableComponents = new ResuableComponents();
	
	public Response updateGuestUserUsingPutCall(ExtentTest test, String reqBody,String guestToken) throws Exception {
		RestAssured.baseURI = executionParams.get("GuestScyllaUrl");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("X-Z5-Guest-Token", (guestToken));
		headers.put("Content-Type", globalProp.getProperty("GuestScyllaContentType"));
		Response resp = resuableComponents.executePutAPI(EndPoints.endPointList.get("GUESTSCYLLAUSERDETAILSUPDATE"), reqBody, globalProp, test, headers);
		return resp;
	}
	public Response updateGuestUserUsingNewTokenPutCall(ExtentTest test, String reqBody,String guestToken) throws Exception {
		RestAssured.baseURI = executionParams.get("GuestScyllaUrl");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("X-Z5-Guest-Token", (guestToken));
		headers.put("Content-Type", globalProp.getProperty("GuestScyllaContentType"));
		Response resp = resuableComponents.executePutAPI(EndPoints.endPointList.get("GUESTSCYLLAUSERDETAILSUPDATEWITHNEWTOKEN"), reqBody, globalProp, test, headers);
		return resp;
	}
	public Response getGuestUserDetailsPutCall(ExtentTest test,String guestToken) throws Exception{ 
		RestAssured.baseURI = executionParams.get("GuestScyllaUrl");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("X-Z5-Guest-Token", (guestToken));
		headers.put("Content-Type", globalProp.getProperty("GuestScyllaContentType"));
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("GUESTSCYLLAUSERDETAILS"),globalProp, test, headers);
		return resp;			
	}
}
