package BusinessComponents;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

import com.EndPoints.EndPoints;
import com.relevantcodes.extentreports.ExtentTest;
import baseTestPackage.BaseTest_TestNG;
import baseTestPackage.SuiteConstant;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import reusableLibrary.ResuableComponents;

public class Invoice_AsAPI extends BaseTest_TestNG{

	List<String> list = new ArrayList<String>();
	SuiteConstant suiteMap = new SuiteConstant();
	ResuableComponents resuableComponents = new ResuableComponents();

 public Response GetactuatorHealth(ExtentTest test)
 {
	 	RestAssured.baseURI = executionParams.get("baseURIActHealth");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("GETactuator_health"),globalProp, test, headers);
		return resp;
 }
 
 public Response GetPurchase(ExtentTest test,String subscriptionId,String paymentId)
 {
	 	RestAssured.baseURI = executionParams.get("baseURIActHealth");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));		
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("GETpurchase"),globalProp, test, headers);
		return resp;
 }
 
 public Response GetPurchaseNoPaymentId(ExtentTest test,String subscriptionId)
 {
	 	RestAssured.baseURI = executionParams.get("baseURIActHealth");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));		
		String endPoint=  EndPoints.endPointList.get("GETpurchase_nopayment").replace("{subscriptionId}", subscriptionId);		
		Response resp = resuableComponents.executeGetAPI(endPoint,globalProp, test, headers);
		return resp;
 }
 
 public Response GetPurchaseNoSubId(ExtentTest test,String paymentId)
 {
	 	RestAssured.baseURI = executionParams.get("baseURIActHealth");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));		
		String endPoint=  EndPoints.endPointList.get("GETpurchase_nosubid").replace("{paymentId}", paymentId);		
		Response resp = resuableComponents.executeGetAPI(endPoint,globalProp, test, headers);
		return resp;
 }
 
}
