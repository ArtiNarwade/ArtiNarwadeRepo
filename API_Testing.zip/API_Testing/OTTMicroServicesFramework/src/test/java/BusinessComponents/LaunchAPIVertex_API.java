package BusinessComponents;


import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import com.EndPoints.EndPoints;
import com.relevantcodes.extentreports.ExtentTest;

import baseTestPackage.BaseTest_TestNG;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import reusableLibrary.ResuableComponents;

public class LaunchAPIVertex_API extends BaseTest_TestNG {
	
	List<String> list = new ArrayList<String>();
	ResuableComponents resuableComponents = new ResuableComponents();
	
	public Response LAUNCHEKSGET(ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("baselaunchvertex");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("LAUNCHAPIVERTEX"),globalProp, test, headers);
		return resp;
	}
	

}
