package BusinessComponents;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

import com.EndPoints.EndPoints;
import com.relevantcodes.extentreports.ExtentTest;

import baseTestPackage.BaseTest_TestNG;
import baseTestPackage.SuiteConstant;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import reusableLibrary.ResuableComponents;

public class MW_ContentDashboardAPI extends BaseTest_TestNG {
	
	List<String> list = new ArrayList<String>();
	SuiteConstant suiteMap = new SuiteConstant();
	ResuableComponents resuableComponents = new ResuableComponents();

	public Response getContentDashboard(ExtentTest test) throws Exception {
		RestAssured.baseURI =executionParams.get("Content_Dashboard_baseURI");
		Hashtable<String, String> headers =new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("Cookie", globalProp.getProperty("cookie"));
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("GETCONTENTDASHBOARD"), globalProp, test, headers);
		int statusCode = resp.getStatusCode();
		return resp;
	}
	
	public Response beforeTvAdd(ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("Content_Dashboard_baseURI");
		Hashtable<String, String> headers =new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("Cookie", globalProp.getProperty("cookie"));
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("BEFORETVADD"), globalProp, test, headers);
		int statusCode = resp.getStatusCode();
		 
		return resp;
	}
	
	public Response beforeTvFilter(ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("Content_Dashboard_baseURI");
		Hashtable<String, String> headers =new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("Cookie", globalProp.getProperty("cookie"));
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("BEFORETVFILTER"), globalProp, test, headers);
		int statusCode = resp.getStatusCode();
	 	return resp;
	}

	public Response verifyContentDashboard(String body,ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("Content_Dashboard_baseURI");
		Hashtable<String, String> headers =new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("Cookie", globalProp.getProperty("cookie"));
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("VERIFYCONTENTDASHBOARD"), body, globalProp, test, headers);
		int statusCode = resp.getStatusCode();
		return resp;
	}

}
