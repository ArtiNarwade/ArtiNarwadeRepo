package BusinessComponents;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

import com.EndPoints.EndPoints;
import com.relevantcodes.extentreports.ExtentTest;

import baseTestPackage.BaseTest_TestNG;
import baseTestPackage.SuiteConstant;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import reusableLibrary.ResuableComponents;

public class MW_ImageProcessHealthCheckAPI extends BaseTest_TestNG {
	List<String> list = new ArrayList<String>();
	SuiteConstant suiteMap = new SuiteConstant();
	ResuableComponents resuableComponents = new ResuableComponents();
	
	 
	  
 	public Response GetDPCall(ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("dataprocessURL");
	 	Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("TIGGER"), globalProp, test);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
	 	return resp;
	}	 
 	 
	public Response GetIPHealthCheckCall(ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("dataprocessURL");
	 	Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("IMAGEPROCESSHEALTHCHECK"), globalProp, test);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
	 	return resp;
		
	}	
	public Response getIMRedis_TestCall(ExtentTest test) throws Exception {
		RestAssured.baseURI =  executionParams.get("dataprocessURL");
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("REDISTEST"), globalProp, test);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
	 	return resp;
	}
 
	public Response GetIPTiggerCall(ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("dataprocessURL");
	 	Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("IMAGEPROCESSTIGGER"), globalProp, test);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
	 	return resp;
	}	
	public Response GetDPHealthCheckAPICall(ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("dataprocessURL");
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("HEALTHCHECK"), globalProp, test);;    
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
	   	return resp;
	}
}
			

