package BusinessComponents;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import com.EndPoints.EndPoints;
import com.relevantcodes.extentreports.ExtentTest;

import baseTestPackage.BaseTest_TestNG;
import baseTestPackage.SuiteConstant;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import reusableLibrary.ResuableComponents;

public class MW_Launch_API extends BaseTest_TestNG {
	List<String> list = new ArrayList<String>();
	SuiteConstant suiteMap = new SuiteConstant();
	ResuableComponents resuableComponents = new ResuableComponents();

	public Response GetCountryCodeApiCall(ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("launchApiURL");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("Cookie", CSU.decrypt(globalProp.getProperty("cookie")));
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("COUNTRYCODE"), globalProp, test,headers);
		return resp;
	}

}
