package BusinessComponents;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import com.EndPoints.EndPoints;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import baseTestPackage.BaseTest_TestNG;
import baseTestPackage.SuiteConstant;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import reusableLibrary.ResuableComponents;

public class MetadataDomainServiceAPI extends BaseTest_TestNG {
	
	List<String> list = new ArrayList<String>();
	ResuableComponents resuableComponents = new ResuableComponents();
	
	public Response MetadatadomaniServiceGetCall(ExtentTest test) throws Exception{ 
		RestAssured.baseURI = executionParams.get("basemetadadomainserviceurl");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("METADATADOMAINSERVICE"),globalProp, test, headers);
		return resp;			
	}
	

}
