package BusinessComponents;

import java.util.Hashtable;

import com.EndPoints.EndPoints;
import com.relevantcodes.extentreports.ExtentTest;

import baseTestPackage.BaseTest_TestNG;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import reusableLibrary.ResuableComponents;

public class MirageAPI extends BaseTest_TestNG{

	ResuableComponents resuableComponents = new ResuableComponents();
	String posttag;
	
	public Response CreateSSOTag(String requestBody,ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("mirageURI");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("Authorization", CSU.decrypt(globalProp.getProperty("posttag_Authorization")));
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("GENERATESSOTAG_mirage"),requestBody,
				globalProp,test,headers);
		
		JsonPath js=resp.jsonPath();
		posttag=js.get("tag");
		System.out.println("SSO Tag is...." + posttag);
		return resp;
	}
	
	public Response GetAuthToken(ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("mirageURI");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.getAuthToken_Mirage(EndPoints.endPointList.get("GETAUTHTOKEN_mirage"), globalProp, test, posttag);
		return resp;
	}
}
