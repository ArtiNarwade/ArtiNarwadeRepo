package BusinessComponents;


import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import com.EndPoints.EndPoints;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import baseTestPackage.BaseTest_TestNG;
import baseTestPackage.SuiteConstant;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import reusableLibrary.ResuableComponents;

public class NotificationService_API extends BaseTest_TestNG {
	
	List<String> list = new ArrayList<String>();
	ResuableComponents resuableComponents = new ResuableComponents();
	
	public Response getNotificationGETCall(ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("basenotificationurl");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
	
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("GETNOTIFICATION"),globalProp, test, headers);
		return resp;
	}

		
	public Response PostNotificationPOSTCall(ExtentTest test, String requestBody) throws Exception {
		RestAssured.baseURI = executionParams.get("basenotificationurl");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("X-API-KEY", CSU.decrypt(globalProp.getProperty("X-API-KEY")));
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("POSTNOTIFICATION"), requestBody,globalProp, test, headers);
		return resp;
	}


}
