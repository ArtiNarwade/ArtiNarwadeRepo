
package BusinessComponents;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import java.util.Random;

import com.EndPoints.EndPoints;
import com.relevantcodes.extentreports.ExtentTest;

import baseTestPackage.BaseTest_TestNG;
import baseTestPackage.SuiteConstant;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import reusableLibrary.ResuableComponents;

public class OtpApi extends BaseTest_TestNG {
	List<String> list = new ArrayList<String>();
	UM_UserToken usertoken = new UM_UserToken();
	public static String responsebody;
	SuiteConstant suiteMap = new SuiteConstant();
	ResuableComponents resuableComponents = new ResuableComponents();
    
    public String generateMD5(String input) {
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            md.update(input.getBytes());
            byte[] byteData = md.digest();

            // Convert the byte array to a hexadecimal string
            StringBuilder sb = new StringBuilder();
            for (byte b : byteData) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            System.err.println("MD5 algorithm not found");
            e.printStackTrace();
            return null;
        }
    }

    public Response SendEmailOrMobileOtpPostCall(ExtentTest test, String requestBody) throws Exception {
		RestAssured.baseURI = globalProp.getProperty("uapinodeserviceuri");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("device_id", globalProp.getProperty("UserToken_deviceID"));
		headers.put("esk",globalProp.getProperty("UserToken_eskID"));
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("SENDOTP"), requestBody,globalProp, test, headers);
		return resp;
	}
    
    public Response VerifyEmailOrMobileOtpPostCall(ExtentTest test, String requestBody) throws Exception {
		RestAssured.baseURI = globalProp.getProperty("uapinodeserviceuri");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("device_id", globalProp.getProperty("UserToken_deviceID"));
		headers.put("esk",globalProp.getProperty("UserToken_eskID"));
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("VERIFYOTP"), requestBody,globalProp, test, headers);
		return resp;
	}
	
	
	//Reusable to get OTP form the String recieved from DB
	
	public String OTPCode(String data)
	{
		String[] Data=data.split(",");
		String [] code= Data[1].split(":");
		String OTP=code[1];
		OTP=OTP.replaceAll("\"", "");
		
		return OTP;
		
	}
	
	private static String generateRandomString(int length) {
        int leftLimit = 48; // '0' ASCII value
        int rightLimit = 122; // 'z' ASCII value
        Random random = new Random();

        String generatedString = random.ints(leftLimit, rightLimit + 1)
                .filter(i -> (i <= 57 || (i >= 65 && i <= 90) || i >= 97))
                .limit(length)
                .collect(StringBuilder::new, StringBuilder::appendCodePoint, StringBuilder::append)
                .toString();

        return generatedString;
    }
	
	public String generateRandomEmailid() {
		return "auto" + generateRandomString(4) + "@yopmail.com";
	}
}
