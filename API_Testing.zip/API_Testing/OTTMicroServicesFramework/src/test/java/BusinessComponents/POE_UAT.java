package BusinessComponents;

import java.util.Hashtable;

import com.EndPoints.EndPoints;
import com.relevantcodes.extentreports.ExtentTest;

import baseTestPackage.BaseTest_TestNG;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import reusableLibrary.ResuableComponents;

public class POE_UAT extends BaseTest_TestNG{

	ResuableComponents resuableComponents = new ResuableComponents();
	
	public Response OrderMgmtCheckout(String requestBody, ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("poeURI");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("api-key", CSU.decrypt(globalProp.getProperty("ordermgmt_api-key")));
		headers.put("jwttoken", CSU.decrypt(globalProp.getProperty("ordermgmt_jwttoken")));
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("ORDERMGMT_POE"), requestBody,
				globalProp,test,headers);
		return resp;
	}
	
	public Response OrderMgmtPayment(String requestBody, ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("poeURI");
		// RestAssured.baseURI = globalProp.getProperty("securepaymentURI");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("api-key", CSU.decrypt(globalProp.getProperty("ordermgmt_api-key")));
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("ORDERMGMTPAYMENT_POE"), requestBody,
				globalProp,test,headers);
		return resp;
	}
	
	/*public Response OlmHookPayment(String requestBody, ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("poeURI");
		// RestAssured.baseURI = globalProp.getProperty("securepaymentURI");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("api-key", globalProp.getProperty("poe_api-key"));
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("ORDERMGMTPAYMENT_POE"), requestBody,
				globalProp,test,headers);
		return resp;
	}*/
	
	public Response OrderbffCheckout(String requestBody, ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("order-bff");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("x-access-token", CSU.decrypt(globalProp.getProperty("checkout_x-access-token")));
		headers.put("authorization", CSU.decrypt(globalProp.getProperty("checkout_authorization")));
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("ORDERBFF_POE"), requestBody,
				globalProp,test,headers);
		return resp;
	}
	
	public Response GlobalCheckout(String requestBody, ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("poeURI");
		// RestAssured.baseURI = globalProp.getProperty("securepaymentURI");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("api-key", CSU.decrypt(globalProp.getProperty("global_api-key")));
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("GLOBALCHECKOUT_POE"), requestBody,
				globalProp,test,headers);
		return resp;
	}
	
	public Response GetOrderMgmt( ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("poeURI");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("api-key", CSU.decrypt(globalProp.getProperty("ordermgmt_api-key")));
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("GETORDERMGMTALL_POE"),
				globalProp,test,headers);
		return resp;
	}
	
	public Response GetOrderMgmtPromote( ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("poeURI");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("api-key", CSU.decrypt(globalProp.getProperty("ordermgmt_api-key")));
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("GETORDERMGMTPROMOTE_POE"),
				globalProp,test,headers);
		return resp;
	}
	
	public Response GetOrderMgmtMandate( ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("poeURI");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("api-key", CSU.decrypt(globalProp.getProperty("ordermgmt_api-key")));
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("GETORDERMGMTMANDATE_POE"),
				globalProp,test,headers);
		return resp;
	}
	
	public Response GetOrderMgmtV1( ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("poeURI");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("api-key", CSU.decrypt(globalProp.getProperty("ordermgmt_api-key")));
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("GETORDERMGMT_POE"),
				globalProp,test,headers);
		return resp;
	}
	
	public Response GetOrder( ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("poeURI");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("api-key", CSU.decrypt(globalProp.getProperty("ordermgmt_api-key")));
		headers.put("user-id", globalProp.getProperty("getordermgmt_user-id"));
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("GETV1ORDERMGMT_POE"),
				globalProp,test,headers);
		return resp;
	}
}
