package BusinessComponents;

import java.util.Hashtable;

import com.EndPoints.EndPoints;
import com.relevantcodes.extentreports.ExtentTest;

import baseTestPackage.BaseTest_TestNG;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import reusableLibrary.ResuableComponents;

public class PackEntitlementAPI extends BaseTest_TestNG{

    ResuableComponents resuableComponents = new ResuableComponents();
	
	public Response getSubscription(ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("packentitlement");
		Hashtable<String, String> headers=new Hashtable<String, String>();
		headers.put("api-key", CSU.decrypt(globalProp.getProperty("packen_api-key")));
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("GETSUBSCRIPTION_packentitle"), globalProp,
				test, headers);
		return resp;
	}
	
	public Response CreatePlayback(ExtentTest test,String reqBody) throws Exception {
		RestAssured.baseURI = executionParams.get("packentitlement");
		Hashtable<String, String> headers=new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("api-key", CSU.decrypt(globalProp.getProperty("packen_api-key")));
		headers.put("user-id", globalProp.getProperty("postsub_user-id"));
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("POSTSUBSCRIBEPLAYBACK_packentitle"), reqBody,
				globalProp, test, headers);
		return resp;
	}
	
	public Response CreateSubscription(ExtentTest test,String reqBody) throws Exception {
		RestAssured.baseURI = executionParams.get("packentitlement");
		Hashtable<String, String> headers=new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("api-key", CSU.decrypt(globalProp.getProperty("packen_api-key")));
		headers.put("user-id", globalProp.getProperty("postsub_user-id"));
		headers.put("PACK_ENTITLEMENT_ISC_KEY", globalProp.getProperty("postsub_PACK_ENTITLEMENT_ISC_KEY"));
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("POSTSUBSCRIBE_packentitle"), reqBody,
				globalProp, test, headers);
		return resp;
	}
	
	public Response UpdatebyID(ExtentTest test,String reqBody) throws Exception {
		RestAssured.baseURI = executionParams.get("packentitlement");
		Hashtable<String, String> headers=new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("api-key", CSU.decrypt(globalProp.getProperty("packen_api-key")));
		Response resp = resuableComponents.executePutAPI(EndPoints.endPointList.get("PUTBYID_packentitle"), reqBody,
				globalProp, test, headers);
		return resp;
	}	
	
	public Response CreateRenewal(ExtentTest test,String reqBody) throws Exception {
		RestAssured.baseURI = executionParams.get("packentitlement");
		Hashtable<String, String> headers=new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("api-key", CSU.decrypt(globalProp.getProperty("packen_api-key")));
		headers.put("user-id", globalProp.getProperty("postsub_user-id"));
		//headers.put("PACK_ENTITLEMENT_ISC_KEY", globalProp.getProperty("postrenew_PACK_ENTITLEMENT_ISC_KEY"));
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("POSTRENEWAL_packentitle"), reqBody,
				globalProp, test, headers);
		return resp;
	}
	
	public Response UpdatePlayback(ExtentTest test,String reqBody) throws Exception {
		RestAssured.baseURI = executionParams.get("packentitlement");
		Hashtable<String, String> headers=new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("api-key", CSU.decrypt(globalProp.getProperty("packen_api-key")));
		headers.put("user-id", globalProp.getProperty("putplay_user-id"));
		Response resp = resuableComponents.executePutAPI(EndPoints.endPointList.get("PUTPLAYBACK_packentitle"), reqBody,
				globalProp, test, headers);
		return resp;
	}
	
	public Response PatchbyID(ExtentTest test,String reqBody) throws Exception {
		RestAssured.baseURI = executionParams.get("packentitlement");
		Hashtable<String, String> headers=new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("api-key", CSU.decrypt(globalProp.getProperty("packen_api-key")));
		headers.put("user-id", globalProp.getProperty("patchplay_user-id"));
		Response resp = resuableComponents.executePatchAPI(EndPoints.endPointList.get("PATCH_packentitle"), reqBody,
				globalProp, test, headers);
		return resp;
	}
	
	public Response getPlayback(ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("packentitlement");
		Hashtable<String, String> headers=new Hashtable<String, String>();
		headers.put("api-key", CSU.decrypt(globalProp.getProperty("packen_api-key")));
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("GETBYPLAYBACK_packentitle"), globalProp,
				test, headers);
		return resp;
	}
	
	public Response getSubscriptionbyID(ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("packentitlement");
		Hashtable<String, String> headers=new Hashtable<String, String>();
		headers.put("api-key", CSU.decrypt(globalProp.getProperty("packen_api-key")));
		headers.put("user-id", globalProp.getProperty("postsub_user-id"));
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("GETBYID_packentitle"), globalProp,
				test, headers);
		return resp;
	}
}
