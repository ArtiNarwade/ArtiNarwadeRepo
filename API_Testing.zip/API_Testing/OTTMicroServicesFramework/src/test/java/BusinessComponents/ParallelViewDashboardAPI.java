package BusinessComponents;

import com.EndPoints.EndPoints;
import com.relevantcodes.extentreports.ExtentTest;

import baseTestPackage.BaseTest_TestNG;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import reusableLibrary.ResuableComponents;

public class ParallelViewDashboardAPI extends BaseTest_TestNG{

	ResuableComponents resuableComponents = new ResuableComponents();
	
	public Response GetParallelHealthcheck(ExtentTest test)throws Exception{
		RestAssured.baseURI=executionParams.get("parallelviewURI");
		Response resp=resuableComponents.executeGetAPI(EndPoints.endPointList.get("PARALLELDASHBOARDHEALTHCHECK"), 
				globalProp, test);
		return resp;
	}
	
	public Response GetParallelDashboard(ExtentTest test)throws Exception{
		RestAssured.baseURI=executionParams.get("parallelviewURI");
		Response resp=resuableComponents.executeGetAPI(EndPoints.endPointList.get("GETPARALLELDASHBOARD"), 
				globalProp, test);
		return resp;
	}
}