package BusinessComponents;

import java.util.Hashtable;

import com.EndPoints.EndPoints;
import com.relevantcodes.extentreports.ExtentTest;

import baseTestPackage.BaseTest_TestNG;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import reusableLibrary.ResuableComponents;

public class PartnerAuthAPI extends BaseTest_TestNG{

	ResuableComponents resuableComponents = new ResuableComponents();
	String Accesstoken;
	
	public Response PostClient(String requestBody,ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("partnerauthURI");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("POSTCLIENT_partnerauth"),requestBody,
				globalProp,test,headers);
		return resp;
	}
	
	public Response PatchClient(String requestBody,ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("partnerauthURI");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Cookie", CSU.decrypt(globalProp.getProperty("pauth_Cookie")));
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.executePatchAPI(EndPoints.endPointList.get("PATCHANDGETCLIENTTEST_partnerauth"),requestBody,
				globalProp,test,headers);
		return resp;
	}
	
	public Response PostClientToken(ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("partnerauthURI");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Cookie", CSU.decrypt(globalProp.getProperty("clitoken_Cookie")));
		headers.put("Authorization", CSU.decrypt(globalProp.getProperty("clitoken_Authorization")));
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.getAuthToken_Partnerauth(EndPoints.endPointList.get("POSTCLIENTTOKEN_partnerauth"), globalProp, test);
		
		JsonPath js=resp.jsonPath();
		Accesstoken=js.get("accessToken");
		System.out.println("Access token is...." + Accesstoken);
		return resp;
	}
	
	public Response PostClientIntrospect(ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("partnerauthURI");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Cookie", CSU.decrypt(globalProp.getProperty("cliintro_Cookie")));
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.getAuthToken_ClientIntrospect(EndPoints.endPointList.get("POSTINTROSPECT_partnerauth"), globalProp, test, Accesstoken);
		return resp;
	}
	
	public Response GetClient(ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("partnerauthURI");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Cookie", CSU.decrypt(globalProp.getProperty("clitest_Cookie")));
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("PATCHANDGETCLIENTTEST_partnerauth"),
				globalProp,test,headers);
		return resp;
	}
}
