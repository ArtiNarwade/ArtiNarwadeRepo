package BusinessComponents;

import java.util.Hashtable;

import com.EndPoints.EndPoints;
import com.relevantcodes.extentreports.ExtentTest;

import baseTestPackage.BaseTest_TestNG;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import reusableLibrary.ResuableComponents;

public class PartnerIamAPI extends BaseTest_TestNG{

	ResuableComponents resuableComponents = new ResuableComponents();
	String SelfRegister;
	String SelfLogin;
	
	
	public Response GetSelfRegister(ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("partneriamURI");
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("GETSELFREGISTER_partner"), globalProp,
				test);		
		/*ResponseBody body=resp.getBody();
		String bodyobj=body.asString();
		System.out.println("My response is: \n" + bodyobj);
		GetID=resp.path(GetID, "id");*/
		JsonPath js=resp.jsonPath();
		SelfRegister=js.get("id");
		System.out.println("Self Registration ID is...." + SelfRegister);
		return resp;
	}
	
	public Response CreateSelfRegister(ExtentTest test,String reqBody) throws Exception {
		RestAssured.baseURI = executionParams.get("partneriamURI");
		Hashtable<String, String> headers =new Hashtable<String,String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("POSTSELFREGISTER_partner").replace("ID", SelfRegister), reqBody,
				globalProp, test, headers);
		return resp;
	}
	
	public Response GetSelfLogin(ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("partneriamURI");
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("GETSELFLOGIN_partner"), globalProp,
				test);
		JsonPath js=resp.jsonPath();
		SelfLogin=js.get("id");
		System.out.println("Self Login ID is...." + SelfLogin);
		return resp;		
	}
	
	public Response CreateSelfLogin(ExtentTest test,String reqBody) throws Exception {
		RestAssured.baseURI = executionParams.get("partneriamURI");
		Hashtable<String, String> headers =new Hashtable<String,String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("POSTSELFLOGIN_partner").replace("ID", SelfLogin), reqBody,
				globalProp, test, headers);
		return resp;
	}
}
