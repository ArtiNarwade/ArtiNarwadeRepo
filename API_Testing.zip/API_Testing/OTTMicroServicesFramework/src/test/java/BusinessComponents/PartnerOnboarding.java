package BusinessComponents;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

import com.EndPoints.EndPoints;
import com.OTTPlatform.B2B.Tests_PartnerOnboarding;
import com.relevantcodes.extentreports.ExtentTest;

import baseTestPackage.BaseTest_TestNG;
import baseTestPackage.SuiteConstant;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import reusableLibrary.DBUtils;
import reusableLibrary.ResuableComponents;

public class PartnerOnboarding extends BaseTest_TestNG {
	
	List<String> list = new ArrayList<String>();
	SuiteConstant suiteMap = new SuiteConstant();
	ResuableComponents resuableComponents = new ResuableComponents();
	DBUtils dbUtils= new DBUtils();
	


	public Response Request_partner(ExtentTest test, String reqBody) throws Exception {
		RestAssured.baseURI = executionParams.get("PartnerOnboarding");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("PARTNER_REQUEST"), reqBody, globalProp,
				test, headers);
		return resp;
	}
	
	public Response Request_Update(ExtentTest test, String reqBody) throws Exception {
		RestAssured.baseURI = executionParams.get("PartnerOnboarding");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("USER-ID", globalProp.getProperty("USER-ID"));
		Response resp = resuableComponents.executePutAPI(EndPoints.endPointList.get("PARTNER_UPDATE")+Tests_PartnerOnboarding.request_id, reqBody, globalProp,
				test, headers);
		return resp;
	}
	
	public Response Approve_partner(ExtentTest test, String reqBody) throws Exception {
		RestAssured.baseURI = executionParams.get("PartnerOnboarding");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("USER-ID", globalProp.getProperty("USER-ID"));
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("PARTNER_APPROVE"), reqBody, globalProp,
				test, headers);
		return resp;
	}
	
	public Response getProductDetails(ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("PartnerOnboarding");
		Hashtable<String, String> headers =new Hashtable<String,String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("GETPRODUCT"), globalProp, test, headers);
		return resp;
	}
	
	public Response getApiDetails(ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("PartnerOnboarding");
		Hashtable<String, String> headers =new Hashtable<String,String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("APIDETAILS"), globalProp, test, headers);
		return resp;
	}
	
	public Response UpdatePlans(ExtentTest test, String reqBody) throws Exception {
		RestAssured.baseURI = executionParams.get("PartnerOnboarding");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("USER-ID", globalProp.getProperty("USER-ID"));
		Response resp = resuableComponents.executePutAPI(EndPoints.endPointList.get("UPDATEPLANS")+Tests_PartnerOnboarding.ticketId1_Search+"/plans", reqBody, globalProp,
				test, headers);
		return resp;
	}
	
	public Response SearchTicket(ExtentTest test, String reqBody) throws Exception {
		RestAssured.baseURI = executionParams.get("PartnerOnboarding");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("USER-ID", globalProp.getProperty("USER-ID"));
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("TICKETSEARCH"), reqBody, globalProp,
				test, headers);
		return resp;
	}
	public Response UpdateTicketStatus(ExtentTest test, String reqBody) throws Exception {
		String str1=dbUtils.getValueFromPostgresDb("partner_onboarding_pt","user_id", "ticket_details",  "id",  Tests_PartnerOnboarding.ticketId1_Search);
		RestAssured.baseURI = executionParams.get("PartnerOnboarding");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("USER-ID", str1);
		Response resp = resuableComponents.executePutAPI(EndPoints.endPointList.get("TICKETSTATUSIUPDATE")+Tests_PartnerOnboarding.ticketId1_Search, reqBody, globalProp,
				test, headers);
		return resp;
	}
	
	public Response getClientCredentials(ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("PartnerOnboarding");
		Hashtable<String, String> headers =new Hashtable<String,String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("USER-ID", globalProp.getProperty("USER-ID"));
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("CLIENTCREDENTIALS"), globalProp, test, headers);
		return resp;
	}
	public Response getDownloadDocs(ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("PartnerOnboarding");
		Hashtable<String, String> headers =new Hashtable<String,String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("USER-ID", globalProp.getProperty("USER-ID"));
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("DOWNLOAD_DOCS")+Tests_PartnerOnboarding.ticketId1_upload, globalProp, test, headers);
		return resp;
	}
	
	public Response getPartnerRolewithSessionID(ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("PartnerOnboarding");
		Hashtable<String, String> headers =new Hashtable<String,String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("PARTNERROLEWITHSESSIONID"), globalProp, test, headers);
		return resp;
	}
	public Response AccountRecovery(ExtentTest test, String reqBody) throws Exception {
		RestAssured.baseURI = executionParams.get("PartnerOnboarding");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("ACCOUNTRECOVERY"), reqBody, globalProp,
				test, headers);
		return resp;
	}
	public Response ticket_transactions_details(ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("PartnerOnboarding");
		Hashtable<String, String> headers =new Hashtable<String,String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("USER-ID", globalProp.getProperty("USER-ID"));
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("TICKETTRANSACTIONDETAILS")+Tests_PartnerOnboarding.request_id, globalProp, test, headers);
		return resp;
	}
	public Response user_Details(ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("PartnerOnboarding");
		Hashtable<String, String> headers =new Hashtable<String,String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("USERDETAILS"), globalProp, test, headers);
		return resp;
	}
	public Response partner_contact(ExtentTest test, String reqBody) throws Exception {
		RestAssured.baseURI = executionParams.get("PartnerOnboarding");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("PARTNER_CONTACT"), reqBody, globalProp,
				test, headers);
		return resp;
	}
	
	public Response CreateUpload(ExtentTest test,String reqBody) throws Exception {
		RestAssured.baseURI = executionParams.get("PartnerOnboarding");
		String filepath = globalProp.getProperty("partnerOnboarding_TestFile");
		  Hashtable<String, String> headers = new Hashtable<String, String>();
		  Hashtable<String, String> formparams = new Hashtable<String, String>();
		  headers.put("Content-Type",globalProp.getProperty("MultiPartContent"));
		  headers.put("USER-ID", globalProp.getProperty("USER-ID"));
		  formparams.put("file", filepath);
		  formparams.put("type", "CONTRACT");
		  formparams.put("ticketId", Tests_PartnerOnboarding.ticketId1_Approve);
		  Response resp = resuableComponents.executePOSTMultiform_Onboarding(EndPoints.endPointList.get("UPLOAD_DOC"),
				  filepath,globalProp, headers, formparams, test);
		  return resp;
		
	}
	
	
	public Response delete_Details(ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("PartnerOnboarding");
		Hashtable<String, String> headers =new Hashtable<String,String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("USER-ID", globalProp.getProperty("USER-ID"));
		Response resp = resuableComponents.executeDeleteAPI(EndPoints.endPointList.get("DELETE_DOC")+Tests_PartnerOnboarding.ticketId1_upload, globalProp, test, headers);
		return resp;
	}



	





	




}
