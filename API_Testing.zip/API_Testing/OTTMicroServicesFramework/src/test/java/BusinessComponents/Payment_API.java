package BusinessComponents;

import java.util.Hashtable;

import com.EndPoints.EndPoints;
import com.relevantcodes.extentreports.ExtentTest;

import baseTestPackage.BaseTest_TestNG;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import reusableLibrary.ResuableComponents;

public class Payment_API extends BaseTest_TestNG {
	
	ResuableComponents resuableComponents = new ResuableComponents();
	
	public Response PaymentDetails_payment(ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("PaymentURI");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("api_key", CSU.decrypt(globalProp.getProperty("payment_APIKey")));
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("Payment_GetPayment"), globalProp, test,
				headers);
		return resp;
	}
	
	public Response PaymentTransformer(String requestBody, ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("PaymentURI");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("api_key", CSU.decrypt(globalProp.getProperty("payment_APIKey")));
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("Payment_CreatePayment"), requestBody,
				globalProp, test, headers);
		return resp;
	}
	
	public Response PaymentBilling(String requestBody, ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("PaymentURI");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("api_key", CSU.decrypt(globalProp.getProperty("payment_APIKey")));
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("Payment_BillingPayment"), requestBody,
				globalProp, test, headers);
		return resp;
	}
	


}
