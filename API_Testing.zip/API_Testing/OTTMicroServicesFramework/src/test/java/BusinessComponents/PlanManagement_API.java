package BusinessComponents;

import java.util.Hashtable;

import com.EndPoints.EndPoints;
import com.relevantcodes.extentreports.ExtentTest;

import baseTestPackage.BaseTest_TestNG;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import reusableLibrary.ResuableComponents;

public class PlanManagement_API extends BaseTest_TestNG{

ResuableComponents resuableComponents = new ResuableComponents();
	
	public Response PostEntitlement(String requestBody, ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("planmanagementURI");
		// RestAssured.baseURI = globalProp.getProperty("securepaymentURI");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("api-key", CSU.decrypt(globalProp.getProperty("plan_api-key")));
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("POSTENTITLEMENT_planmgmt"), requestBody,
				globalProp,test,headers);
		return resp;
	}
	
	public Response GetEntiltleByID(ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("planmanagementURI");
		// RestAssured.baseURI = globalProp.getProperty("securepaymentURI");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("api-key", CSU.decrypt(globalProp.getProperty("plan_api-key")));
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("ENTITLEMENTBYID_planmgmt"), globalProp,test,headers);
		return resp;
	}
	
	public Response GetEntiltlePlanID(ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("planmanagementURI");
		// RestAssured.baseURI = globalProp.getProperty("securepaymentURI");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("api-key", CSU.decrypt(globalProp.getProperty("plan_api-key")));
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("ENTITLEMENTPLANID_planmgmt"), globalProp,test,headers);
		return resp;
	}
	
	public Response PutEntitlement(String requestBody, ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("planmanagementURI");
		// RestAssured.baseURI = globalProp.getProperty("securepaymentURI");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("api-key", CSU.decrypt(globalProp.getProperty("plan_api-key")));
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.executePutAPI(EndPoints.endPointList.get("PUTENTITLEMENT_planmgmt"), requestBody,
				globalProp,test,headers);
		return resp;
	}
	
	public Response PutPlanController(String requestBody, ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("planmanagementURI");
		// RestAssured.baseURI = globalProp.getProperty("securepaymentURI");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("API-KEY", CSU.decrypt(globalProp.getProperty("plan_api-key")));
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.executePutAPI(EndPoints.endPointList.get("PUTANDGETPLANCONTROL_planmgmt"), requestBody,
				globalProp,test,headers);
		return resp;
	}
	
	public Response GetProductReference(ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("planmanagementURI");
		// RestAssured.baseURI = globalProp.getProperty("securepaymentURI");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("api-key", CSU.decrypt(globalProp.getProperty("plan_api-key")));
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("PRODUCTREFERENCE_planmgmt"), globalProp,test,headers);
		return resp;
	}
	
	public Response PostPlanController(String requestBody, ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("planmanagementURI");
		// RestAssured.baseURI = globalProp.getProperty("securepaymentURI");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("API-KEY", CSU.decrypt(globalProp.getProperty("plan_api-key")));
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("POSTANDGETBYPLAN_planmgmt"), requestBody,
				globalProp,test,headers);
		return resp;
	}
	
	public Response GetByPlans(ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("planmanagementURI");
		// RestAssured.baseURI = globalProp.getProperty("securepaymentURI");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("api-key", CSU.decrypt(globalProp.getProperty("plan_api-key")));
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("GETBYPLAN_planmgmt"), globalProp,test,headers);
		return resp;
	}
	
	public Response GetPlanByID(ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("planmanagementURI");
		// RestAssured.baseURI = globalProp.getProperty("securepaymentURI");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("api-key", CSU.decrypt(globalProp.getProperty("plan_api-key")));
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("PUTANDGETPLANCONTROL_planmgmt"), globalProp,test,headers);
		return resp;
	}
	
	public Response GetByPlanControl(ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("planmanagementURI");
		// RestAssured.baseURI = globalProp.getProperty("securepaymentURI");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("api-key", CSU.decrypt(globalProp.getProperty("plan_api-key")));
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("POSTANDGETBYPLAN_planmgmt"), globalProp,test,headers);
		return resp;
	}
}
