package BusinessComponents;

import java.util.Hashtable;

import com.EndPoints.EndPoints;
import com.relevantcodes.extentreports.ExtentTest;

import baseTestPackage.BaseTest_TestNG;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import reusableLibrary.JsonUtils;
import reusableLibrary.ResuableComponents;

public class PollingAdminAPI extends BaseTest_TestNG{

	ResuableComponents resuableComponents = new ResuableComponents();
	UM_UserToken usertoken=new UM_UserToken();
	int PollID;
	
	public static String responsebody;
	
	// GENERIC METHOD TO GENERATE TOKEN
		public JsonPath getUserToken(ExtentTest test) throws Exception {
			String requestBody = JsonUtils.readPayloadJson("UMTokenGenerate.json");
			Response resp = usertoken.tokenGenreatePost(test, requestBody);
			 responsebody = resp.getBody().jsonPath().get("token").toString();
			System.out.println(responsebody);
			JsonPath jsonPath = resp.jsonPath();
			return jsonPath;
		}
	
	public Response PostAdminAddQuiz(String requestBody,ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("padminURI");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Cookie", CSU.decrypt(globalProp.getProperty("poll_Cookie")));
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("ADMINADDQUIZ_admin"),requestBody,
				globalProp,test,headers);
		
		JsonPath js=resp.jsonPath();
		PollID=js.get("result.id");
		return resp;
	}
	
	public Response GetPollAsset(ExtentTest test,String assetid) throws Exception {
		RestAssured.baseURI = executionParams.get("padminURI");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("GETPOLLSASSET_admin").replace("ID", assetid),
				globalProp,test,headers);
		return resp;
	}
	
	public Response GetPollbyID(ExtentTest test,int PollID) throws Exception {
		RestAssured.baseURI = executionParams.get("padminURI");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("GETPOLLBYID_admin")+ PollID,
				globalProp,test,headers);
		return resp;
	}
	
	public Response GetOpinionPollResult(ExtentTest test,int PollID) throws Exception {
		RestAssured.baseURI = executionParams.get("padminURI");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("OPINIONPOLLRESULT_admin")+ PollID,
				globalProp,test,headers);
		return resp;
	}
	
	public Response GetUserReportPollResponse(ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("padminURI");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("USERREPORTPOLLRESPONSE_admin"),
				globalProp,test,headers);
		return resp;
	}
	
	public Response GetOpinionSchedular(ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("padminURI");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("OPINIONSCHEDULAR_admin"),
				globalProp,test,headers);
		return resp;
	}
	
	public Response GetPollSchedular(ExtentTest test,int PollID) throws Exception {
		RestAssured.baseURI = executionParams.get("padminURI");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("POLLSCHEDULAR_admin")+ PollID,
				globalProp,test,headers);
		return resp;
	}
	
	public Response GetPollResponses(ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("padminURI");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("POLLRESPONSES_admin"),
				globalProp,test,headers);
		return resp;
	}
	
	public Response DeletebyPollID(ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("padminURI");
		Hashtable<String, String> headers=new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.executeDeleteAPI(EndPoints.endPointList.get("DELETEBYPOLLID_admin").replace("delID", String.valueOf(PollID))
				,globalProp, test, headers);
		return resp;
	}
	
	public Response PostSubmitPoll(String requestBody,ExtentTest test) throws Exception {
		JsonPath tokenJsonPath = getUserToken(test);
		String token = tokenJsonPath.getString("token");
		
		RestAssured.baseURI = executionParams.get("padminURI");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Cookie", CSU.decrypt(globalProp.getProperty("service_Cookie")));
		
		headers.put("Authorization","bearer " + token);
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("SUBMITPOLL_admin"),requestBody,
				globalProp,test,headers);
		return resp;
	}
	
	public Response GetPollingDetails(ExtentTest test,String assetid) throws Exception {
		JsonPath tokenJsonPath = getUserToken(test);
		String token = tokenJsonPath.getString("token");
		
		RestAssured.baseURI = executionParams.get("padminURI");
		Hashtable<String, String> headers = new Hashtable<String, String>();

		headers.put("Authorization","bearer " + token);
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("GETPOLLINGDETAILS_admin").replace("getpollID", assetid),
				globalProp,test,headers);
		return resp;
	}
	
	public Response GetUserPollResponses(ExtentTest test,int PollID) throws Exception {
		JsonPath tokenJsonPath = getUserToken(test);
		String token = tokenJsonPath.getString("token");
		
		RestAssured.baseURI = executionParams.get("padminURI");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		
		headers.put("Authorization","bearer " + token);
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("GETUSERPOLLRESPONSES_admin")+PollID,
				globalProp,test,headers);
		return resp;
	}
	
	public Response GetServiceOpinionPollResults(ExtentTest test) throws Exception {
		JsonPath tokenJsonPath = getUserToken(test);
		String token = tokenJsonPath.getString("token");
		
		RestAssured.baseURI = executionParams.get("padminURI");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Authorization","bearer " + token);
		
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("GETOPINIONPOLLRESULT_admin"),
				globalProp,test,headers);
		return resp;
	}
	
	public Response PostAdminOpinionPoll(String requestBody,ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("padminURI");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("ADMINADDQUIZ_admin"),requestBody,
				globalProp,test,headers);
		return resp;
	}
}
