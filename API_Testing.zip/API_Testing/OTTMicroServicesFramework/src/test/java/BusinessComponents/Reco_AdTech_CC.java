package BusinessComponents;

import java.util.Hashtable;

import com.EndPoints.EndPoints;
import com.relevantcodes.extentreports.ExtentTest;

import baseTestPackage.BaseTest_TestNG;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import reusableLibrary.ResuableComponents;

public class Reco_AdTech_CC  extends BaseTest_TestNG{
	ResuableComponents resuableComponents = new ResuableComponents();

	
	public Response LoadLatestItemCache(ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("AdtechCC_URI");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("ADTECH_CC_LoadLatestItemCache"), globalProp,test, headers);
		return resp;	
	}
	
	public Response LoadItems(ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("AdtechCC_URI");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("ADTECH_CC_LoadItems"), globalProp,test, headers);
		return resp;	
	}
	public Response LoadMetaData(ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("AdtechCC_URI");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("ADTECH_CC_loadMetaData"), globalProp,test, headers);
		return resp;	
	}
	
	public Response LoadGenericModel(ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("AdtechCC_URI");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("ADTECH_CC_loadGenericModel"), globalProp,test, headers);
		return resp;	
	}
	
	public Response LoadAdServerConfig(ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("AdtechCC_URI");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("ADTECH_CC_LoadAdServerConfig"), globalProp,test, headers);
		return resp;	
	}
	
	public Response LoadRules(ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("AdtechCC_URI");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("ADTECH_CC_LoadRules"), globalProp,test, headers);
		return resp;	
	}
	
	public Response LoadExpItem(ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("AdtechCC_URI");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("ADTECH_CC_LoadExpItem"), globalProp,test, headers);
		return resp;	
	}
	
	public Response GetCache(ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("AdtechCC_URI");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("ADTECH_CC_GetCache"), globalProp,test, headers);
		return resp;	
	}
	
	public Response GetItemCache(ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("AdtechCC_URI");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("ADTECH_CC_GetItemCache"), globalProp,test, headers);
		return resp;	
	}
	
	public Response GetItembyId(ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("AdtechCC_URI");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("ADTECH_CC_GetItembyId"), globalProp,test, headers);
		return resp;	
	}
	
	public Response GetContextualItems(ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("AdtechCC_URI");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("ADTECH_CC_GetContextualItems"), globalProp,test, headers);
		return resp;	
	}
	
	public Response ClearCache(ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("AdtechCC_URI");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("ADTECH_CC_ClearCache"), globalProp,test, headers);
		return resp;	
	}
	
	
	
	
	
	
	
	
	
	
	
	

}
