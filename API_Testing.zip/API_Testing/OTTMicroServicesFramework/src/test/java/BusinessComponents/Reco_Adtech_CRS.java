package BusinessComponents;

import java.util.Hashtable;

import com.EndPoints.EndPoints;
import com.relevantcodes.extentreports.ExtentTest;

import baseTestPackage.BaseTest_TestNG;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import reusableLibrary.ResuableComponents;

public class Reco_Adtech_CRS extends BaseTest_TestNG {

	ResuableComponents resuableComponents = new ResuableComponents();

	public Response UpnextCreate(ExtentTest test, String reqBody) throws Exception {
		RestAssured.baseURI = executionParams.get("Adtech_CRS");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("RECO_UPNEXT"), reqBody,
				globalProp, test, headers);
		return resp;
	}
	public Response ColdStartCreate(ExtentTest test, String reqBody) throws Exception {
		RestAssured.baseURI = executionParams.get("Adtech_CRS");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("RECO_COLDSTART"), reqBody,
				globalProp, test, headers);
		return resp;
	}
	
	public Response GetEpisode(ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("Adtech_CRS");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("RECO_GETEPISODE"),
				globalProp, test, headers);
		return resp;
	}
	
	
	
	
}
