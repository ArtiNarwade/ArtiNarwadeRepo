package BusinessComponents;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import java.util.Random;

import com.EndPoints.EndPoints;
import com.relevantcodes.extentreports.ExtentTest;

import baseTestPackage.BaseTest_TestNG;
import baseTestPackage.SuiteConstant;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import reusableLibrary.ResuableComponents;

public class Reco_adtechCapsAPI extends BaseTest_TestNG{
	
	List<String> list = new ArrayList<String>();
	SuiteConstant suiteMap = new SuiteConstant();
	ResuableComponents resuableComponents = new ResuableComponents();
    public static String responseFeedId;
    public static String responseFeedRuleId;
   public static String responseFeedExpressionRuleId;
	public Response Register_User(String requestBody,ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("Adtech_CapsURI");
 		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("AdtechCaps_REGISTER_USER"), requestBody,globalProp, test, headers);
		return resp;
	}
	
	public Response Authenticate_User(String requestBody,ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("Adtech_CapsURI");
 		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("AdtechCaps_Login_USER"), requestBody,globalProp, test, headers);
		return resp;
	}
	
	//Response Feed
		public Response getFeedByID(ExtentTest test,String caps_token) throws Exception {
	 		RestAssured.baseURI = executionParams.get("Adtech_CapsURI");
	 		Hashtable<String, String> headers = new Hashtable<String, String>();
		 	headers.put("Authorization","Bearer "+caps_token);
	 		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("AdtechCaps_FEEDBYID"), globalProp, test,headers);
	 		return resp;
	 	}
		
		public Response getFeedByClientID(ExtentTest test,String caps_token) throws Exception {
	 		RestAssured.baseURI = executionParams.get("Adtech_CapsURI");
	 		Hashtable<String, String> headers = new Hashtable<String, String>();
		 	headers.put("Authorization","Bearer "+caps_token);
	 		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("AdtechCaps_CLIENTID"), globalProp, test,headers);
	 		return resp;
	 	}
		
		public Response getFeedByStatus(ExtentTest test,String caps_token) throws Exception {
	 		RestAssured.baseURI = executionParams.get("Adtech_CapsURI");
	 		Hashtable<String, String> headers = new Hashtable<String, String>();
		 	headers.put("Authorization","Bearer "+caps_token);
	 		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("AdtechCaps_FEEDBYSTATUS"), globalProp, test,headers);
	 		return resp;
	 	}
		
		public Response InavtiveFeed(ExtentTest test,String caps_token) throws Exception {
			RestAssured.baseURI = executionParams.get("Adtech_CapsURI");
	 		Hashtable<String, String> headers = new Hashtable<String, String>();
		 	headers.put("Authorization","Bearer "+caps_token);
			Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("AdtechCaps_FEED_INACTIVE"), "",globalProp, test, headers);
			return resp;
		}
		
		public Response AvtiveFeed(ExtentTest test,String caps_token) throws Exception {
			RestAssured.baseURI = executionParams.get("Adtech_CapsURI");
	 		Hashtable<String, String> headers = new Hashtable<String, String>();
		 	headers.put("Authorization","Bearer "+caps_token);
			Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("AdtechCaps_FEED_ACTIVE"), "",globalProp, test, headers);
			return resp;
		}
		
		public Response UpdateFeed(String requestBody, ExtentTest test,String caps_token) throws Exception {
			RestAssured.baseURI = executionParams.get("Adtech_CapsURI");
	 		Hashtable<String, String> headers = new Hashtable<String, String>();
		 	headers.put("Authorization","Bearer "+caps_token);
			headers.put("Content-Type", globalProp.getProperty("contentType"));
			Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("AdtechCaps_UPDATE_FEED"), requestBody,globalProp, test, headers);
			return resp;
		}
		
		public Response CreateFeed(String requestBody, ExtentTest test,String caps_token) throws Exception {
			RestAssured.baseURI = executionParams.get("Adtech_CapsURI");
	 		Hashtable<String, String> headers = new Hashtable<String, String>();
		 	headers.put("Authorization","Bearer "+caps_token);
			headers.put("Content-Type", globalProp.getProperty("contentType"));
			Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("AdtechCaps_CREATEFEED"), requestBody,globalProp, test, headers);
			JsonPath js = resp.jsonPath();
			responseFeedId = js.getString("data.responseFeedId[0]");

			return resp;
		}
		
		//Response Feed Rule
		public Response feedRule(ExtentTest test,String caps_token) throws Exception {
	 		RestAssured.baseURI = executionParams.get("Adtech_CapsURI");
	 		Hashtable<String, String> headers = new Hashtable<String, String>();
		 	headers.put("Authorization","Bearer "+caps_token);
	 		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("AdtechCaps_FEEDRULE"), globalProp, test,headers);
	 		return resp;
	 	}
		
		public Response feedRule_ID(ExtentTest test,String caps_token) throws Exception {
	 		RestAssured.baseURI = executionParams.get("Adtech_CapsURI");
	 		Hashtable<String, String> headers = new Hashtable<String, String>();
		 	headers.put("Authorization","Bearer "+caps_token);
	 		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("AdtechCaps_FEEDRULE_ID"), globalProp, test,headers);
	 		return resp;
	 	}
		
		public Response feedRule_Status(ExtentTest test,String caps_token) throws Exception {
	 		RestAssured.baseURI = executionParams.get("Adtech_CapsURI");
	 		Hashtable<String, String> headers = new Hashtable<String, String>();
		 	headers.put("Authorization","Bearer "+caps_token);
	 		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("AdtechCaps_FEEDRULE_STATUS"), globalProp, test,headers);
	 		return resp;
	 	}
		
		public Response feedrule_inactive(ExtentTest test,String caps_token) throws Exception {
			RestAssured.baseURI = executionParams.get("Adtech_CapsURI");
	 		Hashtable<String, String> headers = new Hashtable<String, String>();
		 	headers.put("Authorization","Bearer "+caps_token);
			Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("AdtechCaps_FEEDRULE_INACTIVE"), "",globalProp, test, headers);
			return resp;
		}
		
		public Response FeedRuleUpdate(String requestBody, ExtentTest test,String caps_token) throws Exception {
			RestAssured.baseURI = executionParams.get("Adtech_CapsURI");
	 		Hashtable<String, String> headers = new Hashtable<String, String>();
		 	headers.put("Authorization","Bearer "+caps_token);
			headers.put("Content-Type", globalProp.getProperty("contentType"));
			Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("AdtechCaps_FEEDRULE_UPDATE"), requestBody,globalProp, test, headers);
			return resp;
		}
		
		public Response FeedRuleCreate(String requestBody, ExtentTest test,String caps_token) throws Exception {
			RestAssured.baseURI = executionParams.get("Adtech_CapsURI");
	 		Hashtable<String, String> headers = new Hashtable<String, String>();
		 	headers.put("Authorization","Bearer "+caps_token);
			headers.put("Content-Type", globalProp.getProperty("contentType"));
			Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("AdtechCaps_CREATEFEEDRULE"), requestBody,globalProp, test, headers);
			JsonPath js = resp.jsonPath();
			responseFeedRuleId = js.getString("data.responseFeedRuleId[0]");
			return resp;
		}
		
		public Response feedrule_active(ExtentTest test,String caps_token) throws Exception {
			RestAssured.baseURI = executionParams.get("Adtech_CapsURI");
	 		Hashtable<String, String> headers = new Hashtable<String, String>();
		 	headers.put("Authorization","Bearer "+caps_token);
			Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("AdtechCaps_ACTIVEFEEDRULE"), "",globalProp, test, headers);
			return resp;
		}
		
		public Response FeedConfigRuleCreate(String requestBody, ExtentTest test,String caps_token) throws Exception {
			RestAssured.baseURI = executionParams.get("Adtech_CapsURI");
	 		Hashtable<String, String> headers = new Hashtable<String, String>();
		 	headers.put("Authorization","Bearer "+caps_token);
			headers.put("Content-Type", globalProp.getProperty("contentType"));
			Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("AdtechCaps_CONFIGRULE_CREATE"), requestBody,globalProp, test, headers);
			return resp;
		}
		
		public Response FeedExpression_Create(String requestBody, ExtentTest test,String caps_token) throws Exception {
			RestAssured.baseURI = executionParams.get("Adtech_CapsURI");
	 		Hashtable<String, String> headers = new Hashtable<String, String>();
	 		headers.put("Authorization","Bearer "+caps_token);
			headers.put("Content-Type", globalProp.getProperty("contentType"));
			Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("AdtechCaps_FEEDEXPRESSION_CREATE"), requestBody,globalProp, test, headers);
			JsonPath js = resp.jsonPath();
			responseFeedExpressionRuleId = js.getString("data.feedExpressionId[0]");
			return resp;
		}
		
		public Response FeedExpression_Update(String requestBody, ExtentTest test,String caps_token) throws Exception {
			RestAssured.baseURI = executionParams.get("Adtech_CapsURI");
	 		Hashtable<String, String> headers = new Hashtable<String, String>();
	 		headers.put("Authorization","Bearer "+caps_token);
			headers.put("Content-Type", globalProp.getProperty("contentType"));
			Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("AdtechCaps_FEEDEXPRESSION_UPDATE"), requestBody,globalProp, test, headers);
			return resp;
		}
		
		public Response feedFilteringRule_Create(String requestBody, ExtentTest test,String caps_token) throws Exception {
			RestAssured.baseURI = executionParams.get("Adtech_CapsURI");
	 		Hashtable<String, String> headers = new Hashtable<String, String>();
	 		headers.put("Authorization","Bearer "+caps_token);
			headers.put("Content-Type", globalProp.getProperty("contentType"));
			Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("AdtechCaps_FEEDFILTERINGRULE_CREATE"), requestBody,globalProp, test, headers);
			return resp;
		}
		
		public Response FeedAlgoPinRule_Create(String requestBody,ExtentTest test,String caps_token) throws Exception {
			RestAssured.baseURI = executionParams.get("Adtech_CapsURI");
	 		Hashtable<String, String> headers = new Hashtable<String, String>();
	 		headers.put("Authorization","Bearer "+caps_token);
			headers.put("Content-Type", globalProp.getProperty("contentType"));
			Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("AdtechCaps_ALGOPINRULE_CREATE"), requestBody,globalProp, test, headers);
			return resp;
		}
		public Response configRule_Id(ExtentTest test,String caps_token) throws Exception {
	 		RestAssured.baseURI = executionParams.get("Adtech_CapsURI");
	 		Hashtable<String, String> headers = new Hashtable<String, String>();
	 		headers.put("Authorization","Bearer "+caps_token);
	 		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("AdtechCaps_CONFIGRULEID"), globalProp, test,headers);
	 		return resp;
	 	}
		public Response configrule_Inactive(ExtentTest test,String caps_token) throws Exception {
			RestAssured.baseURI = executionParams.get("Adtech_CapsURI");
	 		Hashtable<String, String> headers = new Hashtable<String, String>();
	 		headers.put("Authorization","Bearer "+caps_token);
			Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("AdtechCaps_CONFIGRULE_INACTIVE"), "",globalProp, test, headers);
			return resp;
		}
		
		public Response configrule_active(ExtentTest test,String caps_token) throws Exception {
			RestAssured.baseURI = executionParams.get("Adtech_CapsURI");
	 		Hashtable<String, String> headers = new Hashtable<String, String>();
	 		headers.put("Authorization","Bearer "+caps_token);
			Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("AdtechCaps_CONFIGRULE_ACTIVE"), "",globalProp, test, headers);
			return resp;
		}
		public Response FeedConfigRuleUpdate(String requestBody, ExtentTest test,String caps_token) throws Exception {
			RestAssured.baseURI = executionParams.get("Adtech_CapsURI");
	 		Hashtable<String, String> headers = new Hashtable<String, String>();
	 		headers.put("Authorization","Bearer "+caps_token);
			headers.put("Content-Type", globalProp.getProperty("contentType"));
			Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("AdtechCaps_CONFIGRULE_UPDATE"), requestBody,globalProp, test, headers);
			return resp;
		}
		
		//Response Feed Pin Position
		public Response PositionPin_Id(ExtentTest test,String caps_token) throws Exception {
	 		RestAssured.baseURI = executionParams.get("Adtech_CapsURI");
	 		Hashtable<String, String> headers = new Hashtable<String, String>();
	 		headers.put("Authorization","Bearer "+caps_token);
	 		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("AdtechCaps_PINPOSITION_ID"), globalProp, test,headers);
	 		return resp;
	 	}
		public Response PositionPin_Active(ExtentTest test,String caps_token) throws Exception {
			RestAssured.baseURI = executionParams.get("Adtech_CapsURI");
	 		Hashtable<String, String> headers = new Hashtable<String, String>();
	 		headers.put("Authorization","Bearer "+caps_token);
			Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("AdtechCaps_PINPOSITION_ACTIVE"), "",globalProp, test, headers);
			return resp;
		}
		
		public Response PositionPin_InActive(ExtentTest test,String caps_token) throws Exception {
			RestAssured.baseURI = executionParams.get("Adtech_CapsURI");
	 		Hashtable<String, String> headers = new Hashtable<String, String>();
	 		headers.put("Authorization","Bearer "+caps_token);
			Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("AdtechCaps_PINPOSITION_INACTIVE"), "",globalProp, test, headers);
			return resp;
		}
		
		public Response PositionPin_Update(String requestBody, ExtentTest test,String caps_token) throws Exception {
			RestAssured.baseURI = executionParams.get("Adtech_CapsURI");
	 		Hashtable<String, String> headers = new Hashtable<String, String>();
	 		headers.put("Authorization","Bearer "+caps_token);
			headers.put("Content-Type", globalProp.getProperty("contentType"));
			Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("AdtechCaps_PINPOSITION_UPDATE"), requestBody,globalProp, test, headers);
			return resp;
		}
		
		//Response Feed Expression
		public Response FeedExpression_Id(ExtentTest test,String caps_token) throws Exception {
	 		RestAssured.baseURI = executionParams.get("Adtech_CapsURI");
	 		Hashtable<String, String> headers = new Hashtable<String, String>();
	 		headers.put("Authorization","Bearer "+caps_token);
	 		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("AdtechCaps_FEEDEXPRESSION_ID"), globalProp, test,headers);
	 		return resp;
	 	}
		
		public Response FeedExpression_Inactive(ExtentTest test,String caps_token) throws Exception {
			RestAssured.baseURI = executionParams.get("Adtech_CapsURI");
	 		Hashtable<String, String> headers = new Hashtable<String, String>();
	 		headers.put("Authorization","Bearer "+caps_token);
			Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("AdtechCaps_FEEDEXPRESSION_INACTIVE"), "",globalProp, test, headers);
			return resp;
		}
		public Response FeedExpression_Active(ExtentTest test,String caps_token) throws Exception {
			RestAssured.baseURI = executionParams.get("Adtech_CapsURI");
	 		Hashtable<String, String> headers = new Hashtable<String, String>();
	 		headers.put("Authorization","Bearer "+caps_token);
			Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("AdtechCaps_FEEDEXPRESSION_ACTIVE"), "",globalProp, test, headers);
			return resp;
		}
		
		//Response Feed Filtering Rule
		public Response feedFilteringRule_ID(ExtentTest test,String caps_token) throws Exception {
	 		RestAssured.baseURI = executionParams.get("Adtech_CapsURI");
	 		Hashtable<String, String> headers = new Hashtable<String, String>();
	 		headers.put("Authorization","Bearer "+caps_token);
	 		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("AdtechCaps_FEEDFILTERINGRULE_ID"), globalProp, test,headers);
	 		return resp;
	 	}
		
		public Response feedFilteringRule_InActive(ExtentTest test,String caps_token) throws Exception {
			RestAssured.baseURI = executionParams.get("Adtech_CapsURI");
	 		Hashtable<String, String> headers = new Hashtable<String, String>();
	 		headers.put("Authorization","Bearer "+caps_token);
			Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("AdtechCaps_FEEDFILTERINGRULE_INACTIVE"), "",globalProp, test, headers);
			return resp;
		}
		
		public Response feedFilteringRule_Active(ExtentTest test,String caps_token) throws Exception {
			RestAssured.baseURI = executionParams.get("Adtech_CapsURI");
	 		Hashtable<String, String> headers = new Hashtable<String, String>();
	 		headers.put("Authorization","Bearer "+caps_token);
			Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("AdtechCaps_FEEDFILTERINGRULE_ACTIVE"), "",globalProp, test, headers);
			return resp;
		}
		
		public Response feedFilteringRule_Update(String requestBody,ExtentTest test,String caps_token) throws Exception {
			RestAssured.baseURI = executionParams.get("Adtech_CapsURI");
	 		Hashtable<String, String> headers = new Hashtable<String, String>();
	 		headers.put("Authorization","Bearer "+caps_token);
			headers.put("Content-Type", globalProp.getProperty("contentType"));
			Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("AdtechCaps_FEEDFILTERINGRULE_UPDATE"), requestBody,globalProp, test, headers);
			return resp;
		}
		
		//Response Feed Algo Pin Rule
		public Response FeedAlgoPinRule_ID(ExtentTest test,String caps_token) throws Exception {
	 		RestAssured.baseURI = executionParams.get("Adtech_CapsURI");
	 		Hashtable<String, String> headers = new Hashtable<String, String>();
	 		headers.put("Authorization","Bearer "+caps_token);
	 		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("AdtechCaps_ALGOPINRULE_ID"), globalProp, test,headers);
	 		return resp;
	 	}

		public Response FeedAlgoPinRule_InActive(ExtentTest test,String caps_token) throws Exception {
			RestAssured.baseURI = executionParams.get("Adtech_CapsURI");
	 		Hashtable<String, String> headers = new Hashtable<String, String>();
	 		headers.put("Authorization","Bearer "+caps_token);
			Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("AdtechCaps_ALGOPINRULE_INACTIVE"), "",globalProp, test, headers);
			return resp;
		}
		
		public Response FeedAlgoPinRule_Active(ExtentTest test,String caps_token) throws Exception {
			RestAssured.baseURI = executionParams.get("Adtech_CapsURI");
	 		Hashtable<String, String> headers = new Hashtable<String, String>();
	 		headers.put("Authorization","Bearer "+caps_token);
			Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("AdtechCaps_ALGOPINRULE_ACTIVE"), "",globalProp, test, headers);
			return resp;
		}
		
		//AdUnit
		public Response AdUnit_ID(ExtentTest test,String caps_token) throws Exception {
	 		RestAssured.baseURI = executionParams.get("Adtech_CapsURI");
	 		Hashtable<String, String> headers = new Hashtable<String, String>();
	 		headers.put("Authorization","Bearer "+caps_token);
	 		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("AdtechCaps_ADUNIT_ID"), globalProp, test,headers);
	 		return resp;
	 	}
		
		public Response AdUnit_Active(ExtentTest test,String caps_token) throws Exception {
			RestAssured.baseURI = executionParams.get("Adtech_CapsURI");
	 		Hashtable<String, String> headers = new Hashtable<String, String>();
	 		headers.put("Authorization","Bearer "+caps_token);
			Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("AdtechCaps_ADUNIT_ACTIVE"), "",globalProp, test, headers);
			return resp;
		}
		
		public Response AdUnit_InActive(ExtentTest test,String caps_token) throws Exception {
			RestAssured.baseURI = executionParams.get("Adtech_CapsURI");
	 		Hashtable<String, String> headers = new Hashtable<String, String>();
	 		headers.put("Authorization","Bearer "+caps_token);
			Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("AdtechCaps_ADUNIT_INACTIVE"), "",globalProp, test, headers);
			return resp;
		}
		
		public Response AdUnit_Create(String requestBody,ExtentTest test,String caps_token) throws Exception {
			RestAssured.baseURI = executionParams.get("Adtech_CapsURI");
	 		Hashtable<String, String> headers = new Hashtable<String, String>();
	 		headers.put("Authorization","Bearer "+caps_token);
			headers.put("Content-Type", globalProp.getProperty("contentType"));
			Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("AdtechCaps_ADUNIT_CREATE_"), requestBody,globalProp, test, headers);
			return resp;
		}
		
		public Response AdUnit_Update(String requestBody,ExtentTest test,String caps_token) throws Exception {
			RestAssured.baseURI = executionParams.get("Adtech_CapsURI");
	 		Hashtable<String, String> headers = new Hashtable<String, String>();
	 		headers.put("Authorization","Bearer "+caps_token);
			headers.put("Content-Type", globalProp.getProperty("contentType"));
			Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("AdtechCaps_ADUNIT_UPDATE"), requestBody,globalProp, test, headers);
			return resp;
		}
		
		//Client
		
		public Response ClientBy_ID(ExtentTest test,String caps_token) throws Exception {
	 		RestAssured.baseURI = executionParams.get("Adtech_CapsURI");
	 		Hashtable<String, String> headers = new Hashtable<String, String>();
	 		headers.put("Authorization","Bearer "+caps_token);
	 		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("AdtechCaps_CLIENT_ID"), globalProp, test,headers);
	 		return resp;
	 	}
		
		public Response ClientBy_Status(ExtentTest test,String caps_token) throws Exception {
	 		RestAssured.baseURI = executionParams.get("Adtech_CapsURI");
	 		Hashtable<String, String> headers = new Hashtable<String, String>();
	 		headers.put("Authorization","Bearer "+caps_token);
	 		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("AdtechCaps_CLIENT_STATUS"), globalProp, test,headers);
	 		return resp;
	 	}
		
		public Response ClientBy_Active(ExtentTest test,String caps_token) throws Exception {
			RestAssured.baseURI = executionParams.get("Adtech_CapsURI");
	 		Hashtable<String, String> headers = new Hashtable<String, String>();
	 		headers.put("Authorization","Bearer "+caps_token);
			Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("AdtechCaps_CLIENT_ACTIVE"), "",globalProp, test, headers);
			return resp;
		}
		
		public Response ClientBy_Create(String requestBody,ExtentTest test,String caps_token) throws Exception {
			RestAssured.baseURI = executionParams.get("Adtech_CapsURI");
	 		Hashtable<String, String> headers = new Hashtable<String, String>();
	 		headers.put("Authorization","Bearer "+caps_token);
			headers.put("Content-Type", globalProp.getProperty("contentType"));
			Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("AdtechCaps_CLIENT_CREATE"), requestBody,globalProp, test, headers);
			return resp;
		}
		
		public Response ClientBy_InActive(ExtentTest test,String caps_token) throws Exception {
			RestAssured.baseURI = executionParams.get("Adtech_CapsURI");
	 		Hashtable<String, String> headers = new Hashtable<String, String>();
	 		headers.put("Authorization","Bearer "+caps_token);
			Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("AdtechCaps_CLIENT_INACTIVE"), "",globalProp, test, headers);
			return resp;
		}
		
		public Response ClientBy_Update(String requestBody,ExtentTest test,String caps_token) throws Exception {
			RestAssured.baseURI = executionParams.get("Adtech_CapsURI");
	 		Hashtable<String, String> headers = new Hashtable<String, String>();
	 		headers.put("Authorization","Bearer "+caps_token);
			headers.put("Content-Type", globalProp.getProperty("contentType"));
			Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("AdtechCaps_CLIENT_UPDATE"), requestBody,globalProp, test, headers);
			return resp;
		}
		
		//Generic Model
		
		public Response ModelBy_ID(ExtentTest test,String caps_token) throws Exception {
	 		RestAssured.baseURI = executionParams.get("Adtech_CapsURI");
	 		Hashtable<String, String> headers = new Hashtable<String, String>();
	 		headers.put("Authorization","Bearer "+caps_token);
	 		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("AdtechCaps_MODELBY_ID"), globalProp, test,headers);
	 		return resp;
	 	}
		
		public Response ModelBy_Status(ExtentTest test,String caps_token) throws Exception {
	 		RestAssured.baseURI = executionParams.get("Adtech_CapsURI");
	 		Hashtable<String, String> headers = new Hashtable<String, String>();
	 		headers.put("Authorization","Bearer "+caps_token);
	 		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("AdtechCaps_MODELBY_STATUS"), globalProp, test,headers);
	 		return resp;
	 	}
		
		public Response ModelBy_Type(ExtentTest test,String caps_token) throws Exception {
	 		RestAssured.baseURI = executionParams.get("Adtech_CapsURI");
	 		Hashtable<String, String> headers = new Hashtable<String, String>();
	 		headers.put("Authorization","Bearer "+caps_token);
	 		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("AdtechCaps_MODELBY_Type"), globalProp, test,headers);
	 		return resp;
	 	}
		
		public Response ModelBy_Create(String requestBody,ExtentTest test,String caps_token) throws Exception {
			RestAssured.baseURI = executionParams.get("Adtech_CapsURI");
	 		Hashtable<String, String> headers = new Hashtable<String, String>();
	 		headers.put("Authorization","Bearer "+caps_token);
			headers.put("Content-Type", globalProp.getProperty("contentType"));
			Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("AdtechCaps_MODELBY_Create"), requestBody,globalProp, test, headers);
			return resp;
		}
		
		public Response ModelBy_Update(String requestBody,ExtentTest test,String caps_token) throws Exception {
			RestAssured.baseURI = executionParams.get("Adtech_CapsURI");
	 		Hashtable<String, String> headers = new Hashtable<String, String>();
	 		headers.put("Authorization","Bearer "+caps_token);
			headers.put("Content-Type", globalProp.getProperty("contentType"));
			Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("AdtechCaps_MODELBY_Update"), requestBody,globalProp, test, headers);
			return resp;
		}

		
		public int generateRandomNumber(int i,int j) {
			Random random= new Random();        
			return random.nextInt((j - i + 1)) + i;
		}




		
}
