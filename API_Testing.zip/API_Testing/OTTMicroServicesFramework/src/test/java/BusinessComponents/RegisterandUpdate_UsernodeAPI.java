package BusinessComponents;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import com.EndPoints.EndPoints;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import baseTestPackage.BaseTest_TestNG;
import baseTestPackage.SuiteConstant;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import reusableLibrary.ResuableComponents;

public class RegisterandUpdate_UsernodeAPI extends BaseTest_TestNG 
{
	
	List<String> list = new ArrayList<String>();
	ResuableComponents resuableComponents = new ResuableComponents();
	
	public Response SendEmailORMOBILEOTPPOSTCall(ExtentTest test, String requestBody) throws Exception {
		RestAssured.baseURI = executionParams.get("baseuriusernode");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("device_id", globalProp.getProperty("UserToken_deviceID"));
		headers.put("esk",globalProp.getProperty("UserToken_eskID"));
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("REGISTERANDUPDATE_SENDEMAILOTP"), requestBody,globalProp, test, headers);
		return resp;
	}
	
	public Response RegisterEmailOTPPOSTCall(ExtentTest test, String requestBody) throws Exception {
		RestAssured.baseURI = executionParams.get("baseuriusernode");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("device_id", globalProp.getProperty("UserToken_deviceID"));
		headers.put("esk",globalProp.getProperty("UserToken_eskID"));
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("REGISTERANDUPDATE_WITHEMAILOTP"), requestBody,globalProp, test, headers);
		return resp;
	}

	public Response RegisterMOBILEOTPPOSTCall(ExtentTest test, String requestBody) throws Exception {
		RestAssured.baseURI = executionParams.get("baseuriusernode");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("device_id", globalProp.getProperty("UserToken_deviceID"));
		headers.put("esk",globalProp.getProperty("UserToken_eskID"));
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("REGISTERANDUPDATE_WITHMOBILEOTP"), requestBody,globalProp, test, headers);
		return resp;
	}
	
	public Response GetUserGetCall(ExtentTest test,Hashtable<String, String> headers1) throws Exception 
	{
		RestAssured.baseURI = executionParams.get("baseuriusernode");
		Hashtable<String, String> headers =new Hashtable<String,String>();
		headers.putAll(headers1);
		headers.put("device_id", globalProp.getProperty("UserToken_deviceID"));
		headers.put("esk",globalProp.getProperty("UserToken_eskID"));
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("REGISTERANDUPDATE_GETUSER") , globalProp, test, headers);
		return resp;
	}
	public Response UpdateMobilePUTCall(ExtentTest test,String requestBody,Hashtable<String, String> headers1) throws Exception 
	{
		RestAssured.baseURI = executionParams.get("baseuriusernode");
		Hashtable<String, String> headers =new Hashtable<String,String>();
		headers.putAll(headers1);
		headers.put("device_id", globalProp.getProperty("UserToken_deviceID"));
		headers.put("esk",globalProp.getProperty("UserToken_eskID"));
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.executePutAPI(EndPoints.endPointList.get("REGISTERANDUPDATE_UPDATE_MOBILE"),requestBody , globalProp, test, headers);
		return resp;
	}
	
	public Response UpdateEmailPUTCall(ExtentTest test,String requestBody,Hashtable<String, String> headers1) throws Exception 
	{
		RestAssured.baseURI = executionParams.get("baseuriusernode");
		Hashtable<String, String> headers =new Hashtable<String,String>();
		headers.putAll(headers1);
		headers.put("device_id", globalProp.getProperty("UserToken_deviceID"));
		headers.put("esk",globalProp.getProperty("UserToken_eskID"));
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.executePutAPI(EndPoints.endPointList.get("REGISTERANDUPDATE_UPDATE_EMAIL") ,requestBody, globalProp, test, headers);
		return resp;
	}
	
	public Response UpdateUserv1PUTCall(ExtentTest test,String requestBody,Hashtable<String, String> headers1) throws Exception 
	{
		RestAssured.baseURI = executionParams.get("baseuriusernode");
		Hashtable<String, String> headers =new Hashtable<String,String>();
		headers.putAll(headers1);
		headers.put("device_id", globalProp.getProperty("UserToken_deviceID"));
		headers.put("esk",globalProp.getProperty("UserToken_eskID"));
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.executePutAPI(EndPoints.endPointList.get("REGISTERANDUPDATE_UPDATEUSER_V1") ,requestBody, globalProp, test, headers);
		return resp;
	}
	
	public Response UpdateUserv2PUTCall(ExtentTest test,String requestBody,Hashtable<String, String> headers1) throws Exception 
	{
		RestAssured.baseURI = executionParams.get("baseuriusernode");
		Hashtable<String, String> headers =new Hashtable<String,String>();
		headers.putAll(headers1);
		headers.put("device_id", globalProp.getProperty("UserToken_deviceID"));
		headers.put("esk",globalProp.getProperty("UserToken_eskID"));
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.executePutAPI(EndPoints.endPointList.get("REGISTERANDUPDATE_UPDATEUSER_V2") ,requestBody, globalProp, test, headers);
		return resp;
	}

	
	//Reusable to get OTP form the String recieved from DB
	
	public String OTPCode(String data)
	{
		String[] Data=data.split(",");
		String [] code= Data[1].split(":");
		String OTP=code[1];
		OTP=OTP.replaceAll("\"", "");
		
		return OTP;
		
	}
	
	

}
