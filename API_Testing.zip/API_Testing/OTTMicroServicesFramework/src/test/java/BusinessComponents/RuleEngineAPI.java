package BusinessComponents;

import java.util.Hashtable;

import com.EndPoints.EndPoints;
import com.relevantcodes.extentreports.ExtentTest;
import com.OTTPlatform.SharedServices.RuleEngine_Test;
import baseTestPackage.BaseTest_TestNG;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import reusableLibrary.ResuableComponents;

public class RuleEngineAPI extends BaseTest_TestNG{

ResuableComponents resuableComponents = new ResuableComponents();
	
	public Response getAllRule(ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("communicationURI");
		Hashtable<String, String> headers=new Hashtable<String, String>();
		headers.put("X-Api-Key", CSU.decrypt(globalProp.getProperty("rule_X-Api-Key")));
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("GETALLRULE_ruleengine") , globalProp,
				test, headers);
		return resp;
	}
	
	public Response CreateEmailRule(ExtentTest test,String reqBody) throws Exception {
		RestAssured.baseURI = executionParams.get("communicationURI");
		Hashtable<String, String> headers=new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("X-Api-Key", CSU.decrypt(globalProp.getProperty("rule_X-Api-Key")));
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("EMAILRULE_ruleengine"), reqBody,
				globalProp, test, headers);
		return resp;
	}
	
	public Response getSpecificRule(ExtentTest test,String RuleName) throws Exception {
		RestAssured.baseURI = executionParams.get("communicationURI");
		Hashtable<String, String> headers=new Hashtable<String, String>();
		headers.put("X-Api-Key", CSU.decrypt(globalProp.getProperty("rule_X-Api-Key")));
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("SPECIFICRULE_ruleengine") + RuleName, globalProp,
				test, headers);
		return resp;
	}
	
	public Response CreateFetchRule(ExtentTest test,String reqBody) throws Exception {
		RestAssured.baseURI = executionParams.get("communicationURI");
		Hashtable<String, String> headers=new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("X-Api-Key", CSU.decrypt(globalProp.getProperty("rule_X-Api-Key")));
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("FETCH_ruleengine"), reqBody,
				globalProp, test, headers);
		return resp;
	}
	
	public Response UpdateRule(ExtentTest test,String reqBody,String RuleName) throws Exception {
		RestAssured.baseURI = executionParams.get("communicationURI");
		Hashtable<String, String> headers=new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("X-Api-Key", CSU.decrypt(globalProp.getProperty("rule_X-Api-Key")));
		Response resp = resuableComponents.executePutAPI(EndPoints.endPointList.get("UPDATERULE_ruleengine")+RuleName,
				reqBody, globalProp, test, headers);
		return resp;
	}
	
	public Response deleteRuleChannel(ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("communicationURI");
		Hashtable<String, String> headers=new Hashtable<String, String>();
		headers.put("X-Api-Key", CSU.decrypt(globalProp.getProperty("rule_X-Api-Key")));
		Response resp = resuableComponents.executeDeleteAPI(EndPoints.endPointList.get("DELETERULECHANNEL_ruleengine"),
				globalProp, test, headers);
		return resp;
	}
	
	public Response deleteRuleName(ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("communicationURI");
		Hashtable<String, String> headers=new Hashtable<String, String>();
		headers.put("X-Api-Key", CSU.decrypt(globalProp.getProperty("rule_X-Api-Key")));
		Response resp = resuableComponents.executeDeleteAPI(EndPoints.endPointList.get("DELETERULENAME_ruleengine"),
				globalProp, test, headers);
		return resp;
	}
	
	public Response CreateSMSRule(ExtentTest test,String reqBody) throws Exception {
		RestAssured.baseURI = executionParams.get("communicationURI");
		Hashtable<String, String> headers=new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("X-Api-Key", CSU.decrypt(globalProp.getProperty("rule_X-Api-Key")));
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("SMSRULE_ruleengine"), reqBody,
				globalProp, test, headers);
		return resp;
	}
}
