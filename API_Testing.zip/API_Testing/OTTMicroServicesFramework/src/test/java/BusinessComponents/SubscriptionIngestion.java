package BusinessComponents;

import java.util.Hashtable;

import com.EndPoints.EndPoints;
import com.relevantcodes.extentreports.ExtentTest;

import baseTestPackage.BaseTest_TestNG;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import reusableLibrary.ResuableComponents;

public class SubscriptionIngestion extends BaseTest_TestNG{

	ResuableComponents resuableComponents = new ResuableComponents();
	
		
	public Response CreateUpload(ExtentTest test,String reqBody) throws Exception {
		 
		RestAssured.baseURI = executionParams.get("Subscription_Ingestion_");
		String excelfilepath = System.getProperty("user.dir") + globalProp.getProperty("SubscriptionExcelSheet");
		  Hashtable<String, String> headers = new Hashtable<String, String>();
		  Hashtable<String, String> formparams = new Hashtable<String, String>();
		  headers.put("Content-Type",globalProp.getProperty("MultiPartContent"));
		  formparams.put("file", excelfilepath);
		  formparams.put("email", globalProp.getProperty("SubscriptionEmail"));
		  Response resp = resuableComponents.POSTMultiform(EndPoints.endPointList.get("SUBSCRIPTION_INGESTION_upload"),
					excelfilepath, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", globalProp, headers, formparams, test);
		  return resp;
		
	}
	
	public Response get_getBatch(ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("Subscription_Ingestion_");
		Hashtable<String, String> headers =new Hashtable<String,String>();
		Hashtable<String, String> formparams = new Hashtable<String, String>();
		  formparams.put("email", globalProp.getProperty("SubscriptionEmail"));
		Response resp = resuableComponents.executeGETMultiform(EndPoints.endPointList.get("SUBSCRIPTION_INGESTION_get_Batch"),
				 globalProp, headers, formparams, test);
		return resp;
	}

}
