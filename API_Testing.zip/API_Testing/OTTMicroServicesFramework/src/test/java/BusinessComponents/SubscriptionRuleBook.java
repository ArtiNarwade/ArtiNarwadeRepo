package BusinessComponents;

import java.util.Hashtable;

import com.EndPoints.EndPoints;
import com.relevantcodes.extentreports.ExtentTest;

import baseTestPackage.BaseTest_TestNG;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import reusableLibrary.ResuableComponents;

public class SubscriptionRuleBook extends BaseTest_TestNG{

	ResuableComponents resuableComponents = new ResuableComponents();
	
	public Response CreateReferrerRule(ExtentTest test,String reqBody) throws Exception {
		RestAssured.baseURI = executionParams.get("inferenceengineURI");
		Hashtable<String, String> headers=new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("api_key", CSU.decrypt(globalProp.getProperty("rulebook_api_key")));
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("REFERRER_subrulebook"), reqBody,
				globalProp, test, headers);
		return resp;
	}
	
	public Response CreateRefereeRule(ExtentTest test,String reqBody) throws Exception {
		RestAssured.baseURI = executionParams.get("inferenceengineURI");
		Hashtable<String, String> headers=new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("api_key", CSU.decrypt(globalProp.getProperty("rulebook_api_key")));
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("REFEREE_subrulebook"), reqBody,
				globalProp, test, headers);
		return resp;
	}
	
	public Response CreateCohortRule(ExtentTest test,String reqBody) throws Exception {
		RestAssured.baseURI = executionParams.get("inferenceengineURI");
		Hashtable<String, String> headers=new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("api_key", CSU.decrypt(globalProp.getProperty("rulebook_api_key")));
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("COHORT_subrulebook"), reqBody,
				globalProp, test, headers);
		return resp;
	}
	
	public Response CreateCLPRule(ExtentTest test,String reqBody) throws Exception {
		RestAssured.baseURI = executionParams.get("inferenceengineURI");
		Hashtable<String, String> headers=new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("api_key", CSU.decrypt(globalProp.getProperty("rulebook_api_key")));
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("CLP_subrulebook"), reqBody,
				globalProp, test, headers);
		return resp;
	}
	
	public Response CreateCouponRule(ExtentTest test,String reqBody) throws Exception {
		RestAssured.baseURI = executionParams.get("inferenceengineURI");
		Hashtable<String, String> headers=new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("api_key", CSU.decrypt(globalProp.getProperty("rulebook_api_key")));
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("COUPON_subrulebook"), reqBody,
				globalProp, test, headers);
		return resp;
	}
	
	public Response getV1Rule(ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("inferenceengineURI");
		Hashtable<String, String> headers=new Hashtable<String, String>();
		headers.put("api_key", CSU.decrypt(globalProp.getProperty("rulebook_api_key")));
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("GETV1RULE_subrulebook"), globalProp,
				test, headers);
		return resp;
	}
	
	public Response CreateV1Rule(ExtentTest test,String reqBody) throws Exception {
		RestAssured.baseURI = executionParams.get("inferenceengineURI");
		Hashtable<String, String> headers=new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("api_key", CSU.decrypt(globalProp.getProperty("rulebook_api_key")));
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("POSTV1RULE_subrulebook_1"), reqBody,
				globalProp, test, headers);
		return resp;
	}
}
