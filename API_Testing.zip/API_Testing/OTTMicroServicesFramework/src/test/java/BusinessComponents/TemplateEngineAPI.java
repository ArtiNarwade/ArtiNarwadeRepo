package BusinessComponents;

import java.util.Hashtable;

import com.EndPoints.EndPoints;
import com.relevantcodes.extentreports.ExtentTest;

import baseTestPackage.BaseTest_TestNG;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import reusableLibrary.ResuableComponents;

public class TemplateEngineAPI extends BaseTest_TestNG{

	ResuableComponents resuableComponents = new ResuableComponents();

	public Response getTemplate(ExtentTest test, String Tempid) throws Exception {
		RestAssured.baseURI = executionParams.get("communicationURI");
		Hashtable<String, String> headers=new Hashtable<String, String>();
		headers.put("X-Api-Key", CSU.decrypt(globalProp.getProperty("template_X-Api-Key")));
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("GETETEMPLATE_templateengine") + Tempid, globalProp,
				test, headers);
		return resp;
	}

	public Response deleteTemplateCache(ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("communicationURI");
		Hashtable<String, String> headers=new Hashtable<String, String>();
		headers.put("X-Api-Key", CSU.decrypt(globalProp.getProperty("template_X-Api-Key")));
		Response resp = resuableComponents.executeDeleteAPI(EndPoints.endPointList.get("DELETETEMPLATECACHE_templateengine"),
				globalProp, test, headers);
		return resp;
	}

	public Response CreateAddTemplate(ExtentTest test,String reqBody) throws Exception {
		RestAssured.baseURI = executionParams.get("communicationURI");
		Hashtable<String, String> headers=new Hashtable<String, String>();
		headers.put("X-Api-Key", CSU.decrypt(globalProp.getProperty("template_X-Api-Key")));
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("ADDTEMPLATE_templateengine"), reqBody,
				globalProp, test, headers);
		return resp;
	}

	public Response UpdateTemplate(ExtentTest test,String reqBody, String Tempid) throws Exception {
		RestAssured.baseURI = executionParams.get("communicationURI");
		Hashtable<String, String> headers=new Hashtable<String, String>();
		headers.put("X-Api-Key", CSU.decrypt(globalProp.getProperty("template_X-Api-Key")));
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.executePutAPI(EndPoints.endPointList.get("UPDATETEMPLATE_templateengine") + Tempid, reqBody,
				globalProp, test, headers);
		return resp;
	}

	public Response deleteTemplatedb(ExtentTest test,String reqBody,String Tempid) throws Exception {
		RestAssured.baseURI = executionParams.get("communicationURI");
		Hashtable<String, String> headers=new Hashtable<String, String>();
		headers.put("X-Api-Key", CSU.decrypt(globalProp.getProperty("template_X-Api-Key")));
		Response resp = resuableComponents.executeDeleteAPI(EndPoints.endPointList.get("DELETETEMPLATEDB_templateengine") + Tempid,reqBody
				,globalProp, test, headers);
		return resp;
	}
}
