package BusinessComponents;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import com.EndPoints.EndPoints;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import baseTestPackage.BaseTest_TestNG;
import baseTestPackage.SuiteConstant;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import reusableLibrary.ResuableComponents;

public class UAPI_WatchList extends BaseTest_TestNG{
		
		List<String> list = new ArrayList<String>();
		ResuableComponents resuableComponents = new ResuableComponents();
		

		public  Response createWatchListwithTimeStamp(ExtentTest test, String reqBody) throws Exception {
			RestAssured.baseURI = executionParams.get("watchListbaseURI");
			Hashtable<String, String> headers = new Hashtable<String, String>();
			headers.put("Content-Type", globalProp.getProperty("contentType"));
			headers.put("Authorization", CSU.decrypt(globalProp.getProperty("watchListAuth")));
			Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("WATCHLISTENDPOINT"), reqBody, globalProp, test,headers);
			test.log(LogStatus.INFO, "<b>DataStore: </b>" + SuiteConstant.dataStore);
			return resp;			
		}
		
		public  Response createWatchListWithoutTimeStamp(ExtentTest test, String reqBody) throws Exception {
			RestAssured.baseURI = executionParams.get("watchListbaseURI");
			Hashtable<String, String> headers = new Hashtable<String, String>();
			headers.put("Content-Type", globalProp.getProperty("contentType"));
			headers.put("Authorization", CSU.decrypt(globalProp.getProperty("watchListAuth")));
			Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("WATCHLISTENDPOINT"), reqBody, globalProp, test,headers);
			return resp;		
		}	
		
		public Response updateAssetwithTimeStamp(ExtentTest test, String reqBody) throws Exception {
			RestAssured.baseURI = executionParams.get("watchListbaseURI");
			Hashtable<String, String> headers = new Hashtable<String, String>();
			headers.put("Content-Type", globalProp.getProperty("contentType"));
			headers.put("Authorization", CSU.decrypt(globalProp.getProperty("watchListAuth")));
			Response resp = resuableComponents.executePutAPI(EndPoints.endPointList.get("WATCHLISTENDPOINT"), reqBody, globalProp, test, headers);
			return resp;
		}
		
		public Response updateAssetwithoutTimeStamp(ExtentTest test, String reqBody) throws Exception {
			RestAssured.baseURI = executionParams.get("watchListbaseURI");
			Hashtable<String, String> headers = new Hashtable<String, String>();
			headers.put("Content-Type", globalProp.getProperty("contentType"));
			headers.put("Authorization", CSU.decrypt(globalProp.getProperty("watchListAuth")));
			Response resp = resuableComponents.executePutAPI(EndPoints.endPointList.get("WATCHLISTENDPOINT"), reqBody, globalProp, test, headers);
			return resp;
		}

		
		public Response accessAssetWithoutTimeStamp(ExtentTest test) throws Exception {
			RestAssured.baseURI = executionParams.get("watchListbaseURI");
			Hashtable<String, String> headers = new Hashtable<String, String>();
			headers.put("Content-Type", globalProp.getProperty("contentType"));
			headers.put("Authorization", CSU.decrypt(globalProp.getProperty("watchListAuth")));
			Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("WATCHLISTENDPOINT"), globalProp, test, headers);
			return resp;
		}
		
		public Response accessAssetWithTimeStamp(ExtentTest test) throws Exception {
			RestAssured.baseURI = executionParams.get("watchListbaseURI");
			Hashtable<String, String> headers = new Hashtable<String, String>();
			headers.put("Content-Type", globalProp.getProperty("contentType"));
			headers.put("Authorization", CSU.decrypt(globalProp.getProperty("watchListAuth")));
			Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("WATCHLISTENDPOINT"), globalProp, test, headers);
			return resp;
		}
		
		
		public Response deleteAssetfromtheWatchList(ExtentTest test) throws Exception {
			RestAssured.baseURI = executionParams.get("watchListbaseURI");
			Hashtable<String, String> headers = new Hashtable<String, String>();
			headers.put("Content-Type", globalProp.getProperty("contentType"));
			headers.put("Authorization", CSU.decrypt(globalProp.getProperty("watchListAuth")));
			Response resp = resuableComponents.executeDeleteAPI(EndPoints.endPointList.get("WATCHLISTENDPOINTASSETDELETE"),globalProp, test, headers);
			return resp;
		}
		
		

		}
		


		

