package BusinessComponents;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import com.EndPoints.EndPoints;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import baseTestPackage.BaseTest_TestNG;
import baseTestPackage.SuiteConstant;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import reusableLibrary.ResuableComponents;

public class UM_GuestGenerator extends BaseTest_TestNG{
		
		List<String> list = new ArrayList<String>();
		ResuableComponents resuableComponents = new ResuableComponents();
		
		public Response verifyGuestGeneratorTokenUsingPostCall(ExtentTest test,String reqBody)  throws Exception{ 
			RestAssured.baseURI = executionParams.get("UserGuestGeneratorUrl");
			Hashtable<String, String> headers = new Hashtable<String, String>();
			headers.put("Content-Type", globalProp.getProperty("GuestGeneratorContentType"));
			headers.put("x-z5-guest-token", CSU.decrypt(globalProp.getProperty("GuestGeneratorGuestToken")));
			Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("GUESTGENERATORGENERATETOKEN"), reqBody,globalProp, test, headers);
			return resp;			
		}

}
		