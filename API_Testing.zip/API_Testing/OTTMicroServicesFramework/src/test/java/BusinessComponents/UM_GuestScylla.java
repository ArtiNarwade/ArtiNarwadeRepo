package BusinessComponents;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import com.EndPoints.EndPoints;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import baseTestPackage.BaseTest_TestNG;
import baseTestPackage.SuiteConstant;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import reusableLibrary.ResuableComponents;

public class UM_GuestScylla extends BaseTest_TestNG{
		
		List<String> list = new ArrayList<String>();
		ResuableComponents resuableComponents = new ResuableComponents();
		
		public Response updateGuestUserUsingPutCall(ExtentTest test, String reqBody) throws Exception {
			RestAssured.baseURI = executionParams.get("GuestScyllaUrl");
			Hashtable<String, String> headers = new Hashtable<String, String>();
			headers.put("device_id", globalProp.getProperty("GuestScyllaDeviceId"));
			headers.put("esk", globalProp.getProperty("GuestScyllaEsk"));
			headers.put("X-Z5-Guest-Token", CSU.decrypt(globalProp.getProperty("GuestScyllaXZ5GuestToken")));
			headers.put("Content-Type", globalProp.getProperty("GuestScyllaContentType"));
			Response resp = resuableComponents.executePutAPI(EndPoints.endPointList.get("GUESTSCYLLAUSERDETAILSUPDATE"), reqBody, globalProp, test, headers);
			return resp;
		}
		public Response updateGuestUserUsingNewTokenPutCall(ExtentTest test, String reqBody) throws Exception {
			RestAssured.baseURI = executionParams.get("GuestScyllaUrl");
			Hashtable<String, String> headers = new Hashtable<String, String>();
			headers.put("device_id", globalProp.getProperty("GuestScyllaDeviceId"));
			headers.put("esk", globalProp.getProperty("GuestScyllaEsk"));
			headers.put("X-Z5-Guest-Token", globalProp.getProperty("GuestScyllaXZ5GuestNewToken"));
			headers.put("Content-Type", globalProp.getProperty("GuestScyllaContentType"));
			Response resp = resuableComponents.executePutAPI(EndPoints.endPointList.get("GUESTSCYLLAUSERDETAILSUPDATEWITHNEWTOKEN"), reqBody, globalProp, test, headers);
			return resp;
		}
		public Response getGuestUserDetailsPutCall(ExtentTest test) throws Exception{ 
			RestAssured.baseURI = executionParams.get("GuestScyllaUrl");
			Hashtable<String, String> headers = new Hashtable<String, String>();
			headers.put("device_id", globalProp.getProperty("GuestScyllaDeviceId"));
			headers.put("esk", globalProp.getProperty("GuestScyllaEsk"));
			headers.put("X-Z5-Guest-Token", CSU.decrypt(globalProp.getProperty("GuestScyllaXZ5GuestToken")));
			headers.put("Content-Type", globalProp.getProperty("GuestScyllaContentType"));
			Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("GUESTSCYLLAUSERDETAILS"),globalProp, test, headers);
			return resp;			
		}
}
		