package BusinessComponents;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import com.EndPoints.EndPoints;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import baseTestPackage.BaseTest_TestNG;
import baseTestPackage.SuiteConstant;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import reusableLibrary.ResuableComponents;

public class UM_TokenVerification extends BaseTest_TestNG{
		
		List<String> list = new ArrayList<String>();
		ResuableComponents resuableComponents = new ResuableComponents();
		
			public Response TokenverificationV1UsingGetCall(ExtentTest test, Hashtable<String, String> headers1) throws Exception{ 
			RestAssured.baseURI = executionParams.get("TokenVerificationUrl");
			Hashtable<String, String> headers = new Hashtable<String, String>();
			headers.put("cms-Authorization", CSU.decrypt(globalProp.getProperty("TokenVerificationCmsAuthorization")));
			headers.putAll(headers1);
			Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("TOKENVERIFICATIONGVERIFYTOKENV1"),globalProp, test, headers);
			return resp;			
		}
			public Response TokenverificationV2UsingGetCall(ExtentTest test,Hashtable<String, String> headers1) throws Exception{ 
				RestAssured.baseURI = executionParams.get("TokenVerificationUrl");
				Hashtable<String, String> headers = new Hashtable<String, String>();
				headers.put("cms-Authorization", CSU.decrypt(globalProp.getProperty("TokenVerificationCmsAuthorization")));
				headers.put("device_id", globalProp.getProperty("TokenVerificationdevice_id"));
				headers.put("esk", globalProp.getProperty("TokenVerificationesk"));
				headers.putAll(headers1);
				Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("TOKENVERIFICATIONGVERIFYTOKENV2"),globalProp, test, headers);
				return resp;			
			}
			public Response TokenverificationUsingGetCall(ExtentTest test,Hashtable<String, String> headers1) throws Exception{ 
				RestAssured.baseURI = executionParams.get("TokenVerificationUrl");
				Hashtable<String, String> headers = new Hashtable<String, String>();
				headers.put("cms-Authorization", CSU.decrypt(globalProp.getProperty("TokenVerificationCmsAuthorization")));
				headers.putAll(headers1);
				Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("TOKENVERIFICATIONGVERIFYTOKEN"),globalProp, test, headers);
				return resp;			
			}
}
		