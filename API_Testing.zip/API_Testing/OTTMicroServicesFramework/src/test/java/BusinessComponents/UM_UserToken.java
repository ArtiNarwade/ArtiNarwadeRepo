package BusinessComponents;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

import javax.crypto.spec.SecretKeySpec;

import com.EndPoints.EndPoints;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import baseTestPackage.BaseTest_TestNG;
import baseTestPackage.SuiteConstant;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import reusableLibrary.Ciper_SecretUtils;
import reusableLibrary.ResuableComponents;


public class UM_UserToken extends BaseTest_TestNG{
		
		List<String> list = new ArrayList<String>();
		ResuableComponents resuableComponents = new ResuableComponents();
		Ciper_SecretUtils CSU= new Ciper_SecretUtils();
		
		public Response tokenGenreatePost(ExtentTest test, String requestBody)  throws Exception{ 
			RestAssured.baseURI = executionParams.get("UserTokenGenerate");
			Hashtable<String, String> headers = new Hashtable<String, String>();
			headers.put("Content-Type", globalProp.getProperty("contentType"));
			
			
		
			
			  headers.put("Authorization", CSU.decrypt(
			  globalProp.getProperty("UserTokenDeviceAuthorization")));
			  headers.put("Cookie",
			  CSU.decrypt(globalProp.getProperty("UserTokenDeviceCookie")));
			  headers.put("esk", globalProp.getProperty("UserToken_eskID"));
			  headers.put("device_id", globalProp.getProperty("UserToken_deviceID"));
			  headers.put("Client-Id", globalProp.getProperty("UserToken_clientID"));
			  headers.put("Client-Secret",
			  CSU.decrypt(globalProp.getProperty("UserToken_sceretID")));
			 
			/*
			 * headers.put("Authorization", (
			 * globalProp.getProperty("UserTokenDeviceAuthorization")));
			 * headers.put("Cookie", (globalProp.getProperty("UserTokenDeviceCookie")));
			 * headers.put("esk", globalProp.getProperty("UserToken_eskID"));
			 * headers.put("device_id", globalProp.getProperty("UserToken_deviceID"));
			 * headers.put("Client-Id", globalProp.getProperty("UserToken_clientID"));
			 * headers.put("Client-Secret", (globalProp.getProperty("UserToken_sceretID")));
			 */
			
			Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("USERTOKENGENERATE"), requestBody,globalProp, test, headers);
			return resp;			
		}
		public Response tokengetClaimUsingPost(ExtentTest test, String requestBody)  throws Exception{ 
			RestAssured.baseURI = executionParams.get("UserTokeGetClaim");
			Hashtable<String, String> headers = new Hashtable<String, String>();
			headers.put("Content-Type", globalProp.getProperty("contentType"));
			headers.put("Client-Id", globalProp.getProperty("UserToken_clientID"));
			headers.put("Client-Secret", CSU.decrypt(globalProp.getProperty("UserToken_sceretID")));
			Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("USERTOKENGETCLAIM"), requestBody,globalProp, test, headers);
			return resp;			
		}
		
		public Response renewTokenUsingPost(ExtentTest test, String requestBody)  throws Exception{ 
			RestAssured.baseURI = executionParams.get("UserTokeRenew");
			Hashtable<String, String> headers = new Hashtable<String, String>();
			headers.put("client-id", globalProp.getProperty("UserToken_clientID"));
			headers.put("client-secret", CSU.decrypt(globalProp.getProperty("UserToken_sceretID")));
			headers.put("Content-Type", globalProp.getProperty("contentType"));
			headers.put("Cookie", CSU.decrypt(globalProp.getProperty("UserTokenDeviceCookie")));
			Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("USERTOKENRENEW"), requestBody,globalProp, test, headers);
			return resp;			
		}
}
		