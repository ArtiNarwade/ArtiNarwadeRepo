package BusinessComponents;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Test;

import com.EndPoints.EndPoints;
import baseTestPackage.BaseTest_TestNG;
import baseTestPackage.SuiteConstant;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import reusableLibrary.ResuableComponents;
import com.relevantcodes.extentreports.ExtentTest;
public class UM_User_Device_Management_API extends BaseTest_TestNG {

	List<String> list = new ArrayList<String>();
	//SuiteConstant suiteMap = new SuiteConstant();
	ResuableComponents resuableComponents = new ResuableComponents();

	public Response GetUserDevicesDetailsGetCall(ExtentTest test,Hashtable<String, String> headers1) throws Exception {
		RestAssured.baseURI = executionParams.get("baseURIUserDeviceManagment");
		Hashtable<String, String> headers =new Hashtable<String,String>();
		headers.putAll(headers1);
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		//headers.put("Cookie", CSU.decrypt(globalProp.getProperty("UserDeviceManagmentCookie")));
	 	Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("USERDEVICEMANAGEMENTGETUSERDEVICEDETAILS") , globalProp, test, headers);
		return resp;
	}
	
	public Response GetDevicesDetailsGetCall(ExtentTest test,Hashtable<String, String> headers1) throws Exception {
		RestAssured.baseURI = executionParams.get("baseURIUserDeviceManagment");
		Hashtable<String, String> headers =new Hashtable<String,String>();
		headers.putAll(headers1);
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		//headers.put("Cookie", CSU.decrypt(globalProp.getProperty("UserDeviceManagmentCookie")));
	 	Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("USERDEVICEMANAGEMENTGETDEVICEDETAILS") , globalProp, test, headers);
		return resp;
	}
	public Response GetUserDevicesPlaybackDetailsGetCall(ExtentTest test,Hashtable<String, String> headers1) throws Exception {
		RestAssured.baseURI = executionParams.get("baseURIUserDeviceManagment");
		Hashtable<String, String> headers =new Hashtable<String,String>();
		headers.putAll(headers1);
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		//headers.put("Cookie", CSU.decrypt(globalProp.getProperty("UserDeviceManagmentCookie")));
	 	Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("USERDEVICEMANAGEMENTGETUSERDEVICEPLAYBACKDETAILS") , globalProp, test, headers);
		return resp;
	}

	public Response GetDevicesAuditDetailsGetCall(ExtentTest test,Hashtable<String, String> headers1) throws Exception {
		RestAssured.baseURI = executionParams.get("baseURIUserDeviceManagment");
		Hashtable<String, String> headers =new Hashtable<String,String>();
		headers.putAll(headers1);
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		//headers.put("Cookie", CSU.decrypt(globalProp.getProperty("UserDeviceManagmentCookie")));
	 	Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("USERDEVICEMANAGEMENTGETDEVICEAUDITDETAILS") , globalProp, test, headers);
		return resp;
	}
	public Response LogoutUserFromDevicePostCall(ExtentTest test,String reqBody,Hashtable<String, String> headers1) throws Exception {
		RestAssured.baseURI = executionParams.get("baseURIUserDeviceManagment");
		Hashtable<String, String> headers =new Hashtable<String,String>();
		headers.putAll(headers1);
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		//headers.put("Cookie", CSU.decrypt(globalProp.getProperty("UserDeviceManagmentCookie")));
	 	Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("USERDEVICEMANAGEMENTLOGOUTUSERFROMDEVICE"), reqBody , globalProp, test, headers);
		return resp;
	}

}
