package BusinessComponents;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import com.EndPoints.EndPoints;
import baseTestPackage.BaseTest_TestNG;
import baseTestPackage.SuiteConstant;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import reusableLibrary.ResuableComponents;
import com.relevantcodes.extentreports.ExtentTest;
public class UP_Auth_API extends BaseTest_TestNG {

	List<String> list = new ArrayList<String>();
	SuiteConstant suiteMap = new SuiteConstant();
	ResuableComponents resuableComponents = new ResuableComponents();

	public Response updateUserMobileNumber(ExtentTest test, String requestBody) throws Exception {
		RestAssured.baseURI = executionParams.get("AuthApiURL");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("esk", globalProp.getProperty("AuthApiEsk"));
		headers.put("device_id", globalProp.getProperty("AuthApiDeviceId"));
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.executePutAPI(EndPoints.endPointList.get("AUTHAPIUPDATEUSERMOBILENUMBER"),requestBody, globalProp, test, headers);
		return resp;
	}

	public Response updateUserEmail(ExtentTest test, String requestBody) throws Exception {
		RestAssured.baseURI = executionParams.get("AuthApiURL");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("esk", globalProp.getProperty("AuthApiEsk"));
		headers.put("device_id", globalProp.getProperty("AuthApiDeviceId"));
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.executePutAPI(EndPoints.endPointList.get("AUTHAPIUPDATEUSEREMAIL"), requestBody,globalProp, test);
		return resp;
	}

	public Response updateUserDetails(ExtentTest test, String requestBody) throws Exception {
		RestAssured.baseURI = executionParams.get("AuthApiURL");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("esk", globalProp.getProperty("AuthApiEsk"));
		headers.put("device_id", globalProp.getProperty("AuthApiDeviceId"));
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.executePutAPI(EndPoints.endPointList.get("AUTHAPIUPDATEUSERDETAILS"), requestBody,globalProp, test, headers);
		return resp;
	}
	public Response updateUserDetailsPostCall(ExtentTest test, String requestBody) throws Exception {
		RestAssured.baseURI = executionParams.get("AuthApiURL");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("esk", globalProp.getProperty("AuthApiEsk"));
		headers.put("device_id", globalProp.getProperty("AuthApiDeviceId"));
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.executePutAPI(EndPoints.endPointList.get("AUTHAPIUPDATEUSERDETAILSV2"), requestBody,globalProp, test, headers);
		return resp;
	}
	public Response getUserDetails(ExtentTest test) throws Exception {

		RestAssured.baseURI = executionParams.get("AuthApiURL");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("esk", globalProp.getProperty("AuthApiEsk"));
		headers.put("device_id", globalProp.getProperty("AuthApiDeviceId"));
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("AUTHAPIUSERDETAILS"), globalProp, test,headers);
		return resp;
	}
	public Response SendOtpToEmail(ExtentTest test, String requestBody) throws Exception {
		RestAssured.baseURI = executionParams.get("AuthApiURL");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("esk", globalProp.getProperty("AuthApiEsk"));
		headers.put("device_id", globalProp.getProperty("AuthApiDeviceId"));
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("AUTHAPIOTPEMAIL"), requestBody,globalProp, test, headers);
		return resp;
	}
	public Response SendOtpToMobile(ExtentTest test, String requestBody) throws Exception {
		RestAssured.baseURI = executionParams.get("AuthApiURL");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("esk", globalProp.getProperty("AuthApiEsk"));
		headers.put("device_id", globalProp.getProperty("AuthApiDeviceId"));
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("AUTHAPIOTPMOBILE"), requestBody,globalProp, test, headers);
		return resp;
	}
	public Response deleteUser(ExtentTest test) throws Exception {

		RestAssured.baseURI = executionParams.get("AuthApiURL");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("esk", globalProp.getProperty("AuthApiEsk"));
		headers.put("device_id", globalProp.getProperty("AuthApiDeviceId"));
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("AUTHAPIDELETEUSER"), globalProp, test,headers);
		return resp;
	}
	////////////////////
	public Response emailOtpVerification(ExtentTest test, String requestBody) throws Exception {
		RestAssured.baseURI = executionParams.get("AuthApiURL");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("esk", globalProp.getProperty("AuthApiEsk"));
		headers.put("device_id", globalProp.getProperty("AuthApiDeviceId"));
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("AUTHAPIOTPVERIFICATIONONEMAIL"), requestBody,globalProp, test, headers);
		return resp;
	}
	public Response mobileOtpVerification(ExtentTest test, String requestBody) throws Exception {
		RestAssured.baseURI = executionParams.get("AuthApiURL");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("esk", globalProp.getProperty("AuthApiEsk"));
		headers.put("device_id", globalProp.getProperty("AuthApiDeviceId"));
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("AUTHAPIOTPVERIFICATIONONMOBILE"), requestBody,globalProp, test, headers);
		return resp;
	}
	public Response registrationWithMobileNumber(ExtentTest test, String requestBody) throws Exception {
		RestAssured.baseURI = executionParams.get("AuthApiURL");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("esk", globalProp.getProperty("AuthApiEsk"));
		headers.put("device_id", globalProp.getProperty("AuthApiDeviceId"));
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("AUTHAPIREGISTRATIONWITHMOBILE"), requestBody,globalProp, test, headers);
		return resp;
	}
	public Response registrationWithEmail(ExtentTest test, String requestBody) throws Exception {
		RestAssured.baseURI = executionParams.get("AuthApiURL");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("esk", globalProp.getProperty("AuthApiEsk"));
		headers.put("device_id", globalProp.getProperty("AuthApiDeviceId"));
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("AUTHAPIREGISTRATIONWITHEMAIL"), requestBody,globalProp, test, headers);
		return resp;
	}

}
