package BusinessComponents;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import com.EndPoints.EndPoints;
import com.relevantcodes.extentreports.ExtentTest;

import baseTestPackage.BaseTest_TestNG;
import baseTestPackage.SuiteConstant;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import reusableLibrary.ResuableComponents;

public class UP_UserProfile extends BaseTest_TestNG {

	List<String> list = new ArrayList<String>();
	SuiteConstant suiteMap = new SuiteConstant();
	ResuableComponents resuableComponents = new ResuableComponents();

	public Response getAllUserProfile(ExtentTest test) throws Exception {

		RestAssured.baseURI = executionParams.get("userProfileURL");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("esk", globalProp.getProperty("UserProfileEsk"));
		headers.put("device_id", globalProp.getProperty("UserProfileDeviceId"));
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("Authorization", CSU.decrypt(globalProp.getProperty("AuthorizationToken")));
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("ALLUSERPROFILE"), globalProp, test,
				headers);
		return resp;
	}

	public Response getSingleUserProfile(ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("userProfileURL");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("esk", globalProp.getProperty("UserProfileEsk"));
		headers.put("device_id", globalProp.getProperty("UserProfileDeviceId"));
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("Authorization", CSU.decrypt(globalProp.getProperty("AuthorizationToken")));
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("SINGLEUSERPROFILE"), globalProp,
				test, headers);
		return resp;
	}

	public Response getLastUsedUserProfile(ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("userProfileURL");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("esk", globalProp.getProperty("UserProfileEsk"));
		headers.put("device_id", globalProp.getProperty("UserProfileDeviceId"));
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("Authorization", CSU.decrypt(globalProp.getProperty("AuthorizationToken")));
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("LASTUSEDUSERPROFILE"), globalProp,
				test, headers);
		return resp;
	}

	public Response createDefaultUser(ExtentTest test, String requestBody) throws Exception {
		RestAssured.baseURI = executionParams.get("userProfileURL");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("esk", globalProp.getProperty("UserProfileEsk"));
		headers.put("device_id", globalProp.getProperty("UserProfileDeviceId"));
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("Authorization", CSU.decrypt(globalProp.getProperty("AuthorizationToken")));
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("CREATEDEFAULTUSER"), requestBody,
				globalProp, test, headers);
		return resp;
	}

	public Response createSingleUserProfile(ExtentTest test, String requestBody) throws Exception {
		RestAssured.baseURI = executionParams.get("userProfileURL");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("esk", globalProp.getProperty("UserProfileEsk"));
		headers.put("device_id", globalProp.getProperty("UserProfileDeviceId"));
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("Authorization", CSU.decrypt(globalProp.getProperty("AuthorizationToken")));
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("CREATESINGLEUSERPROFILE"),
				requestBody, globalProp, test, headers);
		return resp;
	}

	public Response updateSingleUserProfile(ExtentTest test, String requestBody) throws Exception {
		RestAssured.baseURI = executionParams.get("userProfileURL");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("esk", globalProp.getProperty("UserProfileEsk"));
		headers.put("device_id", globalProp.getProperty("UserProfileDeviceId"));
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("Authorization", CSU.decrypt(globalProp.getProperty("AuthorizationToken")));
		Response resp = resuableComponents.executePutAPI(EndPoints.endPointList.get("UPDATESINGLEPROFILE"), requestBody,
				globalProp, test, headers);
		return resp;
	}

	public Response updateLastUserProfile(ExtentTest test, String requestBody) throws Exception {
		RestAssured.baseURI = executionParams.get("userProfileURL");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("esk", globalProp.getProperty("UserProfileEsk"));
		headers.put("device_id", globalProp.getProperty("UserProfileDeviceId"));
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("Authorization", CSU.decrypt(globalProp.getProperty("AuthorizationToken")));
		Response resp = resuableComponents.executePutAPI(EndPoints.endPointList.get("UPDATELASTUSEDUSERPROFILE"),
				requestBody, globalProp, test, headers);
		return resp;
	}

	public Response getSingleUserDetails(ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("userProfileURL");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("esk", globalProp.getProperty("UserProfileEsk"));
		headers.put("device_id", globalProp.getProperty("UserProfileDeviceId"));
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("Authorization", CSU.decrypt(globalProp.getProperty("AuthorizationToken")));
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("SINGLEUSERDETAILS"), globalProp,
				test, headers);
		return resp;
	}

	public Response deleteUser(ExtentTest test) throws Exception {

		RestAssured.baseURI = executionParams.get("userProfileURL");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("esk", globalProp.getProperty("UserProfileEsk"));
		headers.put("device_id", globalProp.getProperty("UserProfileDeviceId"));
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("Authorization", CSU.decrypt(globalProp.getProperty("AuthorizationToken")));
		Response resp = resuableComponents.executeDeleteAPI(EndPoints.endPointList.get("DELETEUSER"), globalProp, test,
				headers);
		return resp;
	}

	public Response createDefaultProfile(ExtentTest test, String requestBody, String token) throws Exception {
		RestAssured.baseURI = globalProp.getProperty("profilesserviceuri");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("esk", globalProp.getProperty("UserToken_eskID"));
		headers.put("device_id", globalProp.getProperty("UserToken_deviceID"));
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("Authorization", "bearer " + token);
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("CREATEDEFAULTUSER"), requestBody,
				globalProp, test, headers);
		return resp;
	}

	public Response createSingleProfile(ExtentTest test, String requestBody, String token) throws Exception {
		RestAssured.baseURI = globalProp.getProperty("profilesserviceuri");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("esk", globalProp.getProperty("UserToken_eskID"));
		headers.put("device_id", globalProp.getProperty("UserToken_deviceID"));
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("Authorization", "bearer " + token);
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("CREATESINGLEUSERPROFILE"),
				requestBody, globalProp, test, headers);
		return resp;
	}

	public Response getAllUserProfile(ExtentTest test, String token) throws Exception {

		RestAssured.baseURI = globalProp.getProperty("profilesserviceuri");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("esk", globalProp.getProperty("UserToken_eskID"));
		headers.put("device_id", globalProp.getProperty("UserToken_deviceID"));
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("Authorization", "bearer " + token);
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("ALLUSERPROFILE"), globalProp, test,
				headers);
		return resp;
	}

	public Response updateSingleUserProfile(ExtentTest test, String requestBody, String token) throws Exception {
		RestAssured.baseURI = globalProp.getProperty("profilesserviceuri");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("esk", globalProp.getProperty("UserToken_eskID"));
		headers.put("device_id", globalProp.getProperty("UserToken_deviceID"));
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("Authorization", "bearer " + token);
		Response resp = resuableComponents.executePutAPI(EndPoints.endPointList.get("UPDATESINGLEPROFILE"), requestBody,
				globalProp, test, headers);
		return resp;
	}

	public Response getSingleProfile(ExtentTest test, String profileId, String token) throws Exception {
		RestAssured.baseURI = globalProp.getProperty("profilesserviceuri");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("esk", globalProp.getProperty("UserToken_eskID"));
		headers.put("device_id", globalProp.getProperty("UserToken_deviceID"));
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("Authorization", "bearer " + token);
		String endpt = EndPoints.endPointList.get("GETSINGLEPROFILE");
		endpt = endpt.replace("{profileId}", profileId);
		Response resp = resuableComponents.executeGetAPI(endpt, globalProp, test, headers);
		return resp;
	}

	public Response updateLastUsedProfile(ExtentTest test, String requestBody, String token) throws Exception {
		RestAssured.baseURI = globalProp.getProperty("profilesserviceuri");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("esk", globalProp.getProperty("UserToken_eskID"));
		headers.put("device_id", globalProp.getProperty("UserToken_deviceID"));
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("Authorization", "bearer " + token);
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("UPDATELASTUSEDUSERPROFILE"),
				requestBody, globalProp, test, headers);
		return resp;
	}

	public Response getLastUsedProfile(ExtentTest test, String token) throws Exception {
		RestAssured.baseURI = globalProp.getProperty("profilesserviceuri");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("esk", globalProp.getProperty("UserToken_eskID"));
		headers.put("device_id", globalProp.getProperty("UserToken_deviceID"));
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("Authorization", "bearer " + token);
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("UPDATELASTUSEDUSERPROFILE"),
				globalProp, test, headers);
		return resp;
	}

	public Response deleteProfile(ExtentTest test, String profileId, String token) throws Exception {
		RestAssured.baseURI = globalProp.getProperty("profilesserviceuri");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("esk", globalProp.getProperty("UserToken_eskID"));
		headers.put("device_id", globalProp.getProperty("UserToken_deviceID"));
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("Authorization", "bearer " + token);
		String endpt = EndPoints.endPointList.get("GETSINGLEPROFILE");
		endpt = endpt.replace("{profileId}", profileId);
		Response resp = resuableComponents.executeDeleteAPI(endpt, globalProp, test, headers);
		return resp;
	}

}
