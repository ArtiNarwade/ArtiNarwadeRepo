package BusinessComponents;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import com.EndPoints.EndPoints;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import baseTestPackage.BaseTest_TestNG;
import baseTestPackage.SuiteConstant;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import reusableLibrary.ResuableComponents;

public class US_SettingMSSQL_API extends BaseTest_TestNG {
	
	List<String> list = new ArrayList<String>();
	ResuableComponents resuableComponents = new ResuableComponents();
	
	public Response addUserSettingsPostCall(ExtentTest test, String requestBody, Hashtable<String, String> headers1) throws Exception {
		RestAssured.baseURI = executionParams.get("baseUserSettingMssqlURL");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.putAll(headers1);
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("ADDUSERSETTINGS"), requestBody,globalProp, test, headers);
		return resp;
	}
	
	public Response getUserSettingsGETCall(ExtentTest test,Hashtable<String, String> headers1) throws Exception {
		RestAssured.baseURI = executionParams.get("baseUserSettingMssqlURL");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.putAll(headers1);
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("GETUSERSETTINGS"),globalProp, test, headers);
		return resp;
	}

	public Response updateUserSettingPUTCall(ExtentTest test, String requestBody, Hashtable<String, String> headers1) throws Exception {
		RestAssured.baseURI = executionParams.get("baseUserSettingMssqlURL");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.putAll(headers1);
		Response resp = resuableComponents.executePutAPI(EndPoints.endPointList.get("UPDATEUSERSETTINGS"), requestBody, globalProp, test, headers);
		return resp;
	}
	
	public Response DeleteUserSettingDeleteCall(ExtentTest test, Hashtable<String, String> headers1) throws Exception {
		RestAssured.baseURI = executionParams.get("baseUserSettingMssqlURL");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.putAll(headers1);
		String endpoint = EndPoints.endPointList.get("DELETEUSERSETTINGS");
		endpoint = endpoint.replace("{keyName}", "Prema");
		Response resp = resuableComponents.executeDeleteAPI(endpoint,globalProp, test, headers);
		return resp;
	}
	
	public Response DeleteUserSettingDeleteCall(String settingsName, ExtentTest test, Hashtable<String, String> headers1) throws Exception {
		RestAssured.baseURI = executionParams.get("baseUserSettingMssqlURL");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.putAll(headers1);
		String endpoint = EndPoints.endPointList.get("DELETEUSERSETTINGS");
		endpoint = endpoint.replace("{keyName}", settingsName);
		Response resp = resuableComponents.executeDeleteAPI(endpoint,globalProp, test, headers);
		return resp;
	}
}
