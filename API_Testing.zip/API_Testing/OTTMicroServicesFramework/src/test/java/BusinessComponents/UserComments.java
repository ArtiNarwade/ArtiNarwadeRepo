
package BusinessComponents;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

import com.EndPoints.EndPoints;
import com.relevantcodes.extentreports.LogStatus;

import baseTestPackage.BaseTest_TestNG;
import baseTestPackage.SuiteConstant;
import io.restassured.response.Response;
import reusableLibrary.ResuableComponents;

public class UserComments extends BaseTest_TestNG {
	List<String> list = new ArrayList<String>();
	UM_UserToken usertoken = new UM_UserToken();
	public static String responsebody;
	SuiteConstant suiteMap = new SuiteConstant();
	ResuableComponents resuableComponents = new ResuableComponents();

	public Response postCreateCommentAndReply(String requestBody, Hashtable<String, String> headers) throws Exception {
		String endPoint = globalProp.getProperty("qa_baseUri") + EndPoints.endPointList.get("POSTCREATECMMNTANDREPLY");
		Response resp = resuableComponents.executePostAPI(endPoint, requestBody, globalProp, test, headers);
		;
		test.log(LogStatus.INFO, "<b>DataStore: </b>" + SuiteConstant.dataStore);
		return resp;
	}

	public Response getComments(String assetId, String page, String listType, Hashtable<String, String> headers)
			throws Exception {
		String endPoint = EndPoints.endPointList.get("GETCOMMENT");
		endPoint = endPoint.replace("{assetId}", assetId);
		endPoint = endPoint.replace("{page}", page);
		endPoint = endPoint.replace("{listType}", listType);
		Response resp = resuableComponents.executeGetAPI(globalProp.getProperty("qa_baseUri") + endPoint, globalProp,
				test, headers);
		test.log(LogStatus.INFO, "<b>DataStore: </b>" + SuiteConstant.dataStore);
		return resp;
	}

	public Response putUpdateComment(String requestBody, Hashtable<String, String> headers) throws Exception {
		String endPoint = EndPoints.endPointList.get("PUTUPDATECOMMENT");
		Response resp = resuableComponents.executePutAPI(globalProp.getProperty("qa_baseUri") + endPoint, requestBody,
				globalProp, test, headers);
		test.log(LogStatus.INFO, "<b>DataStore: </b>" + SuiteConstant.dataStore);
		return resp;
	}

	public Response deleteComment(String requestBody, Hashtable<String, String> headers) throws Exception {
		String endPoint = EndPoints.endPointList.get("DELETECOMMENT");
		Response resp = resuableComponents.executeDeleteAPI(globalProp.getProperty("qa_baseUri") + endPoint,
				requestBody, globalProp, test, headers);
		test.log(LogStatus.INFO, "<b>DataStore: </b>" + SuiteConstant.dataStore);
		return resp;
	}

	public Response postCreateReply(String requestBody, Hashtable<String, String> headers) throws Exception {
		String endPoint = EndPoints.endPointList.get("POSTCREATEREPLY");
		Response resp = resuableComponents.executePostAPI(globalProp.getProperty("qa_baseUri") + endPoint, requestBody,
				globalProp, test, headers);
		test.log(LogStatus.INFO, "<b>DataStore: </b>" + SuiteConstant.dataStore);
		return resp;
	}

	public Response getReply(String page, String assetId, String postNumber, Hashtable<String, String> headers)
			throws Exception {
		String endPoint = globalProp.getProperty("qa_baseUri") + EndPoints.endPointList.get("GETREPLY");
		endPoint = endPoint.replace("{page}", page);
		endPoint = endPoint.replace("{assetId}", assetId);
		endPoint = endPoint.replace("{postNumber}", postNumber);
		Response resp = resuableComponents.executeGetAPI(endPoint, globalProp, test, headers);
		;
		test.log(LogStatus.INFO, "<b>DataStore: </b>" + SuiteConstant.dataStore);
		return resp;
	}

	public Response putUpdateReply(String requestBody, Hashtable<String, String> headers) throws Exception {
		String endPoint = EndPoints.endPointList.get("PUTUPDATEREPLY");
		Response resp = resuableComponents.executePutAPI(globalProp.getProperty("qa_baseUri") + endPoint, requestBody,
				globalProp, test, headers);
		;
		test.log(LogStatus.INFO, "<b>DataStore: </b>" + SuiteConstant.dataStore);
		return resp;
	}

	public Response deleteReply(String requestBody, Hashtable<String, String> headers) throws Exception {
		String endPoint = EndPoints.endPointList.get("DELETEREPLY");
		Response resp = resuableComponents.executeDeleteAPI(globalProp.getProperty("qa_baseUri") + endPoint,
				requestBody, globalProp, test, headers);
		test.log(LogStatus.INFO, "<b>DataStore: </b>" + SuiteConstant.dataStore);
		return resp;
	}

	public Response postCreateLikeAction(String requestBody, Hashtable<String, String> headers) throws Exception {
		String endPoint = EndPoints.endPointList.get("POSTCREATELIKEACTIONS");
		Response resp = resuableComponents.executePostAPI(globalProp.getProperty("qa_baseUri") + endPoint, requestBody,
				globalProp, test, headers);
		test.log(LogStatus.INFO, "<b>DataStore: </b>" + SuiteConstant.dataStore);
		return resp;
	}

	public Response deleteLikeActions(String requestBody, Hashtable<String, String> headers) throws Exception {
		String endPoint = EndPoints.endPointList.get("DELETELIKEACTIONS");
		Response resp = resuableComponents.executeDeleteAPI(globalProp.getProperty("qa_baseUri") + endPoint,
				requestBody, globalProp, test, headers);
		test.log(LogStatus.INFO, "<b>DataStore: </b>" + SuiteConstant.dataStore);
		return resp;
	}
}
