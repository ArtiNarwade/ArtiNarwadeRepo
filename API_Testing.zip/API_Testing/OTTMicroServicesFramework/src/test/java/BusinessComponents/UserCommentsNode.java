package BusinessComponents;

import java.util.Hashtable;
import java.util.Random;

import com.EndPoints.EndPoints;
import com.amazonaws.partitions.model.Endpoint;
import com.relevantcodes.extentreports.ExtentTest;

import baseTestPackage.BaseTest_TestNG;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import reusableLibrary.JsonUtils;
import reusableLibrary.ResuableComponents;

public class UserCommentsNode extends BaseTest_TestNG{

	ResuableComponents resuableComponents = new ResuableComponents();
	UM_UserToken usertoken = new UM_UserToken();
	
	// GENERIC METHOD TO GENERATE TOKEN
			public JsonPath getUserToken(ExtentTest test) throws Exception 
			{
				String requestBody = JsonUtils.readPayloadJson("UM_Usertoken_UserComment.json");
				Response resp = usertoken.tokenGenreatePost(test, requestBody);
				System.out.print(resp);
				String responsebody = resp.getBody().asString();
				JsonPath jsonPath = resp.jsonPath();
				return jsonPath;

			}
	
	public Response createCommentReply(String reqBody,ExtentTest test) throws Exception {
		JsonPath tokenJsonPath = getUserToken(test);
		String token = tokenJsonPath.getString("token");
		RestAssured.baseURI = executionParams.get("userComments");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("x-access-token", CSU.decrypt(globalProp.getProperty("user_Access_token")));
		headers.put("Authorization", token);
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("createComment"),reqBody,
				globalProp,test,headers);
		return resp;
	}
	

	public Response getallComment(ExtentTest test) throws Exception {
		JsonPath tokenJsonPath = getUserToken(test);
		String token = tokenJsonPath.getString("token");
		RestAssured.baseURI = executionParams.get("userComments");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("x-access-token", CSU.decrypt(globalProp.getProperty("user_Access_token")));
		headers.put("Authorization", token);
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("getAllComment"),
				globalProp,test,headers);
		return resp;
	}
	
	public Response updateComment(String reqBody,ExtentTest test) throws Exception {
		JsonPath tokenJsonPath = getUserToken(test);
		String token = tokenJsonPath.getString("token");
		RestAssured.baseURI = executionParams.get("userComments");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("x-access-token", CSU.decrypt(globalProp.getProperty("user_Access_token")));
		headers.put("Authorization", token);
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.executePutAPI(EndPoints.endPointList.get("updateComment"), reqBody, globalProp,
				test, headers);
		return resp;
	}
	
	public Response deleteComment(String reqBody,ExtentTest test) throws Exception {
		JsonPath tokenJsonPath = getUserToken(test);
		String token = tokenJsonPath.getString("token");
		RestAssured.baseURI = executionParams.get("userComments");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("x-access-token", CSU.decrypt(globalProp.getProperty("user_Access_token")));
		headers.put("Authorization", token);
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.executeDeleteAPI(EndPoints.endPointList.get("deleteComment"),reqBody, globalProp,
				test, headers);
		return resp;
	}
	
	
	public Response createReply(String reqBody,ExtentTest test) throws Exception {
		JsonPath tokenJsonPath = getUserToken(test);
		String token = tokenJsonPath.getString("token");
		RestAssured.baseURI = executionParams.get("userComments");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("x-access-token", CSU.decrypt(globalProp.getProperty("user_Access_token")));
		headers.put("Authorization", token);
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("createReply"),reqBody,
				globalProp,test,headers);
		return resp;
	}
	

	public Response getReply(ExtentTest test) throws Exception {
		JsonPath tokenJsonPath = getUserToken(test);
		String token = tokenJsonPath.getString("token");
		RestAssured.baseURI = executionParams.get("userComments");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("x-access-token", CSU.decrypt(globalProp.getProperty("user_Access_token")));
		headers.put("Authorization", token);
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("getReply"),
				globalProp,test,headers);
		return resp;
	}
	
	public Response updateReply(String reqBody,ExtentTest test) throws Exception {
		JsonPath tokenJsonPath = getUserToken(test);
		String token = tokenJsonPath.getString("token");
		RestAssured.baseURI = executionParams.get("userComments");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("x-access-token", CSU.decrypt(globalProp.getProperty("user_Access_token")));
		headers.put("Authorization",token);
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.executePutAPI(EndPoints.endPointList.get("updateReply"), reqBody, globalProp,
				test, headers);
		return resp;
	}
	
	public Response deleteReply(String reqBody,ExtentTest test) throws Exception {
		JsonPath tokenJsonPath = getUserToken(test);
		String token = tokenJsonPath.getString("token");
		RestAssured.baseURI = executionParams.get("userComments");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("x-access-token", CSU.decrypt(globalProp.getProperty("user_Access_token")));
		headers.put("Authorization", token);
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.executeDeleteAPI(EndPoints.endPointList.get("deleteReply"),reqBody, globalProp,
				test, headers);
		return resp;
	}
	
	public Response createlikeAction(String reqBody,ExtentTest test)throws Exception{
		JsonPath tokenJsonPath = getUserToken(test);
		String token=tokenJsonPath.getString("token");
		RestAssured.baseURI=executionParams.get("userComments");
		Hashtable<String,String> headers= new Hashtable<String, String>();
		headers.put("x-access-token", CSU.decrypt(globalProp.getProperty("user_Access_token")));
		headers.put("Authorization", token);
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp=resuableComponents.executePostAPI(EndPoints.endPointList.get("createLikeAction"), reqBody,
				globalProp, test, headers);
		return resp;
		
	}
	public Response deletelikeAction(String reqBody,ExtentTest test)throws Exception{
		JsonPath tokenJsonPath = getUserToken(test);
		String token = tokenJsonPath.getString("token");
		RestAssured.baseURI=executionParams.get("userComments");
		Hashtable<String, String> headers=new Hashtable<String, String>();
		headers.put("x-access-token", CSU.decrypt(globalProp.getProperty("user_Access_token")));
		headers.put("Authorization", token);
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.executeDeleteAPI(EndPoints.endPointList.get("deleteLikeAction"), reqBody, 
				globalProp, test, headers);
		return resp;
	}	
	
	
	public int generateRandomNumber(int i,int j) {
		Random random= new Random();        
		return random.nextInt((j - i + 1)) + i;
	}
}
