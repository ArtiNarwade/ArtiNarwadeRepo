package BusinessComponents;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import com.EndPoints.EndPoints;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import baseTestPackage.BaseTest_TestNG;
import baseTestPackage.SuiteConstant;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import reusableLibrary.ResuableComponents;

public class UserConsent_API extends BaseTest_TestNG{
		
	List<String> list = new ArrayList<String>();
	ResuableComponents resuableComponents = new ResuableComponents();
	

	public  Response userRegistrationWithGoogleIDPostCall(ExtentTest test, String reqBody) throws Exception {
		RestAssured.baseURI = executionParams.get("userConsentbaseURI");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("Authorization", globalProp.getProperty("ConsentAuthorization"));
		headers.put("device_id", globalProp.getProperty("ConsentDeviceId"));
		headers.put("esk", globalProp.getProperty("ConsentEsk"));
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("CONSENTGOOGLEIDREGISTRATION"), reqBody, globalProp, test,headers);
		test.log(LogStatus.INFO, "<b>DataStore: </b>" + SuiteConstant.dataStore);
		return resp;			
	}
	
	public  Response userLoginWithGoogleIDPostCall(ExtentTest test, String reqBody) throws Exception {
		checkURL(executionParams.get("userConsentbaseURI"), test);
		RestAssured.baseURI = executionParams.get("userConsentbaseURI");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("Authorization", globalProp.getProperty("ConsentAuthorization"));
		headers.put("device_id", globalProp.getProperty("ConsentDeviceId"));
		headers.put("esk", globalProp.getProperty("ConsentEsk"));
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("CONSENTGOOGLEIDLOGIN"), reqBody, globalProp, test,headers);
		test.log(LogStatus.INFO, "<b>DataStore: </b>" + SuiteConstant.dataStore);
		return resp;			
	}
	
	public Response deleteUserGoogleId(ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("userConsentbaseURI");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("Authorization", globalProp.getProperty("ConsentAuthorization"));
		headers.put("device_id", globalProp.getProperty("ConsentDeviceId"));
		headers.put("esk", globalProp.getProperty("ConsentEsk"));
		Response resp = resuableComponents.executeDeleteAPI(EndPoints.endPointList.get("CONSENTDELETEGOOGLEID"),globalProp, test, headers);
		return resp;
	}
	
	public  Response userRegistrationWithTwitterIDV1PostCall(ExtentTest test, String reqBody) throws Exception {
		RestAssured.baseURI = executionParams.get("userConsentbaseURI");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("Authorization", globalProp.getProperty("ConsentAuthorization"));
		headers.put("device_id", globalProp.getProperty("ConsentDeviceId"));
		headers.put("esk", globalProp.getProperty("ConsentEsk"));
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("CONSENTV1TWITTERIDREGISTRATION"), reqBody, globalProp, test,headers);
		test.log(LogStatus.INFO, "<b>DataStore: </b>" + SuiteConstant.dataStore);
		return resp;			
	}
	public  Response userRegistrationWithTwitterIDV2PostCall(ExtentTest test, String reqBody) throws Exception {
		RestAssured.baseURI = executionParams.get("userConsentbaseURI");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("Authorization", globalProp.getProperty("ConsentAuthorization"));
		headers.put("device_id", globalProp.getProperty("ConsentDeviceId"));
		headers.put("esk", globalProp.getProperty("ConsentEsk"));
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("CONSENTV2TWITTERIDREGISTRATION"), reqBody, globalProp, test,headers);
		test.log(LogStatus.INFO, "<b>DataStore: </b>" + SuiteConstant.dataStore);
		return resp;			
	}
	public  Response userRegistrationWithTwitterIDV3PostCall(ExtentTest test, String reqBody) throws Exception {
		RestAssured.baseURI = executionParams.get("userConsentbaseURI");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("Authorization", globalProp.getProperty("ConsentAuthorization"));
		headers.put("device_id", globalProp.getProperty("ConsentDeviceId"));
		headers.put("esk", globalProp.getProperty("ConsentEsk"));
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("CONSENTV3TWITTERIDREGISTRATION"), reqBody, globalProp, test,headers);
		test.log(LogStatus.INFO, "<b>DataStore: </b>" + SuiteConstant.dataStore);
		return resp;			
	}
	public  Response existingUserWithTwitterIDV3PostCall(ExtentTest test, String reqBody) throws Exception {
		RestAssured.baseURI = executionParams.get("userConsentbaseURI");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("Authorization", globalProp.getProperty("ConsentAuthorization"));
		headers.put("device_id", globalProp.getProperty("ConsentDeviceId"));
		headers.put("esk", globalProp.getProperty("ConsentEsk"));
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("CONSENTV3TWITTERIDAVAILABLE"), reqBody, globalProp, test,headers);
		test.log(LogStatus.INFO, "<b>DataStore: </b>" + SuiteConstant.dataStore);
		return resp;			
	}
	public  Response userRegistrationWithFacebookIDV1PostCall(ExtentTest test, String reqBody) throws Exception {
		RestAssured.baseURI = executionParams.get("userConsentbaseURI");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("Authorization", globalProp.getProperty("ConsentAuthorization"));
		headers.put("device_id", globalProp.getProperty("ConsentDeviceId"));
		headers.put("esk", globalProp.getProperty("ConsentEsk"));
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("CONSENTV1FACEBOOKIDREGISTRATION"), reqBody, globalProp, test,headers);
		test.log(LogStatus.INFO, "<b>DataStore: </b>" + SuiteConstant.dataStore);
		return resp;			
	}
	public  Response userRegistrationWithFacebookIDV2PostCall(ExtentTest test, String reqBody) throws Exception {
		RestAssured.baseURI = executionParams.get("userConsentbaseURI");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("Authorization", globalProp.getProperty("ConsentAuthorization"));
		headers.put("device_id", globalProp.getProperty("ConsentDeviceId"));
		headers.put("esk", globalProp.getProperty("ConsentEsk"));
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("CONSENTV2FACEBOOKIDREGISTRATION"), reqBody, globalProp, test,headers);
		test.log(LogStatus.INFO, "<b>DataStore: </b>" + SuiteConstant.dataStore);
		return resp;			
	}
	public  Response userRegistrationWithFacebookIDV3PostCall(ExtentTest test, String reqBody) throws Exception {
		RestAssured.baseURI = executionParams.get("userConsentbaseURI");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("Authorization", globalProp.getProperty("ConsentAuthorization"));
		headers.put("device_id", globalProp.getProperty("ConsentDeviceId"));
		headers.put("esk", globalProp.getProperty("ConsentEsk"));
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("CONSENTV3FACEBOOKIDREGISTRATION"), reqBody, globalProp, test,headers);
	//	test.log(LogStatus.INFO, "<b>DataStore: </b>" + SuiteConstant.dataStore);
		return resp;			
	}
	
	public  Response userLoginWithTwitterV2IDPostCall(ExtentTest test, String reqBody) throws Exception {
		RestAssured.baseURI = executionParams.get("userConsentbaseURI");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("Authorization", globalProp.getProperty("ConsentAuthorization"));
		headers.put("device_id", globalProp.getProperty("ConsentDeviceId"));
		headers.put("esk", globalProp.getProperty("ConsentEsk"));
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("CONSENTTWITTERV2IDLOGIN"), reqBody, globalProp, test,headers);
	//	test.log(LogStatus.INFO, "<b>DataStore: </b>" + SuiteConstant.dataStore);
		return resp;			
	}
	public  Response userLoginWithFacebookV2IDPostCall(ExtentTest test, String reqBody) throws Exception {
		RestAssured.baseURI = executionParams.get("userConsentbaseURI");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("Authorization", globalProp.getProperty("ConsentAuthorization"));
		headers.put("device_id", globalProp.getProperty("ConsentDeviceId"));
		headers.put("esk", globalProp.getProperty("ConsentEsk"));
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("CONSENTFACEBOOKV2IDLOGIN"), reqBody, globalProp, test,headers);
		test.log(LogStatus.INFO, "<b>DataStore: </b>" + SuiteConstant.dataStore);
		return resp;			
	}
	public  Response authenticationUserWithEmailPostCall(ExtentTest test, String reqBody) throws Exception {
		RestAssured.baseURI = executionParams.get("userConsentbaseURI");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("Authorization", globalProp.getProperty("ConsentAuthorization"));
		headers.put("device_id", globalProp.getProperty("ConsentDeviceId"));
		headers.put("esk", globalProp.getProperty("ConsentEsk"));
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("CONSENTEMAILAUTHORIZATION"), reqBody, globalProp, test,headers);
	//	test.log(LogStatus.INFO, "<b>DataStore: </b>" + SuiteConstant.dataStore);
		return resp;			
	}
	
	public  Response authenticationUserWithMobileNumberPostCall(ExtentTest test, String reqBody) throws Exception {
		RestAssured.baseURI = executionParams.get("userConsentbaseURI");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("Authorization", globalProp.getProperty("ConsentAuthorization"));
		headers.put("device_id", globalProp.getProperty("ConsentDeviceId"));
		headers.put("esk", globalProp.getProperty("ConsentEsk"));
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("CONSENTEMOBILENUMBERAUTHORIZATION"), reqBody, globalProp, test,headers);
		test.log(LogStatus.INFO, "<b>DataStore: </b>" + SuiteConstant.dataStore);
		return resp;			
	}
	public  Response UpdateUserConsentPutCall(ExtentTest test, String reqBody) throws Exception {
		RestAssured.baseURI = executionParams.get("userConsentbaseURI");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("Authorization", globalProp.getProperty("ConsentAuthorization"));
		headers.put("device_id", globalProp.getProperty("ConsentDeviceId"));
		headers.put("esk", globalProp.getProperty("ConsentEsk"));
		Response resp = resuableComponents.executePutAPI(EndPoints.endPointList.get("UPDATEUSERCONSENT"), reqBody, globalProp, test,headers);
		//test.log(LogStatus.INFO, "<b>DataStore: </b>" + SuiteConstant.dataStore);
		return resp;			
	}
	
	//Need to verify and update URL
	public  Response GetUserConsentGetCall(ExtentTest test,String reqBody) throws Exception {
		checkURL("userConsentbaseURI1", test);
		RestAssured.baseURI = executionParams.get("userConsentbaseURI1");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("Cookie", CSU.decrypt(globalProp.getProperty("ConsentCookie")));
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("GETUSERCONSENT"), globalProp, test,headers);
		//test.log(LogStatus.INFO, "<b>DataStore: </b>" + SuiteConstant.dataStore);
		return resp;			
	}
	public  Response userRegistrationAsGuestPostCall(ExtentTest test, String reqBody) throws Exception {
		 
		RestAssured.baseURI = executionParams.get("userConsentbaseURI");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("device_id", globalProp.getProperty("ConsentDeviceId"));
		headers.put("esk", globalProp.getProperty("ConsentEsk"));
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("CONSENTGUESTUSERREGISTRATION"), reqBody, globalProp, test,headers);
		//test.log(LogStatus.INFO, "<b>DataStore: </b>" + SuiteConstant.dataStore);
		return resp;			
	}
	public  Response OtpSentToMailPostCall(ExtentTest test, String reqBody) throws Exception {
		
		RestAssured.baseURI = executionParams.get("userConsentbaseURI");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("device_id", globalProp.getProperty("ConsentDeviceId"));
		headers.put("esk", globalProp.getProperty("ConsentEsk"));
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("CONSENTOTPTOMAIL"), reqBody, globalProp, test,headers);
	//	test.log(LogStatus.INFO, "<b>DataStore: </b>" + SuiteConstant.dataStore);
		return resp;			
	}
	public  Response OtpVerificationWithMailPostCall(ExtentTest test, String reqBody) throws Exception {
		RestAssured.baseURI = executionParams.get("userConsentbaseURI");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("device_id", globalProp.getProperty("ConsentDeviceId"));
		headers.put("esk", globalProp.getProperty("ConsentEsk"));
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("CONSENTOTPVERIFICATIONWITHMAIL"), reqBody, globalProp, test,headers);
		test.log(LogStatus.INFO, "<b>DataStore: </b>" + SuiteConstant.dataStore);
		return resp;			
	}
	public  Response OtpRegisterPostCall(ExtentTest test, String reqBody) throws Exception {
		RestAssured.baseURI = executionParams.get("userConsentbaseURI");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("device_id", globalProp.getProperty("ConsentDeviceId"));
		headers.put("esk", globalProp.getProperty("ConsentEsk"));
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("CONSENTOTPREGISTER"), reqBody, globalProp, test,headers);
		test.log(LogStatus.INFO, "<b>DataStore: </b>" + SuiteConstant.dataStore);
		return resp;			
	}
	}



	

