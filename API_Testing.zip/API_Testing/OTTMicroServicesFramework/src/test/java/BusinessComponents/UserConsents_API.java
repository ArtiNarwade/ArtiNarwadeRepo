package BusinessComponents;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

import com.EndPoints.EndPoints;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import baseTestPackage.BaseTest_TestNG;
import baseTestPackage.SuiteConstant;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import reusableLibrary.JsonUtils;
import reusableLibrary.ResuableComponents;

public class UserConsents_API extends BaseTest_TestNG{

	List<String> list = new ArrayList<String>();
	SuiteConstant suiteMap = new SuiteConstant();
	ResuableComponents resuableComponents = new ResuableComponents();

	
	public Response addConsentUsingPostCall(ExtentTest test, String requestBody) throws Exception {
		RestAssured.baseURI = executionParams.get("baseURIUserConsent");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		//headers.put("Cookie", globalProp.getProperty("UserConsentCookie"));
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("USERCONSENTADDCONSENT"), requestBody,globalProp, test, headers);
		return resp;
	}
	public Response updateConsentUsingPostCall(ExtentTest test, String requestBody) throws Exception {
		RestAssured.baseURI = executionParams.get("baseURIUserConsent");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		//headers.put("Cookie", globalProp.getProperty("UserConsentCookie"));
		Response resp = resuableComponents.executePutAPI(EndPoints.endPointList.get("USERCONSENTUPDATECONSENT"), requestBody,globalProp, test, headers);
		return resp;
	}
	
	public Response getConsentUsingPostCall(ExtentTest test)
	 {
		 	RestAssured.baseURI = executionParams.get("baseURIUserConsent");
			Hashtable<String, String> headers = new Hashtable<String, String>();
			headers.put("Content-Type", globalProp.getProperty("contentType"));
			//headers.put("Cookie", globalProp.getProperty("UserConsentCookie"));
			Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("USERCONSENTGETCONSENT"),globalProp, test, headers);
			return resp;
	 } 
}
