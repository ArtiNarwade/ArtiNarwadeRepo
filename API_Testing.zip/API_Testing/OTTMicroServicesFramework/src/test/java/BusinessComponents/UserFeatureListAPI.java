package BusinessComponents;

import java.util.Hashtable;

import com.EndPoints.EndPoints;
import com.relevantcodes.extentreports.ExtentTest;

import baseTestPackage.BaseTest_TestNG;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import reusableLibrary.JsonUtils;
import reusableLibrary.ResuableComponents;

public class UserFeatureListAPI extends BaseTest_TestNG{

	ResuableComponents resuableComponents = new ResuableComponents();
	UM_UserToken usertoken=new UM_UserToken();
	public static String responsebody;
	
	// GENERIC METHOD TO GENERATE TOKEN
	public JsonPath getUserToken(ExtentTest test) throws Exception {
				String requestBody = JsonUtils.readPayloadJson("UMTokenGenerate.json");
				Response resp = usertoken.tokenGenreatePost(test, requestBody);
				 responsebody = resp.getBody().jsonPath().get("token").toString();
				System.out.println(responsebody);
				JsonPath jsonPath = resp.jsonPath();
				return jsonPath;
	}
			
	public Response GetUserFeatureHealth(ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("userfeatureURI");
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("USERFEATUREHEALTH_userfeature"),
				globalProp,test);
		return resp;
	}
	
	public Response GetUserFeatureList(ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("userfeatureURI");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("x-access-token", CSU.decrypt(globalProp.getProperty("getfeature_x-access-token")));
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("GETFEATURELIST_userfeature"),
				globalProp,test,headers);
		return resp;
	}
	
	public Response UpdateFeatureList(ExtentTest test) throws Exception {
		JsonPath tokenJsonPath = getUserToken(test);
		String token = tokenJsonPath.getString("token");
		RestAssured.baseURI = executionParams.get("userfeatureURI");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Authorization","bearer " + token);
		Response resp = resuableComponents.executePutAPI(EndPoints.endPointList.get("UPDATEFEATURE_userfeature"),
				globalProp,test,headers);
		return resp;
	}
	
	public Response UpdateAllFeatureList(ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("userfeatureURI");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("x-access-token", CSU.decrypt(globalProp.getProperty("getfeature_x-access-token")));
		Response resp = resuableComponents.executePutAPI(EndPoints.endPointList.get("UPDATEALLFEATURE_userfeature"),
				globalProp,test,headers);
		return resp;
	}
	
	public Response DeleteFeatureList(ExtentTest test) throws Exception {
		JsonPath tokenJsonPath = getUserToken(test);
		String token = tokenJsonPath.getString("token");
		RestAssured.baseURI = executionParams.get("userfeatureURI");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Authorization","bearer " + token);
		headers.put("x-access-token", CSU.decrypt(globalProp.getProperty("getfeature_x-access-token")));
		Response resp = resuableComponents.executePutAPI(EndPoints.endPointList.get("DELETEFEATURE_userfeature"),
				globalProp,test,headers);
		return resp;
	}
}
