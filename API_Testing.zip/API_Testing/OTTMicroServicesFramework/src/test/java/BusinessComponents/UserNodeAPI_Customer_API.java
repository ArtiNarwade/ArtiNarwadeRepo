package BusinessComponents;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

import baseTestPackage.BaseTest_TestNG;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import reusableLibrary.ResuableComponents;

import com.EndPoints.EndPoints;
import com.relevantcodes.extentreports.ExtentTest;

public class UserNodeAPI_Customer_API extends BaseTest_TestNG 
{

	ResuableComponents resuableComponents = new ResuableComponents();
	List<String> list = new ArrayList<String>();
	
	public Response GETCRMTOKEN_POST(ExtentTest test,String requestBody)
	{
		RestAssured.baseURI = executionParams.get("baseuriusernode");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("device_id", globalProp.getProperty("UserToken_deviceID"));
		headers.put("esk",globalProp.getProperty("UserToken_eskID"));
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("GETCRMTOKEN"), requestBody,globalProp, test, headers);
		return resp;
	}
	
	public Response TOKENREFRESHUSERID_GET(ExtentTest test,String endpoint,String auth)
	{
		RestAssured.baseURI = executionParams.get("baseuriusernode");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("device_id", globalProp.getProperty("UserToken_deviceID"));
		headers.put("esk",globalProp.getProperty("UserToken_eskID"));
		headers.put("Authorization", auth);
		Response resp = resuableComponents.executeGetAPI(endpoint,globalProp, test, headers);
		return resp;
	}
	
	public Response CUSTOMEREMAIL_POST(ExtentTest test,String endpoint, String requestBody,String auth)
	{
		RestAssured.baseURI = executionParams.get("baseuriusernode");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("device_id", globalProp.getProperty("UserToken_deviceID"));
		headers.put("esk",globalProp.getProperty("UserToken_eskID"));
		headers.put("Authorization", auth);
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("CUSTOMEREMAIL"), requestBody,globalProp, test, headers);
		return resp;
	}
	public Response CUSTOMERMOBILE_POST(ExtentTest test,String endpoint, String requestBody,String auth)
	{
		RestAssured.baseURI = executionParams.get("baseuriusernode");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("device_id", globalProp.getProperty("UserToken_deviceID"));
		headers.put("esk",globalProp.getProperty("UserToken_eskID"));
		headers.put("Authorization", auth);
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("CUSTOMERMOBILE"), requestBody,globalProp, test, headers);
		return resp;
	}
	
	
	
	
}
