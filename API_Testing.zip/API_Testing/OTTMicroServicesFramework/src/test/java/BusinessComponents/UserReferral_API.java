package BusinessComponents;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Test;

import com.EndPoints.EndPoints;
import baseTestPackage.BaseTest_TestNG;
import baseTestPackage.SuiteConstant;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import reusableLibrary.ResuableComponents;
import com.relevantcodes.extentreports.ExtentTest;


public class UserReferral_API extends BaseTest_TestNG {
	
	List<String> list = new ArrayList<String>();
	ResuableComponents resuableComponents = new ResuableComponents();
	
	public Response ReferralLinkPostCall(ExtentTest test, String requestBody, Hashtable<String, String> headers1) throws Exception {
		RestAssured.baseURI = executionParams.get("baseuserreferralurl");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("device_id",globalProp.getProperty("UserToken_deviceID"));
		headers.put("esk",globalProp.getProperty("UserToken_eskID"));
		headers.putAll(headers1);
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("REFERRALLINK"), requestBody,globalProp, test, headers);
		return resp;
	}
	
	
	public Response ShareLinkGETCall(ExtentTest test,Hashtable<String, String> headers1) throws Exception {
		RestAssured.baseURI = executionParams.get("baseuserreferralurl");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("device_id",globalProp.getProperty("UserToken_deviceID"));
		headers.put("esk",globalProp.getProperty("UserToken_eskID"));
		headers.putAll(headers1);
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("REFERRALSHARELINK"), globalProp, test,headers);
		return resp;
	}
	
	
	public Response deepLinkDetailsPostCall(String requestBody, ExtentTest test, Hashtable<String, String> headers1) throws Exception {
		RestAssured.baseURI = executionParams.get("baseuserreferralurl");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("device_id",globalProp.getProperty("UserToken_deviceID"));
		headers.put("esk",globalProp.getProperty("UserToken_eskID"));
		headers.putAll(headers1);
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("REFERRALDEEPLINKDETAILS"), requestBody,globalProp, test, headers);
		return resp;
	}

	public Response ReferralRewardGETCall(ExtentTest test,Hashtable<String, String> headers1) throws Exception {
		RestAssured.baseURI = executionParams.get("baseuserreferralurl");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("device_id",globalProp.getProperty("UserToken_deviceID"));
		headers.put("esk",globalProp.getProperty("UserToken_eskID"));
		headers.putAll(headers1);
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("REFERRALREWARD"), globalProp, test,headers);
		return resp;
	}
	
	public Response ValidateCodePostCall(String requestBody, ExtentTest test, Hashtable<String, String> headers1) throws Exception {
		RestAssured.baseURI = executionParams.get("baseuserreferralurl");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("device_id",globalProp.getProperty("UserToken_deviceID"));
		headers.put("esk",globalProp.getProperty("UserToken_eskID"));
		headers.putAll(headers1);
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("REFERRALVALIDATECODE"), requestBody,globalProp, test, headers);
		return resp;
	}
	
	public Response RegDiscountPostCall(String requestBody, ExtentTest test, Hashtable<String, String> headers1) throws Exception {
		RestAssured.baseURI = executionParams.get("baseuserreferralurl");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("device_id",globalProp.getProperty("UserToken_deviceID"));
		headers.put("esk",globalProp.getProperty("UserToken_eskID"));
		headers.putAll(headers1);
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("REFERRALREGDISCOUNT"), requestBody,globalProp, test, headers);
		return resp;
	}
	
	public Response RegDiscount_LinkDetailsGETCall(ExtentTest test,Hashtable<String, String> headers1) throws Exception {
		RestAssured.baseURI = executionParams.get("baseuserreferralurl");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("device_id",globalProp.getProperty("UserToken_deviceID"));
		headers.put("esk",globalProp.getProperty("UserToken_eskID"));
		headers.putAll(headers1);
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("REFERRALREGDISCOUNTLINKDETAILS"), globalProp, test,headers);
		return resp;
	}
	

}
