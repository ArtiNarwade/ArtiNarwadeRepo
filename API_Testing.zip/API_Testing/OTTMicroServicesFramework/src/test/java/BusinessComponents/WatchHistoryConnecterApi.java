package BusinessComponents;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

import org.apache.tools.ant.types.Description;

import com.EndPoints.EndPoints;
import com.relevantcodes.extentreports.ExtentTest;

import baseTestPackage.BaseTest_TestNG;
import baseTestPackage.SuiteConstant;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import reusableLibrary.ResuableComponents;

public class WatchHistoryConnecterApi extends BaseTest_TestNG {

	List<String> list = new ArrayList<String>();
	SuiteConstant suiteMap = new SuiteConstant();
	ResuableComponents resuableComponents = new ResuableComponents();

	public Response updatewatchhistory(String requestBody, ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("baseURIWatchHistory");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("X-ACCESS-TOKEN", CSU.decrypt(globalProp.getProperty("X-ACCESS-TOKEN")));
		headers.put("Authorization", CSU.decrypt(globalProp.getProperty("WatchHistoryToken")));
		Response resp = resuableComponents.executePutAPI(EndPoints.endPointList.get("UpdateWatchHistory"), requestBody,
				globalProp, test, headers);
		int statusCode = resp.getStatusCode();
		return resp;
	}

	public Response getDeleteAPICall(ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("baseURIWatchHistory");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("X-ACCESS-TOKEN", CSU.decrypt(globalProp.getProperty("X-ACCESS-TOKEN")));
		headers.put("Authorization", CSU.decrypt(globalProp.getProperty("WatchHistoryToken")));
		Response resp = resuableComponents.executeDeleteAPI(EndPoints.endPointList.get("DeleteWatchHistory"),
				globalProp, test, headers);
		int statusCode = resp.getStatusCode();
		return resp;
	}

	public Response getWatch() throws Exception {
		RestAssured.baseURI = executionParams.get("baseURIWatchHistory");
		;
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("X-ACCESS-TOKEN", CSU.decrypt(globalProp.getProperty("X-ACCESS-TOKEN")));
		headers.put("Authorization", CSU.decrypt(globalProp.getProperty("WatchHistoryToken")));
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("WATCHSTATUS"), globalProp, test,
				headers);
		int statusCode = resp.getStatusCode();
		return resp;
	}

	public Response getWatch(ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("baseURIWatchHistory");
		;
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("X-ACCESS-TOKEN", CSU.decrypt(globalProp.getProperty("X-ACCESS-TOKEN")));
		headers.put("Authorization", CSU.decrypt(globalProp.getProperty("WatchHistoryToken")));
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("WATCHSTATUS"), globalProp, test,
				headers);
		int statusCode = resp.getStatusCode();
		return resp;
	}

	public Response getContinueWatching(ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("baseURIWatchHistory");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("X-ACCESS-TOKEN", CSU.decrypt(globalProp.getProperty("X-ACCESS-TOKEN")));
		headers.put("Authorization", CSU.decrypt(globalProp.getProperty("WatchHistoryToken")));
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("CONTINUEWATCH"), globalProp, test,
				headers);
		int statusCode = resp.getStatusCode();
		return resp;
	}

	public Response getConcurrentUserSession(ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("baseURIWatchHistory");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("X-ACCESS-TOKEN", CSU.decrypt(globalProp.getProperty("X-ACCESS-TOKEN")));
		headers.put("Authorization", CSU.decrypt(globalProp.getProperty("WatchHistoryToken")));
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("CONCURRENTUSERSESSION"),
				globalProp, test, headers);
		int statusCode = resp.getStatusCode();
		return resp;
	}

	public Response getConcurrentUserSession() throws Exception {
		RestAssured.baseURI = executionParams.get("baseURIWatchHistory");
		;
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("X-ACCESS-TOKEN", CSU.decrypt(globalProp.getProperty("X-ACCESS-TOKEN")));
		headers.put("Authorization", CSU.decrypt(globalProp.getProperty("WatchHistoryToken")));
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("CONCURRENTUSERSESSION"),
				globalProp, test, headers);
		int statusCode = resp.getStatusCode();
		return resp;
	}
}
