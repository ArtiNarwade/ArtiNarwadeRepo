package BusinessComponents;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import com.EndPoints.EndPoints;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import baseTestPackage.BaseTest_TestNG;
import baseTestPackage.SuiteConstant;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import reusableLibrary.ResuableComponents;

public class WatchlistUserActivity extends BaseTest_TestNG{
		
		List<String> list = new ArrayList<String>();
		ResuableComponents resuableComponents = new ResuableComponents();
		
			public Response addUserActivityV1UsingPostCall(ExtentTest test, String requestBody, Hashtable<String, String> headers1) throws Exception {
				RestAssured.baseURI = executionParams.get("WatchlistUserActivityUrl");
				Hashtable<String, String> headers = new Hashtable<String, String>();
				headers.put("Content-Type", globalProp.getProperty("WatchlistUesrActivityContentType"));
				headers.putAll(headers1);
				Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("WATCHLISTUSERACTIVITYADDACTIVITY"), requestBody,globalProp, test, headers);
				return resp;
			}
			public Response getUserActivityV1UsingGetCall(ExtentTest test,Hashtable<String, String> headers1) throws Exception{ 
				RestAssured.baseURI = executionParams.get("WatchlistUserActivityUrl");
				Hashtable<String, String> headers = new Hashtable<String, String>();
				headers.put("device_id", globalProp.getProperty("WatchlistUesrActivityDeviceId"));
				headers.put("esk", globalProp.getProperty("WatchlistUesrActivityEsk"));
				headers.put("user_id", globalProp.getProperty("WatchlistUesrActivityUserId"));
				headers.put("profile_id", globalProp.getProperty("WatchlistUesrActivityProfileId"));
				headers.putAll(headers1);
				Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("WATCHLISTUSERACTIVITYGETACTIVITY"),globalProp, test, headers);
				return resp;			
			}
			public Response deleteUserActivityV1UsingDeleteCall(ExtentTest test, Hashtable<String, String> headers1) throws Exception {
				RestAssured.baseURI = executionParams.get("WatchlistUserActivityUrl");
				Hashtable<String, String> headers = new Hashtable<String, String>();
				headers.put("device_id", globalProp.getProperty("WatchlistUesrActivityDeviceId"));
				headers.put("esk", globalProp.getProperty("WatchlistUesrActivityEsk"));
				headers.put("user_id", globalProp.getProperty("WatchlistUesrActivityUserId"));
				headers.put("profile_id", globalProp.getProperty("WatchlistUesrActivityProfileId"));
				headers.putAll(headers1);
				Response resp = resuableComponents.executeDeleteAPI(EndPoints.endPointList.get("WATCHLISTUSERACTIVITYDELETEACTIVITY"),globalProp, test, headers);
				return resp;
			}
			public Response toggleUserActivityV1UsingPostCall(ExtentTest test, String requestBody, Hashtable<String, String> headers1) throws Exception {
				RestAssured.baseURI = executionParams.get("WatchlistUserActivityUrl");
				Hashtable<String, String> headers = new Hashtable<String, String>();
				headers.put("Content-Type", globalProp.getProperty("WatchlistUesrActivityContentType"));
				headers.put("device_id", globalProp.getProperty("WatchlistUesrActivityDeviceId"));
				headers.put("esk", globalProp.getProperty("WatchlistUesrActivityEsk"));
				headers.putAll(headers1);
				Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("WATCHLISTUSERACTIVITYTOGGLEACTIVITY"), requestBody,globalProp, test, headers);
				return resp;
			}
}
		