package BusinessComponents;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import com.EndPoints.EndPoints;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import baseTestPackage.BaseTest_TestNG;
import baseTestPackage.SuiteConstant;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import reusableLibrary.ResuableComponents;

public class WatchlistUserAgregator extends BaseTest_TestNG{
		
		List<String> list = new ArrayList<String>();
		ResuableComponents resuableComponents = new ResuableComponents();
		
			public Response addUserWatchlistAgregatorV1UsingPostCall(ExtentTest test, String requestBody, Hashtable<String, String> headers1) throws Exception {
				RestAssured.baseURI = executionParams.get("WatchlistUserAgregatorUrl");
				Hashtable<String, String> headers = new Hashtable<String, String>();
				headers.put("Content-Type", globalProp.getProperty("WatchlistUesrAgregatorContentType"));
				headers.putAll(headers1);
				Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("WATCHLISTUSERAGREGATORADDAGREGATOR"), requestBody,globalProp, test, headers);
				return resp;
			}
			public Response getUserWatchlistAgregatorV1UsingGetCall(ExtentTest test,Hashtable<String, String> headers1) throws Exception{ 
				RestAssured.baseURI = executionParams.get("WatchlistUserAgregatorUrl");
				Hashtable<String, String> headers = new Hashtable<String, String>();
				headers.put("device_id", globalProp.getProperty("WatchlistUesrAgregatorDeviceId"));
				headers.put("esk", globalProp.getProperty("WatchlistUesrAgregatorEsk"));
				headers.putAll(headers1);
				Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("WATCHLISTUSERAGREGATORGETAGREGATORV1"),globalProp, test, headers);
				return resp;			
			}
			public Response getUserWatchlistAgregatorV2UsingGetCall(ExtentTest test,Hashtable<String, String> headers1) throws Exception{ 
				RestAssured.baseURI = executionParams.get("WatchlistUserAgregatorUrl");
				Hashtable<String, String> headers = new Hashtable<String, String>();
				headers.put("profile_id", globalProp.getProperty("WatchlistUesrAgregatorProfileId"));
				headers.putAll(headers1);
				Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("WATCHLISTUSERAGREGATORGETAGREGATORV2"),globalProp, test, headers);
				return resp;			
			}
			public Response deleteUserWatchlistAgregatorV1UsingDeleteCall(ExtentTest test, Hashtable<String, String> headers1) throws Exception {
				RestAssured.baseURI = executionParams.get("WatchlistUserAgregatorUrl");
				Hashtable<String, String> headers = new Hashtable<String, String>();
				headers.put("device_id", globalProp.getProperty("WatchlistUesrAgregatorDeviceId"));
				headers.put("esk", globalProp.getProperty("WatchlistUesrAgregatorEsk"));
				headers.putAll(headers1);
				Response resp = resuableComponents.executeDeleteAPI(EndPoints.endPointList.get("WATCHLISTUSERAGREGATORDELETEAGREGATOR"),globalProp, test, headers);
				return resp;
			}

}
		