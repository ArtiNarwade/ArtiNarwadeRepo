package BusinessComponents;

import java.util.Hashtable;

import com.EndPoints.EndPoints;
import com.relevantcodes.extentreports.ExtentTest;

import baseTestPackage.BaseTest_TestNG;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import reusableLibrary.ResuableComponents;

public class Zas_Connect extends BaseTest_TestNG {
	
	ResuableComponents resuableComponents = new ResuableComponents();
	
	public Response getZasConnectDetails(ExtentTest test) throws Exception {
 		RestAssured.baseURI = executionParams.get("Zas_Connect");
 		Hashtable<String, String> headers = new Hashtable<String, String>();
 		headers.put("true-client-ip", globalProp.getProperty("true-client-ip"));
 		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("ZAS_CONNECT"), globalProp, test,headers);
 		System.out.println(resp.asString());
 		
 		return resp;
 	}

}
