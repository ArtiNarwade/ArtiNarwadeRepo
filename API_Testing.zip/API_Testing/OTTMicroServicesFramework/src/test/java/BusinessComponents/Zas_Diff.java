package BusinessComponents;

import java.util.Hashtable;

import com.EndPoints.EndPoints;
import com.relevantcodes.extentreports.ExtentTest;

import baseTestPackage.BaseTest_TestNG;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import reusableLibrary.ResuableComponents;

public class Zas_Diff extends BaseTest_TestNG{
	
	ResuableComponents resuableComponents = new ResuableComponents();
	
	public Response createReloadRadis(ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("Zas_Diff");
		Hashtable<String, String> headers=new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("ZasConnect_CreateRadis"), "",
				globalProp, test, headers);
		return resp;
	}
	
	public Response testReadiness(ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("Zas_Diff");
		Hashtable<String, String> headers=new Hashtable<String, String>();
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("ZasConnect_TestReadness"),
				globalProp, test, headers);
		return resp;
	}
	
	public Response testLiveness(ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("Zas_Diff");
		Hashtable<String, String> headers=new Hashtable<String, String>();
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("ZasConnect_TestLiveness"),
				globalProp, test, headers);
		return resp;
	}
	
	public Response flushRadis(ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("Zas_Diff");
		Hashtable<String, String> headers=new Hashtable<String, String>();
		Response resp = resuableComponents.executeDeleteAPI(EndPoints.endPointList.get("ZasConnect_FlushRadis"),
				globalProp, test, headers);
		return resp;
	}



}
