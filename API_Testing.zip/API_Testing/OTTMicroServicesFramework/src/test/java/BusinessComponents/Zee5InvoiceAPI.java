package BusinessComponents;

import baseTestPackage.BaseTest_TestNG;
import com.EndPoints.EndPoints;
import com.relevantcodes.extentreports.ExtentTest;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import reusableLibrary.ResuableComponents;
import java.util.Hashtable;

public class Zee5InvoiceAPI extends BaseTest_TestNG {
    ResuableComponents resuableComponents = new ResuableComponents();

    public Response GetactuatorHealth(ExtentTest test)
    {
        RestAssured.baseURI = executionParams.get("baseURIActHealth");
        Hashtable<String, String> headers = new Hashtable<String, String>();
        headers.put("Content-Type", globalProp.getProperty("contentType"));
        Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("GETactuator_health"),globalProp, test, headers);
        return resp;
    }

    public Response GetPurchase(ExtentTest test)
    {
        RestAssured.baseURI = executionParams.get("baseURIActHealth");
        Hashtable<String, String> headers = new Hashtable<String, String>();
        headers.put("Content-Type", globalProp.getProperty("contentType"));
        Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("GETpurchase"),globalProp, test, headers);
        return resp;
    }
    public Response GetAPIPurchase(ExtentTest test)
    {
        RestAssured.baseURI = executionParams.get("baseURIActHealth");
        Hashtable<String, String> headers = new Hashtable<String, String>();
        headers.put("SubscrptionID", globalProp.getProperty("subscrptionID"));
        headers.put("PAYMENTID", globalProp.getProperty("paymentID"));
        headers.put("Content-Type", globalProp.getProperty("contentType"));
        Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("Purchase"),globalProp, test, headers);
        return resp;
    }
}
