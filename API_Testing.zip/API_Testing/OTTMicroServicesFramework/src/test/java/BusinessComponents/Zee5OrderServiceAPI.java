 package BusinessComponents;

import java.util.Hashtable;

import com.EndPoints.EndPoints;
import com.OTTPlatform.OrderManagement.Zee5OrderServiceTest;
import com.OTTPlatform.OrderManagement.testclass;
import com.relevantcodes.extentreports.ExtentTest;
import baseTestPackage.BaseTest_TestNG;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import reusableLibrary.ResuableComponents;

public class Zee5OrderServiceAPI extends BaseTest_TestNG{

	ResuableComponents resuableComponents = new ResuableComponents();
	 	
	public Response GetActuator(ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("zee5orderservice");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("ORDER_ISC_KEY", globalProp.getProperty("act_ORDER_ISC_KEY"));
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("ACTUATOR_zee5order"),
				globalProp,test,headers);
		return resp;
	}
	
	public Response GetActuatorHealth(ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("zee5orderservice");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("ORDER_ISC_KEY", globalProp.getProperty("act_ORDER_ISC_KEY"));
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("ACTUATORHEALTH_zee5order"),
				globalProp,test,headers);
		return resp;
	}
	
	public Response GetActuatorV1Order(ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("zee5orderservice");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("ORDER_ISC_KEY", globalProp.getProperty("act_ORDER_ISC_KEY"));
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("ACTUATORDER_zee5order"),
				globalProp,test,headers);
		return resp;
	}
	
	public Response PostV1Order(String requestBody,ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("zee5orderservice");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("ORDER_ISC_KEY", globalProp.getProperty("act_ORDER_ISC_KEY"));
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("POSTORDER_zee5order") ,
				requestBody,globalProp,test,headers);
		return resp;
		
	}
	
	public Response PatchV1Order(String requestBody,ExtentTest test) throws Exception {
		System.out.println(testclass.postorderid);
		RestAssured.baseURI = executionParams.get("zee5orderservice");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("ORDER_ISC_KEY", globalProp.getProperty("act_ORDER_ISC_KEY"));
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.executePatchAPI(EndPoints.endPointList.get("PATCHORDER_zee5order") + Zee5OrderServiceTest.postorderid ,  
				requestBody,globalProp,test,headers);
		return resp;
	}
	
	public Response PostChurnArrestCoupon(String requestBody,ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("zee5orderservice");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("ORDER_ISC_KEY", globalProp.getProperty("act_ORDER_ISC_KEY"));
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("COUPON_zee5order"),
				requestBody,globalProp,test,headers);
		return resp;
	}
	
	public Response GetChurnCoupon(ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("zee5orderservice");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("ORDER_ISC_KEY", globalProp.getProperty("act_ORDER_ISC_KEY"));
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("GETCHURN_zee5order"),
				globalProp,test,headers);
		return resp;
	}
	
	public Response PatchChurnCoupon(String requestBody,ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("zee5orderservice");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("ORDER_ISC_KEY", globalProp.getProperty("act_ORDER_ISC_KEY"));
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.executePatchAPI(EndPoints.endPointList.get("PATCHCHURN_zee5order"),
				requestBody,globalProp,test,headers);
		return resp;
	}
	
	public Response GetPromotionOrder(ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("zee5orderservice");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("ORDER_ISC_KEY", globalProp.getProperty("act_ORDER_ISC_KEY"));
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("PROMOTION_zee5order"),
				globalProp,test,headers);
		return resp;
	}
	
	public Response GetChurnCouponID(ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("zee5orderservice");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("ORDER_ISC_KEY", globalProp.getProperty("act_ORDER_ISC_KEY"));
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("PATCHCHURN_zee5order"),
				globalProp,test,headers);
		return resp;
	}
	
	public Response PostOrderHistory(String requestBody,ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("zee5orderservice");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("ORDER_ISC_KEY", globalProp.getProperty("act_ORDER_ISC_KEY"));
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("POSTHISTORY_zee5order"),
				requestBody,globalProp,test,headers);
		return resp;
	}
	

	public Response GetCartOrder(ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("zee5orderservice");
		// RestAssured.baseURI = globalProp.getProperty("securepaymentURI");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("ORDER_ISC_KEY", globalProp.getProperty("act_ORDER_ISC_KEY"));
		headers.put("order_id", globalProp.getProperty("getcart_order_id"));
		headers.put("user-id", globalProp.getProperty("getcart_user-id"));
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("GETCARTABAN_zee5order"),
				globalProp,test,headers);
		return resp;
	}
	
	public Response GetPromotionDetail(ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("zee5orderservice");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("api-key", globalProp.getProperty("act_ORDER_ISC_KEY"));
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("GETPROMOTION_zee5order"),
				globalProp,test,headers);
		return resp;
	}
	
	
	
	public Response PostTaxOrder(String requestBody,ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("zee5orderservice");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("ORDER_ISC_KEY", globalProp.getProperty("act_ORDER_ISC_KEY"));
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("POSTTAX_zee5order"),
				requestBody,globalProp,test,headers);
		return resp;
	}

	
	public Response GetTaxOrder(ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("zee5orderservice");
	 	Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("ORDER_ISC_KEY", globalProp.getProperty("act_ORDER_ISC_KEY"));
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("GETTAX_zee5order"),
				globalProp,test,headers);
		return resp;
	}
	
	public Response PutTaxOrder(String requestBody,ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("zee5orderservice");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("ORDER_ISC_KEY", globalProp.getProperty("act_ORDER_ISC_KEY"));
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.executePutAPI(EndPoints.endPointList.get("POSTTAX_zee5order"),
				requestBody,globalProp,test,headers);
		return resp;
	}
	
	public Response GetCouponCode(ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("zee5orderservice");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("ORDER_ISC_KEY", globalProp.getProperty("act_ORDER_ISC_KEY"));
		headers.put("user_id", globalProp.getProperty("getcoupon_user_id"));
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("COUPON_zee5order"),
				globalProp,test,headers);
		return resp;
	}
	
	public Response GetOrders(ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("zee5orderservice");
	 	Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("ORDER_ISC_KEY", globalProp.getProperty("act_ORDER_ISC_KEY"));
		headers.put("user-id", globalProp.getProperty("product_user-id"));
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("GETORDER_zee5order"),
				globalProp,test,headers);
		return resp;
	}
	
	public Response GetOrderbyDate(ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("zee5orderservice");
	 	Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("ORDER_ISC_KEY", globalProp.getProperty("act_ORDER_ISC_KEY"));
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("GETORDERBYDATE_zee5order"),
				globalProp,test,headers);
		return resp;
	}
}
