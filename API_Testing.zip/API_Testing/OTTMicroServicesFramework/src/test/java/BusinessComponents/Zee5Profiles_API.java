package BusinessComponents;

import java.util.Hashtable;

import com.EndPoints.EndPoints;
import com.relevantcodes.extentreports.ExtentTest;

import baseTestPackage.BaseTest_TestNG;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import reusableLibrary.ResuableComponents;

public class Zee5Profiles_API extends BaseTest_TestNG{

	ResuableComponents resuableComponents = new ResuableComponents();
	
	public Response create_DefaultProfile(String requestBody,ExtentTest test,String Mobile_accesstoken) throws Exception {
		RestAssured.baseURI = executionParams.get("Zee5_Profile");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("esk", globalProp.getProperty("Zee5Profile_esk"));
		headers.put("device_id", globalProp.getProperty("Zee5Profile_device_id"));
		headers.put("Authorization","bearer "+ Mobile_accesstoken);
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("CREATEDEFAULTPROFILE"),requestBody,
				globalProp,test,headers);
		return resp;
	}
	
	public Response create_Profile(String requestBody,ExtentTest test,String Mobile_accesstoken ) throws Exception {
		RestAssured.baseURI = executionParams.get("Zee5_Profile");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("esk", globalProp.getProperty("Zee5Profile_esk"));
		headers.put("device_id", globalProp.getProperty("Zee5Profile_device_id"));
		headers.put("Authorization","bearer "+ Mobile_accesstoken);
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("CREATEPROFILE"),requestBody,
				globalProp,test,headers);
		return resp;
	}
	
	public Response get_AllUserProfile(ExtentTest test,String Mobile_accesstoken) throws Exception {
		RestAssured.baseURI = executionParams.get("Zee5_Profile");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("esk", globalProp.getProperty("Zee5Profile_esk"));
		headers.put("device_id", globalProp.getProperty("Zee5Profile_device_id"));
		headers.put("Authorization","bearer "+ Mobile_accesstoken);
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("GETALLUSERPROFILE"),
				globalProp,test,headers);
		return resp;
	}
	
	public Response get_Profile(ExtentTest test,String Mobile_accesstoken,String Profile_id) throws Exception {
		RestAssured.baseURI = executionParams.get("Zee5_Profile");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("esk", globalProp.getProperty("Zee5Profile_esk"));
		headers.put("device_id", globalProp.getProperty("Zee5Profile_device_id"));
		headers.put("Authorization","bearer "+ Mobile_accesstoken);
		String endpoint=EndPoints.endPointList.get("GETPROFILE").replace("{$PID$}", Profile_id);
		Response resp = resuableComponents.executeGetAPI(endpoint,
				globalProp,test,headers);
		return resp;
	}
	
	public Response update_Profiles(ExtentTest test, String reqBody,String Mobile_accesstoken) throws Exception {
		RestAssured.baseURI = executionParams.get("Zee5_Profile");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("esk", globalProp.getProperty("Zee5Profile_esk"));
		headers.put("device_id", globalProp.getProperty("Zee5Profile_device_id"));
		headers.put("Authorization","bearer "+ Mobile_accesstoken);
		Response resp = resuableComponents.executePutAPI(EndPoints.endPointList.get("UPDATEPROFILES"), reqBody, globalProp,
				test, headers);
		return resp;
	}
	
	public Response update_LastUsedProfile(String requestBody,ExtentTest test,String Mobile_accesstoken) throws Exception {
		RestAssured.baseURI = executionParams.get("Zee5_Profile");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("esk", globalProp.getProperty("Zee5Profile_esk"));
		headers.put("device_id", globalProp.getProperty("Zee5Profile_device_id"));
		headers.put("Authorization","bearer "+ Mobile_accesstoken);
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("UPDATELASTUSEDPROFILE"),requestBody,
				globalProp,test,headers);
		return resp;
	}
	
	public Response get_LastUsedProfile(ExtentTest test,String Mobile_accesstoken) throws Exception {
		RestAssured.baseURI = executionParams.get("Zee5_Profile");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("esk", globalProp.getProperty("Zee5Profile_esk"));
		headers.put("device_id", globalProp.getProperty("Zee5Profile_device_id"));
		headers.put("Authorization","bearer "+ Mobile_accesstoken);
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("GETLASTUSEDPROFILE"),
				globalProp,test,headers);
		return resp;
	}
	
	public Response SendEmailORMOBILEOTPPOSTCall(ExtentTest test, String requestBody) throws Exception {
		RestAssured.baseURI = executionParams.get("baseuriusernode");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("device_id", globalProp.getProperty("UserToken_deviceID"));
		headers.put("esk",globalProp.getProperty("UserToken_eskID"));
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("REGISTERANDUPDATE_SENDEMAILOTP"), requestBody,globalProp, test, headers);
		return resp;
	}
	
	public Response OTPACCESSTOKEN(ExtentTest test, String requestBody) throws Exception {
		RestAssured.baseURI = executionParams.get("baseuriusernode");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("device_id", globalProp.getProperty("UserToken_deviceID"));
		headers.put("esk",globalProp.getProperty("UserToken_eskID"));
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("OTPVERIFY"), requestBody,globalProp, test, headers);
		return resp;
	}
	
	
	public Response delete_Profile(ExtentTest test,String Mobile_accesstoken,String Profile_id) throws Exception {
		RestAssured.baseURI = executionParams.get("Zee5_Profile");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		headers.put("esk", globalProp.getProperty("Zee5Profile_esk"));
		headers.put("device_id", globalProp.getProperty("Zee5Profile_device_id"));
		headers.put("Authorization","bearer "+ Mobile_accesstoken);
		String endpoint=EndPoints.endPointList.get("GETPROFILE").replace("{$PID$}", Profile_id);
		Response resp = resuableComponents.executeDeleteAPI(endpoint, globalProp, test,
				headers);
		return resp;
	}
	//Reusable to get OTP form the String recieved from DB
	
		public String OTPCode(String data)
		{
			String[] Data=data.split(",");
			String [] code= Data[1].split(":");
			String OTP=code[1];
			OTP=OTP.replaceAll("\"", "");
			
			return OTP;
			
		}
	
}
