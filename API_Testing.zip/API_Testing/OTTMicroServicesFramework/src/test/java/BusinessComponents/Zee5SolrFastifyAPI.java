package BusinessComponents;


import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

import com.EndPoints.EndPoints;
import com.relevantcodes.extentreports.ExtentTest;

import baseTestPackage.BaseTest_TestNG;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import reusableLibrary.ResuableComponents;

public class Zee5SolrFastifyAPI extends BaseTest_TestNG {

	List<String> list = new ArrayList<String>();
	ResuableComponents resuableComponents = new ResuableComponents();
	private Hashtable<String, String> headers = new Hashtable<String, String>();
	
	public void Zee5SolarFastify() {
		headers.put("X-ACCESS-TOKEN", CSU.decrypt(executionParams.get("X-AccessToken")));
		headers.put("User-Agent", executionParams.get("User-Agent"));
		headers.put("sec-ch-ua", executionParams.get("sec-ch-ua"));
		headers.put("sec-ch-ua-mobile", executionParams.get("sec-ch-ua-mobile"));
		headers.put("sec-ch-ua-platform", executionParams.get("sec-ch-ua-platform"));
	}
	
	public Response GetCollectionGETCall(ExtentTest test) throws Exception
	{
		RestAssured.baseURI = executionParams.get("basesolrfastify");
		this.Zee5SolarFastify();
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("GETCOLLECTION"),globalProp, test, headers);
		return resp;
	}
	
	public Response CollectionNewsGETCall(ExtentTest test) throws Exception
	{
		RestAssured.baseURI = executionParams.get("basesolrfastify");
		this.Zee5SolarFastify();
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("COLLECTIONNEWS"),globalProp, test, headers);
		return resp;
	}
	public Response CollectionMusicGETCall(ExtentTest test) throws Exception
	{
		RestAssured.baseURI = executionParams.get("basesolrfastify");
		this.Zee5SolarFastify();
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("COLLECTIONMUSIC"),globalProp, test, headers);
		return resp;
	}
	public Response CollectionHomePageGETCall(ExtentTest test) throws Exception
	{
		RestAssured.baseURI = executionParams.get("basesolrfastify");
		this.Zee5SolarFastify();
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("COLLECTIONHOMEPAGE"),globalProp, test, headers);
		return resp;
	}
	public Response CollectionHoichoiGETCall(ExtentTest test) throws Exception
	{
		RestAssured.baseURI = executionParams.get("basesolrfastify");
		this.Zee5SolarFastify();
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("COLLECTIONHOICHOI"),globalProp, test, headers);
		return resp;
	}
	public Response CollectionHomePageAddonGETCall(ExtentTest test) throws Exception
	{
		RestAssured.baseURI = executionParams.get("basesolrfastify");
		this.Zee5SolarFastify();
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("COLLECTIONHOMEPAGEADDON"),globalProp, test, headers);
		return resp;
	}
	
	public Response CollectionAHAGETCall(ExtentTest test) throws Exception
	{
		RestAssured.baseURI = executionParams.get("basesolrfastify");
		this.Zee5SolarFastify();
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("COLLECTIONAHA"),globalProp, test, headers);
		return resp;
	}
	public Response CollectionTVShowsGETCall(ExtentTest test) throws Exception
	{
		RestAssured.baseURI = executionParams.get("basesolrfastify");
		this.Zee5SolarFastify();
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("COLLECTIONTVSHOWS"),globalProp, test, headers);
		return resp;
	}
	
	public Response CollectionTVShowsMoreGETCall(ExtentTest test) throws Exception
	{
		RestAssured.baseURI = executionParams.get("basesolrfastify");
		this.Zee5SolarFastify();
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("COLLECTIONTVSHOWSMORE"),globalProp, test, headers);
		return resp;
	}
	public Response CollectionMoviesGETCall(ExtentTest test) throws Exception
	{
		RestAssured.baseURI = executionParams.get("basesolrfastify");
		this.Zee5SolarFastify();
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("COLLECTIONMOVIES"),globalProp, test, headers);
		return resp;
	}
	
	public Response CollectionPremiumContentGETCall(ExtentTest test) throws Exception
	{
		RestAssured.baseURI = executionParams.get("basesolrfastify");
		this.Zee5SolarFastify();
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("COLLECTIONPREMIUMCONTENTS"),globalProp, test, headers);
		return resp;
	}
	public Response CollectionZeePlexGETCall(ExtentTest test) throws Exception
	{
		RestAssured.baseURI = executionParams.get("basesolrfastify");
		this.Zee5SolarFastify();
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("COLLECTIONZEEPLEX"),globalProp, test, headers);
		return resp;
	}
	public Response CollectionPlayGETCall(ExtentTest test) throws Exception
	{
		RestAssured.baseURI = executionParams.get("basesolrfastify");
		this.Zee5SolarFastify();
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("COLLECTIONPLAY"),globalProp, test, headers);
		return resp;
	}
	public Response CollectionWebSeriesGETCall(ExtentTest test) throws Exception
	{
		RestAssured.baseURI = executionParams.get("basesolrfastify");
		this.Zee5SolarFastify();
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("COLLECTIONWEBSERIES"),globalProp, test, headers);
		return resp;
	}
	public Response CollectionVideosGETCall(ExtentTest test) throws Exception
	{
		RestAssured.baseURI = executionParams.get("basesolrfastify");
		this.Zee5SolarFastify();
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("COLLECTIONVIDEOS"),globalProp, test, headers);
		return resp;
	}
	public Response CollectionChannelsGETCall(ExtentTest test) throws Exception
	{
		RestAssured.baseURI = executionParams.get("basesolrfastify");
		this.Zee5SolarFastify();
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("COLLECTIONCHANNEL"),globalProp, test, headers);
		return resp;
	}
	public Response CollectionKidsGETCall(ExtentTest test) throws Exception
	{
		RestAssured.baseURI = executionParams.get("basesolrfastify");
		this.Zee5SolarFastify();
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("COLLECTIONKIDS"),globalProp, test, headers);
		return resp;
	}
	public Response CollectionEduraaGETCall(ExtentTest test) throws Exception
	{
		RestAssured.baseURI = executionParams.get("basesolrfastify");
		this.Zee5SolarFastify();
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("COLLECTIONEDURAA"),globalProp, test, headers);
		return resp;
	}
}
