package BusinessComponents;

import java.util.Hashtable;

import com.EndPoints.EndPoints;
import com.relevantcodes.extentreports.ExtentTest;

import baseTestPackage.BaseTest_TestNG;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import reusableLibrary.ResuableComponents;

public class Zee5_Themis extends BaseTest_TestNG{

	ResuableComponents resuableComponents = new ResuableComponents();
	
	public Response rulesPayment(String requestBody,ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("zee5Themis");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("api_key", CSU.decrypt(globalProp.getProperty("themis-api_key")));
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("PAYMENTRULES"),requestBody,
				globalProp,test,headers);
		return resp;
	}
	
	public Response addRules(String requestBody,ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("zee5Themis");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("api_key", CSU.decrypt(globalProp.getProperty("themis-api_key")));
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("ADDRULES"),requestBody,
				globalProp,test,headers);
		return resp;
	}
	
	public Response getRulesbyNameSpace(ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("zee5Themis");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("api_key", CSU.decrypt(globalProp.getProperty("themis-api_key")));
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("GETRULESBYNAMESPACE"),
				globalProp,test,headers);
		return resp;
	}
	
	public Response paymentMethod(String requestBody,ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("zee5Themis");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("api_key", CSU.decrypt(globalProp.getProperty("themis-api_key")));
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("PAYMENTMETHOD"),requestBody,
				globalProp,test,headers);
		return resp;
	}
	
	public Response getRulesbyId(ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("zee5Themis");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("api_key", CSU.decrypt(globalProp.getProperty("themis-api_key")));
		headers.put("Content-Type", globalProp.getProperty("contentType"));
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("GETRULESBYID"),
				globalProp,test,headers);
		return resp;
	}
	
	
//	
//	public Response updateComment(ExtentTest test, String reqBody) throws Exception {
//		RestAssured.baseURI = executionParams.get("userComments");
//		Hashtable<String, String> headers = new Hashtable<String, String>();
//		headers.put("x-access-token", globalProp.getProperty("user_Access_token"));
//		headers.put("Authorization", globalProp.getProperty("user_Auth_token"));
//		headers.put("Content-Type", globalProp.getProperty("contentType"));
//		Response resp = resuableComponents.executePutAPI(EndPoints.endPointList.get("updateComment"), reqBody, globalProp,
//				test, headers);
//		return resp;
//	}
	
}
