package BusinessComponents;

import java.util.Hashtable;

import com.EndPoints.EndPoints;
import com.relevantcodes.extentreports.ExtentTest;

import baseTestPackage.BaseTest_TestNG;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import reusableLibrary.ResuableComponents;

public class ptDisplayAdsSubscriptionAPI extends BaseTest_TestNG {

	ResuableComponents resuableComponents = new ResuableComponents();

	public Response addUser_appleApp(String reqBody, ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("displayAdsHost");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("v1_x-access-token", CSU.decrypt(globalProp.getProperty("display_v1_access-token")));
		headers.put("v1_Authorization", CSU.decrypt(globalProp.getProperty("display_v1_Auth-token")));
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("v1_appleApp"), reqBody,
				globalProp, test, headers);
		return resp;
	}

	public Response V2_UKRegistered_User_android_mobile(String reqBody, ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("displayAdsHost");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("v1_x-access-token", CSU.decrypt(globalProp.getProperty("display_v1_access-token")));
		headers.put("v1_Authorization", CSU.decrypt(globalProp.getProperty("display_v1_Auth-token")));
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("v2_android_mobile"), reqBody,
				globalProp, test, headers);
		return resp;
	}

	public Response get_V3UKRegisteredUserDesktop_web(ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("displayAdsHost");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		headers.put("x-access-token", CSU.decrypt(globalProp.getProperty("display_v1_access-token")));
		headers.put("Authorization", CSU.decrypt(globalProp.getProperty("display_v3_Auth-token")));
		Response resp = resuableComponents.executeGetAPI(EndPoints.endPointList.get("v3_desktopWeb"), globalProp, test,
				headers);
		return resp;
	}
}
