package BusinessComponents;

import java.util.Hashtable;

import com.EndPoints.EndPoints;
import com.relevantcodes.extentreports.ExtentTest;

import baseTestPackage.BaseTest_TestNG;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import reusableLibrary.ResuableComponents;

public class zee5_entitlement_vertx_API extends BaseTest_TestNG
{
	
	ResuableComponents resuableComponents = new ResuableComponents();
	GCP_OTP_UAT_API CCP= new GCP_OTP_UAT_API();
	

	
	public Response SubScriptionType_Free_POST(String requestBody,ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("Zee5EntitlementVertex");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		
		
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("SUBSCRIPTIONTYPEFREE"),requestBody,
				globalProp,test,headers);
		return resp;
	}
	public Response SubScriptionType_Premium_POST(String requestBody,ExtentTest test) throws Exception {
		RestAssured.baseURI = executionParams.get("Zee5EntitlementVertex");
		Hashtable<String, String> headers = new Hashtable<String, String>();
		
		
		Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("SUBSCRIPTIONTYPEFREE"),requestBody,
				globalProp,test,headers);
		return resp;
	}
	
	public Response AdduseridSubscription(String requestBody,ExtentTest test) 
	{
		RestAssured.baseURI = executionParams.get("CommunicationEmailAPI");
	Hashtable<String, String> headers = new Hashtable<String, String>();
	headers.put("Authorization",CSU.decrypt(globalProp.getProperty("CMSTOKEN")));
	headers.put("Content-Type", "application/json");
	Response resp = resuableComponents.executePostAPI(EndPoints.endPointList.get("ADDUSERIDTOSUBSCRIPTION"),requestBody,
			globalProp,test,headers);
	return resp;
		
		
	}
	
	
	

}
