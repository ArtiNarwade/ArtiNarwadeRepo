package baseTestPackage;

import java.io.File;
import java.io.FileReader;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import org.testng.Reporter;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import reusableLibrary.Ciper_SecretUtils;

public class BaseTest_TestNG implements ITestListener{
	public static ExtentReports report;
	public static ExtentTest test;
	public static Properties globalProp;
	public static Map<String, String> executionParams = new HashMap<>();
	public static String env = null;
    public static String baseDirectoryPath=getBasePath();
    public Ciper_SecretUtils CSU= new Ciper_SecretUtils();
	@BeforeSuite(alwaysRun = true)
	public void startTest(ITestContext testContext) throws Exception {
		getBasePath();
		if (System.getProperty("env") == null) {
			executionParams = testContext.getSuite().getXmlSuite().getAllParameters();
			env = executionParams.get("env");
		} else {
			env = System.getProperty("env").trim().toLowerCase();
			System.out.println(env +"env"+"From inputs.......");
		}
	 try {
		globalProp = loadPropertyFile(baseDirectoryPath + "//GlobalProperties.properties");
			Set<Object> set = globalProp.keySet();
			System.out.println("Reading all key values from properties file \n");
			for (Object o : set) {
				String key = (String) o;
			 	if (key.trim().toString().startsWith(env + "_")) {
					executionParams.put(key.substring(env.length() + 1), globalProp.getProperty(key));
				}
			}
			System.out.println(executionParams);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		 
		Date date = Calendar.getInstance().getTime();
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd_hh_mm_ss");
		String strDate = dateFormat.format(date);
		File reportFile = new File( baseDirectoryPath + "//ExtentReport//ExtentReportResults1_" + strDate + ".html");
		System.out.println("ExtentReport Path :"+reportFile);
		if (!reportFile.exists()) {
			reportFile.createNewFile();
		}
		report = new ExtentReports(baseDirectoryPath + "//ExtentReport//ExtentReportResults1_" + strDate + ".html",
 
				true);
	}
	@AfterSuite(alwaysRun = true)
	public static void endTest() throws Exception {
		report.endTest(test);
		report.flush();
	}
	public static Properties loadPropertyFile(String strFilePath) throws Exception {
		FileReader reader = new FileReader(strFilePath);
		Properties prop = new Properties();
		prop.load(reader);
		return prop;
	}
	public static String getBasePath()
	{
	 		Path currentRelativePath = Paths.get("");
			String s = currentRelativePath.toAbsolutePath().toString();
		//	System.out.println("Current relative path is: " + s);
			
			return s;
	}
	
	public static void checkURL(String data,ExtentTest test)
	{
		if(executionParams.get(data)==null)
	{
	test.log(LogStatus.FAIL, " BaseURL Data value is NUll for '"+data+"'");
	}
	else 
	{
		test.log(LogStatus.INFO, " BaseURL Data value "+executionParams.get(data)+ " is Present for  '"+data+"'");
		}
	}
	
	@Override
	public void onTestSkipped(ITestResult result)
	{
	ExtentTest test= report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
	test.log(LogStatus.FAIL, "This Testcase is dependent on :" +result.getMethod().getMethodsDependedUpon()[0]);
	
	}
}
