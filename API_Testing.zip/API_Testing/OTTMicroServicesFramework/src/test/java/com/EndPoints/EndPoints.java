package com.EndPoints;

import java.util.HashMap;
import java.util.Map;

import com.OTTPlatform.Adtech.AdTech_InHouse_Test;

public class EndPoints {

	public static Map<String, String> endPointList = new HashMap<String, String>() {{
	   
      put("VERIFYCONTENTDASHBOARD","/content-dashboard/zee5dashboard/verify");
      put("GETCONTENTDASHBOARD","/content-dashboard/zee5dashboard");
      put("BEFORETVADD","/content-dashboard/zee5dashboard/beforetv/add");
      put("BEFORETVFILTER","/content-dashboard/zee5dashboard/beforetv-filter");
      put("CHANGEUSEREMAIL","/v1/user/changeEmail");
      put("CHANGEUSEREPHONENUMBER","/v1/user/changePhoneNumber");
      put("GETUSERTOKEN","/v1/user/getUserToken");
      put("GETUSER","/v1/user");
      put("SENDOTP","/v1/user/sendotp");
      //WatchHistory Connector
      put("UpdateWatchHistory","/api/v1/watchhistory");
      put("WATCHSTATUS","/watch/status?asset_ids=0-0-101641");
      put("DeleteWatchHistory","/watchhistory/delete?id=0-0-101641");
      put("CONTINUEWATCH","/continuewatching?user_id=1E03B0CA-33F4-4D00-B935-3C2F6FE9869C&asset_id=0-0-101641");
      put("CONCURRENTUSERSESSION","/sessions/user/1E03B0CA-33F4-4D00-B935-3C2F6FE9869C");
      //MW DataProcess
      put("TIGGER","/dataprocess/test/process/0-1-6z573117");
      put("HEALTHCHECK","/dataprocess/test");
      put("REDISTEST","/imageprocess/test/cache");
      //MW Image process
      put("IMAGEPROCESSHEALTHCHECK","/imageprocess/test");
      put("IMAGEPROCESSTIGGER","/imageprocess/test/process/0-1-6z573117");

      //VideoAds Vertx
      put("VIDEOADSPOST","/videoAds");
      put("VIDEOADSGET","/videoAds/probes/liveness"); 

      //Games API
      put("GAMESFILTERALL","/games/filter?tag=all&page=1&item_limit=20&translation=en&country=IN&languages=hi%2Cen&version=13");
      put("GAMESFILTERCASUAL","/games/filter?tag=casual&page=1&item_limit=20&translation=en&country=IN&languages=hi%2Cen&version=13");
      put("GAMESFILTERPUZZLE","/games/filter?tag=Puzzle&page=1&item_limit=20&translation=en&country=IN&languages=hi%2Cen&version=13");
      put("GAMESFILTERARCADE","/games/filter?tag=Arcade&page=1&item_limit=20&translation=en&country=IN&languages=hi%2Cen&version=13");
      put("GAMESFILTERALLACTION","/games/filter?tag=Action&page=1&item_limit=20&translation=en&country=IN&languages=hi%2Cen&version=13");
      put("GAMESFILTERALLSPORTS","/games/filter?tag=Sports&page=1&item_limit=20&translation=en&country=IN&languages=hi%2Cen&version=13");
      put("GAMESALLOWEDTAGS","/games/filter/allowedTags?page=1&item_limit=20&translation=hi&country=IN&languages=en&version=13");
      put("GAMESWITHSTREAK","/games/recentlyPlayed/withStreak");
      put("GAMESWITHOUTSTREAK","/games/recentlyPlayed/withoutStreak");

      //Audio Ads
      put("AUDIOADS","/audioAds?content_id=51733765&country=IN&device_id=74b83f08-4396-4f58-9c79-a1339962bd70&app_version=2.51.41&age_group=25-32&gender=Male&platform_name=android_mobile&age=20");

      //Display Ads
      put("v1_appleApp","/singlePlayback/displayAds?state=MH&country=GB&platform_name=apple_app&user_type=guest&ppid=zUtiLbdKYBS4T0xUl9vk000000000000&uid=a2a98898-d776-47ec-9f3d-82538c61c2bf&gender=@@@@&age_group=756756757fggf&content_id=0-0-khalnayak12");	    
      put("v2_android_mobile","/singlePlayback/v2/displayAds?state=MH&country=GB&platform_name=android_mobile&user_type=guest&ppid=zUtiLbdKYBS4T0xUl9vk000000000000&uid=a2a98898-d776-47ec-9f3d-82538c61c2bf&gender=@@@@&age_group=756756757fggf&content_id=0-0-khalnayak12");
      put("v3_desktopWeb","/singlePlayback/displayAds/v3?state=MH&country=UK&platform_name=desktop_web&user_type=guest&ppid=zUtiLbdKYBS4T0xUl9vk000000000000&uid=a2a98898-d776-47ec-9f3d-82538c61c2bf&gender=@@@@&age_group=756756757fggf&content_id=0-0-khalnayak12"); 

     // Reco_Adtech_caps
      put("AdtechCaps_REGISTER_USER","/recocaps/caps/user/register-user");
      put("AdtechCaps_Login_USER","/recocaps/caps/authenticate");
      put("AdtechCaps_FEEDBYID","/recocaps/caps/feed/46");
      put("AdtechCaps_CLIENTID","/recocaps/caps/feed/clientId/1");
      put("AdtechCaps_FEEDBYSTATUS","/recocaps/caps/feed/status/01");
      put("AdtechCaps_FEED_INACTIVE","/recocaps/caps/feed/inactive/46");
      put("AdtechCaps_FEED_ACTIVE","/recocaps/caps/feed/active/46");
      put("AdtechCaps_UPDATE_FEED","/recocaps/caps/feed/update/");
      put("AdtechCaps_CREATEFEED","/recocaps/caps/feed/create/");
      put("AdtechCaps_FEEDRULE","/recocaps/caps/feedRule/190");
      put("AdtechCaps_FEEDRULE_ID","/recocaps/caps/feedRule/feedId/46");
      put("AdtechCaps_FEEDRULE_STATUS","/recocaps/caps/feedRule/status/1");
      put("AdtechCaps_FEEDRULE_INACTIVE","/recocaps/caps/feedRule/inactive/193");
      put("AdtechCaps_FEEDRULE_UPDATE","/recocaps/caps/feedRule/update/");
      put("AdtechCaps_CREATEFEEDRULE","/recocaps/caps/feedRule/create/");
      put("AdtechCaps_ACTIVEFEEDRULE","/recocaps/caps/feedRule/active/191");
      put("AdtechCaps_CONFIGRULE_CREATE","/recocaps/caps/feedConfigRule/create/");
      put("AdtechCaps_FEEDEXPRESSION_CREATE","/recocaps/caps/feedExpression/create/");
      put("AdtechCaps_FEEDEXPRESSION_UPDATE","/recocaps/caps/feedExpression/update/");
      put("AdtechCaps_FEEDFILTERINGRULE_CREATE","/recocaps/caps/feedFilteringRule/create/");
      put("AdtechCaps_ALGOPINRULE_CREATE","/recocaps/caps/algoPinRule/create/");
      put("AdtechCaps_CONFIGRULEID","/recocaps/caps/feedConfigRule/1");
      put("AdtechCaps_CONFIGRULE_INACTIVE","/recocaps/caps/feedConfigRule/inactive/167");
      put("AdtechCaps_CONFIGRULE_ACTIVE","/recocaps/caps/feedConfigRule/active/183");
      put("AdtechCaps_CONFIGRULE_UPDATE","/recocaps/caps/feedConfigRule/update/");
      put("AdtechCaps_PINPOSITION_ID","/recocaps/caps/pinPosition/52");
      put("AdtechCaps_PINPOSITION_ACTIVE","/recocaps/caps/pinPosition/active/52");
      put("AdtechCaps_PINPOSITION_INACTIVE","/recocaps/caps/pinPosition/inactive/52");
      put("AdtechCaps_PINPOSITION_UPDATE","/recocaps/caps/pinPosition/update/");
      put("AdtechCaps_FEEDEXPRESSION_ID","/recocaps/caps/feedExpression/3");
      put("AdtechCaps_FEEDEXPRESSION_INACTIVE","/recocaps/caps/feedExpression/inactive/2");
      put("AdtechCaps_FEEDEXPRESSION_ACTIVE","/recocaps/caps/feedExpression/active/2");
      put("AdtechCaps_FEEDFILTERINGRULE_ID","/recocaps/caps/feedFilteringRule/3");
      put("AdtechCaps_FEEDFILTERINGRULE_INACTIVE","/recocaps/caps/feedFilteringRule/inactive/3");
      put("AdtechCaps_FEEDFILTERINGRULE_ACTIVE","/recocaps/caps/feedFilteringRule/inactive/3");
      put("AdtechCaps_FEEDFILTERINGRULE_UPDATE","/recocaps/caps/feedFilteringRule/update/");
      put("AdtechCaps_ALGOPINRULE_ID","/recocaps/caps/algoPinRule/30");
      put("AdtechCaps_ALGOPINRULE_INACTIVE","/recocaps/caps/algoPinRule/inactive/30");
      put("AdtechCaps_ALGOPINRULE_ACTIVE","/recocaps/caps/algoPinRule/inactive/30");
      put("AdtechCaps_ADUNIT_ID","/recocaps/caps/adUnit/1458");
      put("AdtechCaps_ADUNIT_ACTIVE","/recocaps/caps/adUnit/active/2");
      put("AdtechCaps_ADUNIT_INACTIVE","/recocaps/caps/adUnit/inactive/2");
      put("AdtechCaps_ADUNIT_CREATE_","/recocaps/caps/adUnit/create/");
      put("AdtechCaps_ADUNIT_UPDATE","/recocaps/caps/adUnit/update/");
      put("AdtechCaps_CLIENT_ID","/recocaps/caps/client/700");
      put("AdtechCaps_CLIENT_STATUS","/recocaps/caps/client/status/1");
      put("AdtechCaps_CLIENT_ACTIVE","/recocaps/caps/client/active/39");
      put("AdtechCaps_CLIENT_CREATE","/recocaps/caps/client/create/");
      put("AdtechCaps_CLIENT_INACTIVE","/recocaps/caps/client/inactive/39");
      put("AdtechCaps_CLIENT_UPDATE","/recocaps/caps/client/update/");
      put("AdtechCaps_MODELBY_ID","/recocaps/caps/model/7");
      put("AdtechCaps_MODELBY_STATUS","/recocaps/caps/model/status/1");
      put("AdtechCaps_MODELBY_Type","/recocaps/caps/model/type/2");
      put("AdtechCaps_MODELBY_Create","/recocaps/caps/model/create/");
      put("AdtechCaps_MODELBY_Update","/recocaps/caps/model/update/");


      //LAUNCH API
      put("COUNTRYCODE","/launch?ccode=US&version=5&country=US");

      //User PROFILE
      put("ALLUSERPROFILE","/v1/profiles");
      put("SINGLEUSERPROFILE","/v1/profiles?profile_id=94688af4-fb2f-450f-9ec0-17466350a3e0");
      put("LASTUSEDUSERPROFILE","/v1/profiles/lastUsedProfile");
      put("CREATEDEFAULTUSER","/v1/profiles/defaultProfile");
      put("CREATESINGLEUSERPROFILE","/v1/profiles");
      put("UPDATESINGLEPROFILE","/v1/profiles");
      put("UPDATELASTUSEDUSERPROFILE","/v1/profiles/lastUsedProfile");
      put("SINGLEUSERDETAILS","/v1/users");
      put("DELETEUSER","/v1/profiles?profile_id=0ebc4757-fdd0-452f-b7db-d8d60f222911");

      //LAUNCH API
      put("COUNTRYCODE","/launch?ccode=US&version=5&country=US");

      //WATCHLIST
      put("WATCHLISTENDPOINT","/v1/watchlist");
      put("WATCHLISTENDPOINTASSETDELETE","/v1/watchlist?id=0-0-1z51489847&asset_type=0");


      //UserToken
      put("USERDEVICELOGOUT","/device/devices/6fc134db-c8a9-4504-a2d4-e23df0c51bf/audit");
      put("USERDEVICE","/token/users/F1FFF243-B8F9-4458-A5C0-372BF87ACB6B/devices");
      put("USERSENDOTP","/v1/user/sendotp");
      put("VERIFYOTP","/v1/user/verifyotp");
      put("USERTOKENGENERATE","/token/generate");
      put("USERTOKENGENERATEVERIFY","/token/verifyToken");
      put("USERTOKENGETCLAIM","/token/getClaims");
      put("USERTOKENRENEW","/usertokenservice/token/renewToken");
      put("USERDEVICECODE","/v1/user/getcode");
      put("ADDEDUSERDEVICECODE","/v1/user/verifycode");

      //GuestScylla
      put("GUESTSCYLLAUSERDETAILSUPDATE","/v1/guest");
      put("GUESTSCYLLAUSERDETAILS","/v1/guest");
      put("GUESTSCYLLAUSERDETAILSUPDATEWITHNEWTOKEN","/v1/guest");

      //TokenVerification
      put("TOKENVERIFICATIONGVERIFYTOKENV1","/verify_token/v1/user/verifyToken");
      put("TOKENVERIFICATIONGVERIFYTOKENV2","/verify_token/v2/user/verifyToken");
      put("TOKENVERIFICATIONGVERIFYTOKEN","/verify_token");


      //GuestGenerator
      put("GUESTGENERATORGENERATETOKEN","/guest_generator/user");

      //WatchlistUserActivity
      put("WATCHLISTUSERACTIVITYADDACTIVITY","/v1/watchlist?asset_id=0-1-234");
      put("WATCHLISTUSERACTIVITYGETACTIVITY","/v1/watchlist");
      put("WATCHLISTUSERACTIVITYDELETEACTIVITY","/v1/watchlist?asset_id=0-1-234");
      put("WATCHLISTUSERACTIVITYTOGGLEACTIVITY","/toggle/v1/like");

      //WatchlistUserAgregator
      put("WATCHLISTUSERAGREGATORADDAGREGATOR","/v1/watchlist");
      put("WATCHLISTUSERAGREGATORGETAGREGATORV1","/v1/watchlist");
      put("WATCHLISTUSERAGREGATORGETAGREGATORV2","/v2/watchlist?translation=en&country=IN");
      put("WATCHLISTUSERAGREGATORDELETEAGREGATOR","/v1/watchlist?id=0-1-6z5227266");


      //CS-Help
      put("TOPICID","/cs/self-help/topic?topicId=1.1.2.1&lang=en&company=ZEEL&publisher=Zee5&userType=Premium&countryCode=IN&region=DL");
      put("PARENTTOPICID","/cs/self-help/topic/sub?parentTopic=1.1.2&lang=en&company=ZEEL&publisher=Zee5");
      put("HOMETOPICID","/cs/self-help/topic/home?lang=en&company=ZEEL&publisher=Zee5");
      put("FAQ","/cs/self-help/topic/faq?lang=en&company=ZEEL&publisher=Zee5&countryCode=IN&region=DL&userType=Premium");
      put("STATICPAGE","/cs/self-help/static?ccode=IN&text_type=about-us&lang=en");





      //zee5orderservice
      put("ACTUATOR_zee5order","/zee5-order/order-srv/actuator");
      put("ACTUATORHEALTH_zee5order","/zee5-order/order-srv/actuator/health");
      put("ACTUATORDER_zee5order","/zee5-order/order-srv/v1/order/2531c428-a6e3-4232-b6f7-673bbb6944b0");
      put("POSTORDER_zee5order","/zee5-order/order-srv/v1/order");
      put("COUPON_zee5order","/zee5-order/order-srv/v1/churn-arrest/coupon");
      put("GETCHURN_zee5order","/zee5-order/order-srv/v1/churn-arrest/coupon/14e480ae-5459-4ad0-ab68-0618cfe15d78");
      put("PATCHCHURN_zee5order","/zee5-order/order-srv/v1/churn-arrest/coupon/14e480ae-5459-4ad0-ab68-0618cfe15d78");
      put("PROMOTION_zee5order","/zee5-order/order-srv/v1/order/promotion/details?product_id=23&order_id=554f1c2a-25f6-43ca-8d0a-6921c42be159");
      put("POSTHISTORY_zee5order","/zee5-order/order-srv/v1/order/history");
      put("GETCARTABAN_zee5order","/zee5-order/order-srv/v1/order/cartAbandonment");
      put("GETPROMOTION_zee5order","/zee5-order/order-srv/v1/promotion?user_id=d3bc15ad-c448-40d6-9239-d32ae9ee3bd8&promo_code=string");
      put("PATCHORDER_zee5order","/zee5-order/order-srv/v1/order/");
      put("POSTTAX_zee5order","/zee5-order/order-srv/v1/order/tax");
      put("GETTAX_zee5order","/zee5-order/order-srv/v1/order/tax?order_id=14e480ae-5459-4ad0-ab68-0618cfe15d78&type=CREDIT");
      put("POSTAGGREGATOR_zee5order","/zee5-order/order-srv/v1/domain-aggregator");
      put("GETORDER_zee5order","/zee5-order/order-srv/v1/orders");
      put("GETORDERBYDATE_zee5order","/zee5-order/order-srv/v1/order/orders-by-date?country_code=IN&payment_provider=string hello 12h");


      //subscription ingestion
      put("UPLOAD_subscriptioning","subingestion/neoteric/register/upload");
      put("GETBATCHDETAIL_subscriptioning","/subingestion/neoteric/register/getBatch/4028540d884463e501884468b8fb0001");    	    
      put("POSTSUBSCRIBE","/pack-entitle/v1/subscription");
      put("GETSUBSCRIPTION","/pack-entitle/v1/subscriptions?payment_provider=Adyen&order_id=1b7eeb3e-3b33-4d5e-88b1-938e5cb75a54&plan_id=0-11-3224");
      put("GETBYID","/pack-entitle/v1/subscription/1b7eeb3e-3b33-4d5e-88b1-938e5cb75a54");
      put("PUTBYID","/pack-entitle/v1/subscription/1eac4c55-d614-46bc-ac35-a59e36a0210b");
      put("PATCH","/pack-entitle/v1/subscription/3fa85f82-5717-4562-b3fc-2c963f66afa6");
      put("POSTRENEWAL","/pack-entitle/v1/subscription/renewal");
      put("PLAYBACK","/pack-entitle/v1/subscription/playback");
      put("GETPLAYBACK","/pack-entitle/v1/subscription/3fa85f64-5717-4562-b3fc-2c963f66afa6/playback");
      put("UPDATEPLAYBACK","/pack-entitle/v1/subscription/1eac4c55-d613-46bc-ac35-a59e36f0210a/playback");



      //subscriptionrulebook
      put("REFERRER_subrulebook","/subscriptionRuleBook/subscription-rule-book/api/v1/rules/referrer");
      put("REFEREE_subrulebook","/subscriptionRuleBook/subscription-rule-book/api/v1/rules/referee");
      put("COHORT_subrulebook","/subscriptionRuleBook/subscription-rule-book/api/v1/rules/cohort");
      put("CLP_subrulebook","/subscriptionRuleBook/subscription-rule-book/api/v1/rules/clp");
      put("COUPON_subrulebook","/subscriptionRuleBook/subscription-rule-book/api/v1/rules/coupon");
      //put("PAYMENT_subrulebook","/subscription-rule-book/api/v1/rules/payment");
      put("GETV1RULE_subrulebook","/subscriptionRuleBook/subscription-rule-book/api/v1/rules?namespace=CHURN_ARREST_COUPON");
      put("POSTV1RULE_subrulebook","/subscription-rule-book/api/v1/rules");
      //put("DELETEV1RULE_subrulebook","/subscription-rule-book/api/v1/rules/7dce6d1f-e03e-40b7-9f7d-55cd6a2c803e");
      //put("GETIDRULE_subrulebook","/subscription-rule-book/api/v1/rules/bf0a4e46-73aa-4e3f-bd5f-203792d0f76f");

      //PLANMANAGEMENT_PT
      put("POSTENTITLEMENT_planmgmt","/plan-management/v1/entitlement");
      put("ENTITLEMENTBYID_planmgmt","/plan-management/v1/entitlement/6406e5a14d452d6fab50d2e8");
      put("ENTITLEMENTPLANID_planmgmt","/plan-management/v1/entitlement/plan/0-11-3287");
      put("PUTENTITLEMENT_planmgmt","/plan-management/v1/entitlement/63f5c056ff72d03801e72092");
      put("PUTANDGETPLANCONTROL_planmgmt","/plan-management/v1/plan/testdeepfeb161");
      put("PRODUCTREFERENCE_planmgmt","/plan-management/v1/product-reference?providerName=Play Store&productReference=zee5_1y_premium_svod_ar_global");
      put("POSTANDGETBYPLAN_planmgmt","/plan-management/v1/plan");
      put("GETBYPLAN_planmgmt","/plan-management/v1/plans?country_code=CA&plan_id=testdeepfeb161&platform_code=web");


			/*
			 * //Pack-Entitlement Subscription put("GETSUBSCRIPTION_packentitle",
			 * "/pack/pack-entitle/v1/subscription/1b7eeb3e-3b33-4d5e-88b1-938e5cb75a54");
			 * put("POSTSUBSCRIBEPLAYBACK_packentitle",
			 * "/pack/pack-entitle/v1/subscription/playback");
			 * put("POSTSUBSCRIBE_packentitle",
			 * "/pack/pack-entitle/v1/subscription/fa2b586d-d18b-4d04-be93-db3a90f07b3a");
			 * put("PUTBYID_packentitle",
			 * "/pack/pack-entitle/v1/subscription/1b7eeb3e-3b33-4d5e-88b1-938e5cb75a54");
			 * put("PUTPLAYBACK_packentitle",
			 * "/pack/pack-entitle/v1/subscription/1eac4c55-d613-46bc-ac35-a59e36f0210a/playback"
			 * ); put("PATCH_packentitle",
			 * "/pack/pack-entitle/v1/subscription/3fa85f82-5717-4562-b3fc-2c963f66afa6");
			 * put("GETBYPLAYBACK_packentitle",
			 * "/pack/pack-entitle/v1/subscription/3fa85f64-5717-4562-b3fc-2c963f66afa6/playback"
			 * );
			 * put("POSTRENEWAL_packentitle","/pack/pack-entitle/v1/subscription/renewal");
			 * put("GETBYID_packentitle",
			 * "/pack/pack-entitle/v1/subscriptions?payment_provider=Adyen&order_id=1b7eeb3e-3b33-4d5e-88b1-938e5cb75a54&plan_id=0-11-3224"
			 * );
			 */
      
      //POE_UAT
      put("ORDERMGMT_POE","/zee5-purchase-order-engine/order-mgmt/v1/checkout");
      put("ORDERMGMTPAYMENT_POE","/zee5-purchase-order-engine/order-mgmt/olm-hook/v1/order-payment");
      put("ORDERBFF_POE","/order-bff/v1/checkout");
      put("GLOBALCHECKOUT_POE","/zee5-purchase-order-engine/order-mgmt/v1/global-checkout/order");
      put("GETORDERMGMTALL_POE","/zee5-purchase-order-engine/order-mgmt/v1/getAll/48107bd6-73b5-4064-951b-b7937f9aef97");
      put("GETORDERMGMTPROMOTE_POE","/zee5-purchase-order-engine/order-mgmt/v1/promotion?user_id=f8838fae-30eb-430a-bcf5-9d5ffa55852c&promo_code=GET99");
      put("GETORDERMGMTMANDATE_POE","/zee5-purchase-order-engine/order-mgmt/v1/mandate/9c437de0-adeb-40ea-8178-38db95fc63ee");
      put("GETORDERMGMT_POE","/zee5-purchase-order-engine/order-mgmt/v1/48107bd6-73b5-4064-951b-b7937f9aef97");
      put("GETV1ORDERMGMT_POE","/zee5-purchase-order-engine/order-mgmt/v1");

      //CS-Content API
      put("CONTENTAPITVSHOWGENRELIST","/seo/tvshowGenreList?languages=hi,ta,te,ml,en&translation=ta&country=in&limit=5&page=1&genre=drama&asset_subtype=zee5original");
      put("CONTENTAPIMOVIEGENRE","/seo/movieGenre?language=hi&translation=en&country=IN&genre=action&page_size=25&page=1&sort_by_field=release_date&sort_order=desc&business_type=free");
      put("CONTENTAPIPARTNERFEEDCONTENTLISTING","/partnerFeeds/listing?type=episode&page=1&limit=25&third_party_name=Xiaomi");
      put("CONTENTAPINEWSRELATED","/news/related?limit_limit=25&page=1&content_owner=Zee");
      put("CONTENTAPIEXTRACTPLATFORMURL","/getPlatformUrl?asset_subtype=tvshow&date=16&month=04&year=2014");
      put("CONTENTAPITVSHOWHOME","/seo/tvshowHome?languages=hi,kn,te&country=in&translation=hi&page=1&limit=25&internal_test=1&asset_subtype=zee5original");
      put("CONTENTAPIMOVIELANGUAGES","/seo/movieLanguage?translation=en&country=IN&genres=crime&page_size=25&page=1&sort_by_field=release_date&sort_order=desc&business_type=free");
      put("CONTENTAPITVSHOWGENRE","/seo/tvshowGenre?page=1&asset_subtype=tvshow&language=ta&translation=en&country=IN&limit=25");
      put("CONTENTAPISEOGENREORLANGUAGES","/seo/genres-languages?type=language&country=IN&asset_subtype=movies&language=hi%2Cen&genre=crime&ignore_lang=hi%2Cen&ignore_genre=action%2Cadventure&sort_order=asc");

      //communicationengine
      put("COMM_communicationeng","/comm-engine-api/communication-engine/api/v1/notification");
      put("COMMNOTIFICATION_communicationeng","/comm-engine-api/communication-engine/api/v1/notification/E_2705f119-a2ed-4edd-9c42-f906eabfcc31");

      //TemplateEngine
      put("GETETEMPLATE_communicationeng","/template-engine-api/template-engine/api/v1/template/TEMP00101016");
      put("DELETETEMPLATECACHE_communicationeng","/template-engine-api/template-engine/cache/data");
      put("ADDTEMPLATE_communicationeng","/template-engine-api/template-engine/api/v1/template");
      put("DELETETEMPLATEDB_communicationeng","/template-engine-api/template-engine/api/v1/template/6000");

      // Adtech_PII
      put("ADTECH_PII","/Adtech/adtech-pii/enriched-user-metadata?user_id=801b1aca-22a8-466c-b5e0-3cfd4efb064d");

      //countryapi
      put("SINGLEIPOLD_country","/country-api/country/?ip=49.37.39.65");
      put("MULTIPLEIPOLD_country","/country-api/country/?ip=49.37.39.65,59.144.134.74");
      put("SINGLEIPNEW_country","/country-api/country/?ip=49.37.39.65");
      put("MULTIPLEIPNEW_country","/country-api/country/?ip=59.144.134.74,49.37.39.65");
      put("NOIP_country","/country-api/country");


      //communicationengine
      put("COMM_communicationeng","/comm-engine-api/communication-engine/api/v1/notification");
      put("COMMNOTIFICATION_communicationeng","/comm-engine-api/communication-engine/api/v1/notification/E_2705f119-a2ed-4edd-9c42-f906eabfcc31");
      put("GETALLRULE_communicationeng","/rule-engine-api/rule-engine/api/v1/rule/ZEE5_SMS_1");
      put("EMAILRULE_communicationeng","//rule-engine-api/rule-engine/api/v1/rule");
      put("SPECIFICRULE_communicationeng","/rule-engine-api/rule-engine/api/v1/rule/ZEE5_WHATSAPP_2");
      put("UPDATERULE_communicationeng","/rule-engine-api/rule-engine/api/v1/rule/ZEE5_EMAIL_10");
      put("DELETERULECHANNEL_communicationeng","/rule-engine-api/rule-engine/api/v1/rules?tenant=ZEE5&channel=EMAIL");
      put("DELETERULENAME_communicationeng","/rule-engine-api/rule-engine/api/v1/rule/ZEE5_SMS_3");
      put("FETCH_communicationeng","/rule-engine-api/rule-engine/api/v1/fetch");
      put("SMSRULE_communicationeng","/rule-engine-api/rule-engine/api/v1/rule/");
      put("GETETEMPLATE_communicationeng","/template-engine-api/template-engine/api/v1/template/TEMP00101016");
      put("DELETETEMPLATECACHE_communicationeng","/template-engine-api/template-engine/cache/data");
      put("ADDTEMPLATE_communicationeng","/template-engine-api/template-engine/api/v1/template");
      put("DELETETEMPLATEDB_communicationeng","/template-engine-api/template-engine/api/v1/template/6000");

      // Adtech_PII
      put("ADTECH_PII","/enriched-user-metadata?user_id=801b1aca-22a8-466c-b5e0-3cfd4efb064d");

      //Adtech-Diff  
      put("AUTHENTICATEDIF","/authenticate");
      put("RELOADCRON","/api/ssai-info/reload");
      put("ENEBLEDISABLECRON","api/ssai-info/cron/enable");
      put("SETSKIPPEDCHANNELS","/api/ssai-info/skip-channel-ids?id=");
      put("GETALLSKIPPEDCHANNELS","/api/ssai-info/skip-channel-ids");
      put("EVICTCHANNELID","/api/ssai-info/evict?id=0-9-339");
      put("GETASSETINFO","/api/ssai-info/get-asset-info?id=0-9-201");
      put("SETCUSTOMID","/api/ssai-info/set-custom-ids?id=0-9-zeenews&id=0-9-284,0-9-224&id=0-9-tvpictureshd");
      put("GETCUSTOMID","/api/ssai-info/get-custom-ids");
      put("HEALTHCHECK","/api/probes/liveness");
      put("REDINESS","/api/probes/readiness"); 

      //Adtech-In-House
      put("ADTECHINHOUSE","/raw-ad-playlist?device_id=d1&video_session_id=session1&user_targeting=%7B%22gender%22%3A%22male%22%2C%22agrGroup%22%3A%2218-24%22%2C%22countries%22%3A%22INDIA%22%7D&placements=pre-roll&placements=midroll-1");
      put("ADETCHPIXELTRACKER","/pixel-errors?ad_session_id=63f72f5a-7976-405f-a73b-71d382ddd66d&video_session_id=session1&device_id=d1&campaign_id=01bce50f-f945-4e5e-8fe0-6adb05a21f78&expiration=1702473724917&auth_code=bb2e5e6b76e6e5691f5aae87ae7ff471cb302c447287cd2ebc30297cc4bad3b6&creative_id=5cedfd7a-100a-47c0-9aa1-fa6387f7bd55&errorType=[ERRORTYPE]&errorCode=[ERRORCODE]&errorMessage=[ERRORMESSAGE]");
      put("ADETCHPIXELIMORESSION","/impression-pixels?ad_session_id=fb0bcf54-99ff-4646-acc9-ead4b5d0e219&video_session_id=session1&device_id=d1&campaign_id=01bce50f-f945-4e5e-8fe0-6adb05a21f78&expiration=1702291194350&auth_code=2bb5ac9e2f65a06ec2682126871cd6dead9ba57a3acfd73e87a4c4998da5a840&creative_id=f95d5064-34eb-4dea-b008-e9a7b42434f6");


      //PLANMANAGEMENT_PT
      put("POSTENTITLEMENT_planmgmt","/zee5-plan/plan-management/v1/entitlement");
      put("ENTITLEMENTBYID_planmgmt","/zee5-plan/plan-management/v1/entitlement/6406e5a14d452d6fab50d2e8");
      put("ENTITLEMENTPLANID_planmgmt","/zee5-plan/plan-management/v1/entitlement/plan/0-11-3287");
      put("PUTENTITLEMENT_planmgmt","/zee5-plan/plan-management/v1/entitlement/63f5c056ff72d03801e72092");
      put("PUTANDGETPLANCONTROL_planmgmt","/zee5-plan/plan-management/v1/plan/testdeepfeb161");
      put("PRODUCTREFERENCE_planmgmt","/zee5-plan/plan-management/v1/product-reference?providerName=AmazonIAP&productReference=zee5_premium_pack_in_3m");
      put("POSTANDGETBYPLAN_planmgmt","/zee5-plan/plan-management/v1/plan");
      put("GETBYPLAN_planmgmt","/zee5-plan/plan-management/v1/plans?country_code=CA&plan_id=testdeepfeb161&platform_code=web");

      //PartnerIam
      put("GETSELFREGISTER_partner","/partner-iam/self-service/registration/api");
      put("GETSELFLOGIN_partner","/partner-iam/self-service/login/api?refresh=true");
      put("POSTSELFREGISTER_partner","/partner-iam/self-service/registration?flow=ID");
      put("POSTSELFLOGIN_partner","/partner-iam/self-service/login?flow=ID");

      //CommunicationWhatsapp
      put("POSTWHATSAPPNOTIFICATION_commwp","/comm-engine-api/communication-engine/api/v1/notification");
      put("GETWHATSAPPNOTIFICATION_commwp","/comm-engine-api/communication-engine/api/v1/notification/W_d3405cd9-e48d-433a-8617-ab225e65b2cb");

      //CommunicationSMS
      put("POSTCOMMSMS_commsms","/comm-engine-api/communication-engine/api/v1/notification");

      //Pack-Entitlement Subscription
			/*
			 * put("GETSUBSCRIPTION_packentitle",
			 * "/pack/pack-entitle/v1/subscription/1b7eeb3e-3b33-4d5e-88b1-938e5cb75a54");
			 * put("POSTSUBSCRIBEPLAYBACK_packentitle",
			 * "/pack/pack-entitle/v1/subscription/playback");
			 * put("POSTSUBSCRIBE_packentitle","/pack/pack-entitle/v1/subscription");
			 * put("PUTBYID_packentitle",
			 * "/pack/pack-entitle/v1/subscription/1b7eeb3e-3b33-4d5e-88b1-938e5cb75a54");
			 * put("PUTPLAYBACK_packentitle",
			 * "/pack/pack-entitle/v1/subscription/1eac4c55-d613-46bc-ac35-a59e36f0210a/playback"
			 * ); put("PATCH_packentitle",
			 * "/pack/pack-entitle/v1/subscription/3fa85f82-5717-4562-b3fc-2c963f66afa6");
			 * put("GETBYPLAYBACK_packentitle",
			 * "/pack/pack-entitle/v1/subscription/3fa85f64-5717-4562-b3fc-2c963f66afa6/playback"
			 * );
			 * put("POSTRENEWAL_packentitle","/pack/pack-entitle/v1/subscription/renewal");
			 * put("GETBYID_packentitle",
			 * "/pack/pack-entitle/v1/subscriptions?payment_provider=Adyen&order_id=1b7eeb3e-3b33-4d5e-88b1-938e5cb75a54&plan_id=0-11-3224"
			 * );
			 */
      
//      //VideoLikeDislike
//      put("GETUSERACTION_videolikedislike","/video-like-dislike/v1.0/video/getUserActionDetails?assetId=0-0-1234501011");
//      put("CREATELIKE_videolikedislike","/video-like-dislike/v1.0/video/createUserAction");

      //Mirage-B2B
      put("GENERATESSOTAG_mirage","/b2b-mirage/generateSSOTag");
      put("GETAUTHTOKEN_mirage","/b2b-mirage/getAuthToken");

      //partnerauth
      put("POSTCLIENT_partnerauth","/partner-authorization/client");
      put("PATCHANDGETCLIENTTEST_partnerauth","/partner-authorization/client/92e57d14-6c2a-485d-9526-123d8125dc4c");
      put("POSTCLIENTTOKEN_partnerauth","/partner-authorization/client/token");
      put("POSTINTROSPECT_partnerauth","/partner-authorization/client/introspect");

      //Games API
      put("GAMESFILTERALL","/games/filter?tag=action&page=1&item_limit=20&translation=en&country=IN&languages=hi%2Cen&version=11");
      put("GAMESALLOWEDTAGS","/games/filter/allowedTags");
      put("GAMESWITHSTREAK","/games/recentlyPlayed/withStreak");
      put("GAMESWITHOUTSTREAK","/games/recentlyPlayed/withoutStreak");
      put("DELETEGAMESWITHSTREAK","/games/recentlyPlayed/withStreak/0-101-10z579580");
      put("DELETEGAMESWITHOUTSTREAK","/games/recentlyPlayed/withoutStreak/0-101-10z579580");
      put("USERDATAQUESTION","/games/userdata/question");
      put("CREATEDATAENTRYGAMES","/games/data");
      put("CREATEFEEDBACKSUBMIT","/games/feedback/submit");
      put("CREATEFEEDBACKGETQUESTION","/games/feedback/getQuestions");
      put("DISCOUNTHYPERLINK","/games/engagement-games/puzzles/get-discount");
      put("USERDATASUBMIT","/games/userdata/submit");
      //x-access-token
      put("x-acesstoken","/token/platform_tokens");

    //Adtech Config
	    put("GETDISCOVERYREADINESS","/api/probes/readiness");	    
	    put("GETDISCOVERYHEALTHCHECK","/api/probes/liveness");
	    put("GETDISCOVERYCOMPONENTSUPPORTEDREGION","/api/discovery/VIDEO_ADS/supported-regions");
	    put("GETDISCOVERYALLAVAILABLEREGION","/api/discovery/region");
	    put("GETDISCOVERYAVAILABLECONFIGKEYS","/api/discovery/VIDEO_ADS/IN_CONFIG/config-keys");
	    put("GETDISCOVERYOPERATORS","/api/discovery/operators");
	    put("GETDISCOVERYCONFIGKEYFORMULATION","/api/discovery/VIDEO_ADS/SCC/GAM_VIDEO_AD_TAGS/config-params");
	    put("GETDISCOVERYCONFIGTYPE","/api/discovery/config-types");
	    put("GETDISCOVERYAdSERVERTYPE","/api/discovery/adservers");
	    put("GETDISCOVERYCOMPONENTTYPE","/api/discovery/components");
	    put("CREATEDEFAULMISC01","/api/scc");
	    put("FORCEDROP","/api/scc/force-drop/VIDEO_ADS/IN_CONFIG/VIDEO_ADS:GAM_COMPANION_AD_TAGS:LIVE:DEFAULT:ANDROID_MOBILE");
	    put("FLUSHCONFIGCACHE","/api/scc/flush/VIDEO_ADS/IN_CONFIG/GAM_COMPANION_AD_TAGS");
	    put("FLUSHCONFIG","/api/scc/flush/VIDEO_ADS/IN_CONFIG");
	    put("DISABLECONFIG","/api/scc/disable/VIDEO_ADS/IN_CONFIG/VIDEO_ADS:GAM_COMPANION_AD_TAGS:LIVE:DEFAULT:ANDROID_MOBILE");
	    put("RELOADCONTEXT","/api/scc/reload/VIDEO_ADS/IN_CONFIG/GAM_VIDEO_AD_TAGS");
	    put("RELOADCONFIG","/api/scc/reload/VIDEO_ADS/IN_CONFIG");
	    put("GETDETAILS","/api/scc/details/VIDEO_ADS/IN_CONFIG/VIDEO_ADS:GAM_COMPANION_AD_TAGS:LIVE:DEFAULT:IOS");
	    put("GETALLCONFIG","/api/scc/list/VIDEO_ADS/IN_CONFIG/GAM_COMPANION_AD_TAGS");
	    put("ADTECHCONFIGENDPOINT","/api/scc/IN_CONFIG");
	    put("DEFAULT_MISC","/api/scc/IN_CONFIG");
	    put("GetDetails","/api/scc/details/VIDEO_ADS/IN_CONFIG/VIDEO_ADS:GAM_COMPANION_AD_TAGS:LIVE:DEFAULT:IOS");
	    put("USERADTECH","/api/user");
	    put("GETUSERIDADTECH","/api/user/2");
	    put("GETUSERNAMEADTECH","/api/user/username/wapsa");
	    put("DELETEUSERIDADTECH","/api/user/1");
	    put("DELETEUSERNAMEADTECH","/api/user/username/wapsa");
	    put("AUTHENTICATEADTECH","/authenticate");
	    put("GENERATEPASSWORDADTECH","/api/utility/password-hash/dev@123");
	    put("GETDISCOVERYOPERATORS","/api/discovery/operators");
	    put("UPLOADVIDEOCREATIVE","/api/creative/{{redis_env}}/upload");
	    put("UPLOADURLCREATIVE","/api/creative/{{redis_env}}/upload");
	    put("REPLICATERECORDCREATIVE","/api/creative/{{redis_env}}/replicate/d0676e1f-e1f0-40f3-aab4-5eaaa3d2b8ed/AWS_IN_BETA_CONFIG");
	    put("GETALLCREATIVEADS","/api/creative/{{redis_env}}");
	    put("UPDATECREATIVEADS","/api/creative/{{redis_env}}/060d874b-3ea4-455b-ba31-e0e521689ef8");
	    put("GETALLTARGET","/api/creative/targets");
	    put("GETALLPLACEMENT","/api/creative/placements");

      //Solr_fastify
      put("GETCOLLECTION","/content/collection/0-8-4098?page=1&limit=5&item_limit=20&version=10");
      put("COLLECTIONNEWS","/content/collection/0-8-626?version=12&page=1&limit=5&item_limit=20&country=IN&translation=en&languages=en,ta,ml");
      put("COLLECTIONMUSIC","/content/collection/0-8-2707?page=1&limit=5&item_limit=20&country=IN&translation=en&languages=en,hi,mr&version=10");
      put("COLLECTIONHOMEPAGE","/content/collection/0-8-homepage?country=IN&page=1&translation=en&version=13&limit=20&item_limit=20&languages=en,ta,ml");
      put("COLLECTIONHOICHOI","/content/collection/0-8-homepage?page=1&limit=5&item_limit=20&translation=hi,kn&languages=en,hi,mr&version=2&country=IN");
      put("COLLECTIONHOMEPAGEADDON","/content/collection/0-8-3z580697?page=1&limit=5&item_limit=20&translation=hi,kn&languages=en,hi,mr&version=2&country=US");
      put("COLLECTIONAHA","/content/collection/0-8-3z580697?page=1&limit=5&item_limit=20&translation=hi,kn&languages=en,hi,mr&version=2&country=US");
      put("COLLECTIONTVSHOWS","/content/collection/0-8-tvshows?page=1&limit=5&item_limit=20&languages=mr&version=13&country=IN&translation=hi&test=dsd");
      put("COLLECTIONTVSHOWSMORE","/content/collection/0-8-3z578321?page=1&limit=5&item_limit=20&country=IN&translation=en&languages=en,hi,mr&version=10");
      put("COLLECTIONMOVIES","/content/collection/0-8-movies?page=1&limit=5&item_limit=20&country=IN&translation=en&languages=en,hi,mr&version=10");
      put("COLLECTIONPREMIUMCONTENTS","/content/collection/0-8-premiumcontents?page=1&limit=5&item_limit=20&country=IN&translation=en&languages=en,hi,mr&version=10");
      put("COLLECTIONZEEPLEX","/content/collection/0-8-8072?page=1&limit=5&item_limit=20&country=IN&translation=en&languages=en&version=10");
      put("COLLECTIONPLAY","/content/collection/0-8-3z579470?page=1&limit=5&item_limit=20&country=IN&translation=en&languages=en,hi,mr&version=10");
      put("COLLECTIONWEBSERIES","/content/collection/0-8-6449?page=1&limit=5&item_limit=20&country=IN&translation=en&languages=en,hi,mr&version=10");
      put("COLLECTIONVIDEOS","/content/collection/0-8-videos?page=1&limit=5&item_limit=20&country=IN&translation=en&languages=en,hi,ta&version=13");
      put("COLLECTIONCHANNEL","/content/collection/0-8-4107?page=1&limit=5&item_limit=20&country=IN&translation=en&languages=en,hi,mr&version=10");
      put("COLLECTIONKIDS","/content/collection/0-8-3673?page=1&limit=5&item_limit=20&country=IN&translation=en&languages=en,hi,mr&version=10");
      put("COLLECTIONEDURAA","/content/collection/0-8-8514?page=1&limit=5&item_limit=20&country=IN&translation=en&languages=en,hi,ta&version=13");

    //user-setting-mssql
      put("ADDUSERSETTINGS","/settings?is_profile_required=2&current_profile_id=e4c162f7-ccff-413c-bb59-b21e95e2e99d");
      put("GETUSERSETTINGS","/settings?is_profile_required=2&current_profile_id=e4c162f7-ccff-413c-bb59-b21e95e2e99d&key=prema");
      put("UPDATEUSERSETTINGS","/settings?is_profile_required=2&current_profile_id=e4c162f7-ccff-413c-bb59-b21e95e2e99d");
      put("DELETEUSERSETTINGS","/settings?key={keyName}&is_profile_required=2&current_profile_id=e4c162f7-ccff-413c-bb59-b21e95e2e99d");

      //Metadataservice
      put("METADATADOMAINSERVICE","/v1?translation=hi&asset_ids=0-6-510&country=in");

      //NotificationService
      put("GETNOTIFICATION","/mw/notification/test");
      put("POSTNOTIFICATION","/mw/notification/email");

      //ContentDashboard
      put("CONTENTDASHBOARD","/content-dashboard/zee5dashboard");

      //Launch API Vertex
      put("LAUNCHAPIVERTEX","/launch?ccode=US&version=5&country=US");

        //CRM-Customer service
        put("CRMCustomer","/cs-crm-customer/crm-customer/customer/detail");

        //GWAPIDASHBOARD-be
      put("LOGIN","/login");
      put("UPDATETTL","/update_ttl/tv_shows?ttl=86455&ttl_set=86455&premium_ttl=86455&reco_ttl=86455");
      put("CACHINGCONTENTGENRE","/content/content_genre/movie");
      put("DETAILS","/content/details/show");
      put("TVSHOWAPIS","/content/tv_shows/show");
      put("CONTENTGENERE","/content/tv_shows/show");
      put("NEXTPREVIOUS","/content/tv_shows/show");
      put("APIRULES","/cache/clear/CONTENT_GENRE");
      put("APIRULESTVSHOWS","/cache/clear/TV_SHOWS");
      put("APIRULESNEXTPREVIOUS","/cache/clear/TV_SHOWS");
      put("APIRULESDETAILS","/cache/clear/DETAILS");

      //GCPPlayback
      put("AKAMAI","/search?languages=hi&country=IN&q=kumkum");
      put("V3SEARCH","/v3/search?languages=hi%2Cen%2Cmr&q=akbar&country=IN&limit=10&age=10");
      put("GCPCONTENTSEARCH","/search?languages=hi&country=IN&q=kumkum");
      put("GCPQUERYSUGGEST","/querySuggest?version=9&limit=20&q=kum&page=0");
      put("TOPHIT","/tophits?country=INDIA&version=7&limit=9&languages=hi&city=Karnatka&state=Bangalore&age=16&test12=test1");

      //Zee5Invoice
      put("GETactuator_health","/zee5-invoice/invoice-mgmt/actuator/health");
      put("GETpurchase","/zee5-invoice/invoice-mgmt/v1/purchase?user_token=zts&format=pdf&subscription_id=d697d400-6cc9-4c79-a791-4fb51de0c465&payment_id=c92cd359-5c6e-11ee-ade9-3917fd9c96f3");
      put("Purchase","/zee5-invoice/invoice-mgmt/v1/purchase?subscription_id=d697d400-6cc9-4c79-a791-4fb51de0c465&payment_id=c92cd359-5c6e-11ee-ade9-3917fd9c96f3");

      //UserCommentNode
      put("createComment","/comment/createComment");
      put("getAllComment","/comment/getAllComment?assetId=12&page=0&listType=latest");
      put("updateComment","/comment/updateComment");
      put("deleteComment","/comment/deleteComment");
      put("createReply","/comment/createComment");
      put("getReply","/comment/getAllReply?page=0&assetId=12&postNumber=11");
      put("updateReply","/comment/updateComment");
      put("deleteReply","/comment/deleteComment");
      put("createLikeAction","/likeAction/createLikeAction");
      put("deleteLikeAction","/likeAction/deleteLikeActions");

      //Zee5Themis
      put("PAYMENTRULES","/rules/payment");
      put("ADDRULES","/rules/");
      put("GETRULESBYNAMESPACE","/rules/?namespace=PAYMENT");
      put("PAYMENTMETHOD","/paymentmethod");
      put("GETRULESBYID","/rules/10cdd008-4bb6-4653-8115-231647133a03");

      //UserFeatureList
      put("USERFEATUREHEALTH_userfeature","/userFeatureList/user-feature/actuator/health");
      put("GETFEATURELIST_userfeature","/userFeatureList/user-feature/v1/getFeatureList");
      put("UPDATEFEATURE_userfeature","/userFeatureList/user-feature/v1/updateFeatureList?featureList=UserComments,UserReaction");
      put("UPDATEALLFEATURE_userfeature","/userFeatureList/user-feature/v1/updateAll?featureList=UserComments,Tambola");
      put("DELETEFEATURE_userfeature","/userFeatureList/user-feature/v1/deleteFeatureListForAll");
	    put("VERIFYCONTENTDASHBOARD","/content-dashboard/zee5dashboard/verify");
	    put("GETCONTENTDASHBOARD","/content-dashboard/zee5dashboard");
	    put("BEFORETVADD","/content-dashboard/zee5dashboard/beforetv/add");
	    put("BEFORETVFILTER","/content-dashboard/zee5dashboard/beforetv-filter");
	    put("CHANGEUSEREMAIL","/v1/user/changeEmail");
	    put("CHANGEUSEREPHONENUMBER","/v1/user/changePhoneNumber");
	    put("GETUSERTOKEN","/v1/user/getUserToken");
	    put("GETUSER","/v1/user");
	    put("SENDOTP","/v1/user/sendotp");
	    //WatchHistory Connector
	    put("UpdateWatchHistory","/api/v1/watchhistory");
	    put("WATCHSTATUS","/watch/status?asset_ids=0-0-101641");
	    put("DeleteWatchHistory","/watchhistory/delete?id=0-0-101641");
	    put("CONTINUEWATCH","/continuewatching?user_id=1E03B0CA-33F4-4D00-B935-3C2F6FE9869C&asset_id=0-0-101641");
	    put("CONCURRENTUSERSESSION","/sessions/user/1E03B0CA-33F4-4D00-B935-3C2F6FE9869C");
	    //MW DataProcess
	    put("TIGGER","/dataprocess/test/process/0-1-6z573117");
	    put("HEALTHCHECK","/dataprocess/test");
	    put("REDISTEST","/imageprocess/test/cache");
	    //MW Image process
	    put("IMAGEPROCESSHEALTHCHECK","/imageprocess/test");
	    put("IMAGEPROCESSTIGGER","/imageprocess/test/process/0-1-6z573117");
	    
	    //VideoAds Vertx
	    put("VIDEOADSPOST","/videoAds");
	    put("VIDEOADSGET","/videoAds/probes/liveness"); 
	    
	    //Games API
	    put("GAMESFILTERALL","/games/filter?tag=all&page=1&item_limit=20&translation=en&country=IN&languages=hi%2Cen&version=13");
	    put("GAMESFILTERCASUAL","/games/filter?tag=casual&page=1&item_limit=20&translation=en&country=IN&languages=hi%2Cen&version=13");
	    put("GAMESFILTERPUZZLE","/games/filter?tag=Puzzle&page=1&item_limit=20&translation=en&country=IN&languages=hi%2Cen&version=13");
	    put("GAMESFILTERARCADE","/games/filter?tag=Arcade&page=1&item_limit=20&translation=en&country=IN&languages=hi%2Cen&version=13");
	    put("GAMESFILTERALLACTION","/games/filter?tag=Action&page=1&item_limit=20&translation=en&country=IN&languages=hi%2Cen&version=13");
	    put("GAMESFILTERALLSPORTS","/games/filter?tag=Sports&page=1&item_limit=20&translation=en&country=IN&languages=hi%2Cen&version=13");
	    put("GAMESALLOWEDTAGS","/games/filter/allowedTags?page=1&item_limit=20&translation=hi&country=IN&languages=en&version=13");
	    put("GAMESWITHSTREAK","/games/recentlyPlayed/withStreak");
	    put("GAMESWITHOUTSTREAK","/games/recentlyPlayed/withoutStreak");
	    
	    //Audio Ads
	    put("AUDIOADS","/audioAds?content_id=51733765&country=IN&device_id=74b83f08-4396-4f58-9c79-a1339962bd70&app_version=2.51.41&age_group=25-32&gender=Male&platform_name=android_mobile&age=20");
	    
	    //Display Ads
	    put("v1_appleApp","/singlePlayback/displayAds?state=MH&country=GB&platform_name=apple_app&user_type=guest&ppid=zUtiLbdKYBS4T0xUl9vk000000000000&uid=a2a98898-d776-47ec-9f3d-82538c61c2bf&gender=@@@@&age_group=756756757fggf&content_id=0-0-khalnayak12");	    
	    put("v2_android_mobile","/singlePlayback/v2/displayAds?state=MH&country=GB&platform_name=android_mobile&user_type=guest&ppid=zUtiLbdKYBS4T0xUl9vk000000000000&uid=a2a98898-d776-47ec-9f3d-82538c61c2bf&gender=@@@@&age_group=756756757fggf&content_id=0-0-khalnayak12");
	    put("v3_desktopWeb","/singlePlayback/displayAds/v3?state=MH&country=UK&platform_name=desktop_web&user_type=guest&ppid=zUtiLbdKYBS4T0xUl9vk000000000000&uid=a2a98898-d776-47ec-9f3d-82538c61c2bf&gender=@@@@&age_group=756756757fggf&content_id=0-0-khalnayak12"); 

	    
	    put("GETCACHE","/caps/cache/get?cacheName=CACHE_ZEE_GENERIC_MODEL");
	    put("GOALMAPPING","/caps/debug/goal-mappings?lid=18");
	    put("LOADCACHE","/caps/cache/load?cacheName=CACHE_ZEE_GENERIC_MODEL");
	    put("SYNCAUDIENCE","/caps/api/syncAudience?adServerType=1&audienceType=2&customAudKey=12520672");
	    put("LINEITEM","/caps/api/syncLineItemGet?adServerType=1&numberOfHours=24");
	    put("SYNCCLIENT","/caps/api/syncClient?adServerType=1");
	    put("SYNCCUSTOMAUDIENCEDIMENSIONDATA","/caps/api/syncDimensionData?adServerType=1&optimizationType=3&numberOfDays=7");
	    put("SYNCLINEITEMCUSTOMEAUDIENCEDATA","/caps/api/syncLineItemDimensionData?adServerType=1&numberOfDays=7&optimizationType=3");
	    put("OPTIMIZELINEITEMCUSTOM","/caps/api/optimize?adServerType=1&optimizationType=3");
	    put("ADSERVERCONFIGVALUES","/caps/debug/config?key=OPTIMIZATION_ENABLE&adServerType=5");
	    put("CHECKUPDATEMODEL","/caps/api/checkUpdateModel");
	    put("ADDSECRET","/caps/secret/add-secret?secretName=zee5.adtech.token.details");
	    put("SECRETDETAILS","/caps/secret/fetch-secret-details?secretName=zee5.adtech.token.details");
	    put("ADDSECRETKEYS","/caps/secret/add-secret-key?secretName=zee5.adtech.token.details");
	    put("SECRETKEYSDETAILS","/caps/secret/fetch-secret-keys?secretName=zee5.adtech.eh.details");
	    put("CAPSHEALTH","/caps/health");
	    
	   
	   //LAUNCH API
	    put("COUNTRYCODE","/launch?ccode=US&version=5&country=US");
	    
	    //User PROFILE
	    put("ALLUSERPROFILE","/v1/profiles");
	    put("SINGLEUSERPROFILE","/v1/profiles?profile_id=94688af4-fb2f-450f-9ec0-17466350a3e0");
	    put("LASTUSEDUSERPROFILE","/v1/profiles/lastUsedProfile");
	    put("CREATEDEFAULTUSER","/v1/profiles/defaultProfile");
	    put("CREATESINGLEUSERPROFILE","/v1/profiles");
	    put("UPDATESINGLEPROFILE","/v1/profiles");
	    put("UPDATELASTUSEDUSERPROFILE","/v1/profiles/lastUsedProfile");
	    put("SINGLEUSERDETAILS","/v1/users");
	    put("DELETEUSER","/v1/profiles?profile_id=0ebc4757-fdd0-452f-b7db-d8d60f222911");
	    put("GETSINGLEPROFILE","/v1/profiles?profile_id={profileId}");
	    
	   //LAUNCH API
	    put("COUNTRYCODE","/launch?ccode=US&version=5&country=US");
	    
	   //WATCHLIST
	    put("WATCHLISTENDPOINT","/v1/watchlist");
	    put("WATCHLISTENDPOINTASSETDELETE","/v1/watchlist?id=0-0-1z51489847&asset_type=0");
	   
	        	
	    //UserToken
	    put("USERDEVICELOGOUT","/device/devices/6fc134db-c8a9-4504-a2d4-e23df0c51bf/audit");
	    put("USERDEVICE","/token/users/F1FFF243-B8F9-4458-A5C0-372BF87ACB6B/devices");
	    put("USERSENDOTP","/v1/user/sendotp");
	    put("USERTOKENGENERATE","/token/generate");
	    put("USERTOKENGENERATEVERIFY","/token/verifyToken");
	    put("USERTOKENGETCLAIM","/token/getClaims");
	    put("USERTOKENRENEW","/usertokenservice/token/renewToken");
	    put("USERDEVICECODE","/v1/user/getcode");
	    put("ADDEDUSERDEVICECODE","/v1/user/verifycode");
	    
	    //GuestScylla
	    put("GUESTSCYLLAUSERDETAILSUPDATE","/v1/guest");
	    put("GUESTSCYLLAUSERDETAILS","/v1/guest");
	    put("GUESTSCYLLAUSERDETAILSUPDATEWITHNEWTOKEN","/v1/guest");
	    
	    //TokenVerification
	    put("TOKENVERIFICATIONGVERIFYTOKENV1","/verify_token/v1/user/verifyToken");
	    put("TOKENVERIFICATIONGVERIFYTOKENV2","/verify_token/v2/user/verifyToken");
	    put("TOKENVERIFICATIONGVERIFYTOKEN","/verify_token");
	    
	
	    //GuestGenerator
	    put("GUESTGENERATORGENERATETOKEN","/guest_generator/user");
	    
	    //WatchlistUserActivity
	    put("WATCHLISTUSERACTIVITYADDACTIVITY","/v1/watchlist?asset_id=0-1-234");
	    put("WATCHLISTUSERACTIVITYGETACTIVITY","/v1/watchlist");
	    put("WATCHLISTUSERACTIVITYDELETEACTIVITY","/v1/watchlist?asset_id=0-1-234");
	    put("WATCHLISTUSERACTIVITYTOGGLEACTIVITY","/toggle/v1/like");
	    
	  //WatchlistUserAgregator
	    put("WATCHLISTUSERAGREGATORADDAGREGATOR","/v1/watchlist");
	    put("WATCHLISTUSERAGREGATORGETAGREGATORV1","/v1/watchlist");
	    put("WATCHLISTUSERAGREGATORGETAGREGATORV2","/v2/watchlist?translation=en&country=IN");
	    put("WATCHLISTUSERAGREGATORDELETEAGREGATOR","/v1/watchlist?id=0-1-6z5227266");

        //mrss-feed
        put("MRSS_FEED","/Adtech/mrss/new-mrssfeed?dai_mrss=phone&show_id=1&content_id=1&page=1");

        //CS-Help
	    put("TOPICID","/cs/self-help/topic?topicId=1.1.2.1&lang=en&company=ZEEL&publisher=Zee5&userType=Premium&countryCode=IN&region=DL");
	    put("PARENTTOPICID","/cs/self-help/topic/sub?parentTopic=1.1.2&lang=en&company=ZEEL&publisher=Zee5");
	    put("HOMETOPICID","/cs/self-help/topic/home?lang=en&company=ZEEL&publisher=Zee5");
	    put("FAQ","/cs/self-help/topic/faq?lang=en&company=ZEEL&publisher=Zee5&countryCode=IN&region=DL&userType=Premium");
	    put("STATICPAGE","/cs/self-help/static?ccode=IN&text_type=about-us&lang=en");
	   	        
	    
	  //zee5orderservice
	    put("ACTUATOR_zee5order","/zee5-order/order-srv/actuator");
	    put("ACTUATORHEALTH_zee5order","/zee5-order/order-srv/actuator/health");
	    put("ACTUATORDER_zee5order","/zee5-order/order-srv/v1/order/2531c428-a6e3-4232-b6f7-673bbb6944b0");
	    put("POSTORDER_zee5order","/zee5-order/order-srv/v1/order");
	    put("COUPON_zee5order","/zee5-order/order-srv/v1/churn-arrest/coupon");
	    put("GETCHURN_zee5order","/zee5-order/order-srv/v1/churn-arrest/coupon/14e480ae-5459-4ad0-ab68-0618cfe15d78");
	    put("PATCHCHURN_zee5order","/zee5-order/order-srv/v1/churn-arrest/coupon/14e480ae-5459-4ad0-ab68-0618cfe15d78");
	    put("PROMOTION_zee5order","/zee5-order/order-srv/v1/order/promotion/details?product_id=23&order_id=554f1c2a-25f6-43ca-8d0a-6921c42be159");
	    put("POSTHISTORY_zee5order","/zee5-order/order-srv/v1/order/history");
	    put("GETCARTABAN_zee5order","/zee5-order/order-srv/v1/order/cartAbandonment");
	    put("GETPROMOTION_zee5order","/zee5-order/order-srv/v1/promotion?user_id=d3bc15ad-c448-40d6-9239-d32ae9ee3bd8&promo_code=string");
	    put("PATCHORDER_zee5order","/zee5-order/order-srv/v1/order/");
	    put("POSTTAX_zee5order","/zee5-order/order-srv/v1/order/tax");
	    put("GETTAX_zee5order","/zee5-order/order-srv/v1/order/tax?order_id=14e480ae-5459-4ad0-ab68-0618cfe15d78&type=CREDIT");
	    put("POSTAGGREGATOR_zee5order","/zee5-order/order-srv/v1/domain-aggregator");
	    put("GETORDER_zee5order","/zee5-order/order-srv/v1/orders");
	    put("GETORDERBYDATE_zee5order","/zee5-order/order-srv/v1/order/orders-by-date?country_code=IN&payment_provider=string hello 12h");
	    
	    
	  //subscription ingestion
	    put("UPLOAD_subscriptioning","subingestion/neoteric/register/upload");
	    put("GETBATCHDETAIL_subscriptioning","/subingestion/neoteric/register/getBatch/4028540d884463e501884468b8fb0001");    	    
	    put("POSTSUBSCRIBE","/pack-entitle/v1/subscription");
	    put("GETSUBSCRIPTION","/pack-entitle/v1/subscriptions?payment_provider=Adyen&order_id=1b7eeb3e-3b33-4d5e-88b1-938e5cb75a54&plan_id=0-11-3224");
	    put("GETBYID","/pack-entitle/v1/subscription/1b7eeb3e-3b33-4d5e-88b1-938e5cb75a54");
	    put("PUTBYID","/pack-entitle/v1/subscription/1eac4c55-d614-46bc-ac35-a59e36a0210b");
	    put("PATCH","/pack-entitle/v1/subscription/3fa85f82-5717-4562-b3fc-2c963f66afa6");
	    put("POSTRENEWAL","/pack-entitle/v1/subscription/renewal");
	    put("PLAYBACK","/pack-entitle/v1/subscription/playback");
	    put("GETPLAYBACK","/pack-entitle/v1/subscription/3fa85f64-5717-4562-b3fc-2c963f66afa6/playback");
	    put("UPDATEPLAYBACK","/pack-entitle/v1/subscription/1eac4c55-d613-46bc-ac35-a59e36f0210a/playback");

	  //subscriptionrulebook
	    put("REFERRER_subrulebook","/subscriptionRuleBook/subscription-rule-book/api/v1/rules/referrer");
	    put("REFEREE_subrulebook","/subscriptionRuleBook/subscription-rule-book/api/v1/rules/referee");
	    put("COHORT_subrulebook","/subscriptionRuleBook/subscription-rule-book/api/v1/rules/cohort");
	    put("CLP_subrulebook","/subscriptionRuleBook/subscription-rule-book/api/v1/rules/clp");
	    put("COUPON_subrulebook","/subscriptionRuleBook/subscription-rule-book/api/v1/rules/coupon");
	    //put("PAYMENT_subrulebook","/subscription-rule-book/api/v1/rules/payment");
	    put("GETV1RULE_subrulebook","/subscriptionRuleBook/subscription-rule-book/api/v1/rules?namespace=CHURN_ARREST_COUPON");
	    put("POSTV1RULE_subrulebook","/subscription-rule-book/api/v1/rules");
	    //put("DELETEV1RULE_subrulebook","/subscription-rule-book/api/v1/rules/7dce6d1f-e03e-40b7-9f7d-55cd6a2c803e");
	    //put("GETIDRULE_subrulebook","/subscription-rule-book/api/v1/rules/bf0a4e46-73aa-4e3f-bd5f-203792d0f76f");

	    //PLANMANAGEMENT_PT
	    put("POSTENTITLEMENT_planmgmt","/plan-management/v1/entitlement");
	    put("ENTITLEMENTBYID_planmgmt","/plan-management/v1/entitlement/6406e5a14d452d6fab50d2e8");
	    put("ENTITLEMENTPLANID_planmgmt","/plan-management/v1/entitlement/plan/0-11-3287");
	    put("PUTENTITLEMENT_planmgmt","/plan-management/v1/entitlement/63f5c056ff72d03801e72092");
	    put("PUTANDGETPLANCONTROL_planmgmt","/plan-management/v1/plan/testdeepfeb161");
	    put("PRODUCTREFERENCE_planmgmt","/plan-management/v1/product-reference?providerName=Play Store&productReference=zee5_1y_premium_svod_ar_global");
	    put("POSTANDGETBYPLAN_planmgmt","/plan-management/v1/plan");
	    put("GETBYPLAN_planmgmt","/plan-management/v1/plans?country_code=CA&plan_id=testdeepfeb161&platform_code=web");
	    
	      
	  //POE_UAT
	    put("ORDERMGMT_POE","/zee5-purchase-order-engine/order-mgmt/v1/checkout");
	    put("ORDERMGMTPAYMENT_POE","/zee5-purchase-order-engine/order-mgmt/olm-hook/v1/order-payment");
	    put("ORDERBFF_POE","/order-bff/v1/checkout");
	    put("GLOBALCHECKOUT_POE","/zee5-purchase-order-engine/order-mgmt/v1/global-checkout/order");
	    put("GETORDERMGMTALL_POE","/zee5-purchase-order-engine/order-mgmt/v1/getAll/48107bd6-73b5-4064-951b-b7937f9aef97");
	    put("GETORDERMGMTPROMOTE_POE","/zee5-purchase-order-engine/order-mgmt/v1/promotion?user_id=f8838fae-30eb-430a-bcf5-9d5ffa55852c&promo_code=GET99");
	    put("GETORDERMGMTMANDATE_POE","/zee5-purchase-order-engine/order-mgmt/v1/mandate/9c437de0-adeb-40ea-8178-38db95fc63ee");
	    put("GETORDERMGMT_POE","/zee5-purchase-order-engine/order-mgmt/v1/48107bd6-73b5-4064-951b-b7937f9aef97");
	    put("GETV1ORDERMGMT_POE","/zee5-purchase-order-engine/order-mgmt/v1");
	    
	    //CS-Content API
	    put("CONTENTAPITVSHOWGENRELIST","/seo/tvshowGenreList?languages=hi,ta,te,ml,en&translation=ta&country=in&limit=5&page=1&genre=drama&asset_subtype=zee5original");
	    put("CONTENTAPIMOVIEGENRE","/seo/movieGenre?language=hi&translation=en&country=IN&genre=action&page_size=25&page=1&sort_by_field=release_date&sort_order=desc&business_type=free");
	    put("CONTENTAPIPARTNERFEEDCONTENTLISTING","/partnerFeeds/listing?type=episode&page=1&limit=25&third_party_name=Xiaomi");
	    put("CONTENTAPINEWSRELATED","/news/related?limit_limit=25&page=1&content_owner=Zee");
	    put("CONTENTAPIEXTRACTPLATFORMURL","/getPlatformUrl?asset_subtype=tvshow&date=16&month=04&year=2014");
	    put("CONTENTAPITVSHOWHOME","/seo/tvshowHome?languages=hi,kn,te&country=in&translation=hi&page=1&limit=25&internal_test=1&asset_subtype=zee5original");
	    put("CONTENTAPIMOVIELANGUAGES","/seo/movieLanguage?translation=en&country=IN&genres=crime&page_size=25&page=1&sort_by_field=release_date&sort_order=desc&business_type=free");
	    put("CONTENTAPITVSHOWGENRE","/seo/tvshowGenre?page=1&asset_subtype=tvshow&language=ta&translation=en&country=IN&limit=25");
	    put("CONTENTAPISEOGENREORLANGUAGES","/seo/genres-languages?type=language&country=IN&asset_subtype=movies&language=hi%2Cen&genre=crime&ignore_lang=hi%2Cen&ignore_genre=action%2Cadventure&sort_order=asc");

	  //communicationengine
	    put("COMM_communicationeng","/comm-engine-api/communication-engine/api/v1/notification");
	    put("COMMNOTIFICATION_communicationeng","/comm-engine-api/communication-engine/api/v1/notification/E_2705f119-a2ed-4edd-9c42-f906eabfcc31");
	    
	  //TemplateEngine
	    put("GETETEMPLATE_communicationeng","/template-engine-api/template-engine/api/v1/template/TEMP00101016");
	    put("DELETETEMPLATECACHE_communicationeng","/template-engine-api/template-engine/cache/data");
	    put("ADDTEMPLATE_communicationeng","/template-engine-api/template-engine/api/v1/template");
	    put("DELETETEMPLATEDB_communicationeng","/template-engine-api/template-engine/api/v1/template/6000");
	    
	    // Adtech_PII
	    put("ADTECH_PII","/Adtech/adtech-pii/enriched-user-metadata?user_id=801b1aca-22a8-466c-b5e0-3cfd4efb064d");
	    

	   //communicationengine
	    put("COMM_communicationeng","/comm-engine-api/communication-engine/api/v1/notification");
	    put("COMMNOTIFICATION_communicationeng","/comm-engine-api/communication-engine/api/v1/notification/E_2705f119-a2ed-4edd-9c42-f906eabfcc31");
	    put("GETALLRULE_communicationeng","/rule-engine-api/rule-engine/api/v1/rule/ZEE5_SMS_1");
	    put("EMAILRULE_communicationeng","//rule-engine-api/rule-engine/api/v1/rule");
	    put("SPECIFICRULE_communicationeng","/rule-engine-api/rule-engine/api/v1/rule/ZEE5_WHATSAPP_2");
	    put("UPDATERULE_communicationeng","/rule-engine-api/rule-engine/api/v1/rule/ZEE5_EMAIL_10");
	    put("DELETERULECHANNEL_communicationeng","/rule-engine-api/rule-engine/api/v1/rules?tenant=ZEE5&channel=EMAIL");
	    put("DELETERULENAME_communicationeng","/rule-engine-api/rule-engine/api/v1/rule/ZEE5_SMS_3");
	    put("FETCH_communicationeng","/rule-engine-api/rule-engine/api/v1/fetch");
	    put("SMSRULE_communicationeng","/rule-engine-api/rule-engine/api/v1/rule/");
	    put("GETETEMPLATE_communicationeng","/template-engine-api/template-engine/api/v1/template/TEMP00101016");
	    put("DELETETEMPLATECACHE_communicationeng","/template-engine-api/template-engine/cache/data");
	    put("ADDTEMPLATE_communicationeng","/template-engine-api/template-engine/api/v1/template");
	    put("DELETETEMPLATEDB_communicationeng","/template-engine-api/template-engine/api/v1/template/6000");

	    // Adtech_PII
	    put("ADTECH_PII","/enriched-user-metadata?user_id=801b1aca-22a8-466c-b5e0-3cfd4efb064d");
	    
	    //Adtech-Diff  
	    put("AUTHENTICATEDIF","/authenticate");
	    put("RELOADCRON","/api/ssai-info/reload");
	    put("ENEBLEDISABLECRON","api/ssai-info/cron/enable");
	    put("SETSKIPPEDCHANNELS","/api/ssai-info/skip-channel-ids?id=78970");
	    put("GETALLSKIPPEDCHANNELS","/api/ssai-info/skip-channel-ids");
	    put("EVICTCHANNELID","/api/ssai-info/evict?id=0-9-339");
	    put("GETASSETINFO","/api/ssai-info/get-asset-info?id=0-9-201");
	    put("SETCUSTOMID","/api/ssai-info/set-custom-ids?id=0-9-zeenews&id=0-9-284,0-9-224&id=0-9-tvpictureshd");
	    put("GETCUSTOMID","/api/ssai-info/get-custom-ids");
	    put("HEALTHCHECK","/api/probes/liveness");
	    put("REDINESS","/api/probes/readiness"); 
	    
	    //Adtech-In-House
	    put("ADTECHINHOUSE","/raw-ad-playlist?device_id=d1&video_session_id=session1&user_targeting=%7B%22gender%22%3A%22male%22%2C%22agrGroup%22%3A%2218-24%22%2C%22countries%22%3A%22INDIA%22%7D&placements=pre-roll&placements=midroll-1");
	    put("ADETCHPIXELTRACKER","/pixel-errors?ad_session_id=63f72f5a-7976-405f-a73b-71d382ddd66d&video_session_id=session1&device_id=d1&campaign_id=01bce50f-f945-4e5e-8fe0-6adb05a21f78&expiration=1702473724917&auth_code=bb2e5e6b76e6e5691f5aae87ae7ff471cb302c447287cd2ebc30297cc4bad3b6&creative_id=5cedfd7a-100a-47c0-9aa1-fa6387f7bd55&errorType=[ERRORTYPE]&errorCode=[ERRORCODE]&errorMessage=[ERRORMESSAGE]");
	    put("ADETCHPIXELIMORESSION","/impression-pixels?ad_session_id=fb0bcf54-99ff-4646-acc9-ead4b5d0e219&video_session_id=session1&device_id=d1&campaign_id=01bce50f-f945-4e5e-8fe0-6adb05a21f78&expiration=1702291194350&auth_code=2bb5ac9e2f65a06ec2682126871cd6dead9ba57a3acfd73e87a4c4998da5a840&creative_id=f95d5064-34eb-4dea-b008-e9a7b42434f6");
	    
	    
	  //PLANMANAGEMENT_PT
	    put("POSTENTITLEMENT_planmgmt","/zee5-plan/plan-management/v1/entitlement");
	    put("ENTITLEMENTBYID_planmgmt","/zee5-plan/plan-management/v1/entitlement/6406e5a14d452d6fab50d2e8");
	    put("ENTITLEMENTPLANID_planmgmt","/zee5-plan/plan-management/v1/entitlement/plan/0-11-3287");
	    put("PUTENTITLEMENT_planmgmt","/zee5-plan/plan-management/v1/entitlement/63f5c056ff72d03801e72092");
	    put("PUTANDGETPLANCONTROL_planmgmt","/zee5-plan/plan-management/v1/plan/testdeepfeb161");
	    put("PRODUCTREFERENCE_planmgmt","/zee5-plan/plan-management/v1/product-reference?providerName=AmazonIAP&productReference=63j3iYEQ");
	    put("POSTANDGETBYPLAN_planmgmt","/zee5-plan/plan-management/v1/plan");
	    put("GETBYPLAN_planmgmt","/zee5-plan/plan-management/v1/plans?country_code=CA&plan_id=testdeepfeb161&platform_code=web");

	    //PartnerIam
	    put("GETSELFREGISTER_partner","/partner-iam/self-service/registration/api");
	    put("GETSELFLOGIN_partner","/partner-iam/self-service/login/api?refresh=true");
	    put("POSTSELFREGISTER_partner","/partner-iam/self-service/registration?flow=ID");
	    put("POSTSELFLOGIN_partner","/partner-iam/self-service/login?flow=ID");
	    
	    //CommunicationWhatsapp
	    put("POSTWHATSAPPNOTIFICATION_commwp","/comm-engine-api/communication-engine/api/v1/notification");
	    put("GETWHATSAPPNOTIFICATION_commwp","/comm-engine-api/communication-engine/api/v1/notification/W_d3405cd9-e48d-433a-8617-ab225e65b2cb");
	    
	    //CommunicationSMS
	    put("POSTCOMMSMS_commsms","/comm-engine-api/communication-engine/api/v1/notification");
	    
	    //Pack-Entitlement Subscription
	    put("GETSUBSCRIPTION_packentitle","/pack/pack-entitle/v1/subscription/1b7eeb3e-3b33-4d5e-88b1-938e5cb75a54");
	    put("POSTSUBSCRIBEPLAYBACK_packentitle","/pack/pack-entitle/v1/subscription/playback");
	    put("POSTSUBSCRIBE_packentitle","/pack/pack-entitle/v1/subscription");
	    put("PUTBYID_packentitle","/pack/pack-entitle/v1/subscription/1b7eeb3e-3b33-4d5e-88b1-938e5cb75a54");
	    put("PUTPLAYBACK_packentitle","/pack/pack-entitle/v1/subscription/1eac4c55-d613-46bc-ac35-a59e36f0210a/playback");
	    put("PATCH_packentitle","/pack/pack-entitle/v1/subscription/3fa85f82-5717-4562-b3fc-2c963f66afa6");
	    put("GETBYPLAYBACK_packentitle","/pack/pack-entitle/v1/subscription/3fa85f64-5717-4562-b3fc-2c963f66afa6/playback");
	    put("POSTRENEWAL_packentitle","/pack/pack-entitle/v1/subscription/renewal"); 
	    put("GETBYID_packentitle","/pack/pack-entitle/v1/subscriptions?payment_provider=Adyen&order_id=1b7eeb3e-3b33-4d5e-88b1-938e5cb75a54&plan_id=0-11-3224");
	    
	    //VideoLikeDislike
	    put("GETUSERACTION_videolikedislike","/video-like-dislike/v1.0/video/getUserActionDetails?assetId=0-0-1234501011");
	    put("CREATELIKE_videolikedislike","/video-like-dislike/v1.0/video/createUserAction");
	    
	    //Mirage-B2B
	    put("GENERATESSOTAG_mirage","/b2b-mirage/generateSSOTag");
	    put("GETAUTHTOKEN_mirage","/b2b-mirage/getAuthToken");
	    
	    //partnerauth
	    put("POSTCLIENT_partnerauth","/partner-authorization/client");
	    put("PATCHANDGETCLIENTTEST_partnerauth","/partner-authorization/client/92e57d14-6c2a-485d-9526-123d8125dc4c");
	    put("POSTCLIENTTOKEN_partnerauth","/partner-authorization/client/token");
	    put("POSTINTROSPECT_partnerauth","/partner-authorization/client/introspect");
	    
	    //Games API
	    put("GAMESFILTERALL","/games/filter?tag=action&page=1&item_limit=20&translation=en&country=IN&languages=hi%2Cen&version=11");
	    put("GAMESALLOWEDTAGS","/games/filter/allowedTags");
	    put("GAMESWITHSTREAK","/games/recentlyPlayed/withStreak");
	    put("GAMESWITHOUTSTREAK","/games/recentlyPlayed/withoutStreak");
	    put("DELETEGAMESWITHSTREAK","/games/recentlyPlayed/withStreak/0-101-10z579580");
	    put("DELETEGAMESWITHOUTSTREAK","/games/recentlyPlayed/withoutStreak/0-101-10z579580");
	    put("USERDATAQUESTION","/games/userdata/question");
	    put("CREATEDATAENTRYGAMES","/games/data");
	    put("CREATEFEEDBACKSUBMIT","/games/feedback/submit");
	    put("CREATEFEEDBACKGETQUESTION","/games/feedback/getQuestions");
	    put("DISCOUNTHYPERLINK","/games/engagement-games/puzzles/get-discount");
	    put("USERDATASUBMIT","/games/userdata/submit");
	    //x-access-token
	    put("x-acesstoken","/token/platform_tokens");
	    
	  //Adtech Config  
	  put("GETDISCOVERYREADINESS","/api/probes/readiness");	    
      put("GETDISCOVERYHEALTHCHECK","/api/probes/liveness");
      put("GETDISCOVERYCOMPONENTSUPPORTEDREGION","/api/discovery/VIDEO_ADS/supported-regions");
      put("GETDISCOVERYALLAVAILABLEREGION","/api/discovery/region");
      put("GETDISCOVERYAVAILABLECONFIGKEYS","/api/discovery/VIDEO_ADS/IN_CONFIG/config-keys");
      put("GETDISCOVERYOPERATORS","/api/discovery/operators");
      put("GETDISCOVERYCONFIGKEYFORMULATION","/api/discovery/VIDEO_ADS/SCC/GAM_VIDEO_AD_TAGS/config-params");
      put("GETDISCOVERYCONFIGTYPE","/api/discovery/config-types");
      put("GETDISCOVERYAdSERVERTYPE","/api/discovery/adservers");
      put("GETDISCOVERYCOMPONENTTYPE","/api/discovery/components");
      put("FORCEDROP","/api/scc/force-drop/VIDEO_ADS/IN_CONFIG/VIDEO_ADS:GAM_COMPANION_AD_TAGS:LIVE:DEFAULT:ANDROID_MOBILE");
      put("FLUSHCONFIGCACHE","/api/scc/flush/VIDEO_ADS/IN_CONFIG/GAM_COMPANION_AD_TAGS");
      put("FLUSHCONFIG","/api/scc/flush/VIDEO_ADS/IN_CONFIG");
      put("DISABLECONFIG","/api/scc/disable/VIDEO_ADS/IN_CONFIG/VIDEO_ADS:GAM_COMPANION_AD_TAGS:LIVE:DEFAULT:ANDROID_MOBILE");
      put("RELOADCONTEXT","/api/scc/reload/VIDEO_ADS/IN_CONFIG/GAM_VIDEO_AD_TAGS");
      put("RELOADCONFIG","/api/scc/reload/VIDEO_ADS/IN_CONFIG");
      put("GETDETAILS","/api/scc/details/VIDEO_ADS/IN_CONFIG/VIDEO_ADS:GAM_COMPANION_AD_TAGS:LIVE:DEFAULT:IOS");
      put("GETALLCONFIG","/api/scc/list/VIDEO_ADS/IN_CONFIG/GAM_COMPANION_AD_TAGS");
      put("ADTECHCONFIGENDPOINT","/api/scc/IN_CONFIG");
      put("DEFAULT_MISC","/api/scc/IN_CONFIG");
      put("AUTHENTICATEADTECH","/authenticate");
      put("GENERATEPASSWORDADTECH","/api/utility/password-hash/dev@123");


      //Solr_fastify
      put("GETCOLLECTION","/content/collection/0-8-4098?page=1&limit=5&item_limit=20&version=10");
      put("COLLECTIONNEWS","/content/collection/0-8-626?version=12&page=1&limit=5&item_limit=20&country=IN&translation=en&languages=en,ta,ml");
      put("COLLECTIONMUSIC","/content/collection/0-8-2707?page=1&limit=5&item_limit=20&country=IN&translation=en&languages=en,hi,mr&version=10");
      put("COLLECTIONHOMEPAGE","/content/collection/0-8-homepage?country=IN&page=1&translation=en&version=13&limit=20&item_limit=20&languages=en,ta,ml");
      put("COLLECTIONHOICHOI","/content/collection/0-8-homepage?page=1&limit=5&item_limit=20&translation=hi,kn&languages=en,hi,mr&version=2&country=IN");
      put("COLLECTIONHOMEPAGEADDON","/content/collection/0-8-3z580697?page=1&limit=5&item_limit=20&translation=hi,kn&languages=en,hi,mr&version=2&country=US");
      put("COLLECTIONAHA","/content/collection/0-8-3z580697?page=1&limit=5&item_limit=20&translation=hi,kn&languages=en,hi,mr&version=2&country=US");
      put("COLLECTIONTVSHOWS","/content/collection/0-8-tvshows?page=1&limit=5&item_limit=20&languages=mr&version=13&country=IN&translation=hi&test=dsd");
      put("COLLECTIONTVSHOWSMORE","/content/collection/0-8-3z578321?page=1&limit=5&item_limit=20&country=IN&translation=en&languages=en,hi,mr&version=10");
      put("COLLECTIONMOVIES","/content/collection/0-8-movies?page=1&limit=5&item_limit=20&country=IN&translation=en&languages=en,hi,mr&version=10");
      put("COLLECTIONPREMIUMCONTENTS","/content/collection/0-8-premiumcontents?page=1&limit=5&item_limit=20&country=IN&translation=en&languages=en,hi,mr&version=10");
      put("COLLECTIONZEEPLEX","/content/collection/0-8-8072?page=1&limit=5&item_limit=20&country=IN&translation=en&languages=en&version=10");
      put("COLLECTIONPLAY","/content/collection/0-8-3z579470?page=1&limit=5&item_limit=20&country=IN&translation=en&languages=en,hi,mr&version=10");
      put("COLLECTIONWEBSERIES","/content/collection/0-8-6449?page=1&limit=5&item_limit=20&country=IN&translation=en&languages=en,hi,mr&version=10");
      put("COLLECTIONVIDEOS","/content/collection/0-8-videos?page=1&limit=5&item_limit=20&country=IN&translation=en&languages=en,hi,ta&version=13");
      put("COLLECTIONCHANNEL","/content/collection/0-8-4107?page=1&limit=5&item_limit=20&country=IN&translation=en&languages=en,hi,mr&version=10");
      put("COLLECTIONKIDS","/content/collection/0-8-3673?page=1&limit=5&item_limit=20&country=IN&translation=en&languages=en,hi,mr&version=10");
      put("COLLECTIONEDURAA","/content/collection/0-8-8514?page=1&limit=5&item_limit=20&country=IN&translation=en&languages=en,hi,ta&version=13");

      //user-setting-mssql
      put("ADDUSERSETTINGS","/settings?is_profile_required=2&current_profile_id=e4c162f7-ccff-413c-bb59-b21e95e2e99d");
      put("GETUSERSETTINGS","/settings?is_profile_required=2&current_profile_id=e4c162f7-ccff-413c-bb59-b21e95e2e99d&key=prema");
      put("UPDATEUSERSETTINGS","/settings?is_profile_required=2&current_profile_id=e4c162f7-ccff-413c-bb59-b21e95e2e99d");
      put("DELETEUSERSETTINGS","/settings?key={keyName}&is_profile_required=2&current_profile_id=e4c162f7-ccff-413c-bb59-b21e95e2e99d");

      //Metadataservice
      put("METADATADOMAINSERVICE","/v1?translation=hi&asset_ids=0-6-510&country=in");

      //NotificationService
      put("GETNOTIFICATION","/mw/notification/test");
      put("POSTNOTIFICATION","/mw/notification/email");

      //ContentDashboard
      put("CONTENTDASHBOARD","/content-dashboard/zee5dashboard");

      //Launch API Vertex
      put("LAUNCHAPIVERTEX","/launch?ccode=US&version=5&country=US");

      //GWAPIDASHBOARD-be
      put("LOGIN","/login");
      put("UPDATETTL","/update_ttl/tv_shows?ttl=86455&ttl_set=86455&premium_ttl=86455&reco_ttl=86455");
      put("CACHINGCONTENTGENRE","/content/content_genre/movie");
      put("DETAILS","/content/details/show");
      put("TVSHOWAPIS","/content/tv_shows/show");
      put("CONTENTGENERE","/content/tv_shows/show");
      put("NEXTPREVIOUS","/content/tv_shows/show");
      put("APIRULES","/cache/clear/CONTENT_GENRE");
      put("APIRULESTVSHOWS","/cache/clear/TV_SHOWS");
      put("APIRULESNEXTPREVIOUS","/cache/clear/TV_SHOWS");
      put("APIRULESDETAILS","/cache/clear/DETAILS");

      //USER CONSENT
      put("USERCONSENTADDCONSENT","/v1/consents");
      put("USERCONSENTUPDATECONSENT","/v1/consents");
      put("USERCONSENTGETCONSENT","/v1/consents?userId=68a29249-4d84-40fe-b9a4-51f6c5907a81");


      //GCPPlayback
      put("AKAMAI","/search?languages=hi&country=IN&q=kumkum");
      put("V3SEARCH","/v3/search?languages=hi%2Cen%2Cmr&q=akbar&country=IN&limit=10&age=10");
      put("GCPCONTENTSEARCH","/search?languages=hi&country=IN&q=kumkum");
      put("GCPQUERYSUGGEST","/querySuggest?version=9&limit=20&q=kum&page=0");
      put("TOPHIT","/tophits?country=INDIA&version=7&limit=9&languages=hi&city=Karnatka&state=Bangalore&age=16&test12=test1");

      //SubscriptionIngestion
      put("SUBSCRIPTION_INGESTION_upload","/subingestion/neoteric/register/upload");
      put("SUBSCRIPTION_INGESTION_get_Batch","/subingestion/neoteric/register/getBatch/4028540d884463e501884468b8fb0001");
      //Reco-Adtech-CC
      put("Adtech_CC_LOADLATESTITEM","/cache/loadLatestContent");
      put("Adtech_CC_LOADITEMS","/cache/loadItem");
      put("Adtech_CC_LOADMETADATA","/cache/loadEpisodes");
      put("Adtech_CC_LOADGENERICMODEL","/cache/loadGenericModel");
      put("Adtech_CC_LOADADSERVERCONFIG","/cache/loadAdServerConfig");
      put("Adtech_CC_LOADADRULES","/cache/loadRules");
      put("Adtech_CC_LOADEXPRESSIONITEM","/cache/loadExpItem");
      put("Adtech_CC_GETCACHE","/cache/get?cacheName=CACHE_CONFIG_RULE");
      put("Adtech_CC_GETITEMCACHE","/cache/get?cacheName=CACHE_AD_CONFIG");
      put("Adtech_CC_GETITEMBYID","/debug/getItem?id=2799");
      put("Adtech_CC_GETCONTEXTUALITEM","/debug/getContextualItems?itemId=2183&langs=hi&version=1");
      put("Adtech_CC_CLEARCACHE","/cache/clear?cacheName=CACHE_CS");


      //UserFeatureList
      put("USERFEATUREHEALTH_userfeature","/userFeatureList/user-feature/actuator/health");
      put("GETFEATURELIST_userfeature","/userFeatureList/user-feature/v1/getFeatureList");
      put("UPDATEFEATURE_userfeature","/userFeatureList/user-feature/v1/updateFeatureList?featureList=UserComments,UserReaction");
      put("UPDATEALLFEATURE_userfeature","/userFeatureList/user-feature/v1/updateAll?featureList=UserComments,Tambola");
      put("DELETEFEATURE_userfeature","/userFeatureList/user-feature/v1/deleteFeatureListForAll");

      //USER DEVICE MANAGEMENT 
        put("USERDEVICEMANAGEMENTGETUSERDEVICEDETAILS","/device/users/devices");
        put("USERDEVICEMANAGEMENTGETDEVICEDETAILS","/device/devices?ids=q2DSkY6pyZomFdzrJFYi000000000000");
        put("USERDEVICEMANAGEMENTGETUSERDEVICEPLAYBACKDETAILS","/device/devices/playback?ids=74b83f08-4396-4f58-9c79-a1339962bd70");
        put("USERDEVICEMANAGEMENTGETDEVICEAUDITDETAILS","/device/devices/6fc134db-c8a9-4504-a2d4-e23df0c51bf/audit");
        put("USERDEVICEMANAGEMENTLOGOUTUSERFROMDEVICE","/device/users/devices/logout");

      //MusicBackend  
        put("MUSICBACKENDUSERPLAYLIST","/api/v1/music/user-playlists?type=music&start=1&length=10&hardware_id=74b83f08-4396-4f58-9c79-a1339962bd70&platform=android");
        put("MUSICBACKENDARTISTDETAILS","/api/v1/music/artistdetails?artist_id=15298&hardware_id=74b83f08-4396-4f58-9c79-a1339962bd70");
        put("MUSICBACKENDSONGDETAILS","/api/v1/music/song-details?country=IN&content_id=105104461&hardware_id=74b83f08-4396-4f58-9c79-a1339962bd70");
        put("MUSICBACKENDALBUMDETAILS","/api/v1/music/albumdetails?country=IN&content_id=61980672&hardware_id=74b83f08-4396-4f58-9c79-a1339962bd70&length=1");
        put("MUSICBACKENDDISCOVERY","/api/v1/music/discovery?language=hi&country=IN&hardware_id=74b83f08-4396-4f58-9c79-a1339962bd70&page=1");
        put("MUSICBACKENDUPDATEUSERPLAYLIST","/api/v1/music/user-playlists");
        put("MUSICBACKENDSONGPLAYBACK","/api/v1/music/songplayback?content_id=51733776&hardware_id=74b83f08-4396-4f58-9c79-a1339962bd70");
        put("MUSICBACKENDLANGUAGELIST","/api/v1/music/languages?hardware_id=74b83f08-4396-4f58-9c79-a1339962bd70");
        put("MUSICBACKENDSETUSERLANGUAGE","/api/v1/music/user-languages");
        put("MUSICBACKENDUPDATEUSERLANGUAGE","/api/v1/music/user-languages?hardware_id=74b83f08-4396-4f58-9c79-a1339962bd70");
        put("MUSICBACKENDUSERGETPLAYLIST","/api/v1/music/tracks/user-playlists?type=music&playlist_id=20890663&length=1&getartist=0&hardware_id=74b83f08-4396-4f58-9c79-a1339962bd70");
        put("MUSICBACKENDUPDATETRACKRECORDPLAYLIST","/api/v1/music/tracks/user-playlists");
        put("MUSICBACKENDPLAYLISTDETAILS","/api/v1/music/playlistdetails?country=IN&content_id=123358&start=1&length=10&track=0&hardware_id=74b83f08-4396-4f58-9c79-a1339962bd70");
        put("MUSICBACKENDADDFAVOURITE","/api/v1/music/favorite");
        put("MUSICBACKENDCONTENTFAVORITE","/api/v1/music/favorite?type=playlist&start=1&length=10&hardware_id=74b83f08-4396-4f58-9c79-a1339962bd70&sort=titleasc");
        put("MUSICBACKENDFAVORITETYPECOUNT","/api/v1/music/favorite/count?hardware_id=74b83f08-4396-4f58-9c79-a1339962bd70&action=alltypefavcount");
        put("MUSICBACKENDSEARCH","/api/v1/music/search?keyword=salman&hardware_id=74b83f08-4396-4f58-9c79-a1339962bd70&start=1&length=10&dlang=eng&type=All");
        put("MUSICBACKENDFOLLOWANDUNFoLLOW","/api/v1/music/followunfollowartist?artist_id=15298&dlang=eng&action=follow&hardware_id=74b83f08-4396-4f58-9c79-a1339962bd70");
        put("MUSICBACKENDRECENTLYPLAYED","/api/v1/music/recentlyplayed");
        put("MUSICBACKENDRECENTLYPLAYEDGET","/api/v1/music/recentlyplayed?hardware_id=74b83f08-4396-4f58-9c79-a1339962bd70");
        put("MUSICBACKENDSETUSERPLAYLISTPOST","/api/v1/music/user-playlists");
        put("MUSICBACKENDCELEBRADIO","/api/v1/music/celebradiodetails?artist_id=15298&hardware_id=74b83f08-4396-4f58-9c79-a1339962bd70&images=500_X_500&start=1");
        put("MUSICBACKENDONDEMANDRADIO","/api/v1/music/ondemandradio?radio_id=35494&hardware_id=74b83f08-4396-4f58-9c79-a1339962bd70");
        put("MUSICBACKENDTRENDINGARTISTDETAILS","/api/v1/music/trendingartist?country=IN&language=hi&page=1&hardware_id=74b83f08-4396-4f58-9c79-a1339962bd70");
        put("MUSICBACKENDFOLLOWEDARTISTLIST","/api/v1/music/followedartistlist?start=1&length=10&dlang=en&hardware_id=74b83f08-4396-4f58-9c79-a1339962bd70");
        put("MUSICBACKENDSONGSRECOMNIDATION","/api/v1/music/songsrecommendation?language=enhita&hardware_id=74b83f08-4396-4f58-9c79-a1339962bd70");
        put("MUSICBACKENDALLTYPERECOMNDIATION","/api/v1/music/allrecommendations?language=en&hardware_id=74b83f08-4396-4f58-9c79-a1339962bd70");
        put("MUSICBACKENDARTISTRECOMNIDATION","/api/v1/music/artist/recommendations?language=hiente&country=IN&type=artist&page=1&length=10&hardware_id=74b83f08-4396-4f58-9c79-a1339962bd70");
        put("MUSICBACKENDPLAYLISTGENERE","/api/v1/music/playlistbuckets?genre=romance&title=Romance&language=hiteta&page=1&hardware_id=74b83f08-4396-4f58-9c79-a1339962bd70");
        put("MUSICBACKENDPLAYLISTTAG","/api/v1/music/playlistbuckets?tag=love&language=hiteta&page=1&hardware_id=74b83f08-4396-4f58-9c79-a1339962bd70");
        put("MUSICBACKENDVIEWBUCKET","/api/v1/music/viewbucket?bucket_id=539&language=hiente&country=IN&type=home&page=1&hardware_id=74b83f08-4396-4f58-9c79-a1339962bd70");
        put("MUSICBACKENDHUNGAMAUSERID","/api/v1/music/gethungamauser?hardware_id=74b83f08-4396-4f58-9c79-a1339962bd70");
        put("MUSICBACKENDENTRYPOINTRAILS","/api/v1/music/entrypoint-rails?language=hi%2Cen%2Cpa&hardware_id=74b83f08-4396-4f58-9c79-a1339962bd70&collection_id=0-8-homepage");
        put("MUSICBACKENDDELETEREMOVEFAVORITE","/api/v1/music/favorite");
        put("MUSICBACKENDDELETEUSERPLAYLIST","/api/v1/music/user-playlists?type=music&playlist_id=ID&hardware_id=74b83f08-4396-4f58-9c79-a1339962bd70");
        put("MUSICBACKENDDELETERECENTLYPLAYED","/api/v1/music/recentlyplayed");
        put("MUSICBACKENDDOWNLOADS","/api/v1/music/download?country=IN&hardware_id=6d2373b7-6f3e-48ad-a9cc-00b23c6f9776&platform_name=android");
        put("MUSICBACKENDADDDOWNLOADSTRACK","/api/v1/music/download");
        put("MUSICBACKENDREMOVESONGSDOWNLOADLIST","/api/v1/music/download?hardware_id=6d2373b7-6f3e-48ad-a9cc-00b23c6f9776&country=IN");
        put("MUSICBACKENDDELETEDOWNLOADSONG","/api/v1/music/download?country=IN&hardware_id=5b51d3ce-12f5-46d5-9cd6-e0da2b2ac132&platform_name=android");
        put("MUSICBACKENDPODCASTDETAILS","/api/v1/music/podcast-detail?source=search&content_id=63998256&user_id=127906569&store_id=1&country=IN&hardware_id=xSWHkDzr0hwq3rcwpn1-YJ4y21kKGHa1TdhnZ045LSA%3D&enc=1&b64=2&ads=true&dlang=eng&PRODUCT=ZEE5");
        put("MUSICBACKENDSIMILARPODCAST","/api/v1/music/similar-podcast?user_id=29726888&start=1&length=30&hardware_id=NB6WUNKCwP_IJc2MYupANp4y21kKGHa1TdhnZ045LSA=&content_id=61312820&images=500x500&dlang=eng");
        put("MUSICBACKENDPODCASTTAGWISE","/api/v1/music/podcast-tagwise?tag=Society&language=hi&ps=1&page=1&store_id=1&country=IN&user_id=190128263&dlang=eng&internal_test=1&hardware_id=74b83f08-4396-4f58-9c79-a1339962bd70");
        put("MUSICBACKENDAUTHENTICATEDHUNGAMAUSER","/api/v1/music/gethungamauser?hardware_id=74b83f08-4396-4f58-9c79-a1339962bd70");



		//PollingAdmin
		put("ADMINADDQUIZ_admin","/polling-admin/admin/add");
		put("GETPOLLSASSET_admin","/polling-admin/admin/getPollByAssetId?assetId=ID&geo=IN&lCode=en&pollCategory=QUIZ");
		put("GETPOLLBYID_admin","/polling-admin/admin/getPollById/");
		put("OPINIONPOLLRESULT_admin","/polling-admin/admin/getPollById/");
		put("USERREPORTPOLLRESPONSE_admin","/polling-admin/admin/getUserReportPollResponse/7238");
		put("OPINIONSCHEDULAR_admin","/polling-admin/admin/opinion-scheduler");
		put("POLLSCHEDULAR_admin","/polling-admin/admin/poll-scheduler?startDate=2023-09-13T00:00:00&endDate=2023-09-15T00:00:00&pollId=");
		put("POLLRESPONSES_admin","/polling-admin/admin/poll-responses/7238");
		put("DELETEBYPOLLID_admin","/polling-admin/admin/delete/delID");
		put("SUBMITPOLL_admin","/polling-service/polls/submit?tenantId=ZEE5_SAREGAMAPA&milestone=QUIZ_RIGHT_ANSWER&firstName=Nitin&lastName=kumar");
		put("GETPOLLINGDETAILS_admin","/polling-service/polls/getDetails?tenantId=ZEE5_SAREGAMAPA&languageCode=EN&assetId=getpollID");
		put("GETUSERPOLLRESPONSES_admin","/polling-service/polls/getUserPollResponses?pollId=");
		put("GETOPINIONPOLLRESULT_admin","/polling-service/polls/getOpinionPollResults?pollId=9710&questionId=12150");

		//templateengine
		put("GETETEMPLATE_templateengine","/template-engine-api/template-engine/api/v1/template/");
		put("DELETETEMPLATECACHE_templateengine","/template-engine-api/template-engine/cache/data");
		put("ADDTEMPLATE_templateengine","/template-engine-api/template-engine/api/v1/template");
		put("UPDATETEMPLATE_templateengine","/template-engine-api/template-engine/api/v1/template/");
		put("DELETETEMPLATEDB_templateengine","/template-engine-api/template-engine/api/v1/template/");

		//subscriptionrulebook
//		put("REFERRER_subrulebook","/subscriptionRuleBook/subscription-rule-book/api/v1/rules/referrer");
//		put("REFEREE_subrulebook","/subscriptionRuleBook/subscription-rule-book/api/v1/rules/referee");
//		put("COHORT_subrulebook","/subscriptionRuleBook/subscription-rule-book/api/v1/rules/cohort");
//		put("CLP_subrulebook","/subscriptionRuleBook/subscription-rule-book/api/v1/rules/clp");
//		put("COUPON_subrulebook","/subscriptionRuleBook/subscription-rule-book/api/v1/rules/coupon");
//		//put("PAYMENT_subrulebook","/subscription-rule-book/api/v1/rules/payment");
//		put("GETV1RULE_subrulebook","/subscriptionRuleBook/subscription-rule-book/api/v1/rules?namespace=CHURN_ARREST_COUPON");
		put("POSTV1RULE_subrulebook_1","/subscriptionRuleBook/subscription-rule-book/api/v1/rules");
    
		//UserFeatureList
		put("USERFEATUREHEALTH_userfeature","/userFeatureList/user-feature/actuator/health");
		put("GETFEATURELIST_userfeature","/userFeatureList/user-feature/v1/getFeatureList");
		put("UPDATEFEATURE_userfeature","/userFeatureList/user-feature/v1/updateFeatureList?featureList=UserComments,UserReaction");
		put("UPDATEALLFEATURE_userfeature","/userFeatureList/user-feature/v1/updateAll?featureList=UserComments,Tambola");
		put("DELETEFEATURE_userfeature","/userFeatureList/user-feature/v1/deleteFeatureListForAll");

		
		//User Comments PTv2.0
	    put("POSTCREATECMMNTANDREPLY","/user-comments-node/v2.0/comment/createComment");
	    put("GETCOMMENT","/user-comments-node/v2.0/comment/getAllComment?assetId={assetId}&page={page}&listType={listType}");
	    put("PUTUPDATECOMMENT","/user-comments-node/v2.0/comment/updateComment");
	    put("DELETECOMMENT","/user-comments-node/v2.0/comment/deleteComment");
	    put("POSTCREATEREPLY","/user-comments-node/v2.0/comment/createComment");
	    put("GETREPLY","/user-comments-node/v2.0/comment/getAllReply?page={page}&assetId={assetId}&postNumber={postNumber}");
	    put("PUTUPDATEREPLY","/user-comments-node/v2.0/comment/updateComment");
	    put("DELETEREPLY","/user-comments-node/v2.0/comment/deleteComment");
	    put("POSTCREATELIKEACTIONS","/user-comments-node/v2.0/likeAction/createLikeAction");
	    put("DELETELIKEACTIONS","/user-comments-node/v2.0/likeAction/deleteLikeActions");
	    
	    //USER REFERRAL
	    put("REFERRALLINK","/referral/link");
	    put("REFERRALSHARELINK","/referral/shareLink");
	    put("REFERRALDEEPLINKDETAILS","/referral/deepLinkDetails");
	    put("REFERRALREWARD","/referral/rewards");
	    put("REFERRALVALIDATECODE","/referral/validateCode");
	    put("REFERRALREGDISCOUNT","/acquivision/regDiscount");
	    put("REFERRALREGDISCOUNTLINKDETAILS","/acquivision/discountLinkDetails");
	    
	    
	    //Parallelviewdashboard
	    put("PARALLELDASHBOARDHEALTHCHECK","/healthcheck");
	    put("GETPARALLELDASHBOARD","/dashboard");
	    
	  //Partner-Onboarding
        put("PARTNER_REQUEST","/partner-onboarding/partner/request");
        put("PARTNER_UPDATE","/partner-onboarding/partner/request/");
        put("PARTNER_APPROVE","/partner-onboarding/partner/approve");
        put("GETPRODUCT","/partner-onboarding/product");
        put("APIDETAILS","/partner-onboarding/product/1");
        put("UPDATEPLANS","/partner-onboarding/ticket/");
        put("TICKETSEARCH","/partner-onboarding/ticket/search?pageNo=0&pageSize=2");
        put("TICKETSTATUSIUPDATE","/partner-onboarding/ticket/");
        put("CLIENTCREDENTIALS","/partner-onboarding/ticket/AHFS765/clientCredentials");
        put("DOWNLOAD_DOCS","/partner-onboarding/docs/download?id=");
        put("PARTNERROLEWITHSESSIONID","/partner-onboarding/user/role/cf52b9b5-1890-4309-8127-9652e8afd8b5");
        put("ACCOUNTRECOVERY","/partner-onboarding/user/accountRecovery");
        put("TICKETTRANSACTIONDETAILS","/partner-onboarding/ticket/");
        put("USERDETAILS","/partner-onboarding/user/141");
        put("PARTNER_CONTACT","/partner-onboarding/partner/contact");
        put("DELETE_DOC","/partner-onboarding/docs?id=");
        put("UPLOAD_DOC","/partner-onboarding/docs/upload");
      
	   
	  //ruleengine
	    put("GETALLRULE_ruleengine","/rule-engine-api/rule-engine/api/v1/rule/ZEE5_SMS_26");
	    put("EMAILRULE_ruleengine","/rule-engine-api/rule-engine/api/v1/rule");
	    put("SPECIFICRULE_ruleengine","/rule-engine-api/rule-engine/api/v1/rule/");
	    put("UPDATERULE_ruleengine","/rule-engine-api/rule-engine/api/v1/rule/");
	    put("DELETERULECHANNEL_ruleengine","/rule-engine-api/rule-engine/api/v1/rules?tenant=ZEE5&channel=EMAIL");
	    put("DELETERULENAME_ruleengine","/rule-engine-api/rule-engine/api/v1/rule/ZEE5_EMAIL_12");
	    put("FETCH_ruleengine","/rule-engine-api/rule-engine/api/v1/fetch");
	    put("SMSRULE_ruleengine","/rule-engine-api/rule-engine/api/v1/rule");
	    
	  //CommunicationEmailService
	    put("COMMUNICATIONEMAIL_commemailservice","/comm-engine-api/communication-engine/api/v1/notification");
	   
	    
	    //Zee5 Profiles
	    put("CREATEDEFAULTPROFILE","/v1/profiles/defaultProfile");
	    put("CREATEPROFILE","/v1/profiles");
	    put("GETALLUSERPROFILE","/v1/profiles");
	    put("GETPROFILE","/v1/profiles?profile_id={$PID$}");
	    put("UPDATEPROFILES","/v1/profiles");
	    put("UPDATELASTUSEDPROFILE","/v1/profiles/lastUsedProfile");
	    put("GETLASTUSEDPROFILE","/v1/profiles/lastUsedProfile");
	    put("DELETEPROFILE","/v1/profiles?profile_id={$PID$}");
	    put("REGISTERANDUPDATE_SENDEMAILOTP","/v1/user/sendotp");
	    put("OTPVERIFY","v1/user/verifyotp");
	    

	    
	  //UserNodeAPI-RegisterandUpdate
	    put("REGISTERANDUPDATE_SENDEMAILOTP","/v1/user/sendotp");
	    put("REGISTERANDUPDATE_SENDMOBILEOTP","/v1/user/sendotp");
		put("REGISTERANDUPDATE_WITHEMAILOTP","/v1/user/registerWithOTPMobileorEmail");
		put("REGISTERANDUPDATE_WITHMOBILEOTP","/v1/user/registerWithOTPMobileorEmail");
		put("REGISTERANDUPDATE_GETUSER","/v1/user");
		put("REGISTERANDUPDATE_UPDATE_MOBILE","/v1/user");
		put("REGISTERANDUPDATE_UPDATE_EMAIL","/v1/user");
		put("REGISTERANDUPDATE_UPDATEUSER_V1","/v1/user");
		put("REGISTERANDUPDATE_UPDATEUSER_V2","/v2/user");
		
		//UserNodeAPI-GCP_UAT
	    put("GCP_SENDEMAILOTP","/v1/user/sendotp");
	    put("GCP_SENDMOBILEOTP","/v1/user/sendotp");
	    put("GCP_OTPVERIFY","/v1/user/verifyotp");
		put("GCP_WITHEMAILOTP","/v1/user/registerWithOTPMobileorEmail");
		put("GCP_WITHMOBILEOTP","/v1/user/registerWithOTPMobileorEmail");
		put("GCP_SENDMOBILEOTPV2","/v2/user/sendotp");
		put("GCP_SENDEMAILOTPV2","/v2/user/sendotp");
		put("GCP_OTPVERIFYV2","/v2/user/verifyotp");
		put("GCP_OTPVERIFYV3","/v3/user/sendotp");
		put("GCP_OTPREGISTEREMAIL","/v2/user/verifyOtpRegister");
		put("GCP_OTPREGISTERMOBILE","/v2/user/verifyOtpRegister");
		put("GCP_USERRENEW_V1","/v1/user/renew?refresh_token=$RefreshToken$");
		put("GCP_USERRENEW_V2","/v2/user/renew?refresh_token=$RefreshToken$");
		put("GCP_USERRENEWTELE_V2","/v2/user/renewTele?refresh_token=$RefreshToken$");
		put("GCP_AS1","/v1/healthCheck");
		put("GCP_AS2","/v1/healthCheck");
		put("GCP_GETUSERV1","/v1/user");
		
		//UserNodeAPI-Customer
		put("GETCRMTOKEN","/v2/manage/customer/getcrmtoken");
		put("TOKENREFRESHUSERIDV1","/v1/manage/customer/tokenwithrefresh/$USERID$?cttl=1800");
		put("GETCUSTOMERIDV1","/v1/manage/customer/$CUSTID$");
		put("MANAGECUSTOMER","/v1/manage/customer?id=$CUSTID$");
		put("CUSTOMERTOKENMOBILE","/v1/manage/customer/token?mobile=$MOBNUM$");
		put("CUSTOMERTOKENWITHREFRESHV1","/v1/manage/customer/tokenwithrefresh?email=$EMAILID$");
		put("REFRESHTOKENMOBILEV2","/v2/manage/customer/tokenwithrefresh?mobile=$MOBNUM$");
		put("REFRESHTOKENEMAILV2","/v2/manage/customer/tokenwithrefresh/$CUSTID$");
		
		put("CUSTOMEREMAIL","/v1/manage/customer/email");
		put("CUSTOMERMOBILE","/v1/manage/customer/mobile");
		
		
	  //Payment_API
        put("Payment_GetPayment","/payment/api/v1/payment?providerName=JusPay&country=IN&startDate=2023-12-03%2011%3A00%3A00&endDate=2023-12-03%2012%3A00%3A00&paymentState=SUCCESS");
        put("Payment_CreatePayment","/payment/api/v1/payment?providerName=JusPay&country=US&startDate=2023-12-12%2011%3A00%3A00&endDate=2024-12-14%2011%3A00%3A00&paymentState=SUCCESS");
	    put("Payment_BillingPayment","/payment/api/v1/payment/billing");
	    

	   //Adtech_CC
	    put("ADTECH_CC_LoadLatestItemCache","/cache/loadLatestContent");
	    put("ADTECH_CC_LoadItems","/cache/loadItem");
	    put("ADTECH_CC_loadMetaData","/cache/loadMetaData");
	    put("ADTECH_CC_loadGenericModel","/cache/loadGenericModel");
	    put("ADTECH_CC_LoadAdServerConfig","/cache/loadAdServerConfig");
	    put("ADTECH_CC_LoadRules","/cache/loadRules");
	    put("ADTECH_CC_LoadExpItem","/cache/loadExpItem");
	    put("ADTECH_CC_GetCache","/cache/get?cacheName=CACHE_ITEM_META_DATA");
	    put("ADTECH_CC_GetItemCache","/cache/get?cacheName=CACHE_AD_CONFIG");
	    put("ADTECH_CC_GetItembyId","/debug/getItem?id=7492");
	    put("ADTECH_CC_GetContextualItems","/debug/getContextualItems?itemId=2183&langs=hi&version=1");
	    put("ADTECH_CC_ClearCache","/cache/clear?cacheName=CACHE_CS");


	  //Single_Playback
	    put("SPAPI_healthCheck","/healthCheck");
	    put("SPAPI_RequestGCP","/v2/getDetails/secure?content_id=0-0-newsauto_1bgnudvdj8no&device_id=EPCqkoZ7DGqJjjzMDcdA000000000001&platform_name=desktop_web&translation=en&user_language=en%2Chi%2Cmr&country=IN&state=MH&user_type=register&check_parental_control=false&gender=Unknown&uid=49b0d00e-163b-402d-98c0-3d9d760f6ca7&ppid=y3wpQhrj1HTQ1lSWXQh5000000000000");
        put("SPAPI_ApigeeGuestUser","/getDetails/secure?content_id=0-0-newsauto_1bgnudvdj8no&device_id=EPCqkoZ7DGqJjjzMDcdA000000000001&platform_name=desktop_web&translation=en&user_language=en%2Chi%2Cmr&country=IN&state=MH&user_type=register&check_parental_control=false&gender=Unknown&uid=49b0d00e-163b-402d-98c0-3d9d760f6ca7&ppid=y3wpQhrj1HTQ1lSWXQh5000000000000");
        put("SPAPI_ApigeeRegisteredUser","/getDetails/secure?content_id=0-0-1z579366&device_id=8C5D58CF-5E65-4DD9-B23E-D7E66D7E32B4&platform_name=desktop_web&translation=en&user_language=bn%2Chi%2Cmr%2Cta%2Cte&country=IN&state=&app_version=2.52.51&user_type=premium&check_parental_control=false&gender=Male&age_group=25-32&ppid=GGmnfs8G8hZMLS8m8ebt000000000000&version=12&zgdpr=C0001%2CC0002%2CC0003%2CC0004%2CC0005&zcnstdt=&znpa=");
        put("SPAPI_RegisteredGCP","/v2/getDetails/secure?content_id=0-0-newsauto_1bgnudvdj8no&device_id=8C5D58CF-5E65-4DD9-B23E-D7E66D7E32B4&platform_name=desktop_web&translation=en&user_language=en%2Chi%2Cmr&country=IN&state=MH&user_type=register&check_parental_control=false&gender=Unknown&uid=a07bd239-3082-4411-b915-5692d5267098&ppid=y3wpQhrj1HTQ1lSWXQh5000000000000");
        

    //Zee5 entitlement vertex
        put("SUBSCRIPTIONTYPEFREE","/v1/manage/entitlement");
        put("ADDUSERIDTOSUBSCRIPTION","/zee5-order-bff/order-bff/v2/manage/subscription");
        
    //RECO_Adtech_CRS
        put("RECO_UPNEXT","/adtechcrs-cassandra/crs/api/upnext");
        put("RECO_COLDSTART","/adtechcrs-cassandra/crs/api/cr");
        put("RECO_GETEPISODE","/adtechcrs-cassandra/crs/api/episode/getEpisodeNode?episodeAssetId=0-1-6z5167603");

    //Reco_Adtech_Viewcount
        put("ADTECH_VIEWCOUNT","/viewcount/viewcount/api/v1/asset-counts?is_number_formatted=true");
        
    //ZasDashboard_Zas_Connect
        put("ZAS_CONNECT","/zasconnect/zas-connect/ads/adunitTest1/?device_id=1234&ad_session_id=12e&video_session_id=12345&targeting_params=%7B%22platform_name%22%3A%22ANDROID_MOBILE%22%7D");
	
        //Zas_Diff
        put("ZasConnect_CreateRadis","/zasdif/zas-dif/api/cvc/reloadCache");
        put("ZasConnect_TestReadness","/zasdif/zas-dif/api/probes/readiness");
        put("ZasConnect_TestLiveness","/zasdif/zas-dif/api/probes/liveness");
        put("ZasConnect_FlushRadis","/zasdif/zas-dif/api/cvc/flushCache");
	
	}};
}
