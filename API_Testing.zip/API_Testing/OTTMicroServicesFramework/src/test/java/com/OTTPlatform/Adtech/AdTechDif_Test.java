package com.OTTPlatform.Adtech;

import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentTest;

import BusinessComponents.AdTechDiff;

import baseTestPackage.BaseTest_TestNG;
import io.restassured.response.Response;
import reusableLibrary.JsonUtils;
import reusableLibrary.ResuableComponents;

public class AdTechDif_Test extends  BaseTest_TestNG {

	AdTechDiff adtechdif = new AdTechDiff();

	ResuableComponents resuableComponents = new ResuableComponents();

	@Test( dataProvider = "CrateAuthenticatPOST", description="Crate Authenticate-Dif using POST")
	public void createAddtechcDifAuth(String fileName) throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		String requestBody = JsonUtils.readPayloadJson(fileName);
		Response resp = adtechdif.createauthenticateDif(test,requestBody);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}
	@DataProvider(name = "CrateAuthenticatPOST")
	public Object[][] createauthenticateDif() {
		return new Object[][] { { "adTechDifAuthenticate.json" } };
	}
	
	@Test(dataProvider = "CrateAuthenticatPOST",description = "Reload Cron using Post")
	public void realodCron(String fileName) throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		String requestBody = JsonUtils.readPayloadJson(fileName);
		Response resp = adtechdif.postreloadCronJob(test,requestBody);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}

	@Test(dataProvider = "CrateAuthenticatPOST",description = "Check Cron Status Enable or disable using Get")
	public void enableOrdisbaleCron(String fileName ) throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		String requestBody = JsonUtils.readPayloadJson(fileName);
		Response resp = adtechdif.getenableOrdisableCron(test,requestBody);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}
	
	
	@Test(dataProvider = "CrateAuthenticatPOST", description ="Set Skipped Channel using Post")
	public void setSkippedChannels(String fileName) throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		String requestBody = JsonUtils.readPayloadJson(fileName);
		Response resp = adtechdif.setAllSkippedChannels(test,requestBody);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}
	
	@Test(dataProvider = "CrateAuthenticatPOST", description ="Evict Chanel ID's from Cache using Post")
	public void evictChannelid(String fileName) throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		String requestBody = JsonUtils.readPayloadJson(fileName);
		Response resp = adtechdif.getevictChannelidfromCache(test,requestBody);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}
	
	@Test( dataProvider = "CrateAuthenticatPOST",description = "Get Asset Information")
	public void AssetInfo(String fileName) throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		String requestBody = JsonUtils.readPayloadJson(fileName);
		Response resp = adtechdif.getAssetInfo(test,requestBody);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
		
	}
	
	@Test(dataProvider = "CrateAuthenticatPOST", description = "Create Custom Ids using Post")
	public void createCustomId(String fileName) throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		String requestBody = JsonUtils.readPayloadJson(fileName);
		Response resp = adtechdif.setCustomeid(test,requestBody);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));	
	}
	
	@Test( description = "Health Check using Get")
	public void healthChecks() throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());		
		Response resp = adtechdif.getHealthCheck(test);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}
	
	@Test( description = "Check Readiness using Get")
	public void Readiness() throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		Response resp = adtechdif.getReadiness(test);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}
	
	
	
	}