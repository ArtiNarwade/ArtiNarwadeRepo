package com.OTTPlatform.Adtech;

import BusinessComponents.AdTechConfig;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentTest;

import baseTestPackage.BaseTest_TestNG;
import io.restassured.response.Response;
import reusableLibrary.JsonUtils;
import reusableLibrary.ResuableComponents;

public class AdTech_Config_Test extends BaseTest_TestNG {
	AdTechConfig adtechconfi = new AdTechConfig();
	ResuableComponents resuableComponents = new ResuableComponents();
	public static String Cookie;

	
	@Test(dataProvider = "UserData1", description = "POD3-Adtech-Create authentication",priority=1)
	public void createauthenticate(String fileName) throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		String reqBody = JsonUtils.readPayloadJson(fileName);
		Response resp = adtechconfi.Authenticate(test, reqBody);
		Cookie = resp.getHeader("Set-Cookie");
		System.out.println(Cookie);
		int StatusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(StatusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}

	@DataProvider(name = "UserData1")
	public Object[][] Authenticate() {
		return new Object[][] { { "AdtechConfig_authenticateAdtech.json" } };
	}
	
	@Test(description = "POD3-Adtech-Generate password hash",priority=2)
	public void getpassword() throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		Response resp = adtechconfi.getPassword(test);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}
	
	@Test(dataProvider = "CreateNon-ProdCompanionAddsLIVE", description = "POD3-Adtech-Create Non-Prod CompanionAds LIVE",priority=3)
	public void createCompanioAddsInLive(String fileName) throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		String reqBody = JsonUtils.readPayloadJson(fileName);
		Response resp = adtechconfi.createNonProdCompanionadsLIVE(test, reqBody);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}

	@DataProvider(name = "CreateNon-ProdCompanionAddsLIVE")
	public Object[][] createNonProdCompanionadsLIVE() {
		return new Object[][] { { "AdtechConfig_Live-Default-Andriod_Mobile.json" }};
				
	}
	@Test(dataProvider = "DEFAULT-MISC", description = "POD3-Adtech-Create DEFAULT-MISC",priority=4)
	public void createDEFAULT_MISC(String fileName) throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		String reqBody = JsonUtils.readPayloadJson(fileName);
		Response resp = adtechconfi.default_MISC(test, reqBody);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}

	@DataProvider(name = "DEFAULT-MISC")
	public Object[][] default_MISC() {
		return new Object[][] { { "AdtechConfig_DEFAULT-MISC.json" }};
				
	}

	@Test(dataProvider = "UserData1",description = "POD3-Adtech-All Config Based on Context",priority=5)
	public void getConfig(String fileName) throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		String reqBody = JsonUtils.readPayloadJson(fileName);
		Response resp = adtechconfi.GetConfig(test,reqBody);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}
	
	@Test(dataProvider = "UserData1",description = "POD3-Adtech-Config Details History",priority=6)
	public void getConfigdetails(String fileName) throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		String reqBody = JsonUtils.readPayloadJson(fileName);
		Response resp = adtechconfi.GetConfigDetail(test,reqBody);
		System.out.println(resp.asString());
		
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}
	
	@Test(dataProvider = "UserData1",description = "POD3-Adtech-Reload Component Config Cache",priority=7)
	public void reloadComponents(String fileName) throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		String reqBody = JsonUtils.readPayloadJson(fileName);
		Response resp = adtechconfi.ReloadComponent(test,reqBody);
		int StatusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(StatusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
		
	}
	
	@Test(description = "POD3-Adtech-Reload Context Config Cache",priority=8)
	public void reloadComponentscontext() throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		Response resp = adtechconfi.ReloadContext(test);
		int StatusCode = resp.getStatusCode();
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
		resuableComponents.validateStatusCode(Integer.toString(StatusCode), Integer.toString(200), test);
	}
	@Test(dataProvider = "UserData1",description = "POD3-Adtech-Get the Details of Discovery- Components Types",priority=9)
	public void getComponentDetails(String fileName) throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		String reqBody = JsonUtils.readPayloadJson(fileName);
		Response resp = adtechconfi.getDiscoveryComponentType(test,reqBody);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}
	
	@Test(dataProvider = "UserData1",description = "POD3-Adtech-Get the Details of Discovery- AdServer Types",priority=10)
	public void getAdServerDetails(String fileName) throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		String reqBody = JsonUtils.readPayloadJson(fileName);
		Response resp = adtechconfi.getDiscoveryAdServerType(test,reqBody);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}
	

	@Test(dataProvider = "UserData1",description = "POD3-Adtech-Get the Details of Discovery- Config Types",priority=11)
	public void getConfigDetails(String fileName) throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		String reqBody = JsonUtils.readPayloadJson(fileName);
		Response resp = adtechconfi.getDiscoveryConfigType(test,reqBody);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}

	@Test(dataProvider = "UserData1",description = "POD3-Adtech-Get the Details of Discovery- Config Key Formulation",priority=12)
	public void getConfigkeyForumalation(String fileName) throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		String reqBody = JsonUtils.readPayloadJson(fileName);
		Response resp = adtechconfi.getDiscoveryConfigKeyFormulation(test,reqBody);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}

	@Test(dataProvider = "UserData1",description = "POD3-Adtech-Get the Details of Discovery- Operators Descrption",priority=13)
	public void getOperatorsDesc(String fileName) throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		String reqBody = JsonUtils.readPayloadJson(fileName);
		Response resp = adtechconfi.getDiscoveryOperatorDesc(test,reqBody);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}

	@Test(dataProvider = "UserData1",description = "POD3-Adtech-Get the Details of Discovery- All Available Confi Keys",priority=14)
	public void getAvailableConfKey(String fileName) throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		String reqBody = JsonUtils.readPayloadJson(fileName);
		Response resp = adtechconfi.getDisoveryAvailableConfiKeys(test,reqBody);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}

	@Test(dataProvider = "UserData1",description = "POD3-Adtech-Get the Details of Discovery- All Available Region",priority=15)
	public void getAvailableRegion(String fileName) throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		String reqBody = JsonUtils.readPayloadJson(fileName);
		Response resp = adtechconfi.getDisoveryAllAvailbleRegion(test,reqBody);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}

	@Test(dataProvider = "UserData1",description = "POD3-Adtech-Get the Details of Discovery- Componenet Supported Region",priority=16)
	public void getComponentSupportedRegion(String fileName) throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		String reqBody = JsonUtils.readPayloadJson(fileName);
		Response resp = adtechconfi.getDisoveryComponentSupportedRegion(test,reqBody);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}

	@Test(description = "POD3-Adtech-Get the Details of Discovery- Health Check",priority=17)
	public void HealthCheck() throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		Response resp = adtechconfi.getHealthCheck(test);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}

	@Test(description = "POD3-Adtech-Get the Details of Discovery- Readiness",priority=18)
	public void Rediness() throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		Response resp = adtechconfi.getRediness(test);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}
	
	
	@Test(dataProvider = "UserData1",description = "POD3-Adtech-Disable Config",priority=19)
	public void DeleteConfig(String fileName) throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		String reqBody = JsonUtils.readPayloadJson(fileName);
		Response resp = adtechconfi.DisableConfig(test,reqBody);
		int StatusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(StatusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}
	
	@Test(dataProvider = "UserData1",description = "POD3-Adtech-Flush all config",priority=20)
	public void DeleteConfigflush(String fileName) throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		String reqBody = JsonUtils.readPayloadJson(fileName);
		Response resp = adtechconfi.FlushConfig(test,reqBody);
		int StatusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(StatusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));

	}
	
	@Test(dataProvider = "UserData1",description = "POD3-Adtech-Flush Config Cache",priority=21)
	public void Deleteflushcache(String fileName) throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		String reqBody = JsonUtils.readPayloadJson(fileName);
		Response resp = adtechconfi.FlushConfigCache(test,reqBody);
		int StatusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(StatusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}
	
	@Test(dataProvider = "UserData1",description = "POD3-Adtech-Force drop Config",priority=22)
	public void Deleteforcedrop(String fileName) throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		String reqBody = JsonUtils.readPayloadJson(fileName);
		Response resp = adtechconfi.ForceDrop(test,reqBody);
		int StatusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(StatusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}


}
