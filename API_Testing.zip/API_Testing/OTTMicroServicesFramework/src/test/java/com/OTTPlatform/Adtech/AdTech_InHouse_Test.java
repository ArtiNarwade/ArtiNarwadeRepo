package com.OTTPlatform.Adtech;

import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentTest;

import BusinessComponents.Adtech_Inhouse;
import baseTestPackage.BaseTest_TestNG;
import io.restassured.response.Response;
import reusableLibrary.ResuableComponents;

public class AdTech_InHouse_Test extends BaseTest_TestNG {
	Adtech_Inhouse adtechinhouse = new Adtech_Inhouse();
	ResuableComponents resuableComponents = new ResuableComponents();
	public static String str;
	public static String error;
	public static String impression;
	public static String imp;



	@Test(description = "Get the Details of In-House Using GET Call",priority=1)
	public void inHOuseDetails() throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		Response resp = adtechinhouse.inhouseGet(test);
	    error=resp.getBody().jsonPath().get("pre-roll.trackers.error").toString();
	    impression=resp.getBody().jsonPath().get("pre-roll.trackers.impression").toString();		
		str=error.substring(69);
		imp=impression.substring(69);
      	int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}
	
	@Test(description = "Get the Details of Pixel Tacker Using GET Call",priority=2)
	public void pixelTrackerDetails() throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		Response resp = adtechinhouse.pixetrackerGet(test);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(201), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(201));
	}
	
	@Test(description = "Get the Details of Pixel Impression Using GET Call",priority=3)
	public void pixelImpressionDetails() throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		Response resp = adtechinhouse.pixetrackerGet(test);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(201), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(201));
	}

}
