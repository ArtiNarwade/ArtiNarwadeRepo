package com.OTTPlatform.Adtech;

import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Test;
import com.relevantcodes.extentreports.ExtentTest;
import BusinessComponents.AdTech_mrssfeed_API;
import baseTestPackage.BaseTest_TestNG;
import io.restassured.response.Response;
import reusableLibrary.ResuableComponents;

public class AdTech_MRSS_Feed_Test extends BaseTest_TestNG {
	
	AdTech_mrssfeed_API Mrss_feed = new AdTech_mrssfeed_API();
	ResuableComponents resuableComponents= new ResuableComponents();

	
	@Test(description = "Get MRSS Feed Details")
	public void Mrss_Feed_() throws Exception {
    ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
	Response resp= Mrss_feed.get_mrssFeed(test);
	int statusCode = resp.getStatusCode();
	resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
	Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}


}
