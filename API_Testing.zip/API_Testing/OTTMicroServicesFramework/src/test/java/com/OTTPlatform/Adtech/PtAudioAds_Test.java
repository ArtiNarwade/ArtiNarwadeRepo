package com.OTTPlatform.Adtech;

import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentTest;

import BusinessComponents.Adtech_AudioAdsApi;
import BusinessComponents.UM_UserToken;
import baseTestPackage.BaseTest_TestNG;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import reusableLibrary.JsonUtils;
import reusableLibrary.ResuableComponents;

public class PtAudioAds_Test extends BaseTest_TestNG {

	Adtech_AudioAdsApi AudioAds = new Adtech_AudioAdsApi();
	ResuableComponents resuableComponents = new ResuableComponents();
	
	UM_UserToken usertoken=new UM_UserToken();
	
     public static String responsebody;
	
	// GENERIC METHOD TO GENERATE TOKEN
		public JsonPath getUserToken(ExtentTest test) throws Exception {
			String requestBody = JsonUtils.readPayloadJson("UMTokenGenerate.json");
			Response resp = usertoken.tokenGenreatePost(test, requestBody);
			 responsebody = resp.getBody().jsonPath().get("token").toString();
			System.out.println(responsebody);
			JsonPath jsonPath = resp.jsonPath();
			return jsonPath;
		}

	@Test(dataProvider = "UserData", description = "Check for audio ads RegisteredUser , guestUser & premiumUser")
	public void audioAds(String fileName) throws Exception {

		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());		
		String reqBody = JsonUtils.readPayloadJson(fileName);
		JsonPath tokenJsonPath = getUserToken(test);
		String token = tokenJsonPath.getString("token");
		reqBody=reqBody.replace("$AuthToken$","bearer " + token);
		reqBody=reqBody.replace("$x-access-token$", CSU.decrypt(globalProp.getProperty("ucxaccesstoken")));
		reqBody=reqBody.replace("$X-Z5-Guest-Token$", CSU.decrypt(globalProp.getProperty("X-Z5-Guest-Token")));
		Response resp = AudioAds.postAudioAds(test, reqBody);
		int StatusCode = resp.getStatusCode();
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
		resuableComponents.validateStatusCode(Integer.toString(StatusCode), Integer.toString(200), test);

	}

	@DataProvider(name = "UserData")
	public Object[][] Invalidauth1() {
		return new Object[][] { { "AudioRegisteredUser.json" }, { "AudioGuestUser.json" },
				{ "AudioPremiumUser.json" }

		};
	}

	@Test(dataProvider = "UserData1", description = "Check for invalid access token and authorisation")
	public void invalidAccessTest(String fileName) throws Exception {

		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		String reqBody = JsonUtils.readPayloadJson(fileName);
		JsonPath tokenJsonPath = getUserToken(test);
		String token = tokenJsonPath.getString("token");
		reqBody=reqBody.replace("$AuthToken$","bearer " + token);
		reqBody=reqBody.replace("$x-access-token$", CSU.decrypt(globalProp.getProperty("ucxaccesstoken")));
		Response resp = AudioAds.postAudioAds(test, reqBody);
		int StatusCode = resp.getStatusCode();
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(401));
		resuableComponents.validateStatusCode(Integer.toString(StatusCode), Integer.toString(401), test);

	}

	@DataProvider(name = "UserData1")
	public Object[][] Invalidauth() {
		return new Object[][] { { "AudioInvalidAuth.json" }, { "InvalidAccess.json" }

		};
	}

}
