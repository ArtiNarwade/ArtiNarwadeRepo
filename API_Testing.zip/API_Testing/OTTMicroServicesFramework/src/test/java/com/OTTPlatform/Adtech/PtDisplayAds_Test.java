package com.OTTPlatform.Adtech;

import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentTest;

import BusinessComponents.ptDisplayAdsSubscriptionAPI;
import baseTestPackage.BaseTest_TestNG;
import io.restassured.response.Response;
import reusableLibrary.JsonUtils;
import reusableLibrary.ResuableComponents;

public class PtDisplayAds_Test extends BaseTest_TestNG {

	ptDisplayAdsSubscriptionAPI ptdisplayAdsSubscriptionAPI = new ptDisplayAdsSubscriptionAPI();
	ResuableComponents resuableComponents = new ResuableComponents();

	@Test(dataProvider = "UserData1", description = "Display Ads V1 for UKRegistered User apple_app", groups = { "Regression" })
	public void CreateUser_apple_app(String fileName) throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		String reqBody = JsonUtils.readPayloadJson(fileName);
		Response resp = ptdisplayAdsSubscriptionAPI.addUser_appleApp(reqBody, test);
		resuableComponents.validateStatusCode(Integer.toString(resp.statusCode()), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}

	@Test(dataProvider = "UserData1", description = "Display Ads V2 for UKRegistered User android_mobile", groups = { "Regression" })
	public void V2_UKRegisteredUser_android_mobile(String fileName) throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		String reqBody = JsonUtils.readPayloadJson(fileName);
		Response resp = ptdisplayAdsSubscriptionAPI.V2_UKRegistered_User_android_mobile(reqBody, test);
		resuableComponents.validateStatusCode(Integer.toString(resp.statusCode()), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));

	}

	@DataProvider(name = "UserData1")
	public Object[][] addUser_appleApp() {
		return new Object[][] { { "displayAdsV1.json" } };
	}


	@Test(description = "Get Display Ads V3 for UKRegistered User", groups = { "Regression" })
	public void getUKRegistered_Desktop_web() throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		Response resp = ptdisplayAdsSubscriptionAPI.get_V3UKRegisteredUserDesktop_web(test);
		resuableComponents.validateStatusCode(Integer.toString(resp.statusCode()), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}

}
