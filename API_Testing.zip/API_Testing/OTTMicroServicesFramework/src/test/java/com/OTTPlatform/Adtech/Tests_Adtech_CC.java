package com.OTTPlatform.Adtech;

import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentTest;
import BusinessComponents.Adtech_CC;
import baseTestPackage.BaseTest_TestNG;
import io.restassured.response.Response;
import reusableLibrary.ResuableComponents;

public class Tests_Adtech_CC extends  BaseTest_TestNG {
	
	Adtech_CC adtech_CC = new Adtech_CC();

	ResuableComponents resuableComponents = new ResuableComponents();
	public static String AdtechCC_id ;

	@Test( description = "POD3-Adtech-Load  Latest Item Cache")
	public void GetLoadLatestItemCache() throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		Response resp = adtech_CC.LoadLatestItemCache(test);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}
	
	@Test( description = "POD3-Adtech-Load items")
	public void GetLoadItems() throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		Response resp = adtech_CC.LoadItems(test);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}
	@Test( description = "POD3-Adtech-Load Meta Data")
	public void GetLoadMetaData() throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		Response resp = adtech_CC.LoadMetaData(test);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}
	
	@Test( description = "POD3-Adtech-Load Generic Model")
	public void GetLoadGenericModel() throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		Response resp = adtech_CC.LoadGenericModel(test);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}
	
	@Test( description = "POD3-Adtech-Load AdServer Config")
	public void GetLoadAdServerConfig() throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		Response resp = adtech_CC.LoadAdServerConfig(test);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}
	
	@Test( description = "POD3-Adtech-Load Rules")
	public void GetLoadRules() throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		Response resp = adtech_CC.LoadRules(test);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}
	
	@Test( description = "POD3-Adtech-Load Experession item")
	public void GetLoadExpItem() throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		Response resp = adtech_CC.LoadExpItem(test);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}
	
	@Test(dependsOnMethods="GetLoadMetaData",description = "POD3-Adtech-Get Cache")
	public void GetCacheData() throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		Response resp = adtech_CC.GetCache(test);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}
	
	@Test( description = "POD3-Adtech-Get Item Cache")
	public void GetItemCacheData() throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		Response resp = adtech_CC.GetItemCache(test);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}
	
	@Test( description = "POD3-Adtech-Get Item by Id")
	public void GetItembyIdData() throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		Response resp = adtech_CC.GetItembyId(test);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}
	
	@Test( description = "POD3-Adtech-Get Contextual Items")
	public void GetContextualItemsData() throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		Response resp = adtech_CC.GetContextualItems(test);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}
	
	@Test( description = "POD3-Adtech-Get Clear Cache")
	public void GetClearCache() throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		Response resp = adtech_CC.ClearCache(test);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}


}
