package com.OTTPlatform.Adtech;

import org.testng.Reporter;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentTest;

import BusinessComponents.Adtech_PII;
import baseTestPackage.BaseTest_TestNG;
import io.restassured.response.Response;
import reusableLibrary.ResuableComponents;

public class Tests_Adtech_PII extends BaseTest_TestNG {
	
	Adtech_PII adtech_PII = new Adtech_PII();
	ResuableComponents resuableComponents = new ResuableComponents();
	
	@Test(dataProvider = "adtech_pii",description = "POD3 -ADTECH -Add Adtech PII")
	public void Add_RECO() throws Exception {
	ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
	Response resp= adtech_PII.create_PII(test);
	int statusCode = resp.getStatusCode();
	resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
	
}
	@DataProvider(name = "adtech_pii") 
	public Object[][] create_PII() { 
		 return new Object[][] { 
			 { } 
		}; 
	}


}
