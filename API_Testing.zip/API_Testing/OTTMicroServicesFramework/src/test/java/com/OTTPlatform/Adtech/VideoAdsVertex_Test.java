package com.OTTPlatform.Adtech;

import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentTest;

import BusinessComponents.Adtech_VideoAdsApi;
import baseTestPackage.BaseTest_TestNG;
import io.restassured.response.Response;
import reusableLibrary.JsonUtils;
import reusableLibrary.ResuableComponents;

public class VideoAdsVertex_Test extends BaseTest_TestNG {

	final String VideoAds = "VideoAds Test with payload";

	Adtech_VideoAdsApi adtech_VideoAPi = new Adtech_VideoAdsApi();

	ResuableComponents resuableComponents = new ResuableComponents();

	@Test(dataProvider = "VideoVertex", description = "Post Video Vertex Endpoints", groups = { "Regression" })
	public void postVideoVertex(String filename) throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		String reqBody = JsonUtils.readPayloadJson(filename);
		Response resp = adtech_VideoAPi.videoAdsVertexPost(reqBody, test);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}

	@DataProvider(name = "VideoVertex", parallel = true)
	public Object[][] dataProviderMethod() {
		return new Object[][] { { "premiumMovie.json" }, { "guestEpisode.json" } };
	}

	@Test(dataProvider = "VideoVertex1", description = "Post Video Vertex Endpoints", groups = { "Regression" })
	public void liveNewspostVideoVertex(String filename) throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		String reqBody = JsonUtils.readPayloadJson(filename);
		Response resp = adtech_VideoAPi.videoAdsVertexPost(reqBody, test);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(204), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(204));
	}

	@DataProvider(name = "VideoVertex1", parallel = true)
	public Object[][] dataProviderMethod1() {
		return new Object[][] { { "liveHtml.json" } };
	}
	
	@Test(description = "Get Probes Liveness in VideoAds Vertex", groups = { "Regression" })
	public void getLivenessVideoVertex() throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		Response resp = adtech_VideoAPi.videoAdsVertexGet(test);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}
	
}