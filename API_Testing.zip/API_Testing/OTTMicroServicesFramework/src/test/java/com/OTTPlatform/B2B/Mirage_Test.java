package com.OTTPlatform.B2B;

import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentTest;

import BusinessComponents.MirageAPI;
import baseTestPackage.BaseTest_TestNG;
import io.restassured.response.Response;
import reusableLibrary.JsonUtils;
import reusableLibrary.ResuableComponents;

public class Mirage_Test extends BaseTest_TestNG{

	ResuableComponents resuableComponents = new ResuableComponents();
	MirageAPI mirage=new MirageAPI();
	
	@Test(dataProvider = "createsso",description = "POD2-B2B - Generate the SSO tag")
	public void Generatessotag(String filename) throws Exception {
	    ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		String reqBody = JsonUtils.readPayloadJson(filename);
		Response resp = mirage.CreateSSOTag(reqBody,test);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}
	
	@DataProvider(name = "createsso")
	public Object[][] PostClient() {
		return new Object[][] { { "GenerateSSOTag_Mirage.json" } };
	}
	
	@Test(dependsOnMethods = {"Generatessotag"},  description = "POD2-B2B - Get the authorization token")
	public void Getauthtoken() throws Exception {
	    ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		Response resp = mirage.GetAuthToken(test);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);	
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}
}
