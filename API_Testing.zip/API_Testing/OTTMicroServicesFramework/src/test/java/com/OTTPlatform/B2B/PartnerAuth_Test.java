package com.OTTPlatform.B2B;

import java.util.Hashtable;

import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentTest;

import BusinessComponents.PartnerAuthAPI;
import baseTestPackage.BaseTest_TestNG;
import io.restassured.response.Response;
import reusableLibrary.JsonUtils;
import reusableLibrary.ResuableComponents;

public class PartnerAuth_Test extends BaseTest_TestNG{

	ResuableComponents resuableComponents = new ResuableComponents();
	PartnerAuthAPI partnerauth=new PartnerAuthAPI();
	
	@Test(dataProvider = "postcli",description = "POD2-B2B - Create the partner authorization for client")
	public void Postclient(String filename) throws Exception {
	    ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		String reqBody = JsonUtils.readPayloadJson(filename);
		Response resp = partnerauth.PostClient(reqBody,test);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}
	
	@DataProvider(name = "postcli")
	public Object[][] PostClient() {
		return new Object[][] { { "PostClient_Partnerauth.json" } };
	}
	
	@Test(dataProvider = "patchclient",description = "POD2-B2B - Update the test of partner authorization for client")
	public void Patchclienttest(String filename) throws Exception {
	    ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		String reqBody = JsonUtils.readPayloadJson(filename);
		Response resp = partnerauth.PatchClient(reqBody,test);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}
	
	@DataProvider(name = "patchclient")
	public Object[][] PatchClient() {
		return new Object[][] { { "PatchClient_Partnerauth.json" } };
	}
	
	@Test(description = "POD2-B2B - Create the token for partner authorization client")
	public void Postclienttoken() throws Exception {
	    ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		Response resp = partnerauth.PostClientToken(test);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);	
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}
	
	@Test(dependsOnMethods = {"Postclienttoken"}, description = "POD2-B2B - Create the token for partner authorization client introspect")
	public void Postclientintrospect() throws Exception {
	    ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		Response resp = partnerauth.PostClientIntrospect(test);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}

	@Test(description = "POD2-B2B - Get the client test for given ID")
	public void Getclienttest() throws Exception {
	    ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		Response resp = partnerauth.GetClient(test);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}
}
