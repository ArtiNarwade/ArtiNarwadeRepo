package com.OTTPlatform.B2B;

import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentTest;

import BusinessComponents.PartnerIamAPI;
import baseTestPackage.BaseTest_TestNG;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import reusableLibrary.JsonUtils;
import reusableLibrary.ResuableComponents;

public class PartnerIam_Test extends BaseTest_TestNG{

	ResuableComponents resuableComponents = new ResuableComponents();
	PartnerIamAPI partneriam=new PartnerIamAPI();
	
	@Test(description = "POD2-B2B - Get the self service registration")
	public void Getselfregister() throws Exception {
	    ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		Response resp = partneriam.GetSelfRegister(test);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
		
		//ResponseBody body=resp.getBody();
		//String bodyobj=body.asString();
		//JsonPath js=resp.jsonPath();
		//String value1=js.get("id");
	}
	
	@Test(dataProvider = "selfreg",description = "POD2-B2B - Create the self service registration using get ID")
	public void Postselfregister(String filename) throws Exception {
	    ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		String reqBody = JsonUtils.readPayloadJson(filename);
		reqBody=reqBody.replace("$email$", "Himan"+Math.random()+"@gmail.com");
		Response resp = partneriam.CreateSelfRegister(test,reqBody);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));

	}
	
	@DataProvider(name = "selfreg")
	public Object[][] CreateSelfRegister() {
		return new Object[][] { { "selfRegistration_partneriam.json" } };
	}
	
	@Test(description = "POD2-B2B - Get the self service login")
	public void Getselflogin() throws Exception {
	    ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		Response resp = partneriam.GetSelfLogin(test);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
		
		//ResponseBody body=resp.getBody();
		//String bodyobj=body.asString();
	}
	
	@Test(dataProvider = "selflogin",description = "POD2-B2B - Create the self service login using get ID")
	public void Postselflogin(String filename) throws Exception {
	    ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		String reqBody = JsonUtils.readPayloadJson(filename);
		Response resp = partneriam.CreateSelfLogin(test,reqBody);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);	
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}
	
	@DataProvider(name = "selflogin")
	public Object[][] CreateSelfLogin() {
		return new Object[][] { { "SelfLogin_Partneriam.json" } };
	}
}
