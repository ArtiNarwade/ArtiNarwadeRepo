package com.OTTPlatform.B2B;

import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentTest;

import BusinessComponents.RuleEngineAPI;
import BusinessComponents.PartnerOnboarding;
import baseTestPackage.BaseTest_TestNG;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import reusableLibrary.JsonUtils;
import reusableLibrary.ResuableComponents;

public class Tests_PartnerOnboarding extends BaseTest_TestNG {
	
	ResuableComponents resuableComponents = new ResuableComponents();
	PartnerOnboarding selfServicePortal = new PartnerOnboarding();
	RuleEngineAPI ruletest=new RuleEngineAPI();
	public static String request_id;
	public static String ticketId1_Approve;
	public static String ticketId1_Search;
	public static String ticketId1_upload;

	//Partner-Onboarding
	@Test(dataProvider = "partner_request",description = "POD2-B2B-Create partner request")
	public void partner_request(String filename) throws Exception {
	    ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
	    /*String reqBodyd = JsonUtils.readPayloadJson("emailrule.json");
		ruletest.CreateEmailRule(test, reqBodyd);*/
		
		String reqBody = JsonUtils.readPayloadJson(filename);
		Response resp = selfServicePortal.Request_partner(test,reqBody);
		JsonPath js = resp.jsonPath();
		request_id=js.getString("ticketID");
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));

	}
	@DataProvider(name ="partner_request")
	public Object[][] Request_partner() {
	return new Object[][] { {"SelfServicePortal_request-partner.json"}};
	}
	
	@Test(dependsOnMethods="partner_request",dataProvider = "Request_Update",description = "POD2-B2B-Update partner request",priority=2)
	public void request_Update(String filename) throws Exception {
	    ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		String reqBody = JsonUtils.readPayloadJson(filename);
		Response resp = selfServicePortal.Request_Update(test,reqBody);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);	
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));

	}
	@DataProvider(name ="Request_Update")
	public Object[][] Request_Update() {
	return new Object[][] { {"SelfServicePortal_request-partner.json"}};
		
}
	
	@Test(dependsOnMethods="partner_request",dataProvider = "partner_approve",description = "POD2-B2B-Create partner approve",priority=3)
	public void partner_approve(String filename) throws Exception {
	    ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
	    
	    /*String reqBodyd = JsonUtils.readPayloadJson("emailrule.json");
		ruletest.CreateEmailRule(test, reqBodyd);

	    String reqBody1 = JsonUtils.readPayloadJson("fetchrule.json");
		ruletest.CreateFetchRule(test, reqBody1);*/

		String reqBody = JsonUtils.readPayloadJson(filename);
		reqBody=reqBody.replace("$ID$", request_id);
		Response resp = selfServicePortal.Approve_partner(test,reqBody);
		JsonPath js = resp.jsonPath();
		ticketId1_Approve=js.getString("ticketId");
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));

	}
	@DataProvider(name ="partner_approve")
	public Object[][] Approve_partner() {
	return new Object[][] { {"SelfServicePortal_partner_Approve.json"}};
	}
	
	
	
	@Test(dependsOnMethods="partner_approve",dataProvider = "SearchTicket",description = "POD2-B2B-Search Ticket",priority=4)
	public void Search_ticket(String filename) throws Exception {
	    ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		String reqBody = JsonUtils.readPayloadJson(filename);
		reqBody=reqBody.replace("$Id1$", ticketId1_Approve);
		Response resp = selfServicePortal.SearchTicket(test,reqBody);
		JsonPath js = resp.jsonPath();
		ticketId1_Search=js.getString("searchResponse.ticketId[0]");
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));

	}
	@DataProvider(name ="SearchTicket")
	public Object[][] SearchTicket() {
	return new Object[][] { {"SelfServicePortal_TicketSearch.json"}};
	}
	
	@Test(dependsOnMethods="Search_ticket",dataProvider = "upload", description = "POD2-B2B-upload_DOC")
	public void createupload(String fileName) throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		String reqBody = JsonUtils.jsonFileReader(fileName);
		Response resp = selfServicePortal.CreateUpload(test,reqBody);
		JsonPath js = resp.jsonPath();
		ticketId1_upload=js.getString("id");
		int StatusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(StatusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}
 
	@DataProvider(name = "upload")
	public Object[][] CreateUpload() {
		return new Object[][] { { "Files/parnerOnboarding_test.txt" } };
	}

	
	@Test(dependsOnMethods="Search_ticket",dataProvider = "UpdateTicketPlans",description = "POD2-B2B-Update Ticket Status")
	public void Update_Ticket_Status(String filename) throws Exception {
	    ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		String reqBody = JsonUtils.readPayloadJson(filename);
		Response resp = selfServicePortal.UpdateTicketStatus(test,reqBody);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));

	}
	@DataProvider(name ="UpdateTicketPlans")
	public Object[][] UpdateTicketStatus() {
	return new Object[][] { {"SelfServicePortal_TicketStatusUpdate.json"}};
	}

	@Test(dependsOnMethods="Update_Ticket_Status",dataProvider = "UpdatePlans",description = "POD2-B2B-Update Plans")
	public void plans_Update(String filename) throws Exception {
	    ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		String reqBody = JsonUtils.readPayloadJson(filename);
		Response resp = selfServicePortal.UpdatePlans(test,reqBody);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));

	}
	@DataProvider(name ="UpdatePlans")
	public Object[][] UpdatePlans() {
	return new Object[][] { {"SelfServicePortal_Plans.json"}};
	}
		
	@Test(dependsOnMethods="createupload",description = "POD2-B2B-Get Download Docs")
	public void get_Download_Docs() throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		Response resp = selfServicePortal.getDownloadDocs(test);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}
	
	
	@Test(description = "POD2-B2B-Get Product Details")
	public void GetproductDetails() throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		Response resp = selfServicePortal.getProductDetails(test);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}
	
	@Test(description = "POD2-B2B-Get API Details")
	public void GetAPIDetails() throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		Response resp = selfServicePortal.getApiDetails(test);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}
	
	@Test(description = "POD2-B2B-Get Client Credentials")
	public void GetClientCredentials() throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		Response resp = selfServicePortal.getClientCredentials(test);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}
	
	@Test(description = "POD2-B2B-Get Partner Role With Session Id ")
	public void get_Partner_Role() throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		Response resp = selfServicePortal.getPartnerRolewithSessionID(test);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}
	
	@Test(dataProvider = "AccountRecovery",description = "POD2-B2B-Create Account Recovery")
	public void accountRecovery(String filename) throws Exception {
	    ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
//	    String reqBodyd = JsonUtils.readPayloadJson("fetchrule.json");
//		ruletest.CreateFetchRule(test, reqBodyd);

		String reqBody = JsonUtils.readPayloadJson(filename);
		Response resp = selfServicePortal.AccountRecovery(test,reqBody);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));

	}
	@DataProvider(name ="AccountRecovery")
	public Object[][] AccountRecovery() {
	return new Object[][] { {"SelfServicePortal_AccountRecovery.json"}};
	}
	
	@Test(dependsOnMethods="partner_request",description = "POD2-B2B-Get Ticket Transaction Details")
	public void get_ticket_transactions_details() throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		Response resp = selfServicePortal.ticket_transactions_details(test);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}
	
	@Test(description = "POD2-B2B-Get User Details")
	public void get_user_Details() throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		Response resp = selfServicePortal.user_Details(test);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}
	
	@Test(dataProvider = "partner_contact",description = "POD2-B2B-Create Partner Contact")
	public void Create_partner_contact(String filename) throws Exception {
	    ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
//	    String reqBodyd = JsonUtils.readPayloadJson("fetchrule.json");
//		ruletest.CreateFetchRule(test, reqBodyd);

		String reqBody = JsonUtils.readPayloadJson(filename);
		Response resp = selfServicePortal.partner_contact(test,reqBody);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(201), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(201));

	}
	@DataProvider(name ="partner_contact")
	public Object[][] partner_contact() {
	return new Object[][] { {"SelfServicePortal_PartnerContact.json"}};
	}
	
	
	@Test(dependsOnMethods="get_Download_Docs",description = "POD2-B2B-Delete_DOC")
	public void DeleteDetails() throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		Response resp = selfServicePortal.delete_Details(test);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}


}
