package com.OTTPlatform.CatalogService;

import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import com.relevantcodes.extentreports.ExtentTest;

import baseTestPackage.BaseTest_TestNG;
import BusinessComponents.CS_ContentAPI;
import BusinessComponents.CS_HelpAPI;
import io.restassured.response.Response;
import reusableLibrary.JsonUtils;
import reusableLibrary.ResuableComponents;

public class CS_ContentAPI_Test extends BaseTest_TestNG{

	
	ResuableComponents resuableComponents = new ResuableComponents();
	CS_ContentAPI ContentAPI  = new CS_ContentAPI();
	
	@Test(description = "Get TV show genre list API call")
	public void getTvShowGenreList() throws Exception
	{
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		Response resp = ContentAPI .getTvShowGenreListUsingGetCall(test);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));	
	}
	@Test(description = "Get movie genre API call")
	public void getMovieGenre() throws Exception
	{
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		Response resp = ContentAPI .getMovieGenreUsingGetCall(test);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));	
	}
	@Test(description = "Get partner feed content listing API call")
	public void getPartnerFeedContentListing() throws Exception
	{
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		Response resp = ContentAPI .getPartnerFeedContentListingUsingGetCall(test);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));	
	}
	@Test(description = "Get News API call")
	public void getNewsRelated() throws Exception
	{
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		Response resp = ContentAPI .getNewsRelatedUsingGetCall(test);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));	
	}
	@Test(description = "Get extract platform URL API call")
	public void getExtractPlatformUrl() throws Exception
	{
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		Response resp = ContentAPI .getExtractPlatformUrlUsingGetCall(test);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));	
	}
	@Test(description = "Get TV show home API call")
	public void getTvShowHome() throws Exception
	{
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		Response resp = ContentAPI .getTvShowHomeUsingGetCall(test);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));	
	}
	@Test(description = "Get movie languages API call")
	public void getMovieLanguages() throws Exception
	{
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		Response resp = ContentAPI .getMovieLanguagesUsingGetCall(test);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));	
	}
	@Test(description = "Get TV show genre API call")
	public void getTvShowGenre() throws Exception
	{
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		Response resp = ContentAPI .getTvShowGenreUsingGetCall(test);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));	
	}
	@Test(description = "Get SEO genre or Languages list API call")
	public void getSEOGenreOrLanguages() throws Exception
	{
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		Response resp = ContentAPI .getSEOGenreOrLanguagesUsingGetCall(test);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));	
	}
	
	
	
}
