package com.OTTPlatform.CatalogService;

import java.util.Hashtable;

import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import com.relevantcodes.extentreports.ExtentTest;

import BusinessComponents.CS_MusicBackend;
import BusinessComponents.UM_GuestScylla;
import BusinessComponents.UM_TokenVerification;
import BusinessComponents.UM_UserToken;
import BusinessComponents.UP_UserProfile;
import baseTestPackage.BaseTest_TestNG;
import io.restassured.response.Response;
import reusableLibrary.JsonUtils;
import reusableLibrary.ResuableComponents;
import reusableLibrary.StringUtils;
import io.restassured.path.json.JsonPath;

public class CS_MusicBackend_Test  extends BaseTest_TestNG {
	
	CS_MusicBackend MusicBackend = new CS_MusicBackend();
	ResuableComponents resuableComponents = new ResuableComponents();
	UM_UserToken usertoken = new UM_UserToken();
	StringUtils stringutils= new StringUtils();
	//private JsonPath jsonPath;
	private String Id;
	
	// GENERIC METHOD TO GENERATE TOKEN
	public JsonPath getUserToken(ExtentTest test) throws Exception {
		String requestBody = JsonUtils.readPayloadJson("UMTokenGenerate.json");
		Response resp = usertoken.tokenGenreatePost(test, requestBody);
		System.out.print(resp);
		String responsebody = resp.getBody().asString();
		JsonPath jsonPath = resp.jsonPath();
		
		return jsonPath;

	}
	@Test(description = "Verify Set user playlist API Call")
	public void getUserPlaylist() throws Exception {
	ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
	Hashtable<String, String> headers1 = new Hashtable<String, String>();
	JsonPath tokenJsonPath = getUserToken(test);
	String token = tokenJsonPath.getString("token");
	headers1.put("Authorization","Bearer "+tokenJsonPath.getString("token"));
	Response resp= MusicBackend.getUserPlaylistUsingGetCall(test,headers1);
	int statusCode = resp.getStatusCode();
	resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
	Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
}
	@Test(description = "Verify artist details API Call")
	public void getArtistDetails() throws Exception {
	ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
	Hashtable<String, String> headers1 = new Hashtable<String, String>();
	JsonPath tokenJsonPath = getUserToken(test);
	String token = tokenJsonPath.getString("token");
	Response resp= MusicBackend.getArtistDetailsUsingGetCall(test,headers1);
	int statusCode = resp.getStatusCode();
	resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
	Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
}
	@Test(description = "Verify song details API Call")
	public void getSongDetails() throws Exception {
	ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
	Hashtable<String, String> headers1 = new Hashtable<String, String>();
	JsonPath tokenJsonPath = getUserToken(test);
	String token = tokenJsonPath.getString("token");
	headers1.put("Authorization","Bearer "+tokenJsonPath.getString("token"));
	Response resp= MusicBackend.getSongDetailsUsingGetCall(test,headers1);
	int statusCode = resp.getStatusCode();
	resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
	Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
}
	
	@Test(description = "Verify the Album Details")
	public void getAlbumDetails() throws Exception {
	ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
	Hashtable<String, String> headers1 = new Hashtable<String, String>();
	JsonPath tokenJsonPath = getUserToken(test);
	String token = tokenJsonPath.getString("token");
	headers1.put("Authorization","Bearer "+tokenJsonPath.getString("token"));
	Response resp= MusicBackend.getAlbumDetailsGetCall(test,headers1);
	int statusCode = resp.getStatusCode();
	resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
	Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
}

	@Test(description = "Verify the Discovery API")
	public void getDiscovery() throws Exception {
	ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
	Hashtable<String, String> headers1 = new Hashtable<String, String>();
	JsonPath tokenJsonPath = getUserToken(test);
	String token = tokenJsonPath.getString("token");
	Response resp= MusicBackend.getDiscoveryGetCall(test,headers1);
	int statusCode = resp.getStatusCode();
	resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
	Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
}
	
	@Test(dataProvider = "UpdateUserPlaylist",description = "Update User PlayList PUT API Call")
	public void UpdateUserPlaylistPUT(String fileName) throws Exception {
		
	ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
	String requestBody = JsonUtils.readPayloadJson(fileName);
	Hashtable<String, String> headers1 = new Hashtable<String, String>();
	JsonPath tokenJsonPath = getUserToken(test);
	String token = tokenJsonPath.getString("token");
	headers1.put("Authorization","Bearer "+token);
	Response resp= MusicBackend.UpdateUserPlaylistPUTCall(test,requestBody,headers1);
	int statusCode = resp.getStatusCode();
	resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
	Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));

}
	@DataProvider(name = "UpdateUserPlaylist")
	public Object[][] UpdateUserPlaylist() {
	return new Object[][] { {"MusicBackend_UpdateUserPlaylist.json"  }};
	}
	
	@Test(description = "Verify the Song PlayBack API")
	public void getSongPlayback() throws Exception {
	ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
	Hashtable<String, String> headers1 = new Hashtable<String, String>();
	JsonPath tokenJsonPath = getUserToken(test);
	String token = tokenJsonPath.getString("token");
	Response resp= MusicBackend.getSongPlaybackGetCall(test,headers1);
	int statusCode = resp.getStatusCode();
	resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
	Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
}

	@Test(description = "Verify the Language List API")
	public void getLanguageList() throws Exception {
	ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
	Hashtable<String, String> headers1 = new Hashtable<String, String>();
	JsonPath tokenJsonPath = getUserToken(test);
	String token = tokenJsonPath.getString("token");
	Response resp= MusicBackend.getLanguageListGetCall(test,headers1);
	int statusCode = resp.getStatusCode();
	resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
	Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
}
	
	@Test(dataProvider = "SetUserLanguage",description ="Verify the Set user languages using Post call")
	public void SetUserLanguagePost(String fileName) throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		String requestBody = JsonUtils.readPayloadJson(fileName);
		Hashtable<String, String> headers1 = new Hashtable<String, String>();
		JsonPath tokenJsonPath = getUserToken(test);
		String token = tokenJsonPath.getString("token");
		headers1.put("Authorization","Bearer "+tokenJsonPath.getString("token"));
		Response resp = MusicBackend.SetUserLanguagePostCall(test,requestBody,headers1);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));	
	}
	
	@DataProvider(name = "SetUserLanguage")
	public Object[][] SetUserLanguage() {
	return new Object[][] { {"MusicBackend_SetUserLanguage.json"  }};
	}
	

	@Test(description = "Verify the Get Users Language API")
	public void getUserLanguage() throws Exception {
	ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
	Hashtable<String, String> headers1 = new Hashtable<String, String>();
	JsonPath tokenJsonPath = getUserToken(test);
	headers1.put("Authorization","Bearer "+tokenJsonPath.getString("token"));
	Response resp= MusicBackend.getUserLanguageGetCall(test,headers1);
	int statusCode = resp.getStatusCode();
	resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
	Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
}
	
	@Test(description = "Verify the Users PlayList API")
	public void UserPlaylist() throws Exception {
	ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
	Hashtable<String, String> headers1 = new Hashtable<String, String>();
	JsonPath tokenJsonPath = getUserToken(test);
	headers1.put("Authorization","Bearer "+tokenJsonPath.getString("token"));
	Response resp= MusicBackend.getUserPlayListGetCall(test,headers1);
	int statusCode = resp.getStatusCode();
	resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
	Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
}
	
	@Test(dataProvider = "UpdateTrackRecordPlaylist",description = "Update Track Record PlayList PUT API Call")
	public void UpdateTrackRecordPlaylistPUT(String fileName) throws Exception {
		
	ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
	String requestBody = JsonUtils.readPayloadJson(fileName);
	Hashtable<String, String> headers1 = new Hashtable<String, String>();
	JsonPath tokenJsonPath = getUserToken(test);
	String token = tokenJsonPath.getString("token");
	headers1.put("Authorization","Bearer "+tokenJsonPath.getString("token"));
	Response resp= MusicBackend.UpdateTrackRecordPlaylistPUTCall(test,requestBody,headers1);
	int statusCode = resp.getStatusCode();
	resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
	Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));

	}
	
	@DataProvider(name = "UpdateTrackRecordPlaylist")
	public Object[][] UpdateTrackRecordPlaylist() {
	return new Object[][] { {"MusicBackend_UpdateTrackRecordPlaylist.json"  }};
	}
	
	@Test(description = "Verify the Users PlayList Details API")
	public void GetUserPlaylistDetails() throws Exception {
	ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
	Hashtable<String, String> headers1 = new Hashtable<String, String>();
	JsonPath tokenJsonPath = getUserToken(test);
	headers1.put("Authorization","Bearer "+tokenJsonPath.getString("token"));
	Response resp= MusicBackend.getUserPlayListDetailsGetCall(test,headers1);
	int statusCode = resp.getStatusCode();
	resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
	Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}
	
	@Test(dataProvider="AddFavorite" ,description = "Verify the Add Favorite API")
	public void AddFavoritePost(String fileName) throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		String requestBody = JsonUtils.readPayloadJson(fileName);
		Hashtable<String, String> headers1 = new Hashtable<String, String>();
		JsonPath tokenJsonPath = getUserToken(test);
		String token = tokenJsonPath.getString("token");
		headers1.put("Authorization","Bearer "+tokenJsonPath.getString("token"));
		Response resp = MusicBackend.AddFavouritesPOSTCall(test,requestBody,headers1);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));	

		}
	@DataProvider(name = "AddFavorite")
	public Object[][] AddFavourite() {
	return new Object[][] { {"MusicBackend_AddFavorite.json"  }};
	}
	
	@Test(description = "Verify the Content Favorite API")
	public void ContentFavorite() throws Exception 
	{
		
	ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
	Hashtable<String, String> headers1 = new Hashtable<String, String>();
	JsonPath tokenJsonPath = getUserToken(test);
	headers1.put("Authorization","Bearer "+tokenJsonPath.getString("token"));
	Response resp= MusicBackend.getContentFavoriteGetCall(test,headers1);
	int statusCode = resp.getStatusCode();
	resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
	Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}
	
	@Test(description = "Verify the Favorite Type Count API")
	public void FavoriteTypeCountGet() throws Exception 
	{
		
	ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
	Hashtable<String, String> headers1 = new Hashtable<String, String>();
	JsonPath tokenJsonPath = getUserToken(test);
	headers1.put("Authorization","Bearer "+tokenJsonPath.getString("token"));
	Response resp= MusicBackend.getFavoriteTypeCountGetCall(test,headers1);
	int statusCode = resp.getStatusCode();
	resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
	Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}
	
	@Test(description = "Verify the Search API")
	public void Search() throws Exception 
	{
		
	ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
	Hashtable<String, String> headers1 = new Hashtable<String, String>();
	JsonPath tokenJsonPath = getUserToken(test);
	headers1.put("Authorization","Bearer "+tokenJsonPath.getString("token"));
	Response resp= MusicBackend.SearchGetCall(test,headers1);
	int statusCode = resp.getStatusCode();
	resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
	Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}
	
	@Test(description = "Verify the Follow and UnFollow API")
	public void FollowandUnFollowGet() throws Exception 
	{
		
	ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
	Hashtable<String, String> headers1 = new Hashtable<String, String>();
	JsonPath tokenJsonPath = getUserToken(test);
	headers1.put("Authorization","Bearer "+tokenJsonPath.getString("token"));
	Response resp= MusicBackend.FollowandUnFollowGetCall(test,headers1);
	int statusCode = resp.getStatusCode();
	resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
	Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}
	
	@Test(dataProvider="RecentlyPlayed" ,description = "Verify the Recently Played POST API")
	public void RecentlyPlayedPost(String fileName) throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		String requestBody = JsonUtils.readPayloadJson(fileName);
		Hashtable<String, String> headers1 = new Hashtable<String, String>();
		JsonPath tokenJsonPath = getUserToken(test);
		String token = tokenJsonPath.getString("token");
		headers1.put("Authorization","Bearer "+tokenJsonPath.getString("token"));
		Response resp = MusicBackend.RecentlyPlayedPOSTCall(test,requestBody,headers1);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));	

		}
	@DataProvider(name = "RecentlyPlayed")
	public Object[][] RecentlyPlayed() {
	return new Object[][] { {"MusicBackend_RecentlyPlayed.json"  }};
	}
	
	
	@Test(description = "Verify the Recently Played Get API")
	public void RecentlyPlayedGet() throws Exception 
	{
		
	ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
	Hashtable<String, String> headers1 = new Hashtable<String, String>();
	JsonPath tokenJsonPath = getUserToken(test);
	headers1.put("Authorization","Bearer "+tokenJsonPath.getString("token"));
	Response resp= MusicBackend.RecentlyPlayedGETCall(test,headers1);
	int statusCode = resp.getStatusCode();
	resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
	Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}
	
	@Test(dataProvider="SetUserPlaylist" ,description = "Verify the Set User Playlist POST API Call")
	public void SetUserPlayListPost(String fileName) throws Exception {
		
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		String requestBody = JsonUtils.readPayloadJson(fileName);
		String Playlistname=stringutils.getRandomString();
		
		requestBody=requestBody.replace("$Playlistname$", Playlistname);
		Hashtable<String, String> headers1 = new Hashtable<String, String>();
		JsonPath tokenJsonPath = getUserToken(test);
		String token = tokenJsonPath.getString("token");
		headers1.put("Authorization","Bearer "+tokenJsonPath.getString("token"));
		Response resp = MusicBackend.SetUserPlaylistPOSTCall(test,requestBody,headers1);
		
		JsonPath Playlistid=resp.jsonPath();
		Id=Playlistid.getString("playlists.id");
		
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
		
		

		}
	@DataProvider(name = "SetUserPlaylist")
	public Object[][] SetUserPlaylist() {
	return new Object[][] { {"MusicBackend_SetUserPlaylist.json"  }};
	}
	
	@Test(description = "Verify the Celeb Radio Get API")
	public void CelebRadioGet() throws Exception 
	{
		
	ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
	Hashtable<String, String> headers1 = new Hashtable<String, String>();
	JsonPath tokenJsonPath = getUserToken(test);
	headers1.put("Authorization","Bearer "+tokenJsonPath.getString("token"));
	Response resp= MusicBackend.CelebRadioGETCall(test,headers1);
	int statusCode = resp.getStatusCode();
	resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
	Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}
	
	@Test(description = "Verify the On Demand Radio Get API")
	public void OnDemandRadioGet() throws Exception 
	{
		
	ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
	Hashtable<String, String> headers1 = new Hashtable<String, String>();
	JsonPath tokenJsonPath = getUserToken(test);
	headers1.put("Authorization","Bearer "+tokenJsonPath.getString("token"));
	Response resp= MusicBackend.OnDemandRadioGETCall(test,headers1);
	int statusCode = resp.getStatusCode();
	resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
	Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}
	
	@Test(description = "Verify the Trending Artist Details Get API")
	public void TredingArtistsDetails() throws Exception 
	{
		
	ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
	Hashtable<String, String> headers1 = new Hashtable<String, String>();
	JsonPath tokenJsonPath = getUserToken(test);
	headers1.put("Authorization","Bearer "+tokenJsonPath.getString("token"));
	Response resp= MusicBackend.TrendingArtistDetailsGETCall(test,headers1);
	int statusCode = resp.getStatusCode();
	resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
	Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}
	
	@Test(description = "Verify the Followed Artist List Details Get API")
	public void FollowedArtistsDetails() throws Exception 
	{
		
	ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
	Hashtable<String, String> headers1 = new Hashtable<String, String>();
	JsonPath tokenJsonPath = getUserToken(test);
	headers1.put("Authorization","Bearer "+tokenJsonPath.getString("token"));
	Response resp= MusicBackend.FollowedArtistDetailsGETCall(test,headers1);
	int statusCode = resp.getStatusCode();
	resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
	Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}
	
	
	@Test(description = "Verify the Song recomnidation Get API")
	public void SongRecomnidationGet() throws Exception 
	{
		
	ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
	Hashtable<String, String> headers1 = new Hashtable<String, String>();
	JsonPath tokenJsonPath = getUserToken(test);
	headers1.put("Authorization","Bearer "+tokenJsonPath.getString("token"));
	Response resp= MusicBackend.SongsRecomndatoinGETCall(test,headers1);
	int statusCode = resp.getStatusCode();
	resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
	Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}
	
	@Test(description = "Verify the All Types recomnidation Get API")
	public void AllTypesRecomnidationGet() throws Exception 
	{
		
	ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
	Hashtable<String, String> headers1 = new Hashtable<String, String>();
	JsonPath tokenJsonPath = getUserToken(test);
	headers1.put("Authorization","Bearer "+tokenJsonPath.getString("token"));
	Response resp= MusicBackend.AllTypesRecomndatoinGETCall(test,headers1);
	int statusCode = resp.getStatusCode();
	resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
	Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}
	
	@Test(description = "Verify the Artist recomnidation Get API")
	public void ArtistRecomnidationGet() throws Exception 
	{
		
	ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
	Hashtable<String, String> headers1 = new Hashtable<String, String>();
	JsonPath tokenJsonPath = getUserToken(test);
	headers1.put("Authorization","Bearer "+tokenJsonPath.getString("token"));
	Response resp= MusicBackend.ArtistRecomndatoinGETCall(test,headers1);
	int statusCode = resp.getStatusCode();
	resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
	Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}
	
	@Test(description = "Verify the PlayList Genere Get API")
	public void PlayListGenreGet() throws Exception 
	{
		
	ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
	Hashtable<String, String> headers1 = new Hashtable<String, String>();
	JsonPath tokenJsonPath = getUserToken(test);
	headers1.put("Authorization","Bearer "+tokenJsonPath.getString("token"));
	Response resp= MusicBackend.PlayListGenereGETCall(test,headers1);
	int statusCode = resp.getStatusCode();
	resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
	Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}
	
	@Test(description = "Verify the PlayList Tag Get API")
	public void PlayListTagGet() throws Exception 
	{
		
	ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
	Hashtable<String, String> headers1 = new Hashtable<String, String>();
	JsonPath tokenJsonPath = getUserToken(test);
	headers1.put("Authorization","Bearer "+tokenJsonPath.getString("token"));
	Response resp= MusicBackend.PlayListTagGETCall(test,headers1);
	int statusCode = resp.getStatusCode();
	resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
	Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}
	@Test(description = "Verify the View Bucket Get API")
	public void ViewBucketGet() throws Exception 
	{
		
	ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
	Hashtable<String, String> headers1 = new Hashtable<String, String>();
	JsonPath tokenJsonPath = getUserToken(test);
	headers1.put("Authorization","Bearer "+tokenJsonPath.getString("token"));
	Response resp= MusicBackend.ViewBucketGETCall(test,headers1);
	int statusCode = resp.getStatusCode();
	resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
	Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}
	
	@Test(description = "Verify the Hungama UserId Get API")
	public void HungamaUseridGet() throws Exception 
	{
		
	ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
	Hashtable<String, String> headers1 = new Hashtable<String, String>();
	JsonPath tokenJsonPath = getUserToken(test);
	headers1.put("Authorization","Bearer "+tokenJsonPath.getString("token"));
	Response resp= MusicBackend.HungamaUseridGETCall(test,headers1);
	int statusCode = resp.getStatusCode();
	resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
	Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}
	@Test(description = "Verify the Entry Point Rails Get API")
	public void EntryPointRailsGet() throws Exception 
	{
		
	ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
	Hashtable<String, String> headers1 = new Hashtable<String, String>();
	JsonPath tokenJsonPath = getUserToken(test);
	headers1.put("Authorization","Bearer "+tokenJsonPath.getString("token"));
	Response resp= MusicBackend.EntryPointRailsGETCall(test,headers1);
	int statusCode = resp.getStatusCode();
	resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
	Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}
	
	@Test(dataProvider = "DeleteRemoveFavorite" ,description =  "Delete Remove Favorite DELETE API Call")
	public void DeleteRemoveFavoriteDeleteCall(String fileName) throws Exception {
		
	ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
	Hashtable<String, String> headers1 = new Hashtable<String, String>();
	JsonPath tokenJsonPath = getUserToken(test);
	String requestBody = JsonUtils.readPayloadJson(fileName);
	String token = tokenJsonPath.getString("token");
	headers1.put("Authorization","Bearer "+tokenJsonPath.getString("token"));
	Response resp= MusicBackend.DeleteRemoveFavoriteCall(test,requestBody,headers1);
	int statusCode = resp.getStatusCode();
	resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
	Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}
	
	@DataProvider(name = "DeleteRemoveFavorite")
	public Object[][] DeleteRemoveFavorite() {
	return new Object[][] { {"MusicBackend_DeleteRemoveFavorite.json"  }};
	}
	
	
	@Test(dependsOnMethods = {"SetUserPlayListPost"},description = "Delete User PlayList DELETE API Call")
	public void DeleteUserPlaylist() throws Exception {

		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		Hashtable<String, String> headers1 = new Hashtable<String, String>();
		JsonPath tokenJsonPath = getUserToken(test);
		String token = tokenJsonPath.getString("token");
		headers1.put("Authorization", "Bearer " + tokenJsonPath.getString("token"));
		Response resp = MusicBackend.DeleteUserPlaylistDeleteCall(test, headers1, Id);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));

		
	}
	 
	
	@Test(dataProvider = "DeleteRecentlyPlayed" ,description =  "Delete Recently Played DELETE API Call")
	public void DeleteRecentlyPlayedDeleteCall(String fileName) throws Exception {
		
	ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
	Hashtable<String, String> headers1 = new Hashtable<String, String>();
	JsonPath tokenJsonPath = getUserToken(test);
	String requestBody = JsonUtils.readPayloadJson(fileName);
	String token = tokenJsonPath.getString("token");
	headers1.put("Authorization","Bearer "+tokenJsonPath.getString("token"));
	Response resp= MusicBackend.DeleteRecentlyPlayedDeleteCall(test,requestBody,headers1);
	int statusCode = resp.getStatusCode();
	resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
	Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}
	
	@DataProvider(name = "DeleteRecentlyPlayed")
	public Object[][] DeleteRecentlyPlayed() {
	return new Object[][] { {"MusicBackend_DeleteRemoveFavorite.json"  }};
	}
	
	
	@Test(description = "Verify the Downloads Get API")
	public void DownloadsGet() throws Exception 
	{
	ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
	Hashtable<String, String> headers1 = new Hashtable<String, String>();
	JsonPath tokenJsonPath = getUserToken(test);
	headers1.put("Authorization","Bearer "+tokenJsonPath.getString("token"));
	Response resp= MusicBackend.DownloadsGETCall(test,headers1);
	int statusCode = resp.getStatusCode();
	resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
	Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}
	
	@Test(dataProvider = "AddDownloadsTrack",description ="Verify the Add Downloads Track using Post call")
	public void AddDownloadsTrackPost(String fileName) throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		String requestBody = JsonUtils.readPayloadJson(fileName);
		Hashtable<String, String> headers1 = new Hashtable<String, String>();
		JsonPath tokenJsonPath = getUserToken(test);
		String token = tokenJsonPath.getString("token");
		headers1.put("Authorization","Bearer "+tokenJsonPath.getString("token"));
		Response resp = MusicBackend.AddDownloadsTrackPOSTCall(test,requestBody,headers1);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));	
	}
	
	@DataProvider(name = "AddDownloadsTrack")
	public Object[][] AddDownloadsTrack() {
	return new Object[][] { {"MusicBackend_AddDownloadTracks.json"  }};
	}
	
	@Test(description = "Verify the Remove Song Download List Get API")
	public void RemovesongDownloadsListGet() throws Exception 
	{
	ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
	Hashtable<String, String> headers1 = new Hashtable<String, String>();
	JsonPath tokenJsonPath = getUserToken(test);
	headers1.put("Authorization","Bearer "+tokenJsonPath.getString("token"));
	Response resp= MusicBackend.RemoveSongDownloadsListGETCall(test,headers1);
	int statusCode = resp.getStatusCode();
	resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
	Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}
	
	@Test(description = "Delete Download Song DELETE API Call")
	public void DeleteDownloadSong() throws Exception {
		
	ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
	Hashtable<String, String> headers1 = new Hashtable<String, String>();
	JsonPath tokenJsonPath = getUserToken(test);
	String token = tokenJsonPath.getString("token");
	headers1.put("Authorization","Bearer "+tokenJsonPath.getString("token"));
	Response resp= MusicBackend.DeleteDownloadSongDeleteCall(test,headers1);
	int statusCode = resp.getStatusCode();
	resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
	Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));

}
	
	
	@Test(description = "Verify the PodCast Details Get API")
	public void PodCastDetailsGet() throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		Hashtable<String, String> headers1 = new Hashtable<String, String>();
		JsonPath tokenJsonPath = getUserToken(test);
		headers1.put("Authorization", "Bearer " + tokenJsonPath.getString("token"));
		Response resp = MusicBackend.PodCastDetailsGETCall(test, headers1);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}
	
	@Test(description = "Verify the Similar PodCast Get API")
	public void SimilarPodcastGet() throws Exception 
	{
	ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
	Hashtable<String, String> headers1 = new Hashtable<String, String>();
	JsonPath tokenJsonPath = getUserToken(test);
	headers1.put("Authorization","Bearer "+tokenJsonPath.getString("token"));
	Response resp= MusicBackend.SimilarPodCaseGETCall(test,headers1);
	int statusCode = resp.getStatusCode();
	resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
	Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}
	
	@Test(description = "Verify the PodCast Tagwise Get API")
	public void PodcastTagwiseGet() throws Exception 
	{
	ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
	Hashtable<String, String> headers1 = new Hashtable<String, String>();
	JsonPath tokenJsonPath = getUserToken(test);
	headers1.put("Authorization","Bearer "+tokenJsonPath.getString("token"));
	Response resp= MusicBackend.PodCastTagwiseGETCall(test,headers1);
	int statusCode = resp.getStatusCode();
	resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
	Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}
	
	@Test(description = "Verify the Authenticated Hungama User Get API")
	public void AuthenticatedHungamaUserGet() throws Exception 
	{
	ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
	Hashtable<String, String> headers1 = new Hashtable<String, String>();
	JsonPath tokenJsonPath = getUserToken(test);
	headers1.put("Authorization","Bearer "+tokenJsonPath.getString("token"));
	Response resp= MusicBackend.AuthenticatedHungamaUserGETCall(test,headers1);
	int statusCode = resp.getStatusCode();
	resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
	Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}	
}