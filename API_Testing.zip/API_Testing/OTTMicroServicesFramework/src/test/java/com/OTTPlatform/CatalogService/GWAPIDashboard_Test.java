package com.OTTPlatform.CatalogService;

import java.util.Hashtable;

import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentTest;

import BusinessComponents.GWAPIDashBoardPT_API;
import baseTestPackage.BaseTest_TestNG;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import reusableLibrary.JsonUtils;
import reusableLibrary.ResuableComponents;

public class GWAPIDashboard_Test extends BaseTest_TestNG {


	ResuableComponents resuableComponents = new ResuableComponents();
	GWAPIDashBoardPT_API Dashboard= new GWAPIDashBoardPT_API();
	private String token="";
	
	
	@Test(dataProvider = "Login",description ="Catalog Service - Verify the Login using Post call")
	public void LoginPost(String fileName) throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		String requestBody = JsonUtils.readPayloadJson(fileName);
		Hashtable<String, String> headers1 = new Hashtable<String, String>();
		Response resp = Dashboard.LoginPostCall(test,requestBody,headers1);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));	
		JsonPath Token= resp.jsonPath();
		token=Token.getString("token");
	}
	
	@DataProvider(name = "Login")
	public Object[][] Login() {
	return new Object[][] { {"GWAPIDashboard_Login.json"  }};
	}
	
	
	@Test(dependsOnMethods = { "LoginPost" }, description = "Catalog Service - Verify the TTL Updated using Post call")
	public void TTLUpdatePost() throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		Hashtable<String, String> headers1 = new Hashtable<String, String>();
		headers1.put("token",token);
		Response resp = Dashboard.TTLUpdatePostCall(test, "", headers1);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
		
	}
	
	@Test(dependsOnMethods = {"LoginPost"}, dataProvider = "CachingContentGenre",description ="Catalog Service - Verify the CachingContentGenre using Delete call")
	public void CachingContentGenreDelete(String fileName) throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		String requestBody = JsonUtils.readPayloadJson(fileName);
		Hashtable<String, String> headers1 = new Hashtable<String, String>();
		headers1.put("token",token);
		Response resp = Dashboard.CachingContentGenreDeleteCall(test,requestBody,headers1);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));	
		
	}
	
	@DataProvider(name = "CachingContentGenre")
	public Object[][] CachingContentGenre() {
	return new Object[][] { {"GWAPIDashboard_CachingContentGenre.json"  }};
	}
	
	@Test(dependsOnMethods = {"LoginPost"},dataProvider = "CachingContentGenre",description ="Catalog Service - Verify the Details using Delete call")
	public void DetailsDelete(String fileName) throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		String requestBody = JsonUtils.readPayloadJson(fileName);
		Hashtable<String, String> headers1 = new Hashtable<String, String>();
		headers1.put("token",token);
		Response resp = Dashboard.DetailsDeleteCall(test,requestBody,headers1);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));	
		
	}
	
	@Test(dependsOnMethods = {"LoginPost"}, dataProvider = "TVShowAPIS",description ="Catalog Service - Verify the TVShowAPIS using Delete call")
	public void TVShowAPISDelete(String fileName) throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		String requestBody = JsonUtils.readPayloadJson(fileName);
		Hashtable<String, String> headers1 = new Hashtable<String, String>();
		headers1.put("token",token);
		Response resp = Dashboard.TVShowAPIDeleteCall(test,requestBody,headers1);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));	
		
	}
	
	@DataProvider(name = "TVShowAPIS")
	public Object[][] TVShowAPIS() {
	return new Object[][] { {"GWAPIDashboard_TVShowAPIS.json"  }};
	}
	
	@Test(dependsOnMethods = {"LoginPost"}, dataProvider = "TVShowAPIS",description ="Catalog Service - Verify the Content Genre using Delete call")
	public void ContentGenreDelete(String fileName) throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		String requestBody = JsonUtils.readPayloadJson(fileName);
		Hashtable<String, String> headers1 = new Hashtable<String, String>();
		headers1.put("token",token);
		Response resp = Dashboard.ContentGenreDeleteCall(test,requestBody,headers1);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));	
		
	}
	

	@Test(dependsOnMethods = {"LoginPost"}, dataProvider = "TVShowAPIS",description ="Catalog Service - Verify the Next Previous using Delete call")
	public void NextPreviousDelete(String fileName) throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		String requestBody = JsonUtils.readPayloadJson(fileName);
		Hashtable<String, String> headers1 = new Hashtable<String, String>();
		headers1.put("token",token);
		Response resp = Dashboard.nextpreviousDeleteCall(test,requestBody,headers1);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));	
		
	}
	
	@Test(dependsOnMethods = {"LoginPost"},description ="Catalog Service - Verify the API Rules using Delete call")
	public void APIRulesDelete() throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		Hashtable<String, String> headers1 = new Hashtable<String, String>();
		headers1.put("token",token);
		Response resp = Dashboard.APIRulesDeleteCall(test,headers1);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));	
		
	}
	
	@Test(dependsOnMethods = {"LoginPost"},description ="Catalog Service - Verify the API Rules TV Shows using Delete call")
	public void APIRulesTvshowsDelete() throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		Hashtable<String, String> headers1 = new Hashtable<String, String>();
		headers1.put("token",token);
		Response resp = Dashboard.APIRulesTVShowsDeleteCall(test,headers1);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));	
		
	}
	
	@Test(dependsOnMethods = {"LoginPost"},description ="Catalog Service - Verify the API Rules Next Previous using Delete call")
	public void APIRulesNextPreviousDelete() throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		Hashtable<String, String> headers1 = new Hashtable<String, String>();
		headers1.put("token",token);
		Response resp = Dashboard.APIRulesNextPreviousDeleteCall(test,headers1);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));	
		
	}
	
	@Test(dependsOnMethods = {"LoginPost"},description ="Catalog Service - Verify the API Rules Details using Delete call")
	public void APIRulesDetailsDelete() throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		Hashtable<String, String> headers1 = new Hashtable<String, String>();
		headers1.put("token",token);
		Response resp = Dashboard.APIRulesDetailsDeleteCall(test,headers1);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));	
		
	}
	
	
}
