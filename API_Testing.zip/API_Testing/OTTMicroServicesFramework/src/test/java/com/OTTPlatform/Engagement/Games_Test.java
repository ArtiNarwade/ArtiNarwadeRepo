package com.OTTPlatform.Engagement;

import java.util.Hashtable;

import org.apache.commons.lang.RandomStringUtils;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import BusinessComponents.GamesAPI;
import BusinessComponents.UM_UserToken;
import baseTestPackage.BaseTest_TestNG;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import reusableLibrary.JsonUtils;
import reusableLibrary.ResuableComponents;

public class Games_Test extends BaseTest_TestNG {

	GamesAPI gamesApi = new GamesAPI();
	Hashtable<String, String> headers = new Hashtable<String, String>();
	ResuableComponents resuableComponents = new ResuableComponents();
	UM_UserToken usertoken = new UM_UserToken();

	// GENERIC METHOD TO GENERATE TOKEN
	public String getGamesUserToken(ExtentTest test) throws Exception {
		String requestBody = JsonUtils.readPayloadJson("GamesTokenGeneration.json");
		Response resp = usertoken.tokenGenreatePost(test, requestBody);
		JsonPath jsonPath = resp.jsonPath();
		return jsonPath.getString("token");
	}

	@Test(description = "POD_3_Engagement-Filters all the games endpoint test", groups = { "Regression" }, priority = 1)
	public void getGamesFilterAllTest() throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		try {
		Response resp = gamesApi.getCallForAllGames(test);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
		}catch(Exception ex)
		{
			System.out.println("not getting x-access-token" + ex);
			test.log(LogStatus.FAIL, ex);
		}
	}

	@Test(description = "POD_3_Engagement-Allowed tags in the games endpoint", groups = { "Regression" }, priority = 2)
	public void getAllowedTagsTest() throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		try {
		Response resp = gamesApi.getCallForAllowedTagGames(test);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
		}catch(Exception ex)
		{
			System.out.println("not getting x-access-token" + ex);
			test.log(LogStatus.FAIL, ex);
		}
	}

	@Test(description = "POD_3_Engagement-get recently played games with Streak", groups = { "Regression" }, priority = 7)
	public void getRecentlyWithStreakTest() throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		try {
		Response resp = gamesApi.getRecentlyPlayedGamesWithStreak(test);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
		}
		catch(Exception ex)
		{
			System.out.println("not getting x-access-token" + ex);
			test.log(LogStatus.FAIL, ex);
		}
	}

	@Test(description = "POD_3_Engagement-get recently played games without Streak", groups = { "Regression" }, priority = 6)
	public void getRecentlyWithoutStreakTest() throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		try {
		Response resp = gamesApi.getRecentlyPlayedGamesWithoutStreak(test);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
		}
		catch(Exception ex)
		{
			System.out.println("not getting x-access-token" + ex);
			test.log(LogStatus.FAIL, ex);
		}
	}

	@Test(description = "POD_3_Engagement-Delete recently played games with Streak", groups = { "Regression" }, priority = 9)
	public void deleteWithStreak() throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		try {
		Response resp = gamesApi.deleteRecentlyPlayedWithStreak(test);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
		}
		catch(Exception ex)
		{
			System.out.println("not getting x-access-token" + ex);
			test.log(LogStatus.FAIL, ex);
		}
	}

	@Test(description = "POD_3_Engagement-Delete recently played games without Streak", groups = { "Regression" }, priority = 8)
	public void deleteWithoutStreak() throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		try {
		Response resp = gamesApi.deleteRecentlyPlayedWithoutStreak(test);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
		}
		catch(Exception ex)
		{
			System.out.println("not getting x-access-token" + ex);
			test.log(LogStatus.FAIL, ex);
		}
	}

	@Test(description = "POD_3_Engagement-User data get question", groups = { "Regression" }, priority = 11)
	public void getUserDataQuestion() throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		Response resp = gamesApi.getUserDataQuestion(test);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(201), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(201));
	}

	@Test(dataProvider = "feedbacksubmit", description = "POD_3_Engagement-Submit the feedback for the game", groups = {
			"Regression" }, priority = 4)
	public void feedbackSubmitTest(String filename) throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		String reqBody = JsonUtils.readPayloadJson(filename);
		Response resp = gamesApi.feedbackSubmit(reqBody, test);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(201), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(201));
	}

	@DataProvider(name = "feedbacksubmit", parallel = true)
	public Object[][] feedbacksubmit() {
		return new Object[][] { { "feedbacksubmit.json" } };
	}

	@Test(dataProvider = "feedbackQuestion", description = "POD_3_Engagement-Question the feedback for the game", groups = {
			"Regression" }, priority = 3)
	public void feedbackQuestionTest(String filename) throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		String reqBody = JsonUtils.readPayloadJson(filename);
		Response resp = gamesApi.feedbackGetQuestion(reqBody, test);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}

	@DataProvider(name = "feedbackQuestion", parallel = true)
	public Object[][] dataProviderMethod() {
		return new Object[][] { { "feedbackquestion.json" } };
	}

	@Test(description = "POD_3_Engagement-Get the discount hyperlink", groups = { "Regression" }, priority = 10)
	public void getDiscountHyperlink() throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		Response resp = gamesApi.getDiscountHyperlink(test);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}

	@Test(dataProvider = "createGameData", description = "POD_3_Engagement-Create the game data", groups = {
			"Regression" }, priority = 5)
	public void createGamesDataEntry(String filename) throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		String reqBody = JsonUtils.readPayloadJson(filename);
		reqBody = reqBody.replace("$session$", "1677220672295839" + RandomStringUtils.randomNumeric(5));
		Response resp = gamesApi.createDataEntry(reqBody, test);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(201), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(201));
	}

	@DataProvider(name = "createGameData", parallel = true)
	public Object[][] createGameDataEntries() {
		return new Object[][] { { "createGameDataEntry.json" } };
	}

	@Test(dataProvider = "userdatasubmit", description = "POD_3_Engagement-submit the user data", groups = {
			"Regression" }, priority = 12)
	public void userDataSubmit(String filename) throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		String token = getGamesUserToken(test);
		String reqBody = JsonUtils.readPayloadJson(filename);
		Response resp = gamesApi.userDataSubmit(reqBody, token, test);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(201), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(201));
	}

	@DataProvider(name = "userdatasubmit", parallel = true)
	public Object[][] userData() {
		return new Object[][] { { "userDataSubmit.json" } };
	}

}
