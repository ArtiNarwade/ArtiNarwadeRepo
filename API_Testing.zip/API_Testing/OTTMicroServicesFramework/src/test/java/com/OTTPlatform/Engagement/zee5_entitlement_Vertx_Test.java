package com.OTTPlatform.Engagement;

import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import BusinessComponents.GCP_OTP_UAT_API;
import BusinessComponents.RegisterandUpdate_UsernodeAPI;
import BusinessComponents.zee5_entitlement_vertx_API;
import baseTestPackage.BaseTest_TestNG;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import reusableLibrary.DBUtils;
import reusableLibrary.JsonUtils;
import reusableLibrary.MD5HashGenerator;
import reusableLibrary.ResuableComponents;
import reusableLibrary.StringUtils;

public class zee5_entitlement_Vertx_Test extends BaseTest_TestNG {
	
	
	GCP_OTP_UAT_API GCP= new GCP_OTP_UAT_API();
	ResuableComponents resuableComponents = new ResuableComponents();
	RegisterandUpdate_UsernodeAPI RegisterandUpdate= new RegisterandUpdate_UsernodeAPI();
	StringUtils stringutils= new StringUtils();
	private String Email_accesstoken;
	private String Mobile_accesstoken;
	private MD5HashGenerator hashgen= new MD5HashGenerator() ;
	private DBUtils dbutils= new DBUtils();
	zee5_entitlement_vertx_API vertexapi= new zee5_entitlement_vertx_API();
	private String Id;
	@Test(dataProvider = "Subscriptiontype",description ="POD1-Engagement- Zee5 Entitlement Vertex free using Post call")
	
	public void Connected_division4k_free_POST(String fileName) throws Exception 
	{ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
	
		String SendOTPReqBody=JsonUtils.readPayloadJson("SendEmailORMobileOTP_UserNode.json");
		//Updating as per mode of otp
		
		//generate random email id
		String email=stringutils.getRandomString();
		email=email+"@mailsac.com";
		String hash=hashgen.getMD5Hash(email).toLowerCase();
		System.out.println(hash);
		
		SendOTPReqBody=SendOTPReqBody.replace("$MODEOFOTP$", "email");
		SendOTPReqBody=SendOTPReqBody.replace("$DATA$", email);
		System.out.println(SendOTPReqBody);
		
		Response SendOTPresp = RegisterandUpdate.SendEmailORMOBILEOTPPOSTCall(test,SendOTPReqBody);
		System.out.println(SendOTPresp.asString());
		
		
		//Need to add some method to read email OTP
		String OTP = "";
		try { // Mobile OTP Reading
			OTP = dbutils.getValueFromRedis("RedisOtpPrefix_7_" + hash,
					Integer.parseInt(globalProp.getProperty("redisport")));

		}  catch (Exception ex) {
				test.log(LogStatus.INFO, ex);
				System.out.println("OTP retreving" + ex);
				test.log(LogStatus.FAIL, ex);
				throw ex;
			

		}
		String code=RegisterandUpdate.OTPCode(OTP);
		
		String requestBody = JsonUtils.readPayloadJson("UserNodeAPI_RegisterWithEmailOTP.json");
		requestBody=requestBody.replace("$EMAILID$", email);
		requestBody=requestBody.replace("$OTP$",code);
		Response resp = RegisterandUpdate.RegisterEmailOTPPOSTCall(test,requestBody);
		System.out.println(resp.asString());
		JsonPath js= resp.jsonPath();
		Email_accesstoken=js.getString("access_token");
		Response userid=GCP.GetUser(test,Email_accesstoken);
		System.out.println(userid.asString());
		JsonPath JSP= userid.jsonPath();
		Id=JSP.get("id");
		String Subtype=JsonUtils.readPayloadJson(fileName);
		Subtype=Subtype.replace("$ACCESSTOKEN$", Email_accesstoken);
		Subtype=Subtype.replace("$TYPE$", "free");
		
		Response subresp=vertexapi.SubScriptionType_Free_POST(Subtype, test);
		int statusCode = subresp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(subresp.getStatusCode()), Integer.toString(200));

		
		
	}
	@DataProvider(name = "Subscriptiontype")
	public Object[][] Subscriptiontype() {
	return new Object[][] { {"Zee5_entitlement_vertex_Free.json"  }};
	}
	
	
@Test(dependsOnMethods = {"Connected_division4k_free_POST"}, dataProvider = "Subscriptiontype",description ="POD1-Engagement- Zee5 Entitlement Vertex Premium Downloads using Post call")
	
	public void Connected_division4k_Preimium_POST(String fileName) throws Exception 
	{
	ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
	
	String requestBody = JsonUtils.readPayloadJson("AddUseridToSubscription.json");
	requestBody=requestBody.replace("$USERID$", Id);
	Response res= vertexapi.AdduseridSubscription(requestBody, test);
	int statusCode = res.getStatusCode();
	resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
	Assert.assertEquals(Integer.toString(res.getStatusCode()), Integer.toString(200));

	String Subtype=JsonUtils.readPayloadJson(fileName);
	Subtype=Subtype.replace("$ACCESSTOKEN$", Email_accesstoken);
	Subtype=Subtype.replace("$TYPE$", "premium_downloadable");
	
	Response subresp=vertexapi.SubScriptionType_Free_POST(Subtype, test);
	int statusCodevertex = subresp.getStatusCode();
	resuableComponents.validateStatusCode(Integer.toString(statusCodevertex), Integer.toString(200), test);
	Assert.assertEquals(Integer.toString(subresp.getStatusCode()), Integer.toString(200));

	
	}
}
