package com.OTTPlatform.GCPPlayBack;


import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentTest;

import BusinessComponents.GCP_PlayBack;
import baseTestPackage.BaseTest_TestNG;
import io.restassured.response.Response;
import reusableLibrary.ResuableComponents;

public class GCP_PlayBack_Test extends BaseTest_TestNG {
	
	ResuableComponents resuableComponents = new ResuableComponents();
	GCP_PlayBack gcpplayback= new GCP_PlayBack();
	
	
	
	@Test(description = "gcp_Playback_akamai")
	public void gcp_Playback_akamai() throws Exception {
	ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
	Response resp= gcpplayback.get_GcpGeneric(test,"akamai","AKAMAI");
	int statusCode = resp.getStatusCode();
	resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
	Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}
	
	

	@Test(description = "gcp_Playback_v3search")
	public void gcp_Playback_v3search() throws Exception {
	ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
	Response resp= gcpplayback.get_GcpGeneric(test,"v3search","V3SEARCH");
	int statusCode = resp.getStatusCode();
	resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
	Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}
	
	

	@Test(description = "gcp_Playback_contentsearch")
	public void gcp_Playback_contentsearch() throws Exception {
	ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
	Response resp= gcpplayback.get_GcpGeneric(test,"v3search","GCPCONTENTSEARCH");
	int statusCode = resp.getStatusCode();
	resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
	Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}
	

	@Test(description = "gcp_Playback_querysuggest")
	public void gcp_Playback_querysuggest() throws Exception {
	ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
	Response resp= gcpplayback.get_GcpGeneric(test,"v3search","GCPQUERYSUGGEST");
	int statusCode = resp.getStatusCode();
	resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
	Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}
	

	@Test(description = "gcp_Playback_topHit")
	public void gcp_Playback_topHit() throws Exception {
	ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
	Response resp= gcpplayback.get_GcpGeneric(test,"v3search","TOPHIT");
	int statusCode = resp.getStatusCode();
	resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
	Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}
}
