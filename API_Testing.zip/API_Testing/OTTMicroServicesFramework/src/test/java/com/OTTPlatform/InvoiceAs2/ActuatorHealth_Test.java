package com.OTTPlatform.InvoiceAs2;

import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentTest;

import BusinessComponents.Invoice_AsAPI;
import baseTestPackage.BaseTest_TestNG;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import reusableLibrary.JsonUtils;
import reusableLibrary.ResuableComponents;

public class ActuatorHealth_Test extends BaseTest_TestNG{
	
	ResuableComponents resuableComponents = new ResuableComponents();
	Invoice_AsAPI invoiceAs = new Invoice_AsAPI();
	
	@Test(description = "Get Actuator health for invoice management")
	public void TestActuatorHealth() throws Exception
	{
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		Response resp = invoiceAs.GetactuatorHealth(test);
		String responseBody = resp.getBody().asString();
		JsonPath jsonPath = new JsonPath(responseBody);
		String statusvalue = jsonPath.getString("status");
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(statusCode), Integer.toString(200));
		Assert.assertEquals(statusvalue, "UP");
	
			
	}
	
	@Test(description = "Get purchase using sub id & payment id")
	public void TestPurchase() throws Exception
	{
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		String subscriptionId= globalProp.getProperty("invoice_subscriptionId");
		String paymentId= globalProp.getProperty("invoice_paymentId");
		Response resp = invoiceAs.GetPurchase(test,subscriptionId,paymentId);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(statusCode), Integer.toString(200));
	
			
	}
	
	@Test(description = "Get purchase using empty sub id")
	public void TestPurchaseEmptySubId() throws Exception
	{
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		String subscriptionId= " ";
		String paymentId= globalProp.getProperty("invoice_paymentId");
		Response resp = invoiceAs.GetPurchase(test,subscriptionId,paymentId);
		String responseBody = resp.getBody().asString();
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(statusCode), Integer.toString(200));
		Assert.assertTrue(responseBody.contains("Failed to get Invoice Record. OrderId:"));
	
			
	}
	
	@Test(description = "Get purchase using sub id & empty payment id")
	public void TestPurchaseEmptyPayment() throws Exception
	{
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		String subscriptionId= globalProp.getProperty("invoice_subscriptionId");
		String paymentId= " ";
		Response resp = invoiceAs.GetPurchase(test,subscriptionId,paymentId);
		String responseBody = resp.getBody().asString();
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(statusCode), Integer.toString(200));
		Assert.assertTrue(responseBody.contains("Failed to get Invoice Record. OrderId:"));
	
			
	}
	
	@Test(description = "Get purchase using only sub id")
	public void TestPurchaseSubID() throws Exception
	{
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		String subscriptionId= globalProp.getProperty("invoice_subscriptionId");
		Response resp = invoiceAs.GetPurchaseNoPaymentId(test,subscriptionId);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(400), test);
		Assert.assertEquals(Integer.toString(statusCode), Integer.toString(400));
	
			
	}
	
	@Test(description = "Get purchase using only Payment id")
	public void TestPurchasePaymentID() throws Exception
	{
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		String paymentId= globalProp.getProperty("invoice_paymentId");
		Response resp = invoiceAs.GetPurchaseNoSubId(test,paymentId);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(400), test);
		Assert.assertEquals(Integer.toString(statusCode), Integer.toString(400));
	
			
	}
	
}
