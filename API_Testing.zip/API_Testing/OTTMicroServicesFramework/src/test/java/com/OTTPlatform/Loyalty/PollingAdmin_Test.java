package com.OTTPlatform.Loyalty;

import org.apache.commons.lang.RandomStringUtils;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentTest;

import BusinessComponents.PollingAdminAPI;
import baseTestPackage.BaseTest_TestNG;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import reusableLibrary.JsonUtils;
import reusableLibrary.ResuableComponents;

public class PollingAdmin_Test extends BaseTest_TestNG{

	ResuableComponents resuableComponents = new ResuableComponents();
	PollingAdminAPI pollingadmin=new PollingAdminAPI();
	private int PollID;
	int QuestionID;
	int SelectedOptionID;
	private String assetid;

	@Test(dataProvider = "postadmin",description = "POD-2-Loyalty - Create the admin add quiz",priority=1)
	public void Postadminquiz(String filename) throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		String reqBody = JsonUtils.readPayloadJson(filename);
		assetid="mock" + RandomStringUtils.randomNumeric(4);
		reqBody=reqBody.replace("$assetID$", assetid);
		Response resp = pollingadmin.PostAdminAddQuiz(reqBody,test);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));

		JsonPath js=resp.jsonPath();
		PollID=js.get("result.id");
		System.out.println("The Poll Id is......." + PollID);
	}

	@DataProvider(name = "postadmin")
	public Object[][] PostAdminAddQuiz() {
		return new Object[][] { { "AdminAddQuizPoll_Admin.json" } };
	}

	@Test(description = "POD-2-Loyalty - Get the poll by asset ID",priority=2)
	public void Getpollbyasset() throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		Response resp = pollingadmin.GetPollAsset(test,assetid);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}

	@Test(description = "POD-2-Loyalty - Get the poll by ID",priority=3)
	public void GetpollbyID() throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		Response resp = pollingadmin.GetPollbyID(test, PollID);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}

	@Test(description = "POD-2-Loyalty - Get opinion poll results",priority=4)
	public void Getopinionpollresult() throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		Response resp = pollingadmin.GetOpinionPollResult(test,PollID);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}

	@Test(description = "POD-2-Loyalty - Get user report poll response")
	public void Getuserreportpoll() throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		Response resp = pollingadmin.GetUserReportPollResponse(test);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}

	@Test(description = "POD-2-Loyalty - Get opinion schedular")
	public void Getopinionschedular() throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		Response resp = pollingadmin.GetUserReportPollResponse(test);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}

	@Test(description = "POD-2-Loyalty - Get poll schedular",priority=5)
	public void Getpollschedular() throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		Response resp = pollingadmin.GetPollSchedular(test,PollID);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}

	@Test(description = "POD-2-Loyalty - Get poll responses")
	public void Getpollresponses() throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		Response resp = pollingadmin.GetPollResponses(test);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}

	@Test(dependsOnMethods = {"Postadminquiz","Getpollingdetails"}, dataProvider = "postsubmit",description = "POD-2-Loyalty - Create the submit poll",priority=8)
	public void Postsubmitpoll(String filename) throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		String reqBody = JsonUtils.readPayloadJson(filename);
		String LatestreqBody="";

		LatestreqBody=reqBody.replace("$pollId$", String.valueOf(PollID));
		LatestreqBody=LatestreqBody.replace("$questionId$", String.valueOf(QuestionID));
		LatestreqBody=LatestreqBody.replace("$selectedOptionId$", String.valueOf(SelectedOptionID));
		Response resp = pollingadmin.PostSubmitPoll(LatestreqBody,test);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}

	@DataProvider(name = "postsubmit")
	public Object[][] PostSubmitPoll() {
		return new Object[][] { { "SubmitPoll_Admin.json" } };
	}

	@Test( description = "POD-2-Loyalty - Get details of polling",priority=6)
	public void Getpollingdetails() throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		Response resp = pollingadmin.GetPollingDetails(test,assetid);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));

		JsonPath js=resp.jsonPath();
		QuestionID=js.getJsonObject("data[0].pollQuestionResponseList[0].pollOptionResponseList[0].questionId");
		System.out.println("Question ID is....." + QuestionID);

		SelectedOptionID=js.getJsonObject("data[0].pollQuestionResponseList[0].pollOptionResponseList[0].optionTranslationResponseList[0].optionId");
		System.out.println("Selected Option ID is....." + SelectedOptionID);
	}

	@Test(description = "POD-2-Loyalty - Get user poll responses",priority=7)
	public void Getuserpollresponses() throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		Response resp = pollingadmin.GetUserPollResponses(test,PollID);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}

	@Test(description = "POD-2-Loyalty - Get opinion poll results for service consumer")
	public void Getserviceopinionpollresult() throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		Response resp = pollingadmin.GetServiceOpinionPollResults(test);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}
	@Test(description = "POD-2-Loyalty - Delete by poll id",dependsOnMethods = {"Postsubmitpoll"})
	public void Deletebypoll() throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		Response resp = pollingadmin.DeletebyPollID(test);
		int StatusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(StatusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}
	
	@Test(dataProvider = "postadminop",description = "POD-2-Loyalty - Create the admin opinion poll")
	public void Postadminopinion(String filename) throws Exception {
	    ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		String reqBody = JsonUtils.readPayloadJson(filename);
		reqBody=reqBody.replace("$No$",RandomStringUtils.randomNumeric(3));
		Response resp = pollingadmin.PostAdminOpinionPoll(reqBody,test);		
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}
	
	@DataProvider(name = "postadminop")
	public Object[][] PostAdminOpinionPoll() {
		return new Object[][] { { "AdminOpinionPoll.json" } };
	}
}
