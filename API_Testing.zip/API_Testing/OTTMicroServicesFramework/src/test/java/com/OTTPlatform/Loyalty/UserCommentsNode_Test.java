package com.OTTPlatform.Loyalty;

import java.util.Hashtable;

import org.apache.commons.lang.RandomStringUtils;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.EndPoints.EndPoints;
import com.relevantcodes.extentreports.ExtentTest;

import BusinessComponents.UserCommentsNode;
import baseTestPackage.BaseTest_TestNG;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import reusableLibrary.JsonUtils;
import reusableLibrary.ResuableComponents;

public class UserCommentsNode_Test extends BaseTest_TestNG{

	ResuableComponents resuableComponents = new ResuableComponents();
	UserCommentsNode userCommentsNode=new UserCommentsNode();
	int commentID = userCommentsNode.generateRandomNumber(100,999);
	private int comment;
	private int postNum;
	//Scripts:
	
	@Test(dataProvider = "CreateCommentReply",description = "POD2-Loyalty - Create Comment & Reply")
	public void CreateCommentReply(String filename) throws Exception {
	    ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		String reqBody = JsonUtils.readPayloadJson(filename);
		Response resp = userCommentsNode.createCommentReply(reqBody,test);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
		System.out.println(Reporter.getCurrentTestResult().getMethod().getPriority() + "checking priority...");
	}
	
	
	@Test(dependsOnMethods = "CreateCommentReply", description= "POD2-Loyalty - Get Comment")
	public void GetComment() throws Exception {
	    ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		Response resp = userCommentsNode.getallComment(test);
		comment=resp.jsonPath().get("comments[0].commentId");
		postNum=resp.jsonPath().get("comments[0].postNumber");
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}
	
	@Test(dataProvider = "UpdateComment",description = "POD2-Loyalty - Update Comment")
	public void UpdateComment(String filename) throws Exception {
	    ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		String reqBody = JsonUtils.readPayloadJson(filename);
		Response resp = userCommentsNode.updateComment(reqBody,test);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}
	
	
	@Test(dataProvider = "CreateReply",description = "POD2-Loyalty - Create Reply")
	public void CreateReply(String filename) throws Exception {
	    ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		String reqBody = JsonUtils.readPayloadJson(filename);
		reqBody=reqBody.replace("9", String.valueOf(postNum));
		Response resp = userCommentsNode.createReply(reqBody,test);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}
	
	
	@Test(description = "POD2-Loyalty - Get Reply")
	public void GetReply() throws Exception {
	    ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		Response resp = userCommentsNode.getReply(test);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}
	
	@Test(dataProvider = "UpdateReply",description = "POD2-Loyalty - Update Reply")
	public void UpdateReply(String filename) throws Exception {
	    ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		String reqBody = JsonUtils.readPayloadJson(filename);
		//reqBody=reqBody.replace("31", String.valueOf(comment));
		Response resp = userCommentsNode.updateReply(reqBody,test);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}
	
	@Test(dataProvider = "DeleteReply",description = "POD2-Loyalty - Delete Reply")
	public void DeleteReply(String fileName) throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		String reqBody = JsonUtils.readPayloadJson(fileName);
		//reqBody=reqBody.replace("31", String.valueOf(comment));
		Response resp = userCommentsNode.deleteReply(reqBody,test);
		int StatusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(StatusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}
	
	@Test(dataProvider = "DeleteComment",description = "POD2-Loyalty - Delete Comment")
	public void DeleteComment(String fileName) throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		String reqBody = JsonUtils.readPayloadJson(fileName);
		reqBody=reqBody.replace("27", String.valueOf(commentID));
		Response resp = userCommentsNode.deleteComment(reqBody,test);
		int StatusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(StatusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}
	
	
	@Test(dependsOnMethods = "UpdateReply" ,dataProvider = "CreateLikeAction",description = "POD2-Loyalty - CreateLikeAction")
	public void createlikeaction(String filename) throws Exception{
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
	    System.out.println(Reporter.getCurrentTestResult().getMethod().getPriority());
	    String reqBody = JsonUtils.readPayloadJson(filename);
	    Response resp=userCommentsNode.createlikeAction(reqBody, test);
	    int statusCode = resp.getStatusCode();
	    resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
	    Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}
	
	@Test(dataProvider = "DeleteLikeAction",description = "POD2-Loyalty - DeleteLikeAction")
	public void deletelikeaction(String fileName) throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		System.out.println(Reporter.getCurrentTestResult().getMethod().getPriority());
		String reqBody = JsonUtils.readPayloadJson(fileName);
		Response resp = userCommentsNode.deletelikeAction(reqBody, test);
		int statusCode = resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}
	
		
	@DataProvider(name = "CreateCommentReply")
	public Object[][] CommentReplyData() {
		return new Object[][] { { "CreateComment_Reply.json" } };
	}

	@DataProvider(name = "UpdateComment")
	public Object[][] UpdateCommentData() {
		return new Object[][] { { "Update_Comment.json" } };
	}
	
	@DataProvider(name = "DeleteComment")
	public Object[][] DeleteCommentData() {
		return new Object[][] { { "DeleteComment.json" } };
	}
	
	@DataProvider(name = "CreateReply")
	public Object[][] CreateReplyData() {
		return new Object[][] { { "Create_Reply.json" } };
	}

	@DataProvider(name = "UpdateReply")
	public Object[][] UpdateReplyData() {
		return new Object[][] { { "Update_Reply.json" } };
	}
	
	@DataProvider(name = "DeleteReply")
	public Object[][] DeleteReplyData() {
		return new Object[][] { { "DeleteReply.json" } };
	}
	
	@DataProvider(name="CreateLikeAction")
	public Object[][]createlikeaction() {
		return new Object[][] { { "CreateLike_Action.json" } };
	}
	
	@DataProvider(name="DeleteLikeAction")
	public Object[][] deletelikeaction(){
		return new Object[][] { { "DeleteLike_Action.json" } };
	}
	
	
}
