package com.OTTPlatform.cuj;

import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Test;

import com.OTTPlatform.Playback.Tests_Single_Playback;
import com.relevantcodes.extentreports.ExtentTest;

import BusinessComponents.Single_Playback_API;
import baseTestPackage.BaseTest_TestNG;
import io.restassured.response.Response;
import reusableLibrary.JsonUtils;
import reusableLibrary.ResuableComponents;

public class AdsUserCuj_Test extends BaseTest_TestNG{

	ResuableComponents resuableComponents = new ResuableComponents();
	Single_Playback_API singleplaycuj=new Single_Playback_API();
	
	@Test(description="Verifying Guest user Ads Visbility")
	public void guestuserads()throws Exception{
		ExtentTest test=report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		String requestBody=JsonUtils.jsonFileReader("payload/qa/SPAPI_GCPGuestUser.json");
		Response resp=singleplaycuj.GCP_GuestUser(test, requestBody);
		int statusCode=resp.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
	}
}
