package com.OTTPlatform.cuj;

import org.apache.commons.lang.RandomStringUtils;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentTest;

import BusinessComponents.GuestUserCuj_API;
import BusinessComponents.UM_GuestGenerator;
import baseTestPackage.BaseTest_TestNG;
import io.restassured.response.Response;
import reusableLibrary.JsonUtils;
import reusableLibrary.ResuableComponents;

public class GuestUserCuj_Test extends BaseTest_TestNG{

	GuestUserCuj_API guestcuj=new GuestUserCuj_API();
	UM_GuestGenerator guestgenerate=new UM_GuestGenerator();
	ResuableComponents resuableComponents = new ResuableComponents();
	String token = null;
	
	
	@Test(description="Verify V3 Login and V3 token exchange is successful")
	public void guestUserJourney() throws Exception{
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		
		// Construct JSON object
        String message;
        String aid = "91" + RandomStringUtils.randomNumeric(10);
        JSONObject json = new JSONObject();
        JSONObject jsonObj = new JSONObject();
        jsonObj.put("apikey", "6BAE650FFC9A3CAA61CE54D");
        jsonObj.put("aid", aid);
        json.put("user", jsonObj);
        message = json.toString();
        
        // Generate guest token
        Response resp =guestgenerate.verifyGuestGeneratorTokenUsingPostCall(test, message);
        int statusCode = resp.getStatusCode();
        String guestToken=resp.getBody().jsonPath().get("guest_user").toString();
        resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
		
		// Add Guest user
		String requestBody = JsonUtils.jsonFileReader("payload/qa/UMUpdateGuestUserScylla.json");		
		Response resp1 =guestcuj.updateGuestUserUsingPutCall(test, requestBody,guestToken);
		int statusCode1 = resp1.getStatusCode();
		String code=resp1.getBody().jsonPath().get("code").toString();
		String message1=resp1.getBody().jsonPath().get("message").toString();
		resuableComponents.validateStatusCode(Integer.toString(statusCode1), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp1.getStatusCode()), Integer.toString(200));
		resuableComponents.assertEqualValue("Add guest user message", code, "1", test);
		resuableComponents.assertEqualValue("Add guest user message", message1, "Guest updated successfully", test);
	
		// Get Guest
		Response resp2=guestcuj.getGuestUserDetailsPutCall(test,guestToken);
		int statusCode2=resp2.getStatusCode();
		String gender=resp2.getBody().jsonPath().get("gender").toString();
		resuableComponents.validateStatusCode(Integer.toString(statusCode2), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp1.getStatusCode()), Integer.toString(200));
		resuableComponents.assertEqualValue("Get guest user gender", gender, "male", test);
		
		// Update guest
		String requestBody1 = JsonUtils.jsonFileReader("payload/qa/UMUpdateGuestUserScylla.json");	
		requestBody1=requestBody1.replace("male", "female");
		Response resp3 =guestcuj.updateGuestUserUsingPutCall(test, requestBody1,guestToken);
		int statusCode3=resp3.getStatusCode();
		resuableComponents.validateStatusCode(Integer.toString(statusCode3), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp1.getStatusCode()), Integer.toString(200));
		
		// Get Guest
		Response resp4=guestcuj.getGuestUserDetailsPutCall(test,guestToken);
		int statusCode4=resp4.getStatusCode();
		String gender2=resp4.getBody().jsonPath().get("gender").toString();
		resuableComponents.validateStatusCode(Integer.toString(statusCode4), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp1.getStatusCode()), Integer.toString(200));
		resuableComponents.assertEqualValue("Get guest user gender", gender2, "female", test);
		
	}
}
