package com.OTTPlatform.cuj;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentTest;

import BusinessComponents.OtpApi;
import BusinessComponents.UM_UserToken;
import BusinessComponents.UP_UserProfile;
import BusinessComponents.US_SettingMSSQL_API;
import baseTestPackage.BaseTest_TestNG;
import io.restassured.response.Response;
import reusableLibrary.DBUtils;
import reusableLibrary.JsonUtils;
import reusableLibrary.ResuableComponents;

public class ProfileCuj_Test extends BaseTest_TestNG {

	UM_UserToken usertoken = new UM_UserToken();
	US_SettingMSSQL_API usersettingmssql = new US_SettingMSSQL_API();
	ResuableComponents resuableComponents = new ResuableComponents();
	String token = null;
	OtpApi otpapi = new OtpApi();
	UP_UserProfile userProfile = new UP_UserProfile();

	@Test(description = "Verify Profile V1 User Journey is successful")
	public void userSettingCuj() throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		String requestBody = JsonUtils.jsonFileReader("Payload/qa/SendOtp.json");
		String emailid = otpapi.generateRandomEmailid().toLowerCase();
		requestBody = requestBody.replace("{mode}", "email");
		requestBody = requestBody.replace("{value}", emailid);

		// User Sends OTP to email id
		Response resp = otpapi.SendEmailOrMobileOtpPostCall(test, requestBody);
		int statusCode = resp.getStatusCode();
		String message = resp.getBody().jsonPath().get("message").toString();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
		resuableComponents.assertEqualValue("Send OTP Message", message, "Email successfully sent", test);

		// generate MD5 hash for email
		String dbKey = "RedisOtpPrefix_7_" + otpapi.generateMD5(emailid);

		// user gets otp from redis
		String value = DBUtils.getValueFromRedis(dbKey);
		String fetchedOtp = otpapi.OTPCode(value);

		// user hits verify otp api to get the token
		requestBody = JsonUtils.jsonFileReader("Payload/qa/VerifyOtp.json");
		requestBody = requestBody.replace("{mode}", "email");
		requestBody = requestBody.replace("{value}", emailid);
		requestBody = requestBody.replace("{otpvalue}", fetchedOtp);

		resp = otpapi.VerifyEmailOrMobileOtpPostCall(test, requestBody);
		statusCode = resp.getStatusCode();
		String bearerToken = resp.getBody().jsonPath().get("access_token").toString();
		String tokenType = resp.getBody().jsonPath().get("token_type").toString();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
		resuableComponents.assertEqualValue("Validating token type is bearer", tokenType, "Bearer", test);

		// user creates default profile using above created user token
		requestBody = JsonUtils.jsonFileReader("Payload/qa/createDefaultProfile.json");
		resp = userProfile.createDefaultProfile(test, requestBody, bearerToken);
		statusCode = resp.getStatusCode();
		message = resp.getBody().jsonPath().get("message").toString();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
		resuableComponents.assertEqualValue("Validating message for default profile", message,
				"Default profile created successfully", test);

		// user creates third profile since already 2 profiles are created default and
		// kids
		requestBody = JsonUtils.jsonFileReader("Payload/qa/createSinglrUserProfile.json");
		requestBody = requestBody.replace("{profileName}", "autoprofileno3");
		resp = userProfile.createSingleProfile(test, requestBody, bearerToken);
		statusCode = resp.getStatusCode();
		message = resp.getBody().jsonPath().get("message").toString();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
		resuableComponents.assertEqualValue("Validating message for default profile", message,
				"Profile created successfully", test);

		// user creates fourth profile
		requestBody = requestBody.replace("autoprofileno3", "autoprofileno4");
		resp = userProfile.createSingleProfile(test, requestBody, bearerToken);
		statusCode = resp.getStatusCode();
		message = resp.getBody().jsonPath().get("message").toString();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);

		// user creates fifth profile
		requestBody = requestBody.replace("autoprofileno4", "autoprofileno5");
		resp = userProfile.createSingleProfile(test, requestBody, bearerToken);
		statusCode = resp.getStatusCode();
		message = resp.getBody().jsonPath().get("message").toString();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);

		// user creates sixth profile and gets error saying five profiles exist for this
		// user
		requestBody = requestBody.replace("autoprofileno5", "autoprofileno6");
		resp = userProfile.createSingleProfile(test, requestBody, bearerToken);
		statusCode = resp.getStatusCode();
		message = resp.getBody().jsonPath().get("message").toString();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(400), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(400));
		resuableComponents.assertEqualValue("Validating message for sixth profile", message,
				"Already five profiles exist for this user", test);

		// User gets all profile
		resp = userProfile.getAllUserProfile(test, bearerToken);
		String responseBody = resp.getBody().asString();
		JSONArray jsonArray = new JSONArray(responseBody);
		String[] profileIdArrays = new String[jsonArray.length()];
		String[] arr = { "Guest", "Kids", "autoprofileno3", "autoprofileno4", "autoprofileno5" };
		String[] arrDefaultProf = { "true", "false", "false", "false", "false" };
		for (int i = 0; i < jsonArray.length(); i++) {
			JSONObject jsonObject = jsonArray.getJSONObject(i);
			System.out.println("Object at index " + i + ": " + jsonObject.toString());
			String profileName = jsonObject.getString("profile_name");
			String profileId = jsonObject.getString("profile_id");
			String name = jsonObject.getString("is_default_profile");
			System.out.println("Profile Name: " + profileName);
			System.out.println("Profile Id for Profile Name " + profileName + " is: " + profileId);
			profileIdArrays[i] = profileId;
			resuableComponents.assertEqualValue("Validating profile names", profileName, arr[i], test);
			resuableComponents.assertEqualValue("Validating default profiles", name, arrDefaultProf[i], test);
		}

		// User updates 1 profile
		requestBody = JsonUtils.jsonFileReader("Payload/qa/updatedsingleprofile.json");
		requestBody = requestBody.replace("{updatedname}", "updatedautoprofileno3");
		requestBody = requestBody.replace("{profileid}", profileIdArrays[2]);
		resp = userProfile.updateSingleUserProfile(test, requestBody, bearerToken);
		statusCode = resp.getStatusCode();
		message = resp.getBody().jsonPath().get("message").toString();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
		resuableComponents.assertEqualValue("Validating message for updating profile", message,
				"Profile updated successfully", test);

		// User gets the updated profile
		resp = userProfile.getSingleProfile(test, profileIdArrays[2], bearerToken);
		statusCode = resp.getStatusCode();
		String fetchedProfileId = resp.getBody().jsonPath().get("[0].profile_id").toString();
		String fetchedProfileName = resp.getBody().jsonPath().get("[0].profile_name").toString();

		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
		resuableComponents.assertEqualValue("Validating updated profile details", fetchedProfileId, profileIdArrays[2],
				test);
		resuableComponents.assertEqualValue("Validating updated profile name", fetchedProfileName,
				"updatedautoprofileno3", test);

		// User updates Last used profile
		requestBody = "{\"profile_id\": \"" + profileIdArrays[2] + "\"}";
		resp = userProfile.updateLastUsedProfile(test, requestBody, bearerToken);
		statusCode = resp.getStatusCode();
		message = resp.getBody().jsonPath().get("message").toString();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
		resuableComponents.assertEqualValue("Validating message for updating last used profile", message,
				"Last used profile updated successfully", test);

		// Gets last used profile
		resp = userProfile.getLastUsedProfile(test, bearerToken);
		statusCode = resp.getStatusCode();
		fetchedProfileId = resp.getBody().jsonPath().get("profile_id").toString();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
		resuableComponents.assertEqualValue("Validating last used profile id", profileIdArrays[2], fetchedProfileId,
				test);

		// Delete updated profile
		resp = userProfile.deleteProfile(test, profileIdArrays[2], bearerToken);
		statusCode = resp.getStatusCode();
		message = resp.getBody().jsonPath().get("message").toString();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
		resuableComponents.assertEqualValue("Validating message for delete profile", message,
				"Profile successfully deleted.", test);

		// Get deleted profile to check if it is deleted
		resp = userProfile.getSingleProfile(test, profileIdArrays[2], bearerToken);
		message = resp.getBody().jsonPath().get("message").toString();
		resuableComponents.assertEqualValue("Validating message for deleted profile hitting get Profile api", message,
				"The profile could not be found.", test);
	}

}
