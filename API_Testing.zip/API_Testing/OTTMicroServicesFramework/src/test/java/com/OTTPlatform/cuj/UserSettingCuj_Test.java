package com.OTTPlatform.cuj;

import java.util.Hashtable;

import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentTest;

import BusinessComponents.UM_UserToken;
import BusinessComponents.US_SettingMSSQL_API;
import baseTestPackage.BaseTest_TestNG;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import reusableLibrary.JsonUtils;
import reusableLibrary.ResuableComponents;

public class UserSettingCuj_Test extends BaseTest_TestNG {

	UM_UserToken usertoken = new UM_UserToken();
	US_SettingMSSQL_API usersettingmssql = new US_SettingMSSQL_API();
	ResuableComponents resuableComponents = new ResuableComponents();
	String token = null;

	@BeforeTest
	public String getUserToken() throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		String requestBody = JsonUtils.jsonFileReader("Payload/qa/UMTokenGenerate.json");
		Response resp = usertoken.tokenGenreatePost(test, requestBody);
		JsonPath jsonPath = resp.jsonPath();
		token = jsonPath.getString("token");
		return token;

	}

	@Test(dataProvider = "usersettingscuj", description = "Verify Setting V1 User Journey is Successful")
	public void userSettingCuj(String fileName) throws Exception {
		ExtentTest test = report.startTest(Reporter.getCurrentTestResult().getMethod().getDescription());
		String requestBody = JsonUtils.jsonFileReader(fileName);

		// User Creates first setting
		String settingName1 = "settingcuj1";
		String settingName2 = "settingcuj2";
		requestBody = requestBody.replace("{settingname}", settingName1);
		requestBody = requestBody.replace("{value}", "ok");
		Hashtable<String, String> headers1 = new Hashtable<String, String>();
		headers1.put("Authorization", "Bearer " + token);
		Response resp = usersettingmssql.addUserSettingsPostCall(test, requestBody, headers1);
		int statusCode = resp.getStatusCode();
		String message = resp.getBody().jsonPath().get("message").toString();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
		resuableComponents.assertEqualValue("Create Settings 1 Message", message, "Setting was added successfully",
				test);

		// User Creates second setting
		requestBody = JsonUtils.jsonFileReader(fileName);
		requestBody = requestBody.replace("{settingname}", settingName2);
		requestBody = requestBody.replace("{value}", "ok");
		resp = usersettingmssql.addUserSettingsPostCall(test, requestBody, headers1);
		statusCode = resp.getStatusCode();
		message = resp.getBody().jsonPath().get("message").toString();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
		resuableComponents.assertEqualValue("Create Settings 2 Message", message, "Setting was added successfully",
				test);

		// User hits Get Settings to validate of above created settings are created
		resp = usersettingmssql.getUserSettingsGETCall(test, headers1);
		statusCode = resp.getStatusCode();
		String setting1 = resp.getBody().jsonPath().get("[0].key").toString();
		String setting2 = resp.getBody().jsonPath().get("[1].key").toString();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
		resuableComponents.assertEqualValue("User Settings 1", setting1, settingName1, test);
		resuableComponents.assertEqualValue("User Settings 2", setting2, settingName2, test);

		// User Updates second setting
		requestBody = JsonUtils.jsonFileReader(fileName);
		requestBody = requestBody.replace("{settingname}", settingName2);
		requestBody = requestBody.replace("{value}", "Updatedsettingcuj2");
		resp = usersettingmssql.updateUserSettingPUTCall(test, requestBody, headers1);
		statusCode = resp.getStatusCode();
		message = resp.getBody().jsonPath().get("message").toString();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
		resuableComponents.assertEqualValue("Update Settings 2 Message", message, "Setting was updated successfully",
				test);

		// User hits Get Settings to validate of above updated settings
		resp = usersettingmssql.getUserSettingsGETCall(test, headers1);
		statusCode = resp.getStatusCode();
		setting2 = resp.getBody().jsonPath().get("[1].key").toString();
		String updatedSetting2Value = resp.getBody().jsonPath().get("[1].value").toString();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
		resuableComponents.assertEqualValue("User Settings 2 key", setting2, settingName2, test);
		resuableComponents.assertEqualValue("User Settings 2 value", updatedSetting2Value, "Updatedsettingcuj2", test);

		// User deletes above created both settings
		resp = usersettingmssql.DeleteUserSettingDeleteCall(settingName1, test, headers1);
		message = resp.getBody().jsonPath().get("message").toString();
		resuableComponents.assertEqualValue("Delete Settings 1 Message", message, "Delete successful", test);
		resp = usersettingmssql.DeleteUserSettingDeleteCall(settingName2, test, headers1);
		statusCode = resp.getStatusCode();
		message = resp.getBody().jsonPath().get("message").toString();
		resuableComponents.validateStatusCode(Integer.toString(statusCode), Integer.toString(200), test);
		Assert.assertEquals(Integer.toString(resp.getStatusCode()), Integer.toString(200));
		resuableComponents.assertEqualValue("Delete Settings 2 Message", message, "Delete successful", test);

		// User hits Get Settings to validate if created settings are deleted
		resp = usersettingmssql.getUserSettingsGETCall(test, headers1);
		statusCode = resp.getStatusCode();
		System.out.println(resp.asString());
		resuableComponents.assertEqualValue("Verify if created settings are deleted", resp.asString(), "[]", test);

	}

	@DataProvider(name = "usersettingscuj")
	public Object[][] UserSetting() {
		return new Object[][] { { "Payload/qa/usersettingcuj.json" } };
	}
}
